/***********************************************************************
        Copyright (c) 2002 RADVISION Ltd.
************************************************************************
NOTICE:
This document contains information that is confidential and proprietary
to RADVISION Ltd.. No part of this document may be reproduced in any
form whatsoever without written prior approval by RADVISION Ltd..

RADVISION Ltd. reserve the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
***********************************************************************/

#include "rvtypes.h"
#include "rvlock.h"
#include "rvmemory.h"
#include "rtputil.h"
#include "RtpProfileRfc3550.h"
#include "RtcpTypes.h" /* only for rtcpDemuxOpen */

#ifdef __H323_NAT_FW__
#include "RtpDemux.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if(RV_LOGMASK != RV_LOGLEVEL_NONE)   
static  RvLogSource*     localLogSource = NULL;
#define rvLogPtr        (localLogSource!=NULL?localLogSource:(localLogSource=rtpGetSource(RVRTP_RTP_MODULE)))
static  RvRtpLogger      rtpLogManager = NULL;
#define logMgr          (RvRtpGetLogManager(&rtpLogManager),((RvLogMgr*)rtpLogManager))
#else
#define logMgr          (NULL)
#define rvLogPtr        (NULL)
#endif
#include "rtpLogFuncs.h"

#define ALIGNMENT                 0x10

extern RvRtpInstance        rvRtpInstance;

/* local functions */


RVAPI
void   RVCALLCONV ConvertToNetwork(void *data, RvInt32 pos, RvInt32 n)
{
    RvInt32 i;
    for (i = pos; i < pos + n; ++i)
      ((RvUint32*)data)[i] = RvConvertHostToNetwork32(((RvUint32*)data)[i]);
}

RVAPI
void   RVCALLCONV ConvertFromNetwork(void *data, RvInt32 pos, RvInt32 n)
{
    RvInt32 i;
    for (i = pos; i < pos + n; ++i)
      ((RvUint32*)data)[i] = RvConvertNetworkToHost32(((RvUint32*)data)[i]);
}

RVAPI
void   RVCALLCONV ConvertToNetwork2(void *data, RvInt32 pos, RvInt32 n)
{
    RvInt32 i;
    for (i = pos; i < pos + n; ++i)
        ((RvUint16*)data)[i] = RvConvertHostToNetwork16(((RvUint16*)data)[i]);
}

RVAPI
void   RVCALLCONV ConvertFromNetwork2(void *data, RvInt32 pos, RvInt32 n)
{
    RvInt32 i;
    for (i = pos; i < pos + n; ++i)
        ((RvUint16*)data)[i] = RvConvertNetworkToHost16(((RvUint16*)data)[i]);
}

#undef FUNC_NAME
#define FUNC_NAME(name) "Rtp" #name

/*******************************************************************************
 * RtpSendPacket
 * scope: Private
 * description sends regular or multiplexed packet to the remote peer
 *
 * input:
 *    socketPtr      - pointer to socket
 *    buffer         - filled buffer
 *    p              - pointer to filled RvRtpParam structure
 *    natAddressPtr  - pointer to RtpNatAddress
 *    paddingSize    - size of padding
 * output: none
 * return value: Non-negative value on success
 *               Negative value on failure
 *******************************************************************************/
RVAPI
RvStatus  RVCALLCONV RtpSendPacket(
    IN RvSocket* socketPtr, 
    IN RvUint8* buffer,
    IN RvUint32 paddingSize,
    IN RvRtpParam* p,
    IN RtpNatAddress* natAddressPtr)
{
    RvStatus res = RV_ERROR_UNKNOWN;
	RvLogEnter(rvLogPtr, (rvLogPtr, "RtpSendPacket"));
    
#ifdef __H323_NAT_FW__
    {
        RvUint32* multiplexID  = (RvUint32*)buffer;
        RvUint8*  workBufferPtr = buffer;
        if (natAddressPtr->isMultiplexed)
        {                 
            *multiplexID = natAddressPtr->multiplexID;
            ConvertToNetwork(buffer, 0, 1);
            res = RvSocketSendBuffer(socketPtr, (RvUint8*)buffer+p->sByte, (RvSize_t)p->len + paddingSize, &natAddressPtr->address, logMgr, NULL);				
        }
        else
        {
            workBufferPtr += RvRtpNatMultiplexIdSize();
            res = RvSocketSendBuffer(socketPtr, (RvUint8*)workBufferPtr+p->sByte, (RvSize_t)p->len + paddingSize - RvRtpNatMultiplexIdSize(), &natAddressPtr->address, logMgr, NULL);				
        }
    }
#else
	res = RvSocketSendBuffer(socketPtr, (RvUint8*)buffer+p->sByte, (RvSize_t)p->len + paddingSize, &natAddressPtr->address, logMgr, NULL);				
#endif
	RvLogLeave(rvLogPtr, (rvLogPtr, "RtpSendPacket"));
    return res;
}

/************************************************************************************
 * RtpOpenFrom
 * description: Opens an RTP session in the memory that the application allocated.
 * input: demux       - demux object handle, if demultiplexing is supported, othrwise NULL
 *        pRtpAddress - contains The UDP port number to be used for the RTP session.
 *        ssrcPattern - Synchronization source Pattern value for the RTP session.
 *        ssrcMask    - Synchronization source Mask value for the RTP session.
 *        buffer      - Application allocated buffer with a value no less than the
 *                      value returned by the function RvRtpGetAllocationSize().
 *        bufferSize  - size of the buffer.
 * output: none.
 * return value: If no error occurs, the function returns the handle for the opened RTP
 *               session. Otherwise, it returns NULL.
 *Note:
 *	1) RtpOpenFrom opens an RTP session in the memory that the application!!! allocated.
 *     therefore RvRtpSessionShutdown should not be used.
 *  2) RtpOpenFrom opens one socket with the same port for receiving and for 
 *     sending (no demultiplexing).
 *  3) if demultiplexing is supported first session will be opened with demux=NULL
 *     for other demultiplexed sessions association of RTP session with shared socket
 *     will be in function RvRtpDemuxOpenSession
 ***********************************************************************************/
RVAPI
RvRtpSession RVCALLCONV RtpOpenFrom(
    IN  RvRtpDemux    demux,
    IN  RvNetAddress* pRtpAddress,
    IN  RvUint32      ssrcPattern,
    IN  RvUint32      ssrcMask,
    IN  void*         buffer,
    IN  RvInt32       bufferSize)
{
    RvRtpSessionInfo *s = (RvRtpSessionInfo *)buffer;
    RvRandom         randomValue;
    RvStatus         res = RV_OK;
    RvAddress        localAddress;
    RtpProfileRfc3550* rtpProfilePtr = NULL;
    RvInt32 addressType = RV_ADDRESS_TYPE_IPV4;
	RvUint32 port=0; 
    
	RvLogEnter(rvLogPtr, (rvLogPtr, "RtpOpenFrom"));

    if (bufferSize < RvRtpGetAllocationSize())
	{
        RTPLOG_ERROR_LEAVE(OpenFrom," no room to open session.");   
		return NULL;
	}
    memset(buffer, 0 , (RvSize_t)RvRtpGetAllocationSize());

	if ((pRtpAddress != NULL) && (RvNetGetAddressType(pRtpAddress) != RVNET_ADDRESS_NONE))
    {
		port = RvAddressGetIpPort((RvAddress*)pRtpAddress->address);
		
		if (RvNetGetAddressType(pRtpAddress) == RVNET_ADDRESS_IPV6)
		{
#if (RV_NET_TYPE & RV_NET_IPV6)
			RvAddressConstructIpv6(&localAddress, 
				RvAddressIpv6GetIp(RvAddressGetIpv6((RvAddress*)pRtpAddress->address)),
				port,
				RvAddressGetIpv6Scope((RvAddress*)pRtpAddress->address));
			
			addressType = RV_ADDRESS_TYPE_IPV6;;
#else	
			RTPLOG_ERROR_LEAVE(OpenFrom,"IPV6 is not supported in current configuration.");  
			return NULL;
#endif
		}
		else
		{
			RvUint32 ip = RvAddressIpv4GetIp(RvAddressGetIpv4((RvAddress*)pRtpAddress->address));
			RvAddressConstructIpv4(&localAddress, ip, (RvUint16)port);
		}
	}

    /* Get a random value for the beginning sequence number */
    RvRandomGeneratorGetValue(&rvRtpInstance.randomGenerator, &randomValue);
    RTPLOG_DEBUG((rvLogPtr, "RtpOpenFrom - generated random value %#x", randomValue));   
    /* Encryption callbacks, key and e. mode must be set after opening of session
	s->encryptionPlugInPtr = NULL;
	s->encryptionKeyPlugInPtr = NULL;   NULL callbacks automatically by memset*/
	s->isAllocated    = RV_FALSE;
    s->sSrcPattern    = ssrcPattern;
    s->sSrcMask       = ssrcMask;
    s->sequenceNumber = (RvUint16)randomValue;

	if (NULL == demux)
    {
		if (pRtpAddress != NULL)
		{
			if (RvSocketConstruct(addressType, RvSocketProtocolUdp, logMgr, &s->socket) == RV_OK)
			{
				res = initiateSocket(&s->socket, &localAddress);
				if (res != RV_OK)
				{
					RvLogInfo(rvLogPtr,(rvLogPtr,"RtpOpenFrom: socket=%d ERROR binding to port=%d", s->socket, port ));
					RvSocketDestruct(&s->socket, RV_FALSE, NULL, logMgr);
				}
				else 
					RvLogInfo(rvLogPtr,(rvLogPtr,"RtpOpenFrom: socket=%d bound to port=%d", s->socket, port));
				
			}

		}
    }
#ifdef __H323_NAT_FW__    
    else
    {
        RtpDemux* d = (RtpDemux*)demux;

        RvLockGet(&d->lock, logMgr);
        if ((pRtpAddress != NULL) && (d->rtpSessionsCounter <= 0))
        {
            if (RvSocketConstruct(addressType, RvSocketProtocolUdp, logMgr, &d->rtpSock) == RV_OK)
            {
				res = initiateSocket(&d->rtpSock, &localAddress);
                
                if (res != RV_OK)
                    RvSocketDestruct(&d->rtpSock, RV_FALSE, NULL, logMgr);
            }
        }
        s->socket = d->rtpSock;
        s->demux  = demux;
        RvLockRelease(&d->lock, logMgr);
    }
#endif
	if (pRtpAddress != NULL)
	RvLogDebug(rvLogPtr, (rvLogPtr, "RtpOpenFrom: socket related initializations completed, status = %d", res));
    if (res == RV_OK)
    {
        res = RvLockConstruct(logMgr, &s->lock); 
    }
    else
    {
        RTPLOG_ERROR_LEAVE(OpenFrom, "failed");
        return (RvRtpSession)NULL;
    }
    if (res == RV_OK)
    {
        RvRtpRegenSSRC((RvRtpSession)s);
	    RvRtpAddressListConstruct(&s->addressList);	
    }
    else
    {	
        RvLockDestruct(&s->lock, logMgr); 
        if (NULL == demux)
            RvSocketDestruct(&s->socket, RV_FALSE, NULL, logMgr);
        RTPLOG_ERROR_LEAVE(OpenFrom, "failed");
        return (RvRtpSession)NULL;
    }
	
    if (res == RV_OK)
    {
        rtpProfilePtr = (RtpProfileRfc3550*) (((RvUint8*)buffer) + RvRoundToSize(sizeof(RvRtpSessionInfo), RV_ALIGN_SIZE));
        RtpProfileRfc3550Construct(rtpProfilePtr);
        s->profilePlugin = RtpProfileRfc3550GetPlugIn(rtpProfilePtr);
        RTPLOG_INFO((rvLogPtr, "RTP session opened (handle = %#x, SSRC=%#x)", (RvUint32)s, s->sSrc));        
		RvLogLeave(rvLogPtr, (rvLogPtr, "RtpOpenFrom"));
        return (RvRtpSession)s;
    }
    else
    {
        RvLockDestruct(&s->lock, logMgr); 
        RvRtpAddressListDestruct(&s->addressList);	
        if (NULL == demux)
            RvSocketDestruct(&s->socket, RV_FALSE, NULL, logMgr);
        RTPLOG_ERROR_LEAVE(OpenFrom, "failed");
        return (RvRtpSession)NULL;
    }
}

/************************************************************************************
 * RtpOpenEx
 * description: Opens an RTP session and an associated RTCP session.
 * input: demux       - demux handle, if demultiplexing is supported, NULL - otherwise
 *        pRtpAddress - contains  the UDP port number to be used for the RTP session.
 *        ssrcPattern - Synchronization source Pattern value for the RTP session.
 *        ssrcMask    - Synchronization source Mask value for the RTP session.
 *        cname       - The unique name representing the source of the RTP data.
 * output: none.
 * return value: If no error occurs, the function returns the handle for the open
 *               RTP session. Otherwise, the function returns NULL.
 * Note:
 * 1. RtpOpenEx opens one socket for RTP session with the same port for receiving
 * and for sending, and one for RTCP session with the next port for receiving
 * and for sending (if cname is not NULL).
 * 2. If demultiplexing is supported first session will be opened with demux=NULL
 * for other demultiplexed sessions association of RTP session with shared socket
 * will be in function RvRtpDemuxOpenSession
 ***********************************************************************************/
RVAPI
RvRtpSession RVCALLCONV RtpOpenEx(
                                  IN  RvRtpDemux    demux,
								  IN  RvNetAddress* pRtpAddress,
								  IN  RvUint32      ssrcPattern,
								  IN  RvUint32      ssrcMask,
								  IN  char *        cname)
{
    /* allocate rtp session.*/
    RvRtpSessionInfo* s;
    RvStatus res;
        
	RvLogEnter(rvLogPtr, (rvLogPtr, "RtpOpenEx"));
	if (cname != NULL)
	{
		if (NULL == pRtpAddress || RvNetGetAddressType(pRtpAddress) == RVNET_ADDRESS_NONE)
		{
			RTPLOG_ERROR_LEAVE(OpenEx, "NULL pointer or wrong address type.");
			return NULL;
		}
	}
    res = RvMemoryAlloc(NULL, (RvSize_t)RvRtpGetAllocationSize(), logMgr, (void**)&s);
    if (res != RV_OK)
	{
        RTPLOG_ERROR_LEAVE(OpenEx, "cannot allocate RTP session.");
        return NULL;
	}
    if ((RvRtpSessionInfo *)RtpOpenFrom(demux, pRtpAddress, ssrcPattern, ssrcMask, (void*)s, RvRtpGetAllocationSize())==NULL)
    {
        RvMemoryFree(s, logMgr);

        RTPLOG_ERROR_LEAVE(OpenEx, "RtpOpenFrom() failed.");
        return NULL;
    }
    s->isAllocated = RV_TRUE;
    if (cname)
    {
        /* Open new RTCP session.The port for an RTCP session is always (RTP port + 1) */
        RvNetAddress rtcpAddress;
		
		RvLogDebug(rvLogPtr, (rvLogPtr, "RtpOpenEx: cname=%s - open RTCP session", cname));
		memcpy(&rtcpAddress, pRtpAddress, sizeof(RvNetAddress));
		if (RvNetGetAddressType(pRtpAddress)==RVNET_ADDRESS_IPV6)
		{
#if (RV_NET_TYPE & RV_NET_IPV6)
			RvNetIpv6 Ipv6;		
			RvNetGetIpv6(&Ipv6, pRtpAddress);
			Ipv6.port = (RvUint16)((Ipv6.port)?Ipv6.port+1:Ipv6.port);
			RvNetCreateIpv6(&rtcpAddress,&Ipv6);
#else
            RTPLOG_ERROR_LEAVE(OpenEx, "IPV6 is not supported in current configuration.");
			return NULL;
#endif
		}
        else	 
		{
			RvNetIpv4 Ipv4;	
			RvNetGetIpv4(&Ipv4, pRtpAddress);
			Ipv4.port = (RvUint16)((Ipv4.port)?Ipv4.port+1:Ipv4.port);
			RvNetCreateIpv4(&rtcpAddress,&Ipv4);
		}

        s->hRTCP = rtcpDemuxOpen(demux, s->sSrc, &rtcpAddress, cname);
        if (s->hRTCP == NULL)
        {
            /* Bad RTCP - let's just kill the RTP and be done with it */
            RvRtpClose((RvRtpSession)s);
            s = NULL;
            RTPLOG_ERROR_LEAVE(OpenEx,"rtcpDemuxOpen failed.");
			return NULL;
        }
		else
		{
			RvLogDebug(rvLogPtr, (rvLogPtr, "RtpOpenEx: RTCP session opened - 0x%x ", s->hRTCP));
            rtcpSetRtpSession(s->hRTCP, (RvRtpSession)s);
			RvRtcpSetEncryptionNone(s->hRTCP);
			RvRtcpSessionSetEncryptionMode(s->hRTCP, RV_RTPENCRYPTIONMODE_RFC1889);
            RvRtcpSetProfilePlugin(s->hRTCP, s->profilePlugin);
		}
    }
	RvLogLeave(rvLogPtr, (rvLogPtr, "RtpOpenEx"));
    return (RvRtpSession)s;
}

/************************************************************************************
 * RtpSetRemoveEventHandler
 * description: sets or removes RTP event handler.
 * input: sock         - pointer to socket
 *        selectEngine - pointer to pointer on selectEngine.
 *        selectFd     - pointer to file descriptor.
 *        hasFd        - true, if event handler already has been set.
 *        addFd        - true, if event handler have to be set .
 *        selectCB     - callback function for Read events
 * output: none.
 ***********************************************************************************/
void RtpSetRemoveEventHandler(
        IN RvSocket*              sock,
        IN RvSelectEngine**       selectEngine,
        IN RvSelectFd*            selectFd,
        IN RvBool                 hasFd,
        IN RvBool                 addFd,
        IN RvSelectCb             selectCB)
{   

    
	RvLogEnter(rvLogPtr, (rvLogPtr, "RtpSetRemoveEventHandler"));
    if (addFd && (!hasFd))
    {
         /* Seems like we have to add it to our list of fds */
        RvStatus status;
        /* error result is not irregular behaviour, that is why NULL used for
        eluminating unneeded error printings */
        status = RvSelectGetThreadEngine(/*logMgr*/NULL, selectEngine);
        if ((status != RV_OK) || (*selectEngine == NULL))
            *selectEngine = rvRtpInstance.selectEngine;
        
        RvSocketSetBlocking(sock, RV_FALSE, logMgr);
        RvFdConstruct(selectFd, sock, logMgr);
        RvSelectAdd(*selectEngine, selectFd, RvSelectRead, selectCB);
    }
    
    if (!addFd && hasFd)
    {   
        /* Seems like we have to remove it from our list of fds */
        RvSelectRemove(*selectEngine, selectFd);
        RvFdDestruct(selectFd);
        RvSocketSetBlocking(sock, RV_TRUE, logMgr);
    }
	RvLogLeave(rvLogPtr, (rvLogPtr, "RtpSetRemoveEventHandler"));
}

/************************************************************************************
 * RtpAddRemoteAddress
 * description: Adds the new RTP address of the remote peer or the address of a multicast
 *              group or of multiunicast address list to which the RTP stream will be sent.
 *              Adds multiplexID, if specified
 * input: hRTP  - Handle of the RTP session.
 *        pRtpAddress contains
 *            ip    - IP address to which RTP packets should be sent.
 *            port  - UDP port to which RTP packets should be sent.
 * output: none.
 * return value: none.
 ***********************************************************************************/
RVAPI
void RVCALLCONV RtpAddRemoteAddress(
	IN RvRtpSession  hRTP,   /* RTP Session Opaque Handle */
	IN RvNetAddress* pRtpAddress,
    IN RvUint32*     pMultiplexID)
									  
{
    RvRtpSessionInfo* s = (RvRtpSessionInfo *)hRTP;
    RvAddress* pRvAddress =  NULL;

	RvLogEnter(rvLogPtr, (rvLogPtr, "RtpAddRemoteAddress"));

    if (s != NULL && pRtpAddress!=NULL && RvNetGetAddressType(pRtpAddress)!= RVNET_ADDRESS_NONE)
    {
        RvChar addressStr[64];
        RV_UNUSED_ARG(addressStr); /* in case of RV_LOGLEVEL_NONE warning fix */
		
		RvLockGet(&s->lock, logMgr);
        pRvAddress = (RvAddress*) pRtpAddress->address;
        

        if (
/**h.e
			s->profilePlugin != NULL && 
            s->profilePlugin->funcs != NULL &&
**/
            s->profilePlugin->funcs->addRemAddress != NULL)
        {
            s->profilePlugin->funcs->addRemAddress(s->profilePlugin, hRTP, RV_TRUE, pRtpAddress);
        }

		RvRtpAddressListAddAddress(&s->addressList, pRvAddress, pMultiplexID);
        s->remoteAddressSet = RV_TRUE;

        RTPLOG_INFO((rvLogPtr,"Added remote address %s port =%d to the RTP session %#x", 
            RvAddressGetString(pRvAddress, sizeof(addressStr), addressStr),
            RvAddressGetIpPort(pRvAddress), (RvUint32)hRTP));
		RvLockRelease(&s->lock, logMgr);
    } 
	else 
        RvLogError(rvLogPtr, (rvLogPtr, "RtpAddRemoteAddress: NULL pointer or wrong address type"));      
	
	RvLogLeave(rvLogPtr, (rvLogPtr, "RtpAddRemoteAddress"));
}

/************************************************************************************
 * RtpRemoveRemoteAddress
 * description: removes the specified RTP address of the remote peer or the address 
 *              of a multicast group or of multiunicast address list to which the 
 *              RTP stream was sent.
 *              Removes RTP remote address with multiplexID, if pMultiplexID is specified
 * input: hRTP  - Handle of the RTP session.
 *        pRtpAddress contains
 *            ip    - IP address to which RTP packets should be sent.
 *            port  - UDP port to which RTP packets should be sent.
 *        pMultiplexID - pointer to multiplexID of the remote RTP
 * output: none.
 * return value:If an error occurs, the function returns a negative value.
 *              If no error occurs, the function returns a non-negative value.
 ***********************************************************************************/
RVAPI
RvStatus RVCALLCONV RtpRemoveRemoteAddress(
	IN RvRtpSession  hRTP,
	IN RvNetAddress* pRtpAddress,
    IN RvUint32*     pMultiplexID)
{
    RvRtpSessionInfo* s = (RvRtpSessionInfo *)hRTP;		
    RvAddress* pRvAddress =  NULL;
    RvChar addressStr[64];
	RvStatus res;
  
    RV_UNUSED_ARG(addressStr); /* in case of RV_LOGLEVEL_NONE warning fix */    

	RvLogEnter(rvLogPtr, (rvLogPtr, "RtpRemoveRemoteAddress"));

    if ((s == NULL) || (pRtpAddress == NULL) || (RvNetGetAddressType(pRtpAddress)== RVNET_ADDRESS_NONE))
    {
        RvLogError(rvLogPtr, (rvLogPtr, "RtpRemoveRemoteAddress: NULL pointer or wrong address type"));      
        res = RV_ERROR_UNKNOWN;
    }
	else
	{
		RvLockGet(&s->lock, logMgr);
		pRvAddress = (RvAddress*) pRtpAddress->address;
		RvRtpAddressListRemoveAddress(&s->addressList, pRvAddress, pMultiplexID);

		if (s->profilePlugin->funcs->removeRemAddress != NULL)
		{
			s->profilePlugin->funcs->removeRemAddress(s->profilePlugin, hRTP, pRtpAddress);
		}

		RvLogLeave(rvLogPtr, (rvLogPtr,"Removed remote address %s port =%d from the RTP session %#x", 
			RvAddressGetString(pRvAddress, sizeof(addressStr), addressStr),
			RvAddressGetIpPort(pRvAddress), (RvUint32)hRTP));    

		pRvAddress = RvRtpAddressListGetNext(&s->addressList, NULL);
		if (NULL == pRvAddress)
			s->remoteAddressSet = RV_FALSE;
		RvLockRelease(&s->lock, logMgr);    

		res = RV_OK;
	}

	RvLogLeave(rvLogPtr, (rvLogPtr, "RtpRemoveRemoteAddress"));
    return res;
}

RvStatus initiateSocket(
	IN RvSocket		*socket,  
	IN RvAddress	*address)
{
	RvStatus res;

	RvSocketSetBuffers(socket, 8192, 8192, logMgr);
	res = RvSocketSetBroadcast(socket, RV_TRUE, logMgr);
	if (res == RV_OK)
	res = RvSocketSetBlocking(socket, RV_TRUE, logMgr);
	if (res == RV_OK)
	res = RvSocketBind(socket, address, NULL, logMgr);

	return res;
}

#ifdef __cplusplus
}
#endif










