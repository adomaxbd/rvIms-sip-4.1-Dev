#if (0)
******************************************************************************
Filename   :
Description:
******************************************************************************
                Copyright (c) 1999 RADVision Inc.
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVision LTD..

RADVision LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************
$Revision:$
$Date:$
$Author: S. Cipolli$
******************************************************************************
#endif

#ifndef RV_EPPCLIENT_H
#define RV_EPPCLIENT_H

#include "rvtypes.h"
#include "rvthread.h"
#include "rvsocket.h"
#include "ippmisc.h"
#include "rvlist.h"

#ifdef __cplusplus
extern "C" {
#endif


/* Maximum number of registered terminations we allow to a single MTF instance */
#define EPP_MAX_ENDPOINTS   8
    
#define EP_PROFILE_ANALOG	0
#define EP_PROFILE_IPPHONE	1
/* Client */
struct RvEppClient_;

		
typedef struct
{
    RvSocket                s;/*Only UDP configuration*/
    RvAddress               address;/*Only UDP configuration*/
    RvChar                  name[32];
    void*                   data;
    int                     profile;
    struct RvEppClient_*    ec; /*parent*/ 
} RvEppClientEndpoint;

#define rvEppClientEndpointGetName(ece)         ((ece->name))
#define rvEppClientEndpointGetProfile(ece)		((ece)->profile)
#define rvEppClientEndpointGetUserData(ece)		((ece)->data)
#define rvEppClientEndpointSetUserData(ece, d)	((ece)->data = (d))

typedef RvBool (*RvEppClientRegister)( RvEppClientEndpoint* ece, void *data);/*return rvTrue if register procedure succeeded*/

typedef void (*RvEppClientEvent)(struct RvEppClient_* ec, RvEppClientEndpoint* ece, const char* eventName, char* eventParams, void *data);

typedef void (*RvEppClientUnregister)(struct RvEppClient_* ec, RvEppClientEndpoint* ece, void *data, char* eventParams);


/* The EPP instance */
typedef struct RvEppClient_
{
    RvBool			        bConfigTCP;/* rvTrue - communication with GUI via TCP*/
    RvThread                thread; /* Thread handling EPP socket */
    RvBool                  done; /* RV_TRUE when destructing the client */
    RvSize_t                numEndpoints; /* Current number of endpoints */
    RvEppClientEndpoint     endpoints[EPP_MAX_ENDPOINTS]; /* Connected clients */
    RvAddress               localAddr; /* Local listening address for requests */
    RvEppClientRegister     eRegister; /* New connection callback */
    RvEppClientEvent        eEvent; /* Event on connection callback */
    RvEppClientUnregister   eUnregister; /* Disconnection callback */
    void*                   data; /* User data used for callbacks */
    RvSocket                sListening; /* Listening TCP socket  */
    RvSocket                sEv; /* socket (TCP or UDP) connected to GUI. Used to rcv events in user thread*/
    RvSocket                s; /* Only TCP configuration. TCP socket connected to GUI. Used to send signal and rcv reply in sip stack thread*/
    RvMutex                 sendGuard;
} RvEppClient;


/******************************************************************************
 * rvEppClientConstruct
 * ----------------------------------------------------------------------------
 * General:
 *  Create an EPP client. EPP is used as means to connect between the MTF and
 *  the GUI application. We use two separate processes mainly to enable easy
 *  testing on embedded operating systems without nice GUI.
 *
 *  For some unknown reason, the EPP uses UDP as its protocol of choice, able
 *  to send and receive messages on it.
 *
 * Arguments:
 * Input:  ec           - The EPP client to construct
 *         eppIp        - The IP address in a string format, and without a port
 *         port         - Port number to use.
 *         eRegister    - Callback function to call when a new address tries to
 *                        register itself with the EPP.
 *         eEvent       - Callback function to call for incoming events.
 *         eUnregister  - Callback function to call when someone tries to
 *                        unregister itself from the EPP.
 *         userData     - User data to use for the callback functions.
 * Output: None.
 *
 * Return Value: RV_OK on success, other on failure.
 *****************************************************************************/
RvStatus rvEppClientConstruct(
    IN RvEppClient*             ec,
    IN RvBool                   bConfigTCP,
    IN const RvChar*            eppIp,
    IN RvUint16                 port,
    IN RvEppClientRegister      eRegister,
    IN RvEppClientEvent         eEvent,
    IN RvEppClientUnregister    eUnregister,
    IN void*                    userData);
void rvEppClientDestruct(RvEppClient* ec);
RvBool rvEppClientStart( RvEppClientEndpoint* ece, const char* signal);
RvBool rvEppClientStop( RvEppClientEndpoint* ece, const char* signal);

void rvEppClientEndpointSend(RvEppClientEndpoint* ece,
							 IN char* msgSend,
							 IN RvSize_t sizeSend,
							 IN RvSize_t msgRcvdMaxSize,
							 OUT char* msgRcvd);
							 
#ifdef __cplusplus
}
#endif

#endif
