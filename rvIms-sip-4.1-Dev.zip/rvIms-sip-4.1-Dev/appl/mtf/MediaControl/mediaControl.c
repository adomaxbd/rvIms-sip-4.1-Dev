/******************************************************************************
Filename:    IppMediaControlRemote.c
Description: Common module of Sample Gateway
*******************************************************************************
                Copyright (c) 2005 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

/*=====================================================*/
#if defined(__cplusplus)
extern "C" {
#endif
/*=====================================================*/
#define LOGSRC	LOGSRC_USERAPP

#include "rvsocket.h"
#include "rvsdpenc.h"
#include "ippcodec.h"
#include "MfControl.h"
#include "mediaControl.h"

RvLogSource         g_logSrc;
RvLogMgr			g_logMgr;

RvLogMgr*       mcLogMgr(){ return &g_logMgr;}
RvLogSource*    mcLogSrc(){ return &g_logSrc;}
/***************************************************************************************
      !!!!!!!!!!!!!!!!!!!!!!!!!!!    NOTE   !!!!!!!!!!!!!!!!!!!!!

	The Media Control project plays a role in the MTF NO MEDIA configurations and in the
	GUI MEDIA configurations. It supports configurations where the media is supported
	by the GUI and not by the MTF.
****************************************************************************************/




/***************************************************************************************
 *	Implements IppMediaControl interface as stub <---> proxy.
 *	----------------------------------------------------------
 *	This library may be compiled with IPP_MEDIA_CONTROL_REMOTE flag w/o it.
 *	proxy side should use IPP_MEDIA_CONTROL_REMOTE -compiled lib
 *	stub side should use lib compiled w/o IPP_MEDIA_CONTROL_REMOTE flag
 *
 **************************************************************************************/

/***************************************************************************************
*				L O C A L    I M P L E M E N T A T I O N
*
**************************************************************************************/
typedef	struct
{
	/* send/recv mechanism*/
	RvEppClient*				ec;
	RvAddress					addrRemote;
	RvSocket					s;
}RvIppMediaControlOb;

static RvIppMediaControlOb  g_obInstance;
static RvIppMediaControlOb*	g_ob = NULL;
/***************************************************************************************/
static RvEppClientEndpoint* getEppClientEndpoint( void* context)
{
//MARKA    if (g_ob->ec->numEndpoints > 0)
//        return &g_ob->ec->endpoints[0];

    if(context)
    {
        return (RvEppClientEndpoint*)context;
    }
    else
        return NULL;

}
/***************************************************************************************/
RvStatus sendBuf( void* context, RvUint8* buf, RvUint32 size)
{
	RvEppClientEndpoint* ece = getEppClientEndpoint( context);
	if( ece)
	{
		rvEppClientEndpointSend( ece, (char*)buf, size,MAX_MC_BUF, (char*)buf);
		return RV_OK;
	}
	return RV_ERROR_UNKNOWN;
}

/***************************************************************************************
 * RvMtfMediaControlCreate
 * -------------------------------------------------------------------------------------
 * General:   allocates and constructs RvIppMediaControl object
 *
 * Return Value: object handle or NULL if failed
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *
 * Output:   None
 **************************************************************************************/
 void RvMediaControlCreate( IN RvEppClient*	ec)
{
     g_ob = &g_obInstance;
     memset( g_ob,0, sizeof(RvIppMediaControlOb));

     g_ob->ec = ec;

    /*
	 *	initialize send/receive mechanism
	 */
	{
		RvAddress		localAddr;
	
	/**/
		/*
		 *	initialize send/recv mechanism. used in dynamicModifyRtp implementation
		 */
		/* IPV6 needed*/
		if (RV_OK != RvSocketConstruct( RV_ADDRESS_TYPE_IPV4, RvSocketProtocolUdp, NULL, &g_ob->s))
		{
			 IppLogMessage(RV_TRUE, "RvIppMediaControlCreate() failed in RvSocketConstruct()");
		}

		if( RV_OK != RvSocketSetBlocking(&g_ob->s, rvTrue, NULL))
		{
			 IppLogMessage(RV_TRUE, "rvRtpLinkConstruct::set socket to blocking fail ");
		}

		/*
		 *	get local address string from epp client
		 */
		RvAddressConstructCopy( &ec->localAddr, &localAddr);
		RvAddressSetIpPort(  &localAddr, RV_ADDRESS_IPV4_ANYPORT);
		if(RV_OK != RvSocketBind(&g_ob->s, &localAddr, 0, NULL))
		{
			 IppLogMessage(RV_TRUE, "rvRtpLinkConstruct::bind failed");
			return /* NULL*/;
		}

		/*
		 *	initialize g_ob->addrRemote as empty
		 */
		RvAddressConstruct( RV_ADDRESS_TYPE_IPV4, &g_ob->addrRemote);
	}
}

/***************************************************************************************
 * RvMtfMediaControlDelete
 * -------------------------------------------------------------------------------------
 * General:   destructs and deallocates RvIppMediaControl object
 *
 * Return Value: None
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 RvIppMediaControlHandle	- object handle
 *
 * Output:   None
 *************************************************************************************/
void RvMtfMediaControlDelete( /*RvIppMediaControlHandle hnd */)
{
	RvSocketDestruct( &g_ob->s, rvFalse, RV_ADDRESS_IPV4_ANYPORT, NULL);

    RvAddressDestruct( &g_ob->addrRemote);
	g_ob = NULL;
}

/***************************************************************************************
*				H E L P E R    F U N C T I O N S   I M P L E M E N T A T I O N
*
**************************************************************************************/

/***************************************************************************************/
RvUint32 serializeHeader_to( INOUT RvUint8* buf, IN FuncEnum en)
{
	RvUint32 offset;
	offset = serializeStr_to( buf, HEADER_MAGIC(RV_MFCTRL_VER));
	offset += serializeUint32_to( &buf[offset], (RvUint32)en);
	return offset;
}
/***************************************************************************************/
RvUint32 serializeHeader_from( IN RvUint8* buf, OUT FuncEnum* en)
{
	RvUint32 offset;
	RvUint32 enNum;
	char	sz[20];
	offset = serializeStr_from( buf, sz);
	if(!strcmp( sz, HEADER_MAGIC(RV_MFCTRL_VER)))
	{
		offset += serializeUint32_from( &buf[offset], &enNum);
		*en = (FuncEnum)enNum;
	}
	return offset;
}
/***************************************************************************************/
RvUint32 serializeUint32_to( INOUT RvUint8* buf, IN RvUint32 n)
{
	char	sz[100];
	return serializeStr_to( buf, IppSdpUtil_itoa( n, sz));
}
/***************************************************************************************/
RvUint32 serializeUint32_from( IN RvUint8* buf, OUT RvUint32* n)
{
	char	sz[100];
	RvUint32 offset;

	offset = serializeStr_from( buf, sz);
	*n = atoi( sz);
	return offset;
}
/***************************************************************************************/
RvUint32 serializePtr_to( INOUT RvUint8* buf, IN void* p)
{
    //it's good for 32-bit platform only
    return  serializeUint32_to( buf, (RvUint32)p);
}
/***************************************************************************************/
RvUint32 serializePtr_from( IN RvUint8* buf, OUT void** p)
{
    //it's good for 32-bit platform only
    RvUint32 n, offset;
    offset = serializeUint32_from( buf, &n);
    *p = (void*)n;
    return offset;
}
/***************************************************************************************/
RvUint32 serializeStr_to( INOUT RvUint8* buf, IN const char* sz)
{
	RvUint32 offset = strlen (sz);

	memcpy( buf, sz, offset);
	buf[ offset] = '\0';
	offset++;
	return offset;
}
/***************************************************************************************/
RvUint32 serializeStr_from( IN RvUint8* buf, INOUT const char* sz)
{
	strcpy( (char*)sz, (const char*)buf);
	return (RvUint32)(strlen (sz) +1);
}






/*=====================================================*/
#if defined(__cplusplus)
}
#endif
/*=====================================================*/

