/******************************************************************************
Filename:    IppSampleRtpLink.h
Description: rtp termination handling
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

#ifndef RV_RTPLINK_H
#define RV_RTPLINK_H

#include "rvmdm.h"
#include "rvsocket.h"
#include "rvselect.h"
#ifdef RV_MTF_STUN
#include "rvSipStunApi.h"
#endif/* RV_MTF_STUN*/

#if defined(__cplusplus)
extern "C" {
#endif


#define MAX_NUM_RTP_PROFILES		30

typedef enum RvIppCodingId_
{
	IPP_CODING_G711_MU		= 0x00,				/* 8 bit A-law PCM					*/
	IPP_CODING_G711_A		= 0x08,				/* 8 bit mu-law PCM					*/
	IPP_CODING_G711			= IPP_CODING_G711_MU, /* 8 bit A-law PCM				*/

	IPP_CODING_G723_5_3K	= 0x04,				/* G.723 at 5.3 kbits/second		*/
	IPP_CODING_G723_6_3K	= IPP_CODING_G723_5_3K,	/* G.723 at 6.3 kbits/second		*/

	IPP_CODING_G726_16K		= 0x62,				/* 2 bits/sample ADPCM (G.726)		*/
	IPP_CODING_G726_24K		= IPP_CODING_G726_16K,				/* 3 bits/sample ADPCM (G.726)		*/
	IPP_CODING_G726_32K		= IPP_CODING_G726_16K,				/* 4 bits/sample ADPCM (G.726)		*/
	IPP_CODING_G726_40K		= IPP_CODING_G726_16K,				/* 5 bits/sample ADPCM (G.726)		*/

	IPP_CODING_G727_16K		= 0x63,				/* (2,2) embedded ADPCM (G.727)		*/
	IPP_CODING_G727_24K		= IPP_CODING_G727_16K,				/* (3,2) embedded ADPCM (G.727)		*/
	IPP_CODING_EADPCM_24K	= IPP_CODING_G727_16K,
	IPP_CODING_G727_32K		= IPP_CODING_G727_16K,				/* (4,2) embedded ADPCM (G.727)		*/
	IPP_CODING_EADPCM_32K	= IPP_CODING_G727_16K,
	IPP_CODING_G727_40K		= IPP_CODING_G727_16K,				/* (5,2) embedded ADPCM (G.727)		*/
	IPP_CODING_EADPCM_40K	= IPP_CODING_G727_16K,

	IPP_CODING_G728_16K		= 0x0F,				/* LD-CELP 16K (G.728)				*/
	IPP_CODING_LDCELP_16K	= IPP_CODING_G728_16K,

	IPP_CODING_G729			= 0x12,				/* CS-ACELP 8K (G.729)				*/
	IPP_CODING_G729A		= IPP_CODING_G729,				/* CS-ACELP 8K (G.729A)				*/
	IPP_CODING_G729B		= IPP_CODING_G729,	/* CS-ACELP 8K internal VAD (G.729B)*/
	IPP_CODING_G729AB		= IPP_CODING_G729,	/* CS-ACELP internal VAD (G.729AB)	*/
	IPP_CODING_G729E		= IPP_CODING_G729,				/* CS-ACELP 8K (G.729E)				*/
	IPP_CODING_GSM_EFR		= IPP_CODING_G729,				/* GSM_EFR codec					*/
	IPP_CODING_GSM_FR		= IPP_CODING_G729,				/* GSM_FR codec						*/


	/* Wide-band definitions */
	IPP_CODING_G722_64K		= 0x09,				/* G.722 at 64 kbits/second			*/
	IPP_CODING_G722_56K		= IPP_CODING_G722_64K,				/* G.722 at 56 kbits/second			*/
	IPP_CODING_G722_48K		= IPP_CODING_G722_64K,				/* G.722 at 48 kbits/second			*/

	IPP_CODING_FAX			= 0x64,				/* FAX								*/
	IPP_CODING_T38_FAX		= IPP_CODING_FAX,				/* T38 FAX							*/
	IPP_FAKE_CODING_T38_RTP_FAX = IPP_CODING_FAX,         /* T38 FAX with forced RTP encapsulation   */
	IPP_FAKE_CODING_T38_UDP_FAX = IPP_CODING_FAX,         /* T38 FAX with forced UDP encapsulation   */
	IPP_CODING_CLEAR_CHAN	= IPP_CODING_FAX,				/* Clear Channel - Transparent data */

	IPP_FAKE_CODING_RTP_DTMF_RELAY = 0xa0,      /* 'fake' coding so that we retrieve
												    rtp payload type for rtp dtmf relay */

    IPP_CODING_MODEM_V90    = 0x65,             /* V.90 & V.34 modem termination */
    IPP_CODING_MODEM_V32    = IPP_CODING_MODEM_V90,             /* V32 down to V.21 modem termination */
	IPP_CODING_MODEM_RELAY	= IPP_CODING_MODEM_V90,				/* V.21 & V.22 MODEM RELAY */
    IPP_CODING_MODEM_KFLEX  = IPP_CODING_MODEM_V90,             /* K56flex modem termination */
    IPP_CODING_FAX_TERM     = IPP_CODING_MODEM_V90,             /* fax termination */
    IPP_CODING_DATA_TERM    = IPP_CODING_MODEM_V90,             /* data termination */
    IPP_CODING_SIG_ONLY     = IPP_CODING_MODEM_V90,             /* signaling only */
    IPP_CODING_MODEM_V92    = IPP_CODING_MODEM_V90,             /* V.92 modem termination */

	IPP_CODING_MODEM_HI		= IPP_CODING_MODEM_V90,
	IPP_CODING_MODEM_LOW	= IPP_CODING_MODEM_V90,

	/* The following def. are added for AAL2 and RTP profiles */
	IPP_CODING_GEN_SID		= 0xE0,

	IPP_CODING_INVALID      = 0xff

} RvIppCodingId;

typedef enum
{
    RV_IPP_DTMF_RELAY_OFF = 0,     /* DTMF tones passed as voice */
    RV_IPP_DTMF_RELAY_INBAND = 1,  /* DTMF tones passed as RFC2833 packets */
    RV_IPP_DTMF_RELAY_OOB = 2      /* DTMF tones sent as out-of-band protocol
                                   specific packets */

} RvRtpDtmfRelay;

#if 0
typedef struct
{
	SendMethod		sendMethod;/*contains bound address and method allowing 
								to send raw buffer from bound address; used by stun client*/
} RvRtpLink;
RvRtpLink *rvRtpLinkConstruct(IN RvRtpLink *x);
void rvRtpLinkDestruct(RvRtpLink *x);
void rvRtpLinkConnect(RvRtpLink *a, RvRtpLink *b, RvMdmStreamDirection direction);
void rvRtpLinkDisconnect(RvRtpLink *a, RvRtpLink *b);
/*===============================================================================*/
/*===================  R T P		L I N K		L I S T =========================*/
/*===============================================================================*/
typedef struct {
	RvRtpLink audio;
	RvRtpLink video;
} RvRtpLinkList;

RvRtpLink* RvRtpLinkListGetAudio(RvRtpLinkList* list);
RvRtpLink* RvRtpLinkListGetVideo(RvRtpLinkList* list);
#endif


void rvRtpLinkInitClass(RvMdmTermMgr* termMgr, RvMdmTermClass** rtpClass);

void rvRtpLinkSetPacketTime(RvSdpMediaDescr *media, OUT char* ptime);
/* function to build sdp from the user side */
RvStatus RvRtpLinkSendModifyMedia( IN const char* rtpId, IN RvSdpMsg* sdpMsg);

RvStatus rvRtpLinkSendRawMsg ( RvSocket *x,
						  const char* addrString,
						  RvUint16 addrPort,
						  IN RvUint8* buf,
						  IN RvSize_t size);



#if defined(__cplusplus)
}
#endif

#endif
