/******************************************************************************
Filename:    MtfMediaCallbackHelper.c
Description: TODO...
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#include "ipp_inc_std.h"
#include "ippmisc.h"
#include "IppSampleGatewayBase.h"
#include "MtfMediaCallbacks.h"
#include "MtfMediaCallbacksHelper.h"

#ifndef RV_MTF_MEDIA
#include "mediaControlHelperLocal.h"
#endif

/*==============    GLOBALS  ==========*/
extern RvMtfMediaConstructParam  g_param;
/*====================================================*/
/*====================================================*/
#define AUD_MIX_0   "AUD_MIX_0"
#define VID_MIX_0   "VID_MIX_0"
#define SESS_ID_SHIFT_AUDIO 0
#define SESS_ID_SHIFT_VIDEO 13
/*====================================================*/
/*
 *	declaration of used functions
 */
static RvStatus _createRtpIn( IN void* context, IN RvUint32 sessId, IN const char* rtpId, INOUT RvSdpMediaDescr *descr);
static RvStatus _createRtpOut( IN void* context, IN RvUint32 sessId, IN const char* rtpId, IN RvSdpMediaDescr *descr);
static RvStatus _destroyLink( IN void* context, const char* szId);
static RvStatus _disconnectLinkFromOperator( IN void* context, HLinkDB hLink, ContainerDir dir);
static RvStatus _connectLinks( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo);
static RvStatus _holdLocal( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo);
static RvStatus _unholdLocal( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo);
static RvStatus _unholdInactive2HoldRemote( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo);
static RvStatus _unholdInactive2HoldLocal( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo);
static RvStatus _holdRemote( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo);
static RvStatus _unholdRemote( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo);

static RvStatus _connectLinkToAudMixer0( IN void* context, HLinkDB hLink, ContainerDir dir);
static RvStatus _connectLinkToVidMixer0( IN void* context, HLinkDB hLink, ContainerDir dir);


/*====================================================*/
/*
 *	map registered device name - termId - to media_type
 */
static RvSdpMediaType mapDevIdToMediaType( RvIppMediaDevice devId)
{
    switch(devId)
    {
    case RVIPP_MEDIA_DEV_MIC:
    case RVIPP_MEDIA_DEV_SPEAKER:
        return RV_SDPMEDIATYPE_AUDIO;

    case RVIPP_MEDIA_DEV_CAMERA:
    case RVIPP_MEDIA_DEV_DISPLAY_WINDOW:
        return RV_SDPMEDIATYPE_VIDEO;

    case RVIPP_MEDIA_DEV_MIN:
    case RVIPP_MEDIA_DEV_MAX:
    default:
        return RV_SDPMEDIATYPE_UNKNOWN;
    }
}
/*====================================================*/


/*
 *	make RtpId name according media_type
 */
static const char* makeRtpId(
                             char* buf,
                             RvSize_t bufSize,
                             const char* termId,
                             RvSdpMediaType media_type,
                             RvBool bIn)
{
	static const char szA[7] = " audio";
	static const char szV[7] = " video";

	switch(media_type)
	{
	case RV_SDPMEDIATYPE_AUDIO:
		strncpy( buf, termId, bufSize - sizeof(szA));
		strcat( buf, szA);
		break;
	case RV_SDPMEDIATYPE_VIDEO:
		strncpy( buf, termId, bufSize - sizeof(szV));
		strcat( buf, szV);
		break;
	default:
		IppLogMessage(rvTrue,"makeRtpId():  incorrect media type");
		strcpy( buf, "");
    /*lint -e{788}  all relevant cases are accounted for */
	}
    strcat(buf, (bIn)? "In":"Out");
	return buf;
}
/*====================================================*/

/*====================================================*/
static void insertConnectionFromSdpDescrToMsg( IN RvSdpMediaDescr *descr, INOUT RvSdpMsg *msg )
{
	RvSdpConnection* connDescr	= rvSdpMediaDescrGetConnection(descr);
	RvSdpConnection* connMsg	= rvSdpMsgGetConnection( msg);/* get connection of 0-index*/
    RvChar           addrTxt[256];

	IppLogMessage(rvFalse,"<-- insertConnectionFromSdpDescrToMsg:: (msg%p, descr:%p)",msg, descr);
	IppLogMessage(rvFalse,"insertConnectionFromSdpDescrToMsg:: connDescr:%p, connMsg:%p",connDescr,connMsg);
	if( connDescr != NULL)
	{
		RvSdpNetType	netType = rvSdpConnectionGetNetType(connDescr);
		RvSdpAddrType	addType = rvSdpConnectionGetAddrType(connDescr);
		const char*		address = rvSdpConnectionGetAddress(connDescr);

		IppLogMessage(rvFalse,"insertConnectionFromSdpDescrToMsg::rvSdpMsgSetConnection(descr:%p, netType:%d, addType:%d, address:%s) ",descr, netType, addType, address);

        //change connection parameters
    	if( connMsg != NULL)
        {
		    rvSdpMsgRemoveConnection( msg, 0);/* remove connection of 0-index*/
        }

        if (address)
            strcpy(addrTxt,address);
        else
            addrTxt[0] = 0;
		rvSdpMsgSetConnection(	msg, netType, addType, addrTxt);
	}

	IppLogMessage(rvFalse,"--> insertConnectionFromSdpDescrToMsg");
}
/*====================================================*/
static void insertConnectionFromMsgToSdpDescr( INOUT RvSdpMsg *msg, INOUT RvSdpMediaDescr *descr )
{
	RvSdpConnection* connDescr	= rvSdpMediaDescrGetConnection(descr);
	RvSdpConnection* connMsg	= rvSdpMsgGetConnection( msg);/* get connection of 0-index*/

	IppLogMessage(rvFalse,"<-- insertConnectionFromMsgToSdpDescr:: (msg%p, descr:%p)",msg, descr);
	IppLogMessage(rvFalse,"insertConnectionFromMsgToSdpDescr:: connDescr:%p, connMsg:%p",connDescr,connMsg);
	if( connMsg && !connDescr)
	{
		RvSdpNetType	netType = rvSdpConnectionGetNetType(connMsg);
		RvSdpAddrType	addType = rvSdpConnectionGetAddrType(connMsg);
		const char*		address = rvSdpConnectionGetAddress(connMsg);
        RvChar          addrTxt[256];

        if (address)
            strcpy(addrTxt,address);
        else
            addrTxt[0] = 0;


		IppLogMessage(rvFalse,"insertConnectionFromMsgToSdpDescr::rvSdpMsgSetConnection(descr:%p, netType:%d, addType:%d, address:%s) ",descr, netType, addType, address);

        //change connection parameters
		rvSdpMediaDescrSetConnection( descr, netType, addType, addrTxt);
	}

	IppLogMessage(rvFalse,"--> insertConnectionFromMsgToSdpDescr");
}
/*====================================================*/

static RvStatus _createRtpIn( IN void* context, IN RvUint32 sessId, IN const char* rtpId, INOUT RvSdpMediaDescr *descr)
{
	RvSdpMediaType		media_type  = rvSdpMediaDescrGetMediaType( descr);
    HLinkDB     hLink = wrapDbLinkFindByName( context, rtpId);
    char        szDescr[MFC_MAX_SDP_MSG];

    if( !hLink)
    {
        RvMfCLinkRtpInParam   param;
        param.type = RVMFC_LINK_TYPE_RTP_IN;
        param.szLinkName = rtpId;
        if((media_type ==RV_SDPMEDIATYPE_AUDIO))
        {
            param.bIsVideo  = rvFalse;
            param.nSamplesPerSec    = g_param.mfControlParams.nSamplesPerSecAudio;
            param.nSamplesPerFrame  = g_param.mfControlParams.nSamplesPerFrameAudio;
        }
        else
        {
            param.bIsVideo  = rvTrue;
            param.nSamplesPerSec = g_param.mfControlParams.nSamplesPerSecVideo;
            param.nFrameRate   = g_param.mfControlParams.nFrameRatePerSecVideo;
            param.frameSize = g_param.mfControlParams.nFrameSize;
        }
        param.szDescr = szDescr;
        if(IppSerializeSdpDescrTo( szDescr, MFC_MAX_SDP_MSG, descr) !=RV_OK)
            goto err_exit;
        param.szIpLocal = g_param.mfControlParams.RTPAddress;
        param.portLocal =0; //Port pool will be used
        param.bIsIPV6   = rvFalse;
        param.sessId   = sessId;

        if(RV_OK != wrapLinkNew( context, &hLink, (RvMfCLinkParamBase*)&param))
        	goto err_exit;
        if( IppSerializeSdpDescrFrom( param.szDescr, descr) !=RV_OK)
        {
            goto err_exit;
        }
        IppLogMessage(rvFalse, "Creates %s. hLink = %p", rtpId, hLink);
    }

    return RV_OK;
err_exit:
	return RV_ERROR_UNKNOWN;
}


/***************************************************************************************
 * mcHelperCreateRtpLocal
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to open/modify rtp sessions. Invoke RvIppMediaControlInterface.
 *			At this point  local<-->remote negotiation ended.
 *			msgLocal as well as msgRemote contains not more than 1 audio codec and 1 video codec.
 *			We shall divide these msgs to per codec pieces and shall request RvIppMediaControl object to create or modify
 *			appropriate rtp sessions.
 *			As output RvIppMediaControl API fulfills address/port (m= audio [port] ... and c=[address] ) of local media, if needed.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *          void *          - context: pointer to the epp thread
 *          RvUint32        - connectionId: a unique id for the call. The RvMdmTerm object address is used as an
 *                                          identifier.
 *			const char*		- termId: registered termination name of RvRtpLink object
 *										it's termination representing all rtp session in call
 *			RvSdpMsg*		- msgLocal: list of incoming media
 *
 * Output:
 *			RvSdpMsg*		- msgLocal: list of incoming media. media RTP/RTCP addresses should be initialized.
 *
 **************************************************************************************/
RvStatus mcHelperCreateRtpLocal(  IN void* context,
                                 IN RvUint32        connectionId,
                                 IN const char*     termId,
                                 INOUT RvSdpMsg *msgLocal)
{
    int			i, cnt;
    char				rtpId[20];
    RvSdpMediaDescr		*descr;
    RvSdpMediaType		media_type;
    RvUint32            iAudo = SESS_ID_SHIFT_AUDIO, iVideo =SESS_ID_SHIFT_VIDEO;
    RvUint32            sessId;
    RvBool              bMediaExist = rvFalse;

    /*
    *	for debug purpose only
    */
    IppPrintSdp( msgLocal, "mcHelperSetRtp():\n ** Local SDP before MediaControl Request **");

    cnt = rvSdpMsgGetNumOfMediaDescr (msgLocal);
    for( i= cnt-1; i >= 0; i--)
    {
        descr       = rvSdpMsgGetMediaDescr( msgLocal, i);
        media_type  = rvSdpMediaDescrGetMediaType( descr);
        if(media_type == RV_SDPMEDIATYPE_AUDIO)
            sessId = connectionId + iAudo++;
        else
            sessId = connectionId + iVideo++;

        makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvTrue);
        /* make task for rtpId */
        if(RV_OK != _createRtpIn( context, sessId, rtpId, descr))
        {
            /*remove appropriate RvSdpMediaDescr from RvSdpMsg */
            rvSdpMsgRemoveMediaDescr( msgLocal, i);
            continue;
        }

        bMediaExist = rvTrue;
        /*
        *	update connection
        */
        insertConnectionFromSdpDescrToMsg( descr, msgLocal);
    }

    if(!bMediaExist)
        goto err_exit;

    /*
    *	for debug purpose only
    */
    IppPrintSdp( msgLocal, "mcHelperSetRtp():\n ** Local SDP after MediaControl Request **");

    IppLogMessage(rvFalse,"--> mcHelperSetRtp ");
    return RV_OK;
err_exit:
    return RV_ERROR_UNKNOWN;
}



/***************************************************************************************
 * mcHelperModifyRtpLocal
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to open/modify rtp sessions. Invoke RvIppMediaControlInterface.
 *			At this point  local<-->remote negotiation ended.
 *			msgLocal as well as msgRemote contains not more than 1 audio codec and 1 video codec.
 *			We shall divide these msgs to per codec pieces and shall request RvIppMediaControl object to create or modify
 *			appropriate rtp sessions.
 *			As output RvIppMediaControl API fulfills address/port (m= audio [port] ... and c=[address] ) of local media, if needed.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *          void *          - context: pointer to the epp thread
 *          RvUint32        - connectionId: a unique id for the call. The RvMdmTerm object address is used as an
 *                                          identifier.
 *			const char*		- termId: registered termination name of RvRtpLink object
 *										it's termination representing all rtp session in call
 *			RvSdpMsg*		- msgLocal: list of incoming media
 *
 *			RvMdmTermConnState	- state: defined by user ( say, mute implementation)
 *
 * Output:
 *			None
 *
 **************************************************************************************/
RvStatus mcHelperModifyRtpLocal(  IN void* context,
                                 IN RvUint32        connectionId,
                                 IN const char*     termId,
                                 IN RvSdpMsg*          msgLocal,
                                 IN RvMdmMediaCommand  cmd)
{
    RvStatus    rc;
    int	i, cnt;
    char		rtpId[20];
    HLinkDB  hLinkIn, hLinkOut;
    RvBool          bVideo;
    RvSdpMediaDescr	*descr    ;
    RvSdpMediaType	media_type;

    RV_UNUSED_ARG(connectionId);

	if(!msgLocal)
        return RV_OK;
    /*
    *	for debug purpose only
    */
    IppPrintSdp( msgLocal, "mcHelperSetRtp():\n ** Local SDP before MediaControl Request **");

    cnt = rvSdpMsgGetNumOfMediaDescr (msgLocal);
    for( i= 0; i < cnt; i++)
    {
        descr       = rvSdpMsgGetMediaDescr( msgLocal, i);
        media_type  = rvSdpMediaDescrGetMediaType( descr);
        bVideo      = (RV_SDPMEDIATYPE_VIDEO == media_type);

        makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvTrue);
        hLinkIn = wrapDbLinkFindByName( context, rtpId);
        CHECK_PTR( hLinkIn, RV_ERROR_NOT_FOUND)

        makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvFalse);
        hLinkOut = wrapDbLinkFindByName( context, rtpId);
        CHECK_PTR( hLinkOut, RV_ERROR_NOT_FOUND)

        //treat hold options
        switch( cmd)
        {
        case RVMDM_CMD_HOLD_LOCAL:
        case RVMDM_CMD_HOLD_REMOTE_TO_INACTIVE:
            CHECK_FUNC( _holdLocal( context, hLinkIn, hLinkOut, bVideo));
            break;

        case RVMDM_CMD_UNHOLD_LOCAL:
            CHECK_FUNC( _unholdLocal( context,  hLinkIn, hLinkOut, bVideo));
            break;
        case RVMDM_CMD_UNHOLD_INACTIVE_TO_REMOTE:
            CHECK_FUNC( _unholdInactive2HoldRemote(context,   hLinkIn, hLinkOut, bVideo));
            break;
        default:
            IppLogMessage(rvTrue, "mcHelperModifyRtpLocal(). unexpected case");
            goto err_exit;
        }
    }

    /*
    *	for debug purpose only
    */
    IppPrintSdp( msgLocal, "mcHelperSetRtp():\n ** Local SDP after MediaControl Request **");
    IppLogMessage(rvFalse,"--> mcHelperSetRtp ");
    return RV_OK;
err_exit:
    IppLogMessage(rvTrue, "mcHelperModifyRtpLocal(). mcHelperModifyRtpLocal( %s) failed ", rtpId);
    return RV_ERROR_UNKNOWN;
}


/***************************************************************************************
 * mcHelperModifyRtpLocalBySdp
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to open/modify rtp sessions. Invoke RvIppMediaControlInterface.
 *			At this point  local<-->remote negotiation ended.
 *			msgLocal as well as msgRemote contains not more than 1 audio codec and 1 video codec.
 *			We shall divide these msgs to per codec pieces and shall request RvIppMediaControl object to create or modify
 *			appropriate rtp sessions.
 *			As output RvIppMediaControl API fulfills address/port (m= audio [port] ... and c=[address] ) of local media, if needed.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *          void *          - context: pointer to the epp thread
 *          RvUint32        - connectionId: a unique id for the call. The RvMdmTerm object address is used as an
 *                                          identifier.
 *			const char*		- termId: registered termination name of RvRtpLink object
 *										it's termination representing all rtp session in call
 *			RvSdpMsg*		- msgLocal: list of incoming media
 *
 * Output:
 *			None
 *
 **************************************************************************************/
RvStatus mcHelperModifyRtpLocalBySdp( IN void* context,
                                 IN RvUint32        connectionId,
                                 IN const char*     termId,
                                 IN RvSdpMsg*    msgLocal)
{
    int	i, cnt;
    RvUint32    iAudo = SESS_ID_SHIFT_AUDIO, iVideo =SESS_ID_SHIFT_VIDEO;
    char		rtpId[20];
    char        szDescr[MFC_MAX_SDP_MSG];
    RvUint32    sessId;
    HLinkDB     hLink;
    RvBool      bMediaExist = rvFalse;


    /*
    *	for debug purpose only
    */
    IppPrintSdp( msgLocal, "mcHelperSetRtp():\n ** Local SDP before MediaControl Request **");

    cnt = rvSdpMsgGetNumOfMediaDescr (msgLocal);
    for( i= cnt-1; i >=0; i--)
    {
        RvSdpMediaDescr		*descr      = rvSdpMsgGetMediaDescr( msgLocal, i);
        RvSdpMediaType		media_type  = rvSdpMediaDescrGetMediaType( descr);
        RvSdpConnectionMode mode        = rvSdpMediaDescrGetConnectionMode( descr);
        RvBool bVideo      = (RV_SDPMEDIATYPE_VIDEO == media_type);

        if(media_type == RV_SDPMEDIATYPE_AUDIO)
            sessId = connectionId + iAudo++;
        else
            sessId = connectionId + iVideo++;


        makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvTrue);

        /*
        *	add IP info ("c= ....") to every media descriptor
        */
   		insertConnectionFromMsgToSdpDescr( msgLocal, descr);

        /*
        *	invoke MfControl
        */
        hLink = wrapDbLinkFindByName( context, rtpId);
        if( hLink)
        {
            if((mode ==  RV_SDPCONNECTMODE_SENDONLY)||
                (mode == RV_SDPCONNECTMODE_INACTIVE))
            {
            /* we may get here upon OK-response to local HOLD
            * In such case Link would be already stopped
                */
                if( wrapLinkIsStarted( context, hLink))
                {
                    wrapLinkStop( context, hLink);
                }
            }
            else
            {
                RvMfCLinkModifyParam   param;
                param.in.type = RVMFC_LINK_TYPE_RTP_IN;
                param.in.szLinkName = rtpId;
                param.in.bIsIPV6 = rvFalse;
                param.in.bIsVideo = bVideo;
                param.in.sessId = sessId;
                param.in.szDescr = szDescr;
                param.in.szIpLocal = g_param.mfControlParams.RTPAddress;
                param.in.portLocal = 0;//Port pool will be used
                if(IppSerializeSdpDescrTo( szDescr, MFC_MAX_SDP_MSG, descr) !=RV_OK)
                    goto err_exit;

                /*
                * There are 2 options.
                * 1. Modify on-fly parameters of existing LINK
                * 2. Close existing LINK and create new one (with new parameters)
                * Only specific object (LINK) know it can or cannot modify their parameters upon request.
                * So we ask it about this
                */
                if(wrapLinkModify( context, hLink, &param) == RV_OK)
                {
                    if( !wrapLinkIsStarted( context, hLink))
                    {
                        wrapLinkStart( context, hLink);
                    }
                }
                else
                {
                    /*
                    * 1. we check if this object is connected to some operator
                    * 2. destroy this object
                    * 3. build new object
                    * 4. connect new object to the same operator
                    */
                    HOperDB  hOper = wrapDbGetOperElmIn( context, hLink);
                    /* remove old link object*/
                    _destroyLink( context, rtpId);
                    /*build new link object*/
                    if(RV_OK != _createRtpIn( context, sessId, rtpId, descr))
                    {
                        /*remove appropriate RvSdpMediaDescr from RvSdpMsg */
                        rvSdpMsgRemoveMediaDescr( msgLocal, i);
                        continue;
                    }
                    bMediaExist = rvTrue;

                    if(hOper)
                    {
                        if(bVideo)
                            _connectLinkToVidMixer0( context, hLink, _containerIn);
                        else
                            _connectLinkToAudMixer0( context, hLink, _containerIn);
                    }
                }
            }
        }
        else
        {
                    /*
                    * 3. build new object
                    * 4. connect new object to the mix operator
                    */
                    /*build new link object*/
                    if(RV_OK != _createRtpIn( context, sessId, rtpId, descr))
                    {
                        /*remove appropriate RvSdpMediaDescr from RvSdpMsg */
                        rvSdpMsgRemoveMediaDescr( msgLocal, i);
                        continue;
                    }
                    hLink = wrapDbLinkFindByName( context, rtpId);
                    if(!hLink)
                        continue;
                    bMediaExist = rvTrue;

                    if(bVideo)
                        _connectLinkToVidMixer0( context, hLink, _containerIn);
                    else
                        _connectLinkToAudMixer0( context, hLink, _containerIn);
        }

        /*
        *	update connection
        */
        insertConnectionFromSdpDescrToMsg( descr, msgLocal);
    }


    /*
    *	for debug purpose only
    */
    IppPrintSdp( msgLocal, "mcHelperSetRtp():\n ** Local SDP after MediaControl Request **");

    IppLogMessage(rvFalse,"--> mcHelperSetRtp ");
    return RV_OK;
err_exit:
    return RV_ERROR_UNKNOWN;
}

static RvStatus _createRtpOut( IN void* context, IN RvUint32 sessId, IN const char* rtpId, IN RvSdpMediaDescr *descr)
{
    RvSdpMediaType		media_type  = rvSdpMediaDescrGetMediaType( descr);
    HLinkDB     hLink = wrapDbLinkFindByName( context, rtpId);
    char              szDescr[MFC_MAX_SDP_MSG];/*descr - is local dsp wrapped by SDP msg. address should be updated. INOUT param*/
    RvMfCLinkRtpOutParam   param;

    /*create object*/
    memset( &param,0,sizeof(RvMfCLinkRtpOutParam));
    param.type = RVMFC_LINK_TYPE_RTP_OUT;
    param.szLinkName = rtpId;

    if((media_type ==RV_SDPMEDIATYPE_AUDIO))
    {
        param.bIsVideo  = rvFalse;
        param.nSamplesPerSec    = g_param.mfControlParams.nSamplesPerSecAudio;
        param.nSamplesPerFrame  = g_param.mfControlParams.nSamplesPerFrameAudio;
    }
    else
    {
        param.bIsVideo  = rvTrue;
        param.nSamplesPerSec = g_param.mfControlParams.nSamplesPerSecVideo;
        param.nFrameRate   = g_param.mfControlParams.nFrameRatePerSecVideo;
        param.frameSize = g_param.mfControlParams.nFrameSize;
    }

    param.szDescr = szDescr;

    {
        RvChar buff[10000], *ptr;
        RvSdpMsg *mP;
        RvSdpStatus sts;
        mP = (RvSdpMsg*)descr->iSdpMsg;

        ptr = rvSdpMsgEncodeToBuf(mP,buff,sizeof(buff),&sts);
        printf("%s\n",buff);

    }

    if(IppSerializeSdpDescrTo( szDescr, MFC_MAX_SDP_MSG, descr) !=RV_OK)
        goto err_exit;
    param.szIpLocal = g_param.mfControlParams.RTPAddress;
    param.portLocal =0; //Port pool will be used
    param.bIsIPV6 = rvFalse;
    param.sessId  = sessId;

    if(RV_OK != wrapLinkNew( context, &hLink, (RvMfCLinkParamBase*)&param))
        goto err_exit;

    /*
    * correct SDP message parameters
    */
    if( IppSerializeSdpDescrFrom( param.szDescr, descr) !=RV_OK)
    {
        goto err_exit;
    }
    IppLogMessage(rvFalse, "Creates %s. hLink = %p", rtpId, hLink);
    return RV_OK;
err_exit:
    return RV_ERROR_UNKNOWN;
}


/***************************************************************************************
 * mcHelperModifyRtpRemoteBySdp
 * -------------------------------------------------------------------------------------
 * General: to create or modify appropriate rtp sessions.
 *          Request RTP layer to open/modify rtp sessions. Invoke RvIppMediaControlInterface.
 *			At this point  local<-->remote negotiation ended.
 *			msgRemote contains not more than 1 audio codec and 1 video codec.
 *			We shall divide these msgs to per codec pieces and shall request RvIppMediaControl object to create or modify
 *			appropriate rtp sessions.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *          void *          - context: pointer to the epp thread
 *          RvUint32        - connectionId: a unique id for the call. The RvMdmTerm object address is used as an
 *                                          identifier.
 *			const char*		- termId: registered termination name of RvRtpLink object
 *										it's termination representing all rtp session in call
 *			RvSdpMsg*		- msgRemote: list of outgoing media
 *
 * Output:
 *			None
 *
 **************************************************************************************/
RvStatus mcHelperModifyRtpRemoteBySdp(  IN void* context,
                                 IN RvUint32        connectionId,
                                 IN const char*     termId,
                                 IN RvSdpMsg *msgRemote)
{
    int		i, cnt;
    RvUint32        iAudo = SESS_ID_SHIFT_AUDIO, iVideo =SESS_ID_SHIFT_VIDEO;
    char			rtpId[20];
    char            szDescr[MFC_MAX_SDP_MSG];/*descr - is local dsp wrapped by SDP msg. address should be updated. INOUT param*/
    RvUint32        sessId;
    HLinkDB         hLink;
    RvBool          bMediaExist = rvFalse;

	if(!msgRemote)
        return RV_OK;

     {
        RvChar buff[10000], *ptr;
        RvSdpStatus sts;
        ptr = rvSdpMsgEncodeToBuf(msgRemote,buff,sizeof(buff),&sts);
        printf("%s\n",buff);
    }

    cnt = rvSdpMsgGetNumOfMediaDescr (msgRemote);
    for( i= cnt-1; i >=0; i--)
    {
        RvSdpMediaDescr		*descr      = rvSdpMsgGetMediaDescr( msgRemote, i);
        RvSdpMediaType		media_type  = rvSdpMediaDescrGetMediaType( descr);
        RvSdpConnectionMode mode        = rvSdpMediaDescrGetConnectionMode( descr);
        RvBool bVideo      = (RV_SDPMEDIATYPE_VIDEO == media_type);

        if(media_type == RV_SDPMEDIATYPE_AUDIO)
            sessId = connectionId + iAudo++;
        else
            sessId = connectionId + iVideo++;

        /*
        *	add IP info ("c= ....") to every media descriptor if it's not exist there
        */
     {
        RvChar buff[10000], *ptr;
        RvSdpStatus sts;
        ptr = rvSdpMsgEncodeToBuf(msgRemote,buff,sizeof(buff),&sts);
        printf("%s\n",buff);
    }
   		insertConnectionFromMsgToSdpDescr( msgRemote, descr);

     {
        RvChar buff[10000], *ptr;
        RvSdpStatus sts;
        ptr = rvSdpMsgEncodeToBuf(msgRemote,buff,sizeof(buff),&sts);
        printf("%s\n",buff);
    }
        /*
        *	invoke MfControl
        */
        makeRtpId(  rtpId, sizeof(rtpId), termId, media_type, rvFalse);

     {
        RvChar buff[10000], *ptr;
        RvSdpStatus sts;
        ptr = rvSdpMsgEncodeToBuf(msgRemote,buff,sizeof(buff),&sts);
        printf("%s\n",buff);
    }
        hLink = wrapDbLinkFindByName( context, rtpId);

     {
        RvChar buff[10000], *ptr;
        RvSdpStatus sts;
        ptr = rvSdpMsgEncodeToBuf(msgRemote,buff,sizeof(buff),&sts);
        printf("%s\n",buff);
    }
        /* we may get here upon OK-response to local HOLD
        *  in such case remote dsp mode is not set and we always enter RvMfCLinkModify() below
        */

        if( hLink)
        {
            //treat mute/hold options
            if((mode == RV_SDPCONNECTMODE_SENDONLY)||
                (mode == RV_SDPCONNECTMODE_INACTIVE))
            {
                if( wrapLinkIsStarted( context, hLink))
                {
                    wrapLinkStop( context, hLink);
                }
            }
            else
            {
                RvMfCLinkModifyParam   param;
                param.out.type = RVMFC_LINK_TYPE_RTP_OUT;
                param.out.szLinkName = rtpId;
                param.in.bIsIPV6 = rvFalse;
                param.in.bIsVideo = bVideo;
                param.out.sessId = sessId;
                param.out.szDescr = szDescr;
                param.out.szIpLocal = g_param.mfControlParams.RTPAddress;
                param.out.portLocal = 0;//Port pool will be used
                if(IppSerializeSdpDescrTo( szDescr, MFC_MAX_SDP_MSG, descr) !=RV_OK)
                    goto err_exit;
                /*
                * There are 2 options.
                * 1. Modify parameters of existing LINK on-fly
                * 2. Close existing LINK and create new one (with new parameters)
                * Only specific object (LINK) know it can or cannot modify their parameters upon request.
                * So we ask it about this
                */
                if(wrapLinkModify( context, hLink, &param) == RV_OK)
                {
                    if( !wrapLinkIsStarted( context, hLink))
                    {
                        wrapLinkStart( context, hLink);
                    }
                }
                else
                {
                    /*
                    * 1. we check if this object is connected to some operator
                    * 2. destroy this object
                    * 3. build new object
                    * 4. connect new object to the same operator
                    */
                    HOperDB  hOper = wrapDbGetOperElmOut( context, hLink);
                    /* remove old link object*/
                    _destroyLink( context, rtpId);
                    /*build new link object*/
                    if(RV_OK != _createRtpOut( context, sessId, rtpId, descr))
                    {
                        /*remove appropriate RvSdpMediaDescr from RvSdpMsg */
                        rvSdpMsgRemoveMediaDescr( msgRemote, i);
                        continue;
                    }
                    bMediaExist = rvTrue;

                    if(hOper)
                    {
                        if(bVideo)
                            _connectLinkToVidMixer0( context, hLink, _containerOut);
                        else
                            _connectLinkToAudMixer0( context, hLink, _containerOut);
                    }
                }
            }
        }
        else
        {
            /*
            * 3. build new object
            * 4. connect new object to the same operator
            */
            /*build new link object*/
            if(RV_OK != _createRtpOut( context,sessId, rtpId, descr))
            {
                /*remove appropriate RvSdpMediaDescr from RvSdpMsg */
                rvSdpMsgRemoveMediaDescr( msgRemote, i);
                continue;
            }
                    hLink = wrapDbLinkFindByName( context, rtpId);
                    if(!hLink)
                        continue;
                    bMediaExist = rvTrue;
        }
    }

    IppLogMessage(rvFalse,"--> mcHelperSetRtp ");
    return RV_OK;
err_exit:
    return RV_ERROR_UNKNOWN;
}

/***************************************************************************************
* mcHelperModifyRtpRemote
* -------------------------------------------------------------------------------------
* General: Request RTP layer to open/modify rtp sessions. Invoke RvIppMediaControlInterface.
*			At this point  local<-->remote negotiation ended.
*			msgLocal as well as msgRemote contains not more than 1 audio codec and 1 video codec.
*			We shall divide these msgs to per codec pieces and shall request RvIppMediaControl object to create or modify
*			appropriate rtp sessions.
*			As output RvIppMediaControl API fulfills address/port (m= audio [port] ... and c=[address] ) of local media, if needed.
*
* Return Value: RV_OK if success
* -------------------------------------------------------------------------------------
* Arguments:
* Input:
*           void *          - context: pointer to the epp thread
*           RvUint32        - connectionId: a unique id for the call. The RvMdmTerm object address is used as an *                                          identifier.
*			const char*		- termId: registered termination name of RvRtpLink object
*										it's termination representing all rtp session in call
*			RvSdpMsg*		- msgRemote: list of incoming media
*
*			RvMdmTermConnState	- state: defined by user ( say, mute implementation)
*
* Output:
*			None
*
**************************************************************************************/
RvStatus mcHelperModifyRtpRemote( IN void* context,
                                 IN RvUint32        connectionId,
                                 IN const char*     termId,
                                 IN RvSdpMsg*          msgRemote,
                                 IN RvMdmMediaCommand  cmd)
{
    int		i, cnt;
    char			rtpId[20];
    HLinkDB      hLinkIn, hLinkOut;
    RvBool          bVideo;
    RvSdpMediaDescr	*descr    ;
    RvSdpMediaType	media_type;
	RvStatus rc;

    RV_UNUSED_ARG(connectionId);

    if(!msgRemote)
        return RV_OK;

    cnt = rvSdpMsgGetNumOfMediaDescr (msgRemote);
    for( i= 0; i < cnt; i++)
    {
        descr       = rvSdpMsgGetMediaDescr( msgRemote, i);
        media_type  = rvSdpMediaDescrGetMediaType( descr);
        bVideo      = (RV_SDPMEDIATYPE_VIDEO == media_type);

        makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvTrue);
        hLinkIn = wrapDbLinkFindByName( context, rtpId);
        CHECK_PTR( hLinkIn, RV_ERROR_NOT_FOUND)

        makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvFalse);
        hLinkOut = wrapDbLinkFindByName( context, rtpId);
        CHECK_PTR( hLinkOut, RV_ERROR_NOT_FOUND)

        //treat mute/hold options
        switch(cmd)
        {
        case RVMDM_CMD_MUTE_ALL:
            if( wrapLinkIsStarted( context,  hLinkOut))
            {
                wrapLinkStop(  context,  hLinkOut);
            }
            break;

        case RVMDM_CMD_UNMUTE_ALL:
            if( !wrapLinkIsStarted( context,   hLinkOut))
            {
                wrapLinkStart(  context,  hLinkOut);
            }
            break;

        case RVMDM_CMD_HOLD_REMOTE:
        case RVMDM_CMD_HOLD_LOCAL_TO_INACTIVE:
            _holdRemote( context, hLinkIn, hLinkOut, bVideo);
            break;

        case RVMDM_CMD_UNHOLD_REMOTE:
            _unholdRemote( context, hLinkIn, hLinkOut, bVideo);
            break;
        case RVMDM_CMD_UNHOLD_INACTIVE_TO_LOCAL:
            _unholdInactive2HoldLocal( context, hLinkIn, hLinkOut, bVideo);
            break;
        default:
            IppLogMessage(rvTrue, "mcHelperModifyRtpRemote(). unexpected case");
            goto err_exit;
        }
    }

    IppLogMessage(rvFalse,"--> mcHelperSetRtp ");
    return RV_OK;
err_exit:
    IppLogMessage(rvTrue, "mcHelperModifyRtpRemote(). mcHelperModifyRtpLocal( %s) failed ", rtpId);
    return RV_ERROR_UNKNOWN;
}

/***************************************************************************************
 * _destroyLink
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to destroy rtp sessions.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *			const char*		- rtpId: name Link object
 *
 * Output:  None
 *
 **************************************************************************************/
RvStatus _destroyLink( IN void* context, const char* szId)
{
    RvStatus        rc;

    HLinkDB hLink = wrapDbLinkFindByName( context, szId);
    if(hLink)
    {
        CHECK_FUNC( _disconnectLinkFromOperator( context, hLink, _containerOut));
        CHECK_FUNC( _disconnectLinkFromOperator( context, hLink, _containerIn));

        CHECK_FUNC(wrapLinkDelete( context, hLink));
        IppLogMessage(rvFalse, "Destroy %s. hLink = %p", szId, hLink);
    }

	return RV_OK;
err_exit:
	return RV_ERROR_UNKNOWN;
}

/***************************************************************************************
 * mcHelperDestroyRtp
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to destroy rtp sessions. Invoke RvIppMediaControlInterface.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *			const char*		- termId: registered termination name of RvRtpLink object
 *										it's termination representing all rtp session in call
 *
 * Output:  None
 *
 **************************************************************************************/
RvStatus mcHelperDestroyRtp( IN void* context, const char* termId)
{
	char				rtpId[20];

	/*destroy audio rtp session*/
	makeRtpId( rtpId, sizeof(rtpId), termId, RV_SDPMEDIATYPE_AUDIO, rvTrue);
    if(RV_OK != _destroyLink( context, rtpId))
       	goto err_exit;

	makeRtpId( rtpId, sizeof(rtpId), termId, RV_SDPMEDIATYPE_AUDIO, rvFalse);
    if(RV_OK != _destroyLink( context, rtpId))
       	goto err_exit;

	/*destroy video rtp session*/
	makeRtpId( rtpId, sizeof(rtpId), termId, RV_SDPMEDIATYPE_VIDEO, rvTrue);
    if(RV_OK != _destroyLink( context, rtpId))
       	goto err_exit;

	makeRtpId( rtpId, sizeof(rtpId), termId, RV_SDPMEDIATYPE_VIDEO, rvFalse);
    if(RV_OK != _destroyLink( context, rtpId))
       	goto err_exit;

		return RV_OK;
err_exit:
		return RV_ERROR_UNKNOWN;
}

/***************************************************************************************
 * mcHelperOpenDev
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to open a device. Invoke RvIppMediaControlInterface.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *			RvIppMediaDevice		- devId
 *
 * Output:  None
 *
 **************************************************************************************/
RvStatus mcHelperOpenDev( IN void* context, RvIppMediaDevice devId)
{
    RvStatus    rc = RV_ERROR_UNKNOWN;
    HLinkDB  hLink;
    char        szId[32];

    /*
    * after creation connect device to mixer.
    * device will be disconnect from mixer in mcHelperCloseDev() only
    */

    switch( devId)
    {
    case RVIPP_MEDIA_DEV_CAMERA:
        strcpy( szId, "camera");
        hLink = wrapDbLinkFindByName( context, szId);
        if(!hLink)
        {
            RvMfCLinkCameraParam    param;
            param.type           = RVMFC_LINK_TYPE_CAMERA;
            param.szLinkName = szId;
            /// capture resolution
            param.frameSize      = g_param.mfControlParams.nFrameSize;
            /// local display resolution
            param.frameSizeLocal = g_param.mfControlParams.nFrameSizeLocal;
            param.frameRate      = g_param.mfControlParams.nFrameRatePerSecVideo;//capture rate
            param.bDisplayLocal  = rvTrue;
            param.local_display_poll_interval_msec = 1000/(RvUint32)param.frameRate;
#ifdef WIN32
#if(RV_OS_TYPE != RV_OS_TYPE_WINCE)

            {
                HWND    hParent = FindWindow( NULL,"LocalDlg");
                param.hVideoObj = (HVIDEOOBJ)FindWindowEx( hParent,NULL,"STATIC",NULL);
            }
#endif
#endif
            CHECK_FUNC( wrapLinkNew( context, &hLink, (RvMfCLinkParamBase*)&param));
            IppLogMessage(rvFalse, "Creates CAMERA. hLink = %p", hLink);
            CHECK_FUNC( _connectLinkToVidMixer0( context, hLink, _containerIn));

        }
        break;
    case RVIPP_MEDIA_DEV_DISPLAY_WINDOW:
        strcpy( szId, "window");
        hLink = wrapDbLinkFindByName( context, szId);
        if(!hLink)
        {
            RvMfCLinkWindowParam   param;
            param.type = RVMFC_LINK_TYPE_WINDOW;
            param.szLinkName = szId;
            /// remote display resolution
            param.frameSize = g_param.mfControlParams.nFrameSize;

#ifdef WIN32 /* Connect with GUI*/
#if(RV_OS_TYPE != RV_OS_TYPE_WINCE)
            {
                HWND    hParent = FindWindow( NULL,"RemoteDlg");
                param.hVideoObj = (HVIDEOOBJ)FindWindowEx( hParent,NULL,"STATIC",NULL);
            }
#endif
#endif
            CHECK_FUNC( wrapLinkNew( context, &hLink, (RvMfCLinkParamBase*)&param));
            IppLogMessage(rvFalse, "Creates WINDOW. hLink = %p", hLink);
            CHECK_FUNC( _connectLinkToVidMixer0( context,hLink, _containerOut));
        }
        break;
    case RVIPP_MEDIA_DEV_MIC:
        strcpy( szId, "mic");
        hLink = wrapDbLinkFindByName( context, szId);
        if(!hLink)
        {
            RvMfCLinkMicParam   param;
            param.type = RVMFC_LINK_TYPE_MIC;
            param.szLinkName = szId;
            param.nSamplesPerSec = g_param.mfControlParams.nSamplesPerSecAudio;
            param.nSamplesPerFrame = g_param.mfControlParams.nSamplesPerFrameAudio;
            CHECK_FUNC( wrapLinkNew( context, &hLink, (RvMfCLinkParamBase*)&param));
            IppLogMessage(rvFalse, "Creates MIC. hLink = %p", hLink);
            CHECK_FUNC( _connectLinkToAudMixer0( context, hLink, _containerIn));
        }
        break;
    case RVIPP_MEDIA_DEV_SPEAKER:
        strcpy( szId, "speaker");
        hLink = wrapDbLinkFindByName( context, szId);
        if(!hLink)
        {
            RvMfCLinkSpeakParam   param;
            param.type = RVMFC_LINK_TYPE_SPEAK;
            param.szLinkName = szId;
            param.nSamplesPerSec = g_param.mfControlParams.nSamplesPerSecAudio;
            param.samplesPerFrame = g_param.mfControlParams.nSamplesPerFrameAudio;
            CHECK_FUNC( wrapLinkNew( context, &hLink, (RvMfCLinkParamBase*)&param));
            IppLogMessage(rvFalse, "Creates SPEAKER. hLink = %p", hLink);
            CHECK_FUNC( _connectLinkToAudMixer0( context, hLink, _containerOut));
        }
        break;
    case RVIPP_MEDIA_DEV_MIN:
    case RVIPP_MEDIA_DEV_MAX:
    default:
        goto err_exit;
    }

	return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"mcHelperOpenDev() failed. device Id = %s", szId);
	return rc;
}

/***************************************************************************************
 * mcHelperCloseDev
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to close a device. Invoke RvIppMediaControlInterface.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *			RvIppMediaDevice		- devId
 *
 * Output:  None
 *
 **************************************************************************************/
RvStatus mcHelperCloseDev(  IN void* context, RvIppMediaDevice devId)
{
    RvStatus        rc;

    switch( devId)
    {
    case RVIPP_MEDIA_DEV_CAMERA:
        CHECK_FUNC( _destroyLink(context, "camera"));
        IppLogMessage(rvFalse, "Destroy CAMERA" );
        break;

    case RVIPP_MEDIA_DEV_DISPLAY_WINDOW:
        CHECK_FUNC( _destroyLink(context, "window"));
        IppLogMessage(rvFalse, "Destroy WINDOW");
        break;

    case RVIPP_MEDIA_DEV_MIC:
        CHECK_FUNC( _destroyLink(context, "mic"));
        IppLogMessage(rvFalse, "Destroy MIC");
        break;

    case RVIPP_MEDIA_DEV_SPEAKER:
        CHECK_FUNC( _destroyLink(context, "speaker"));
        IppLogMessage(rvFalse, "Destroy SPEAKER");
        break;
    case RVIPP_MEDIA_DEV_MIN:
    case RVIPP_MEDIA_DEV_MAX:
    default:
        goto err_exit;
    }

	return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"mcHelperCloseDev() failed. devId = %d", devId);
	return RV_ERROR_UNKNOWN;
}

/***************************************************************************************
 * mcHelperConnectRtpToDev
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to connect rtp session to device. Invoke RvIppMediaControlInterface.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *			const char*		- termIdDev: registered termination name of device (like "at/hs")
 *			const char*		- termId: registered termination name of RvRtpLink object (like "rtp/1").
 *										it's termination representing all rtp session in call
 *
 * Output:  None
 *
 **************************************************************************************/
RvStatus mcHelperConnectRtpToDev( IN void* context,
								   RvIppMediaDevice devId,
								   const char* termId)
{
    RvStatus        rc = RV_ERROR_UNKNOWN;
	char			rtpId[20];
	RvSdpMediaType	media_type = mapDevIdToMediaType( devId);
    HLinkDB         hLinkIn = NULL;
    HLinkDB         hLinkOut = NULL;

    switch( devId)
    {
    case RVIPP_MEDIA_DEV_MIC:
        {
    	    makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvFalse);
            hLinkOut = wrapDbLinkFindByName ( context, rtpId);
            hLinkIn = wrapDbLinkFindByName( context, "mic");
            CHECK_PTR( hLinkIn, RV_ERROR_NULLPTR);
            CHECK_PTR( hLinkOut, RV_ERROR_NULLPTR);
            CHECK_FUNC(_connectLinks( context, hLinkIn, hLinkOut, rvFalse));
        }
        break;

    case RVIPP_MEDIA_DEV_SPEAKER:
        {
    	    makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvTrue);
            hLinkIn = wrapDbLinkFindByName( context, rtpId);
            hLinkOut = wrapDbLinkFindByName( context, "speaker");
            CHECK_PTR( hLinkIn, RV_ERROR_NULLPTR);
            CHECK_PTR( hLinkOut, RV_ERROR_NULLPTR);
            CHECK_FUNC(_connectLinks( context, hLinkIn, hLinkOut, rvFalse));
        }
        break;

    case RVIPP_MEDIA_DEV_CAMERA:
        {
    	    makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvFalse);
            hLinkOut = wrapDbLinkFindByName( context, rtpId);
            hLinkIn = wrapDbLinkFindByName( context, "camera");
            CHECK_PTR( hLinkIn, RV_ERROR_NULLPTR);
            CHECK_PTR( hLinkOut, RV_ERROR_NULLPTR);
            CHECK_FUNC(_connectLinks( context, hLinkIn, hLinkOut, rvTrue));
        }
        break;

        case RVIPP_MEDIA_DEV_DISPLAY_WINDOW:
        {
    	    makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvTrue);
            hLinkIn = wrapDbLinkFindByName( context, rtpId);
            hLinkOut = wrapDbLinkFindByName( context, "window");
            CHECK_PTR( hLinkIn, RV_ERROR_NULLPTR);
            CHECK_PTR( hLinkOut, RV_ERROR_NULLPTR);
            CHECK_FUNC(_connectLinks( context, hLinkIn, hLinkOut, rvTrue));
        }
        break;

    case RVIPP_MEDIA_DEV_MIN:
    case RVIPP_MEDIA_DEV_MAX:
default:
        goto err_exit;
    }




	return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"mcHelperConnectRtpToDev() failed. devId = %d, rtpId = %s", devId, rtpId);
	return rc;
}

/***************************************************************************************
 * mcHelperConnectRtpToRtp
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to connect rtp session to another rtp session (used to join calls). Invoke RvIppMediaControlInterface.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *			const char*		- termIdDev: registered termination name of device (like "at/hs")
 *			const char*		- termId: registered termination name of RvRtpLink object (like "rtp/1").
 *										it's termination representing all rtp session in call
 *
 * Output:  None
 *
 **************************************************************************************/
RvStatus mcHelperConnectRtpToRtp( IN void* context,
										   const char* termIdSrc,
										   const char* termId)
{

	RV_UNUSED_ARG(context);
	RV_UNUSED_ARG(termIdSrc);
	RV_UNUSED_ARG(termId);

/*
    All was done in previously coming  mcHelperConnectRtpToDev
    RvBool          bVideo;
	char							rtpId[20];
    HLinkDB  hLinkSrcIn, hLinkSrcOut, hLinkTargIn, hLinkTargOut;
	RvStatus        rc = RV_ERROR_UNKNOWN;

    //audio
    // In Src
    makeRtpId( rtpId, sizeof(rtpId), termIdSrc, RV_SDPMEDIATYPE_AUDIO, rvTrue);
    hLinkSrcIn = wrapDbLinkFindByName( rtpId);
    CHECK_PTR( hLinkSrcIn, RV_ERROR_NOT_FOUND)
    // In Targ
    makeRtpId( rtpId, sizeof(rtpId), termId, RV_SDPMEDIATYPE_AUDIO, rvTrue);
    hLinkTargIn = wrapDbLinkFindByName( rtpId);
    CHECK_PTR( hLinkTargIn, RV_ERROR_NOT_FOUND)
    // Out Src
    makeRtpId( rtpId, sizeof(rtpId), termIdSrc, RV_SDPMEDIATYPE_AUDIO, rvFalse);
    hLinkSrcOut = wrapDbLinkFindByName( rtpId);
    CHECK_PTR( hLinkSrcOut, RV_ERROR_NOT_FOUND)
    // Out Targ
	makeRtpId( rtpId, sizeof(rtpId), termId, RV_SDPMEDIATYPE_AUDIO, rvFalse);
    hLinkTargOut = wrapDbLinkFindByName( rtpId);
    CHECK_PTR( hLinkTargOut, RV_ERROR_NOT_FOUND)

    //Check if Targ is connected to mixer_0

    {
        HOperDB  hOperTargIn  = wrapDbGetOperElmIn( hLinkTargIn) ;
        HOperDB  hOperTargOut = wrapDbGetOperElmOut( hLinkTargOut) ;
        HOperDB  hOperMixer0 = wrapDbOperFindByName( AUD_MIX_0);

        if( !hOperTargIn || !hOperTargOut || !hOperMixer0 ||
            (hOperTargIn != hOperMixer0) || (hOperTargOut != hOperMixer0)
            )
            goto err_exit; //not yet implemented behavior

    }

    CHECK_FUNC( _connectLinkToAudMixer0( hLinkSrcIn, _containerIn));
    CHECK_FUNC( _connectLinkToAudMixer0( hLinkSrcOut, _containerOut));

    if( !wrapLinkIsStarted(  hLinkSrcIn))
        wrapLinkStart(  hLinkSrcIn);

    if( !wrapLinkIsStarted(  hLinkSrcOut))
        wrapLinkStart(  hLinkSrcOut);


	return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"mcHelperConnectRtpToRtp() failed. termIdSrc = %s, termId = %s", termIdSrc, termId));

	return rc;
*/
	return RV_OK;
}

/***************************************************************************************
 * mcHelperDisconnectRtpFromDev
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to disconnect rtp session from device. Invoke RvIppMediaControlInterface.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *			const char*		- termIdDev: registered termination name of device (like "at/hs")
 *			const char*		- termId: registered termination name of RvRtpLink object (like "rtp/1").
 *										it's termination representing all rtp session in call
 *
 * Output:  None
 *
 **************************************************************************************/
RvStatus mcHelperDisconnectRtpFromDev( IN void* context,
											IN RvIppMediaDevice devId,
											IN const char* termId)
{
    RvStatus            rc;
	char				rtpId[20];
	RvSdpMediaType		media_type = mapDevIdToMediaType( devId);
    HLinkDB          hLink;

    makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvTrue);
    hLink = wrapDbLinkFindByName( context, rtpId);
    if(hLink)
    {
        CHECK_FUNC( _disconnectLinkFromOperator( context,hLink, _containerIn));
    }
    else
    {
    	IppLogMessage(rvTrue,"mcHelperDisconnectRtpFromDev() rtpId = %s not found", rtpId);
    }
    makeRtpId( rtpId, sizeof(rtpId), termId, media_type, rvFalse);
    hLink = wrapDbLinkFindByName( context, rtpId);
    if(hLink)
    {
        CHECK_FUNC( _disconnectLinkFromOperator( context,hLink, _containerOut));
    }
    else
    {
    	IppLogMessage(rvTrue,"mcHelperDisconnectRtpFromDev() rtpId = %s not found", rtpId);
    }

/* it will be done just upon closing device
    switch( devId)
    {
    case RVIPP_MEDIA_DEV_MIC:
        hLink = wrapDbLinkFindByName( "mic");
        CHECK_FUNC( _disconnectLinkFromOperator( hLink, _containerIn));
        break;

    case RVIPP_MEDIA_DEV_SPEAKER:
        hLink = wrapDbLinkFindByName( "speaker");
        CHECK_FUNC( _disconnectLinkFromOperator( hLink, _containerOut));
        break;

    case RVIPP_MEDIA_DEV_CAMERA:
        hLink = wrapDbLinkFindByName( "camera");
        CHECK_FUNC( _disconnectLinkFromOperator( hLink, _containerIn));
        break;

        case RVIPP_MEDIA_DEV_DISPLAY_WINDOW:
        hLink = wrapDbLinkFindByName( "window");
        CHECK_FUNC( _disconnectLinkFromOperator( hLink, _containerOut));
        break;

    case RVIPP_MEDIA_DEV_MIN:
    case RVIPP_MEDIA_DEV_MAX:
    default:
        goto err_exit;
    }
*/


	return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"mcHelperDisconnectRtpFromDev() failed. devId = %d, rtpId = %s", devId, rtpId);
	return RV_ERROR_UNKNOWN;
}

/***************************************************************************************
 * mcHelperDisconnectRtpFromRtp
 * -------------------------------------------------------------------------------------
 * General: Request RTP layer to disconnect rtp session from device. Invoke RvIppMediaControlInterface.
 *
 * Return Value: RV_OK if success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:
 *			const char*		- termIdSrc: registered termination name of device (like "at/hs")
 *			const char*		- termId: registered termination name of RvRtpLink object (like "rtp/1").
 *										it's termination representing all rtp session in call
 *
 * Output:  None
 *
 **************************************************************************************/
RvStatus mcHelperDisconnectRtpFromRtp(  IN void* context,
										   IN const char* termIdSrc,
										   IN const char* termId)
{

	RV_UNUSED_ARG(context);
	RV_UNUSED_ARG(termIdSrc);
	RV_UNUSED_ARG(termId);

/*
    All will be done while in following mcHelperDisconnectRtpFromDev
// existing strange bug.
  In Scenario: A call B. Hold. A calls C. A press 'Conf'.
  termIdSrc always contains B and termId always contains C, not depending  of B or C sent 'BYE'

	RvStatus        rc = RV_ERROR_UNKNOWN;
    RvBool          bVideo;
	char							rtpId[20];
    HLinkDB  hLinkSrcIn, hLinkSrcOut, hLinkTargIn, hLinkTargOut;

    //audio
    // In Src
    makeRtpId( rtpId, sizeof(rtpId), termIdSrc, RV_SDPMEDIATYPE_AUDIO, rvTrue);
    hLinkSrcIn = wrapDbLinkFindByName( rtpId);
    CHECK_PTR( hLinkSrcIn, RV_ERROR_NOT_FOUND)
    // In Targ
    makeRtpId( rtpId, sizeof(rtpId), termId, RV_SDPMEDIATYPE_AUDIO, rvTrue);
    hLinkTargIn = wrapDbLinkFindByName( rtpId);
    CHECK_PTR( hLinkTargIn, RV_ERROR_NOT_FOUND)
    // Out Src
    makeRtpId( rtpId, sizeof(rtpId), termIdSrc, RV_SDPMEDIATYPE_AUDIO, rvFalse);
    hLinkSrcOut = wrapDbLinkFindByName( rtpId);
    CHECK_PTR( hLinkSrcOut, RV_ERROR_NOT_FOUND)
    // Out Targ
	makeRtpId( rtpId, sizeof(rtpId), termId, RV_SDPMEDIATYPE_AUDIO, rvFalse);
    hLinkTargOut = wrapDbLinkFindByName( rtpId);
    CHECK_PTR( hLinkTargOut, RV_ERROR_NOT_FOUND)

    if( wrapLinkIsStarted(  hLinkTargIn))
        wrapLinkStop(  hLinkTargIn);

    if( wrapLinkIsStarted(  hLinkTargOut))
        wrapLinkStop(  hLinkTargOut);

    CHECK_FUNC( _disconnectLinkFromOperator( hLinkTargIn, _containerIn));
    CHECK_FUNC( _disconnectLinkFromOperator( hLinkTargOut, _containerOut));

	return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"mcHelperDisconnectRtpFromRtp() failed. termIdSrc = %s, termId = %s", termIdSrc, termId));

	return rc;
*/
	return RV_OK;
}

RvStatus _disconnectLinkFromOperator( IN void* context, HLinkDB hLink, ContainerDir dir)
{
    RvStatus            rc;
    RvMfCOpCmd          cmd;
    RvMfCOpCmdParam     param;
    RvBool              bIn = (dir == _containerIn);
    HOperDB             hOper;

    if(!hLink)
        goto ok_exit;
    if( wrapLinkIsStarted( context,  hLink))
        wrapLinkStop( context,  hLink);

    hOper =   (bIn)?  wrapDbGetOperElmIn( context, hLink) : wrapDbGetOperElmOut( context, hLink);
    if(!hOper)
        goto ok_exit;

    /* ... on MF level*/
    if(bIn)
    {
        cmd = OPCMD_REMOVE_IN;
        param.remove_in.hOperator = hOper;
        param.remove_in.hLinkIn   = hLink;
        CHECK_FUNC( wrapOperatorCmd( context, cmd, &param));
    }
    else
    {
        cmd = OPCMD_REMOVE_OUT;
        param.remove_out.hOperator = hOper;
        param.remove_out.hLinkOut  = hLink;
        CHECK_FUNC( wrapOperatorCmd( context, cmd, &param));
    }
ok_exit:
	return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"_linkDisconnect() failed. hLink = %p, dir = %d", hLink, dir);
    return RV_ERROR_UNKNOWN;
}

RvStatus _connectLinks( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo)
{
    RvStatus        rc;

    if(bVideo)
    {
        CHECK_FUNC( _connectLinkToVidMixer0( context, hLinkIn, _containerIn));
        CHECK_FUNC( _connectLinkToVidMixer0( context, hLinkOut, _containerOut));
    }
    else
    {
        CHECK_FUNC( _connectLinkToAudMixer0( context, hLinkIn, _containerIn));
        CHECK_FUNC( _connectLinkToAudMixer0( context, hLinkOut, _containerOut));
    }

// made in _connectLinkTo...()
//    if( !wrapLinkIsStarted(  hLinkIn))
//        wrapLinkStart(  hLinkIn);
//    if( !wrapLinkIsStarted(  hLinkOut))
//        wrapLinkStart(  hLinkOut);

	return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"_connectLinks() failed. hLinkIn = %p, hLinkOut = %p", hLinkIn, hLinkOut);
    return RV_ERROR_UNKNOWN;
}
/*==========================================================*/
RvStatus _holdLocal( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo)
{
    RvStatus    rc;

    /*current primitive implementation is the same for audio and video */
	RV_UNUSED_ARG(bVideo);

    /*disconnect In link*/
     CHECK_FUNC( _disconnectLinkFromOperator( context, hLinkIn, _containerIn))

    /*disconnect Out link*/
     CHECK_FUNC( _disconnectLinkFromOperator( context, hLinkOut, _containerOut))

     return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"_holdLocal() failed. hLinkIn = %p, hLinkOut = %p", hLinkIn, hLinkOut);
    return rc;
}
/*==========================================================*/
RvStatus _unholdLocal( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo)
{
    RvStatus    rc;

    if(bVideo)
    {
        CHECK_FUNC( _connectLinkToVidMixer0( context, hLinkIn, _containerIn));
        CHECK_FUNC( _connectLinkToVidMixer0( context, hLinkOut, _containerOut));
    }
    else
    {
        CHECK_FUNC( _connectLinkToAudMixer0( context, hLinkIn, _containerIn));
        CHECK_FUNC( _connectLinkToAudMixer0( context, hLinkOut, _containerOut));
    }

    return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"_unholdLocal() failed. hLinkIn = %p, hLinkOut = %p", hLinkIn, hLinkOut);
    return rc;
}
/*==========================================================*/
RvStatus _unholdInactive2HoldRemote( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo)
{
//this removed because of _holdRemote() specific implementation
//    RvStatus    rc;
//    if(bVideo)
//    {
//        CHECK_FUNC( _connectLinkToVidMixer0( hLinkIn, _containerIn));
//    }
//    else
//    {
//        CHECK_FUNC( _connectLinkToAudMixer0( hLinkIn, _containerIn));
//    }
//    return RV_OK;
//err_exit:
//	IppLogMessage(rvTrue,"_unholdLocal() failed. hLinkIn = %p, hLinkOut = %p", hLinkIn, hLinkOut);
//    return rc;
	RV_UNUSED_ARG(context);
	RV_UNUSED_ARG(hLinkIn);
	RV_UNUSED_ARG(hLinkOut);
	RV_UNUSED_ARG(bVideo);
    return RV_OK;
}
/*==========================================================*/
RvStatus _holdRemote( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo)
{
    /* disconnect outgoing channel only later*/
    RvStatus    rc;

    /*current primitive implementation is the same for audio and video */
	RV_UNUSED_ARG(bVideo);

    /*disconnect Out link*/
     CHECK_FUNC( _disconnectLinkFromOperator( context, hLinkIn, _containerIn)) //this added because of video mixer restriction
     CHECK_FUNC( _disconnectLinkFromOperator( context, hLinkOut, _containerOut))

     return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"_holdRemote() failed. hLinkIn = %p, hLinkOut = %p", hLinkIn, hLinkOut);
    return rc;
}
/*==========================================================*/
RvStatus _unholdRemote( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo)
{
    /* connect outgoing channel only later*/
    RvStatus    rc;

    if(bVideo)
    {
        CHECK_FUNC( _connectLinkToVidMixer0( context, hLinkIn, _containerIn));//this added because of _holdRemote() specific implementation
        CHECK_FUNC( _connectLinkToVidMixer0( context, hLinkOut, _containerOut));
    }
    else
    {
        CHECK_FUNC( _connectLinkToAudMixer0( context, hLinkIn, _containerIn));//this added because of _holdRemote() specific implementation
        CHECK_FUNC( _connectLinkToAudMixer0( context, hLinkOut, _containerOut));
    }

    return RV_OK;
err_exit:
	IppLogMessage(rvTrue,"_unholdRemote() failed. hLinkIn = %p, hLinkOut = %p", hLinkIn, hLinkOut);
    return rc;
}
/*==========================================================*/
RvStatus _unholdInactive2HoldLocal( IN void* context, HLinkDB hLinkIn, HLinkDB hLinkOut, RvBool bVideo)
{
	RV_UNUSED_ARG(context);
    RV_UNUSED_ARG( hLinkIn);
    RV_UNUSED_ARG( hLinkOut);
    RV_UNUSED_ARG( bVideo);
    return RV_OK;
}
/*==========================================================*/
RvStatus _connectLinkToAudMixer0( IN void* context, HLinkDB hLink, ContainerDir dir)
{
    RvStatus         rc;
    HOperDB          hOper =NULL, hOperOld =NULL;
    RvMfCOpCmd       cmd =OPCMD_MAX;
    RvMfCOpCmdParam  cmdParam;

    /*
    * find mixer operator or create new
    */
    hOper = wrapDbOperFindByName( context, AUD_MIX_0);
    if(!hOper)
    {
        RvMfCOprMixAudioParam   param;
        param.type = OPR_TYPE_MIX_AUDIO;
        CHECK_FUNC( wrapOperatorNew(  context, &hOper, AUD_MIX_0, (RvMfCOprBaseParam*)&param));
    }
    CHECK_PTR(hOper, RV_ERROR_UNKNOWN);

    hOperOld  = (dir ==_containerIn)? wrapDbGetOperElmIn( context, hLink) : wrapDbGetOperElmOut( context, hLink);
    if( hOperOld == hOper)
        goto ok_exit;

    if(dir ==_containerIn)
    {/* handle In element*/
        /*build parameters in order to connect links to mixer operator*/
        cmd = OPCMD_MIX_AUDIO_ADD_IN;
        cmdParam.mix_audio_add_in.hOperator = hOper;
        cmdParam.mix_audio_add_in.hLinkIn   =  hLink;
    }
    else
    {/* handle Out element*/
        /*build parameters in order to connect links to mixer operator*/
        cmd = OPCMD_MIX_AUDIO_ADD_OUT;
        cmdParam.mix_audio_add_out.hOperator = hOper;
        cmdParam.mix_audio_add_out.hLinkOut  =  hLink;
    }

    /*
    * disconnect link from old operator if any
    */
    if( hOperOld)
        _disconnectLinkFromOperator( context, hLink, dir);
    /*
    * connect to new operator
    */
     CHECK_FUNC( wrapOperatorCmd( context, cmd, &cmdParam));
    /*
    * start Link object
    */
    if( !wrapLinkIsStarted( context, hLink))
    {
        wrapLinkStart( context, hLink);
    }

ok_exit:
return RV_OK;
err_exit:
IppLogMessage(rvTrue,"_connectLinkToAudMixer0() failed. hLink = %p, dir = %d", hLink, dir);
return RV_ERROR_UNKNOWN;
}
/*==========================================================*/
RvStatus _connectLinkToVidMixer0( IN void* context, HLinkDB hLink, ContainerDir dir)
{
    RvStatus         rc;
    HOperDB          hOper, hOperOld =NULL;
    RvMfCOpCmd       cmd =OPCMD_MAX;
    RvMfCOpCmdParam  cmdParam;

    /*
    * find mixer operator or create new
    */
    hOper = wrapDbOperFindByName( context, VID_MIX_0);
    if(!hOper)
    {
        RvMfCOprMixVideoParam   param;
        param.type      = OPR_TYPE_MIX_VIDEO;
        param.frameSize = g_param.mfControlParams.nFrameSize;
        CHECK_FUNC( wrapOperatorNew(  context, &hOper, VID_MIX_0, (RvMfCOprBaseParam*)&param));
    }
    CHECK_PTR(hOper, RV_ERROR_UNKNOWN);

    hOperOld  = (dir ==_containerIn)? wrapDbGetOperElmIn( context, hLink) : wrapDbGetOperElmOut( context, hLink);
    if( hOperOld == hOper)
        goto ok_exit;

    if(dir ==_containerIn)
    { /* handle In element*/
        /*build parameters in order to connect links to mixer operator*/
        cmd = OPCMD_MIX_VIDEO_ADD_IN;
        cmdParam.mix_video_add_in.hOperator = hOper;
        cmdParam.mix_video_add_in.hLinkIn   =  hLink;
    }
    else
    {/* handle Out element*/
        /*build parameters in order to connect links to mixer operator*/
        cmd = OPCMD_MIX_VIDEO_ADD_OUT;
        cmdParam.mix_video_add_out.hOperator = hOper;
        cmdParam.mix_video_add_out.hLinkOut  =  hLink;
    }

    /*
    * disconnect link from old operator if any
    */
    if( hOperOld)
        _disconnectLinkFromOperator( context, hLink, dir);
    /*
    * connect to new operator
    */
    CHECK_FUNC( wrapOperatorCmd( context, cmd, &cmdParam));

    /*
    * start Link object
    */
    if( !wrapLinkIsStarted( context, hLink))
    {
        wrapLinkStart( context, hLink);
    }

ok_exit:
return RV_OK;
err_exit:
IppLogMessage(rvTrue,"_connectLinkToVidMixer0() failed. hLink = %p, dir = %d", hLink, dir);
return RV_ERROR_UNKNOWN;
}
/*==========================================================*/
void ModifyFastUpdate( RvIppTerminalHandle  termEph, RvIppTerminalHandle uiTerm)
{
    void*                   context;
    HLinkDB                 hLink;
    char                    termId[64];
    RvSize_t                termIdLen = sizeof(termId);
    char			        rtpId[20];
    RvSdpMediaType		    media_type  = RV_SDPMEDIATYPE_VIDEO;
    RvMfCLinkModifyParam    param;

    rvIppMdmTerminalGetId( termEph, termId, termIdLen);
    makeRtpId(  rtpId, sizeof(rtpId), termId, media_type, rvFalse);

    context = rvIppMdmTerminalGetUserData ( uiTerm);

    hLink = wrapDbLinkFindByName( context, rtpId);
    param.out.type = RVMFC_LINK_TYPE_RTP_OUT;
    param.out.szLinkName = rtpId;
    param.out.Command = tlinkForceIntra;
    wrapLinkModify( context, hLink, &param);
}
/*==========================================================*/
/*----------------------------------------------------------------------------------------------------------*/
HLinkDB  wrapDbLinkFindByName( IN void* context, IN const char* linkName)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return MfCDbLinkFindByName( linkName);
#else
    return PrxDbLinkFindByName( context, linkName);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
HOperDB  wrapDbOperFindByName( IN void* context, IN const char* opName)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return MfCDbOperFindByName( opName);
#else
    return PrxDbOperFindByName( context, opName);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
HOperDB  wrapDbGetOperElmIn( IN void* context, IN HLinkDB hLinkElm)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return MfCDbGetOperElmIn( hLinkElm);
#else
    return PrxDbGetOperElmIn( context, hLinkElm);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
HOperDB  wrapDbGetOperElmOut( IN void* context, IN HLinkDB hLinkElm)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return MfCDbGetOperElmOut( hLinkElm);
#else
    return PrxDbGetOperElmOut( context, hLinkElm);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapControlInit( IN void* context, IN RvMfControlConstructParam* param)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return RvMfControlInit( param);
#else
    return PrxControlInit( context, param);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
void     wrapControlEnd( IN void* context)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    RvMfControlEnd();
#else
    PrxControlEnd( context);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapLinkNew(  IN void* context, OUT HLinkDB *hLink,INOUT RvMfCLinkParamBase* param)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return RvMfCLinkNew( hLink, param);
#else
    return PrxLinkNew( context, hLink, param);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapLinkDelete( IN void* context, IN HLinkDB hLink)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return RvMfCLinkDelete( hLink);
#else
    return PrxLinkDelete( context, hLink);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapLinkStart  ( IN void* context, IN HLinkDB hLink)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return RvMfCLinkStart( hLink);
#else
    return PrxLinkStart( context, hLink);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapLinkStop ( IN void* context, IN HLinkDB hLink)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return RvMfCLinkStop( hLink);
#else
    return PrxLinkStop( context, hLink);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapLinkModify ( IN void* context, IN HLinkDB hLink, IN RvMfCLinkModifyParam* param)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return RvMfCLinkModify( hLink, param);
#else
    return PrxLinkModify( context, hLink, param);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
RvBool   wrapLinkIsStarted ( IN void* context, IN HLinkDB hLink)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return RvMfCLinkIsStarted( hLink);
#else
    return PrxLinkIsStarted( context, hLink);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapOperatorNew(  IN void* context, OUT HOperDB *hOperator, IN const char* opName, IN RvMfCOprBaseParam* param)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return RvMfCOperatorNew( hOperator, opName, param);
#else
    return PrxOperatorNew( context, hOperator, opName, param);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
void     wrapOperatorDelete( IN void* context, IN HOperDB hOperator)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    RvMfCOperatorDelete( hOperator);
#else
    PrxOperatorDelete( context, hOperator);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/
RvStatus wrapOperatorCmd( IN void* context, IN RvMfCOpCmd cmd, IN RvMfCOpCmdParam* param)
{
#ifdef RV_MTF_MEDIA
	RV_UNUSED_ARG(context);
    return RvMfCOperatorCmd( cmd, param);
#else
    return PrxOperatorCmd( context, cmd, param);
#endif
}
/*----------------------------------------------------------------------------------------------------------*/



