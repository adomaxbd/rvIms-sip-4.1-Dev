/******************************************************************************
Filename:    IppSamplePhoneLink.h
Description: Ip Phone termination handling
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

#ifndef RV_PHONELINK_H
#define RV_PHONELINK_H

#include "rveppclient.h"
#include "IppSampleRtpLink.h"

#if defined(__cplusplus)
extern "C" {
#endif

//MARKA typedef struct
//{
//	RvEppClientEndpoint *endpoint;
//} RvPhoneLink;


typedef struct
{
	RvMdmTermMgr*   termMgr;
	RvEppClient*    eppClient;
} RvPhoneMgr;

RvStatus rvPhoneMgrConstruct(
    IN RvPhoneMgr*      mgr,
    IN RvMdmTermMgr*    termMgr,
    IN RvBool           bConfigTCP,
    IN const RvChar*    eppClientIp,
    IN RvUint16         eppPort);
void rvPhoneMgrDestruct(RvPhoneMgr *mgr);

void rvPhoneMgrInitPhoneClass(RvMdmTermMgr* termMgr, RvMdmTermClass** phoneClass);
void rvPhoneMgrInitUIClass(RvMdmTermMgr* termMgr, RvMdmTermClass** uiClass);
void rvPhoneMgrInitAtClass(RvMdmTermMgr* termMgr, RvMdmTermClass** atClass);

//MARKA RvRtpLink *rvPhoneMgrGetRtpLink(RvMdmMediaStream *stream);


void setPackages(RvMdmTermClass* c);

//MARKA RvPhoneLink *rvPhoneLinkConstruct(RvPhoneLink *x, RvEppClientEndpoint *ece);
//MARKA void rvPhoneLinkDestruct(RvPhoneLink *x);
		   
void rvPhoneMgrOnUnregister(RvEppClient*            ec, 
                            RvEppClientEndpoint*    ece, 
                            void*                   data, 
                            char*                   params);

void rvPhoneMgrOnEvent(RvEppClient *ec, RvEppClientEndpoint *ece, const char *eventName,
					   char* eventParams, void *data);

RvBool rvPhoneMgrOnRegister( RvEppClientEndpoint *ece, void *params);


void rvIppSampleGatewayAddParam(RvMdmParameterList* list, char* paramName, char* paramValue);



#if defined(__cplusplus)
}
#endif

#endif
