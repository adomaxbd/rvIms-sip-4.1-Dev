/******************************************************************************
Filename:    IppSampleSipTlsClbks.c
Description: Implementations for user SIP TLS APIs
*******************************************************************************
                Copyright (c) 2005 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

/* Please note: here we use openSSL functions to load certificates and keys to TLS engines.
This is the reason than we include openSSL h file. 
The location of openSSL include directory and lib files should be predefined. 
Please also note that this application links with 
openSSL lib files libeay32.lib and ssleay32.lib */
#ifdef RV_CFLAG_TLS
#if (RV_TLS_TYPE == RV_TLS_OPENSSL)
#include <openssl/ssl.h>
#endif
#include "IppStdInc.h"
#include "IppSampleSipGateway.h"
#include "RvSipStack.h"
#include "RvSipCallLeg.h"
#include "RvSipContactHeader.h"
#include "RvSipRegClientTypes.h"
#include "rvcctext.h"
#include "rvansi.h"
#include "IppSampleSipUtils.h"
#include "sipRegClient.h"
#include "IppSampleSipTlsClbks.h"
#include "RvSipMid.h"
#ifdef SAMPLE_MWI
#include "IppSampleSipMWI.h"
#endif

#include <stdio.h>
#include <stdarg.h>

#include "rvstr.h"


extern RvIppSampleGateway		gw;

RvIppSipTlsExtClbks		userSipTlsExtClbks =
{
	/* RvIppSipTlsGetBufferCB				tlsGetBufferF; */
	userSipTlsGetBuffer,
	/* RvIppSipTlsPostConnectionAssertionCB	tlsPostConnectionAssertF; */
	userSipTlsPostConnectionAssertion
};

/******************************************************************************
*  userRegisterIppSipTlsExt
*  --------------------------------
*  General :       Register application sip TLS callbacks to IPP 
*                  
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:      None.
******************************************************************************/
void userRegisterIppSipTlsExt(void)
{
	rvIppSipTlsRegisterExtClbks(&userSipTlsExtClbks);
}

/******************************************************************************
*  loadSipStackTlsParams
*  --------------------------------
*  General :       Loads TLS  configuration param to Sip stack configuration 
*                  structure.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          
*                  params            - name of parameter
*                  val               - value of parameter
*				   stackCfg          - pointer to RvSipStackCfg structure
*  Output:         none.
******************************************************************************/
void loadSipStackTlsParams(char *params, char *val, RvSipStackCfg* stackCfg)
{
	RvUint32 tlsAddressIndex = 0;
	RvUint32 tlsPortIndex = 0;

	if(!strcmp(params,"numOfTlsAddresses") )
	{
		sscanf(val,"%d",&stackCfg->numOfTlsAddresses);
		/* Allocate memory to keep the TLS addresses and ports */
		RvSipMidInit();
		stackCfg->localTlsAddresses = RvSipMidMemAlloc(stackCfg->numOfTlsAddresses * sizeof(RvChar*));
		memset(stackCfg->localTlsAddresses, 0, stackCfg->numOfTlsAddresses * sizeof(RvChar*));
		stackCfg->localTlsPorts = RvSipMidMemAlloc(stackCfg->numOfTlsAddresses * sizeof(RvUint16));
		memset(stackCfg->localTlsPorts, 0, stackCfg->numOfTlsAddresses * sizeof(RvUint16));			
	}

	if(!strcmp(params,"localTlsAddresses") )
	{
	/* Each of the entries of localTlsAddresses must be allocated as well, in order to
		contain the requested IP address. */
		stackCfg->localTlsAddresses[tlsAddressIndex] = RvSipMidMemAlloc(sizeof(RvChar*) * strlen(val) + 1);
		rvStrCopy(stackCfg->localTlsAddresses[tlsAddressIndex],val);
		tlsAddressIndex++;
	}

	if(!strcmp(params,"localTlsPorts") )
	{
		RvUint32	tmp;
		sscanf(val,"%d",&tmp);
		stackCfg->localTlsPorts[tlsPortIndex] = (RvUint16)tmp;
		tlsPortIndex++;
	}

	if(!strcmp(params,"numOfTlsEngines") )
	{
		sscanf(val,"%d",&stackCfg->numOfTlsEngines);
	}

	if(!strcmp(params,"maxTlsSessions") )
	{
		sscanf(val,"%d",&stackCfg->maxTlsSessions);
	}
}

/******************************************************************************
*  getCAFileName
*  --------------------------------
*  General :       retrieves CA file name 
*                  .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          
*                  fileNameStr            - name of parameter
*                  caFileName             - value of parameter
*				 
*  Output:         none.
******************************************************************************/
static RvBool getCAFileName(IN char* fileNameStr, OUT char* caFileName)
{
	caFileName[0] = '\0';
	if (fileNameStr[0] == '\0')
		return rvFalse;

    /* the name is not empty */
	strncpy(caFileName, fileNameStr, FILENAME_LEN);
	caFileName[FILENAME_LEN-1]='\0';

	return rvTrue;
}

#if (RV_TLS_TYPE == RV_TLS_OPENSSL)
/* this code contains calls to openSSl */
/******************************************************************************
*  userSipTlsGetBuffer
*  --------------------------------
*  General :       Retrieves certificate or Key buffer
*                  .
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          
*                  bufferType            - type of buffer to retrieve
*
*  Output:         
*                  tlsBuffer             - placeholder for buffer
*				   tlsBufferLen          - length of buffer 
******************************************************************************/
RvBool userSipTlsGetBuffer(IN    RvIppTlsBufferType bufferType,
						 OUT	RvChar			*tlsBuffer, 
						 OUT	RvUint32		*tlsBufferLen)
{
	static RvUint32 caFileIndex = 0;

    BIO*			inKey          = NULL;
    BIO*			inCert         = NULL;
    EVP_PKEY*		pkey           = NULL;
    X509*			x509           = NULL;
    RvChar*			privKey        = NULL;
    RvChar*			keyEnd;
    RvInt			privKeyLen     = 0;
    RvChar*			cert          = NULL;
    RvChar*			certEnd;
    RvInt			certLen        = 0;
	char			caCertFileName[FILENAME_LEN]; 
	char            fileName[FILENAME_LEN];
	
	*tlsBufferLen = 0;


    /* loading key */
	switch (bufferType)
	{
	case IPP_TLS_SERVER_KEY_BUFFER:
		privKey = tlsBuffer;
		keyEnd = privKey;
		inKey=BIO_new(BIO_s_file_internal());
		strcpy(fileName, ROOT_DIR);
		strcat(fileName, gw.keyTlsCfg.privateKeyFileName);
		
		if (BIO_read_filename(inKey, fileName)  <= 0)
		{
			IppLogMessage(RV_TRUE, "rvIppTlsInit: BIO_read_filename() failed in case IPP_TLS_SERVER_KEY_BUFFER for file %s", fileName);
			return rvFalse;
		}

		pkey=PEM_read_bio_PrivateKey(inKey,NULL,NULL,NULL);
		if (NULL == pkey)
		{
			IppLogMessage(RV_TRUE, "rvIppTlsInit: PEM_read_bio_PrivateKey() failed for file %s", fileName);
			return rvFalse;
		}
		privKeyLen = i2d_PrivateKey(pkey,NULL);
		privKeyLen = i2d_PrivateKey(pkey,(unsigned char **)&keyEnd);
		BIO_free(inKey);
		*tlsBufferLen = privKeyLen;
		break;
	case IPP_TLS_SERVER_CA_BUFFER:
		cert = tlsBuffer;
		certEnd=cert;
		inCert=BIO_new(BIO_s_file_internal());

		strcpy(fileName, ROOT_DIR);
		strcat(fileName, gw.keyTlsCfg.privateKeyFileName);

		if (BIO_read_filename(inCert,fileName) <= 0)
		{
			IppLogMessage(RV_TRUE, "rvIppTlsInit:: BIO_read_filename() failed in case IPP_TLS_SERVER_CA_BUFFER for file %s", fileName);
			return rvFalse;
		}

		x509=PEM_read_bio_X509(inCert,NULL,NULL,NULL);
		if (NULL == x509)
		{
			IppLogMessage(RV_TRUE, "rvIppTlsInit:: PEM_read_bio_X509() failed  for file %s", fileName);
			return rvFalse;
		}

		certLen = i2d_X509(x509,NULL);
		certLen = i2d_X509(x509,(unsigned char **)&certEnd);
		BIO_free(inCert);
		*tlsBufferLen = certLen;
		break;

	case IPP_TLS_CLIENT_KEY_BUFFER:
		break;
	
	case IPP_TLS_CA_BUFFER:
		/* 
		   get a CA filenames from the GW list of names
		*/	
		if ((!getCAFileName(gw.keyTlsCfg.caCertFileName[caFileIndex], (char *)&caCertFileName))
		    || (caFileIndex == TLS_MAX_CA))
		{
			return rvFalse;
		}

		/* for adding the approving CA to the list of certificates */
		cert = tlsBuffer;
		certEnd=cert;
		certLen        = 0;
		x509           = NULL;
		memset(cert,0,sizeof(cert));
		
		/* loading certificate */
		inCert=BIO_new(BIO_s_file_internal());

		strcpy(fileName, ROOT_DIR);
		strcat(fileName, caCertFileName);

		if (BIO_read_filename(inCert, fileName) <= 0)
		{
			IppLogMessage(RV_TRUE, "rvIppTlsInit:: Can not load CA certificate from %s", fileName);
			return rvFalse ;
		}
		
		x509=PEM_read_bio_X509(inCert,NULL,NULL,NULL);
		
		certLen = i2d_X509(x509,NULL);
		certLen = i2d_X509(x509,(unsigned char **)&certEnd);
		BIO_free(inCert);
		*tlsBufferLen = certLen;
		caFileIndex++;
		
		break;
	default:
		;
	}

	return rvTrue;
} 
#endif

		

/******************************************************************************
*  userSipTlsPostConnectionAssertion
*  --------------------------------
*  General :  Asserts that the certificate on the connection was indeed given
*          to the computer we are connecting to.
*              In our sample we decide based on a configuration variable.    
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
* Input:     hConnection   - The handle of the connection that changed TLS state
*          hAppConnection - The application handle for the connection
*           strHostName   - A NULL terminated string, indicating the host name
*                          (IP/FQDN) that the connection was meant to connect to.
*          hMsg          - a message if the connection was asserted against a message.
* Output: pbAsserted     - Fill that boolean with the result of your assertion.
*                          RV_TRUE - indicated you asserted the connection, successfully.
*                          RV_FALSE - indicates the assertion failed. the connection
*                                     will be terminated automatically.

******************************************************************************/
void userSipTlsPostConnectionAssertion(IN    RvSipTransportConnectionHandle             hConnection,
									   IN    RvSipTransportConnectionAppHandle          hAppConnection,
									   IN    RvChar*                                   strHostName,
									   IN    RvSipMsgHandle                             hMsg,
									   OUT   RvBool*                                   pbAsserted)
{
	RV_UNUSED_ARG(hConnection);
    RV_UNUSED_ARG(hAppConnection);
    RV_UNUSED_ARG(strHostName);
	RV_UNUSED_ARG(hMsg);

	/* behavior as defined in the configuration file.*/
	*pbAsserted = gw.transportTlsCfg.tlsPostConnectAssertFlag;
}

#else /* RV_CFLAG_TLS */

static int sampleSipTlsClbks_dummy = 0;

#endif /* RV_CFLAG_TLS */
