/*
*********************************************************************************
*                                                                               *
* NOTICE:                                                                       *
* This document contains information that is confidential and proprietary to    *
* RADVision LTD.. No part of this publication may be reproduced in any form     *
* whatsoever without written prior approval by RADVision LTD..                  *
*                                                                               *
* RADVision LTD. reserves the right to revise this publication and make changes *
* without obligation to notify any person of such revisions or changes.         *
*********************************************************************************
*/


/*********************************************************************************
 *                              <RegExpMgr.h>
 *
 * Regular Expression resolver layer callback function wrappers
 *
 *    Author                         Date
 *    ------                        ------
 *    Udi Tir0sh                    Feb 2005
 *********************************************************************************/

#ifndef COMMONAPP_REGEXEMGR_H
#define COMMONAPP_REGEXEMGR_H

#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "RV_SIP_DEF.h"
#include "rpool_API.h"
#include "RvSipTransmitterTypes.h"
/*-------------------------------------------------------------------------*/
/*                        MACRO DEFINITION                                 */
/*-------------------------------------------------------------------------*/ 
/* How many characters in the character set.  */
# define CHAR_SET_SIZE 256

    /* We push at most this many items on the stack.  */
/* We used to use (num_regs - 1), which is the number of registers
   this regexp will save; but that was changed to 5
   to avoid stack overflow for a regexp with lots of parens.  */
#define MAX_FAILURE_ITEMS (5 * NUM_REG_ITEMS + NUM_NONREG_ITEMS)

    /* This is the number of items that are pushed and popped on the stack
   for each register.  */
#define NUM_REG_ITEMS  3

/* Individual items aside from the registers.  */
#ifdef DEBUG
# define NUM_NONREG_ITEMS 5 /* Includes failure point id.  */
#else
# define NUM_NONREG_ITEMS 4
#endif

/* Roughly the maximum number of failure points on the stack.  Would be
   exactly that if always used MAX_FAILURE_ITEMS items each time we failed.
   This is a variable only so users of regex can assign to it; we never
   change it ourselves.  */
#define re_max_failures 100

#define FAILSTACK_SIZE (2 * re_max_failures * MAX_FAILURE_ITEMS)
#define FAILSTACK_BUFF_SIZE (FAILSTACK_SIZE * sizeof (fail_stack_elt_t))

#define BUFPGETFAILSTACK(_bufp) (&(_bufp)->pMgr->fail_stack)

/*-----------------------------------------------------------------------*/
/*                          TYPE DEFINITIONS                             */
/*-----------------------------------------------------------------------*/


union fail_stack_elt
{
  unsigned char *pointer;
  int integer;
};

typedef union fail_stack_elt fail_stack_elt_t;

typedef struct
{
  fail_stack_elt_t *stack;
  unsigned size;
  unsigned avail;			/* Offset of next open position.  */
} fail_stack_type;

/* Declarations and macros for re_match_2.  */

typedef union
{
  fail_stack_elt_t word;
  struct
  {
      /* This field is one if this group can match the empty string,
         zero if not.  If not yet determined,  `MATCH_NULL_UNSET_VALUE'.  */
#define MATCH_NULL_UNSET_VALUE 3
    unsigned match_null_string_p : 2;
    unsigned is_active : 1;
    unsigned matched_something : 1;
    unsigned ever_matched_something : 1;
  } bits;
} register_info_type;

typedef struct
{
    RV_LOG_Handle hLog;
    HRPOOL        hBigPool;
    HRPOOL        hSmallPool;
    RvChar        re_syntax_table[CHAR_SET_SIZE];
    RvBool        syndone;
    /* Size with which the following vectors are currently allocated.
       That is so we can make them bigger as needed,
       but never make them smaller.  */
    RvInt        regs_allocated_size;
    /* If we cannot allocate large objects within re_match_2_internal,
       we make the fail stack and register vectors global.
       The fail stack, we grow to the maximum size when a regexp
       is compiled.
       The register vectors, we adjust in size each time we
       compile a regexp, according to the number of registers it needs.  */
    fail_stack_type fail_stack;

    /* in order to avoid allocation we staticly allocate a fail stack buffer */
    void*           failstackbuff[FAILSTACK_SIZE];
    char **         regstart,     ** regend;
    char **         old_regstart, ** old_regend;
    char **         best_regstart,**best_regend;
    register_info_type *reg_info;
    char **         reg_dummy;
    register_info_type *reg_info_dummy;
}RegExpMgr;

/*-----------------------------------------------------------------------*/
/*                          FUNCTIONS HEADERS                            */
/*-----------------------------------------------------------------------*/
/********************************************************************************************
 * RegExpMgrConstruct
 * purpose : starts the RegExp manager
 * input   : hLog - log handle
 * output  : pMgr - a reg exp manager
 * return  : RvStatus
 ********************************************************************************************/
 RvStatus  RVCALLCONV RegExpMgrConstruct(IN RV_LOG_Handle hLog,
                                                    OUT RegExpMgr**      pMgr);

/********************************************************************************************
 * RegExpMgrDestruct
 * purpose : destructs the RegExp manager
 * input   : pMgr - a reg exp manager
 * output  : 
 * return  : 
 ********************************************************************************************/
 void RVCALLCONV RegExpMgrDestruct(OUT RegExpMgr*      pMgr);

/********************************************************************************************
 * RegExpMgrMalloc
 * purpose : allocates memory
 * input   : pMgr - pointer to RegExpMgr
 *           size - size of allocation
 * output  : -
 * return  : allocated memory is successful, NULL on failure
 ********************************************************************************************/
 void*  RVCALLCONV RegExpMgrMalloc(IN RegExpMgr* pMgr, IN RvSize_t size);

/********************************************************************************************
 * RegExpMgrRealloc
 * purpose : reallocates allocates memory
 * input   : pMgr - pointer to RegExpMgr
 *           paddr - address previously allocated with RegExpMgrMalloc()
 *           size - size of allocation
 * output  : -
 * return  : allocated memory is successful, NULL on failure
 ********************************************************************************************/
 void*  RVCALLCONV RegExpMgrRealloc(IN RegExpMgr* pMgr, IN void* paddr, IN RvSize_t size);

/********************************************************************************************
 * RegExpMgrFree
 * purpose : frees memory allocated with RegExpMgrMalloc
 * input   : pMgr - pointer to RegExpMgr
 *           paddr - address previously allocated with RegExpMgrMalloc()
 * output  : -
 * return  : -
 ********************************************************************************************/
 void  RVCALLCONV RegExpMgrFree(IN RegExpMgr* pMgr, IN void* paddr);

/********************************************************************************************
 * RegExpMgrReset
 * purpose : frees all memory allocated by a regular expression
 * input   : pMgr - pointer to RegExpMgr
 *           size - size of allocation
 * output  : -
 * return  : allocated memory is successful, NULL on failure
 ********************************************************************************************/
 void RVCALLCONV RegExpMgrReset(IN RegExpMgr* pMgr);

/***************************************************************************
 * RegExpMgrRegExecResult
 * ------------------------------------------------------------------------
 * General: compiles a regular expression, performs the regexp and frees 
 *          space allocated by the regular expression
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: pMgr           - regexp manager
 *        strRegexp      - a regular expression from NAPTR query.
 *        strString      - the string to apply the regexp on
 *        matchSize      - the size of the pMatchArray
 *        eFlags         - flags to take in account when applying the 
 *                         regular expression
 * Output:pMatches       - The pMatchArray should be filled in by 
 *                         RvSipResolverRegExpResolutionNeededEv with substring 
 *                         match addresses.  Any unused structure elements 
 *                         should contain the value -1.
 *                         Each startOffSet element that is not -1 indicates 
 *                         the start offset of the next largest substring match 
 *                         within the string. The relative endOffSet element 
 *                         indicates the end offset of the match. 
 ***************************************************************************/
 RvStatus RVCALLCONV  RegExpMgrRegExecResult(
                     IN  RegExpMgr*                 pMgr,
                     IN  const RvChar*              strRegexp,
                     IN  const RvChar*              strString,
                     IN  RvInt32                    matchSize,
                     IN  RvSipTransmitterRegExpFlag    eFlags,
                     OUT RvSipTransmitterRegExpMatch*  pMatches);

#ifdef __cplusplus
}
#endif

#endif /* END OF: #ifndef COMMONAPP_REGEXEMGR_H*/

