/*
*********************************************************************************
*                                                                               *
* NOTICE:                                                                       *
* This document contains information that is confidential and proprietary to    *
* RADVision LTD.. No part of this publication may be reproduced in any form     *
* whatsoever without written prior approval by RADVision LTD..                  *
*                                                                               *
* RADVision LTD. reserves the right to revise this publication and make changes *
* without obligation to notify any person of such revisions or changes.         *
*********************************************************************************
*/


/*********************************************************************************
 *                              <RegExpMgr.c>
 *
 * Regular Expression resolver layer callback function wrappers
 *
 *    Author                         Date
 *    ------                        ------
 *    Udi Tir0sh                    Feb 2005
 *********************************************************************************/


/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "RV_SIP_DEF.h"
#include "AppRegExpMgr.h"
#include "AppRegex.h"
#include "RvSipMid.h"
/*-------------------------------------------------------------------------*/
/*                        MACRO DEFINITIONS                                */
/*-------------------------------------------------------------------------*/
#define REGEXP_POOL_BIG_PAGE_SIZE       700
#define REGEXP_POOL_BIG_NUM_OF_PAGES    3
#define REGEXP_POOL_BIG_NAME            "RegExpBig"
#define REGEXP_POOL_SMALL_PAGE_SIZE     100
#define REGEXP_POOL_SMALL_NUM_OF_PAGES  20
#define REGEXP_POOL_SMALL_NAME          "RegExpSml"
/*-------------------------------------------------------------------------*/
/*                           MODULE FUNCTIONS                              */
/*-------------------------------------------------------------------------*/
/********************************************************************************************
 * RegExpMgrConstruct
 * purpose : starts the RegExp manager
 * input   : hLog - log handle
 * output  : pMgr - a reg exp manager
 * return  : RvStatus
 ********************************************************************************************/
 RvStatus  RVCALLCONV RegExpMgrConstruct(IN RV_LOG_Handle hLog,
                                                    OUT RegExpMgr**      pMgr)
{
    RegExpMgr*      pMgrInternal = NULL;

    pMgrInternal = RvSipMidMemAlloc(sizeof(RegExpMgr));
    if (NULL == pMgrInternal)
    {
        return RV_ERROR_UNKNOWN;
    }
    memset(pMgrInternal,0,sizeof(RegExpMgr));
    pMgrInternal->hLog = hLog;

    pMgrInternal->hBigPool = RPOOL_Construct(REGEXP_POOL_BIG_PAGE_SIZE,REGEXP_POOL_BIG_NUM_OF_PAGES,pMgrInternal->hLog,RV_TRUE,REGEXP_POOL_BIG_NAME);
    if (NULL == pMgrInternal->hBigPool)
    {
        RvSipMidMemFree(pMgrInternal);
        return RV_ERROR_UNKNOWN;
    }
    pMgrInternal->hSmallPool = RPOOL_Construct(REGEXP_POOL_SMALL_PAGE_SIZE,REGEXP_POOL_SMALL_NUM_OF_PAGES,pMgrInternal->hLog,RV_TRUE,REGEXP_POOL_SMALL_NAME);
    if (NULL == pMgrInternal->hSmallPool)
    {
        RegExpMgrDestruct(pMgrInternal);
        return RV_ERROR_UNKNOWN;
    }

    *pMgr = pMgrInternal;
    return RV_OK;
}

/********************************************************************************************
 * RegExpMgrDestruct
 * purpose : destructs the RegExp manager
 * input   : pMgr - a reg exp manager
 * output  : 
 * return  : 
 ********************************************************************************************/
 void RVCALLCONV RegExpMgrDestruct(OUT RegExpMgr*      pMgr)
{
    if (NULL == pMgr)
    {
        return;
    }
    if (NULL != pMgr->hBigPool)
    {
        RPOOL_Destruct(pMgr->hBigPool);
        pMgr->hBigPool = NULL;
    }
    if (NULL != pMgr->hSmallPool)
    {
        RPOOL_Destruct(pMgr->hSmallPool);
        pMgr->hSmallPool = NULL;
    }
    RvSipMidMemFree((void*)pMgr);
}

/********************************************************************************************
 * RegExpMgrMalloc
 * purpose : allocates memory
 * input   : pMgr - pointer to RegExpMgr
 *           size - size of allocation
 * output  : -
 * return  : allocated memory is successful, NULL on failure
 ********************************************************************************************/
 void*  RVCALLCONV RegExpMgrMalloc(IN RegExpMgr* pMgr, IN RvSize_t size)
{
    void*       allocation  = NULL;
    HPAGE       hPage       = NULL_PAGE;
    RvStatus    rv          = RV_OK;  
    RvInt32     offset      = 0;
    HRPOOL      hAllocPool  = NULL;
    
    if (REGEXP_POOL_SMALL_PAGE_SIZE > size)
        hAllocPool = pMgr->hSmallPool;
    else if (REGEXP_POOL_BIG_PAGE_SIZE > size)
        hAllocPool = pMgr->hBigPool;
    else
        return NULL;

    rv = RPOOL_GetPage(hAllocPool,0,&hPage);
    if (RV_OK != rv)
        return NULL;
    
    allocation = RPOOL_AlignAppend(pMgr->hBigPool,hPage,REGEXP_POOL_BIG_PAGE_SIZE,&offset);
    return allocation;   
}

/********************************************************************************************
 * RegExpMgrRealloc
 * purpose : reallocates allocates memory
 * input   : pMgr - pointer to RegExpMgr
 *           paddr - address previously allocated with RegExpMgrMalloc()
 *           size - size of allocation
 * output  : -
 * return  : allocated memory is successful, NULL on failure
 ********************************************************************************************/
 void*  RVCALLCONV RegExpMgrRealloc(IN RegExpMgr* pMgr, IN void* paddr, IN RvSize_t size)
{
    RV_UNUSED_ARG(pMgr);
    if (REGEXP_POOL_BIG_PAGE_SIZE < size)
        return paddr;
    else
        return NULL;
}

/********************************************************************************************
 * RegExpMgrFree
 * purpose : frees memory allocated with RegExpMgrMalloc
 * input   : pMgr - pointer to RegExpMgr
 *           paddr - address previously allocated with RegExpMgrMalloc()
 * output  : -
 * return  : -
 ********************************************************************************************/
 void  RVCALLCONV RegExpMgrFree(IN RegExpMgr* pMgr, IN void* paddr)
{
    RV_UNUSED_ARG(pMgr);
    RV_UNUSED_ARG(paddr);
}

/********************************************************************************************
 * RegExpMgrReset
 * purpose : frees all memory allocated by a regular expression
 * input   : pMgr - pointer to RegExpMgr
 *           size - size of allocation
 * output  : -
 * return  : allocated memory is successful, NULL on failure
 ********************************************************************************************/
 void RVCALLCONV RegExpMgrReset(IN RegExpMgr* pMgr)
{
    RPOOL_FreeAllPages(pMgr->hBigPool);
    RPOOL_FreeAllPages(pMgr->hSmallPool);
}

/***************************************************************************
 * RegExpMgrRegExecResult
 * ------------------------------------------------------------------------
 * General: compiles a regular expression, performs the regexp and frees 
 *          space allocated by the regular expression
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: pMgr           - regexp manager
 *        strRegexp      - a regular expression from NAPTR query.
 *        strString      - the string to apply the regexp on
 *        matchSize      - the size of the pMatchArray
 *        eFlags         - flags to take in account when applying the 
 *                         regular expression
 * Output:pMatches       - The pMatchArray should be filled in by 
 *                         RvSipResolverRegExpResolutionNeededEv with substring 
 *                         match addresses.  Any unused structure elements 
 *                         should contain the value -1.
 *                         Each startOffSet element that is not -1 indicates 
 *                         the start offset of the next largest substring match 
 *                         within the string. The relative endOffSet element 
 *                         indicates the end offset of the match. 
 ***************************************************************************/
 RvStatus RVCALLCONV  RegExpMgrRegExecResult(
                     IN  RegExpMgr*                 pMgr,
                     IN  const RvChar*              strRegexp,
                     IN  const RvChar*              strString,
                     IN  RvInt32                    matchSize,
                     IN  RvSipTransmitterRegExpFlag    eFlags,
                     OUT RvSipTransmitterRegExpMatch*  pMatches)
{
    regex_t     regExp;
    RvInt       cflags          = 0;
    RvInt       ret             = 0;
    regmatch_t* pInternalMatch  = NULL;
    RvInt32     i               = 0;
    RvStatus    rv              = RV_OK;
    
    /* we are always dealing with extended regexp for resolver*/
    cflags |= REG_EXTENDED; 
    
    /* see if we need a caseless compare*/
    cflags |= (RVSIP_TRANSMITTER_REGEXP_FLAG_NO_CASE&eFlags)? REG_ICASE : 0;
    
    pInternalMatch = RegExpMgrMalloc(pMgr,matchSize*sizeof(regmatch_t));
    ret = CaRegcomp(pMgr,&regExp,strRegexp,cflags);
    if (0 != ret)
    {
        CaRegfree(&regExp);
        return RV_ERROR_UNKNOWN;
    }

    ret = CaRegexec(&regExp,strString,matchSize,pInternalMatch,0);
    if (0 != ret)
    {
        CaRegfree(&regExp);
        return RV_ERROR_UNKNOWN;
    }

    for (i=0;i<matchSize;i++)
    {
        pMatches[i].startOffSet = pInternalMatch[i].rm_so;
        pMatches[i].endOffSet   = pInternalMatch[i].rm_eo;
    }
    
    CaRegfree(&regExp);
    RegExpMgrReset(pMgr);
    return rv;
}
