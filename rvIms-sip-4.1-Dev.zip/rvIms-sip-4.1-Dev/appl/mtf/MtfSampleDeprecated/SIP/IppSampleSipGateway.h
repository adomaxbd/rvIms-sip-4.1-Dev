/******************************************************************************
Filename:    IppSampleSipGateway.h
Description: Sample gateway for SIP Phone
*******************************************************************************
                Copyright (c) 2001 RADVision Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVision LTD.

RADVision LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#ifndef RV_SIPGATEWAY_H
#define RV_SIPGATEWAY_H

#include "rvstring.h"
#include "IppSampleGatewayBase.h"
#include "IppSamplePhoneLink.h"
#include "RvSipStackTypes.h"
#include "RvSipMsgTypes.h"
#include "rvSipControlApi.h"

#ifdef RV_CFLAG_TLS
#include "rvSipTlsApi.h"
#include "IppSampleSipTls.h"
#endif

#ifdef RV_MTF_STUN
#include "rvSipStunApi.h"
#endif

#include "AppRegExpMgr.h"

#if defined(__cplusplus)
extern "C" {
#endif

#if(RV_OS_TYPE == RV_OS_TYPE_WINCE)
#define SIP_CONFIGURATION_PATH "\\Program Files\\MtfSipSample\\SIP\\SIPPhone.cfg"
#define MTF_LOG_PATH "\\Program Files\\MtfSipSample\\MtfLog.txt"
/* In WinCE the TLS certificate files should be placed in ROOT_DIR. In the config file
   only the file name should be provided e.g: privateKeyFileName=mycert.com.key-cert.pem.
   The reson is that while parsing the SIPPhone config file the white space in 'Program Files' causes
   partial parsing of the path  */
#define ROOT_DIR  "\\Program Files\\MtfSipSample\\"
#else
#define SIP_CONFIGURATION_PATH "./SIPPhone.cfg"
#define MTF_LOG_PATH "./MtfLog.txt"
#define ROOT_DIR ""
#endif

#define SIP_CONFIGURATION_FILE_SIZE 16000


typedef struct
{
	RvIppSampleGatewayBase		gatewayBase;
	RvString					userDomain;
	RvIppSipLogOptions			logOptions;
	RvSipStackHandle			stackHandle;
	RvString					registrarAddress;
	RvUint16					registrarPort;
	RvString					outboundProxyAddress;
	RvUint16					outboundProxyPort;
#ifdef RV_MTF_STUN
	RvString					stunNeedMask;
	RvChar                      stunServerAddress[64]; /* Address of the STUN server */
	RvUint16					stunServerPort; /* Port of the STUN server */
	RvUint16					stunClientResponsePort; /* Port receiving STUN response messages */
	RvIppStunMgrHandle			stunMgrHndl; /* MTF STUN object to use */
#endif
	RvString					username;		/*For Authentication*/
	RvString					password;		/*For Authentication*/
	RvSipTransport				transportType;
	RvUint16					stackTcpPort;
	RvUint16					stackUdpPort;
	RvString					uiAlias;
    int							maxRegClients;
    RvBool						autoRegister;
    RvInt32						registrationExpire;
    RvInt32						unregistrationExpire;
	RvInt32                     maxAuthenticateRetries; /* how many times we should respond to consequent 401/407 msgs */
#ifdef RV_SIP_IMS_ON
	RvBool						disableAkaAuthentication;
	RvBool				        isAkaAuthOpConfigured;
	RvUint8                     akaAuth_op[AKA_OP_ARRAY_SIZE];
#endif
    RvInt32						referTimeout;
    RvBool						tcpEnabled;
	RvCallWaitingReply			callWaitingReply; /*reply on call waiting - 180(Ringing) or 182(Queued)*/
	RvUint32					watchdogTimeout; /* if positive will start timer for sip resources printing*/
    RvBool                      connectMediaOn180; /* When True, media will be connected both in 180, 183 and 200,
                                                      when False, media will be connect in 183 and 200 only*/
	RvBool                      addUpdateSupport;
	RvUint8                     updateRetryAfterTimeout;
	RvUint16                    callerUpdateResendTimeout;
	RvUint16                    calleeUpdateResendTimeout;
/* For ENUM/Tel-URI: Pointer to an applicative regular expression resolver manager.
   we use this manager when we want to resolve a regular expression. */
    RegExpMgr*                  regExpMgr;
#ifdef SAMPLE_MWI
	RvString					subsServerName;
#endif

#ifdef RV_CFLAG_TLS
	RvIppTransportTlsCfg		transportTlsCfg;
	RvIppKeyTlsCfg				keyTlsCfg;
#endif

} RvIppSampleGateway;

#define rvIppSampleGatewayGetSipBase(gw) (&(gw).gatewayBase);
RvIppSampleGateway *rvIppSipSampleGatewayConstruct(RvIppSampleGateway *gw, char* configBuf);
void rvIppSipSampleGatewayDestruct(RvIppSampleGateway *gw);

#if defined(__cplusplus)
}
#endif

#endif /*RV_SIPGATEWAY_H*/
