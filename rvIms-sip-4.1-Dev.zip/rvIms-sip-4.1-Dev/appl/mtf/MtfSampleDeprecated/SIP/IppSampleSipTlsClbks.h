/******************************************************************************
Filename:    IppSampleSipTlsClbks.h
Description: User Callbacks Header
*******************************************************************************
                Copyright (c) 2005 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever 
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#ifdef RV_CFLAG_TLS
#ifndef USER_TLS_CLBKS_H
#define USER_TLS_CLBKS_H

#include "rvSipTlsApi.h"

void loadSipStackTlsParams(char* params, char* var,  RvSipStackCfg* stackCfg);


void userRegisterIppSipTlsExt(void);


RvBool userSipTlsGetBuffer(IN    RvIppTlsBufferType bufferType,
						 OUT	RvChar			*tlsBuffer, 
						 OUT	RvUint32		*tlsBufferLen);

void userSipTlsPostConnectionAssertion(IN    RvSipTransportConnectionHandle		hConnection,
									   IN    RvSipTransportConnectionAppHandle	hAppConnection,
									   IN    RvChar*							strHostName,
									   IN    RvSipMsgHandle						hMsg,
									   OUT   RvBool*							pbAsserted);


#endif /*USER_TLS_CLBKS_H*/
#endif /* RV_CFLAG_TLS */
