/******************************************************************************
Filename:    IppSampleSipMWI.h
Description: Sample Message waiting Indication for SIP Phone
*******************************************************************************
                Copyright (c) 2005 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

#ifndef RV_SAMPLE_MWI_H
#define RV_SAMPLE_MWI_H

#include "RvSipStackTypes.h"

typedef struct
{
    RvSipStackHandle        stackHandle;
    RvChar*                 localAddress;
    RvString                registrarAddress;
    RvUint16                registrarPort;
    int                     stackUdpPort;
    RvString                uiAlias;
    RvString                subsServerName; /*like MWI@172.20.1.244:5060*/
} RvIppSampleSipMwiCfg;


/* Set subscription related parameters of Sip stack */
void rvIppSampleSipMwiSetStackCfg( RvSipStackCfg* stackCfg);

/*  Start subscription per terminal.
 *  Can support maximum 1 terminal currently */
void rvIppSampleSipMwiRegisterMdmTerm( RvMdmTerm*   termination);
void rvIppSampleSipMwiInit( RvIppSampleSipMwiCfg* subsCfg );

void rvIppSampleSipMwiEnd(void);

#endif/*RV_SAMPLE_MWI_H*/
