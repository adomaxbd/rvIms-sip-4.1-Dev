/******************************************************************************
Filename:    rvMtfSampleCfw.h
*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#include "IppStdInc.h"
#include "rvMtfSample.h"
#include "rvstr.h"

#ifndef RV_SAMPLECFW_H
#define RV_SAMPLECFW_H

#if defined(__cplusplus)
extern "C" {
#endif

void rvIppSampleCfwActivateCompletedCB(
				RvIppTerminalHandle		term,
				RvIppCfwType			cfwType,
				char*					cfwDestination,
				RvIppCfwReturnReasons	returnCode);

void rvIppSampleCfwDeactivateCompletedCB(
				RvIppTerminalHandle		term,
				RvIppCfwType 	 		cfwType,
				RvIppCfwReturnReasons	returnCode);


#if defined(__cplusplus)
}
#endif

#endif /*RV_SAMPLECFW_H*/
