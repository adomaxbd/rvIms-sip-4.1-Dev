/******************************************************************************
Filename:    rvMtfSampleMWI.h
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#ifndef RV_SAMPLE_MWI_H
#define RV_SAMPLE_MWI_H

#include "RvSipStackTypes.h"
#include "rvstring.h"
#include "rvMtfHandles.h"

typedef struct
{
    RvSipStackHandle        stackHandle;
    RvChar*                 localAddress;
    RvString                registrarAddress;
    RvUint16                registrarPort;
    int                     stackUdpPort;
    RvString                user;
    RvString                subsServerName; /*like MWI@172.20.1.244:5060*/
} RvIppSampleSipMwiCfg;


/* Set subscription related parameters of Sip stack */
void rvIppSampleSipMwiSetStackCfg( RvSipStackCfg* stackCfg);

/*  Start subscription per terminal.
 *  Can support maximum 1 terminal currently */
void rvMtfSampleSipSendSubscribe( RvIppTerminalHandle  termination);
void rvMtfSampleSipMwiInit( RvIppSampleSipMwiCfg* subsCfg );

void rvMtfSampleSipMwiEnd(void);

#endif/*RV_SAMPLE_MWI_H*/
