/******************************************************************************
Filename:    rvMtfSampleMWI.c
Description: This file contains a sample code for implementing Message Waiting Indication 
			 (MWI) over MTF.
             The sample provides a complete example of how to:
                1. Register application subscription callbacks.
                2. Implement subscription application callback.
                3. Initiate an independent subscription, using SUBSCRIBE request.
                4. Send a notify request after accepting the subscription.
                5. Refresh the subscription, when alert is given at first time.
                6. Unsubscribe the subscription, when alert is given at second time.
                7. Send a notify (terminated) request, when accepting the unsubscribe request.
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "rvtypes.h"

#ifdef SAMPLE_MWI
/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "IppStdInc.h"
#include "rvMtfSampleMWI.h"
#include "rvMtfSampleEpp.h"
#include "rvMtfExtControlApi.h"
#include "RvSipBody.h"
#include "rveppclient.h"
#include "RvSipBodyPart.h"
#include "RV_SIP_DEF.h"

#ifndef RV_SIP_PRIMITIVES
#if (RV_OS_TYPE == RV_OS_TYPE_INTEGRITY)
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdarg.h>
#include "RvSipStackTypes.h"
#include "RvSipStack.h"
#include "RvSipSubscriptionTypes.h"
#include "RvSipSubscription.h"
#include "RvSipSubscriptionStateHeader.h"
#include "RvSipMid.h"

#ifdef RV_MTF_STUN
#include  "sipStun.h"
#endif

#ifdef __VXWORKS__
#include <vxWorks.h>
#include <taskLib.h>
#include <time.h>
#endif
#ifdef UNDER_CE
#include "simpleOSUtils.h"
#endif

#ifdef EXPRESS_EXTRA_LEAN
#error "Cannot compile simpleSubscription in extra lean mode"
#endif


/*-----------------------------------------------------------------------*/
/*                           INTERNAL TYPES                              */
/*-----------------------------------------------------------------------*/
typedef struct
{
    RvSipStackHandle stackHandle;
    RvChar          localAddress[64];
    RvChar          registrarAddress[64];
    RvUint16        registrarPort;
    int             stackUdpPort;
    RvChar          user[64];
    RvChar          subsServerName[128];
    RvChar          from[128];
    RvChar          to[128];

} RvIppSampleSipMwiCfgInternal;

typedef struct
{
    RvIppTerminalHandle			term;
    RvSipSubsHandle				hSubs;
}SubscribePerTerminal;
/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/
/*Define the To, From, and Event headers values as strings*/
#define EVENT "message-summary"

/*Define the expires header value to use in initial subscribe and in refresh */
#define EXPIRES 100
#define REFRESH_EXPIRES 50

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/
static RvIppSampleSipMwiCfgInternal g_cfg;

static SubscribePerTerminal         g_subsPerTerm[1];
/*Handle to the subscription manager. You can get this handle by calling
  RvSipStackGetSubsMgrHandle. You should supply this handle when
  using the subscription manager API functions.*/
static RvSipSubsMgrHandle g_hSubsMgr  = NULL;

/*Handle to the log-module. You can get this handle by calling
  RvSipStackGetLogHandle. You need this value in order to construct the application
  memory pool.*/
static RV_LOG_Handle         g_hLog         = NULL;

/*Handle to the application memory pool. The application should construct its own
  memory using rpool API. The pool is needed for encoding messages or message
  parts. (See AppPrintMessage() )*/
static HRPOOL                g_appMwiPool      = NULL;

/*Boolean indicates wether it is time to send an unsubscribe request.
  it is set to true, after first refresh subscribe is sent. */
static RV_BOOL               bSendUnsubscribe = RV_FALSE;
/*-----------------------------------------------------------------------*/
/*                        STATIC FUNCTIONS PROTOTYPES                    */
/*-----------------------------------------------------------------------*/
static void sampleSubscribe( SubscribePerTerminal* subsPerTerm);

static void AppPrintMessage(IN RvSipMsgHandle hMsg);

/*---- E V E N T    H A N D L E R S   I M P L M E N T A T I O N ----------*/
static void RVCALLCONV AppSubsCreatedEvHandler(
                                               IN  RvSipSubsHandle    hSubs,
                                               IN  RvSipCallLegHandle hCallLeg,
                                               IN  RvSipAppCallLegHandle hAppCallLeg,
                                               OUT RvSipAppSubsHandle *phAppSubs);

static void RVCALLCONV AppSubsStateChangedEvHandler(
                                    IN  RvSipSubsHandle            hSubs,
                                    IN  RvSipAppSubsHandle         hAppSubs,
                                    IN  RvSipSubsState             eState,
                                    IN  RvSipSubsStateChangeReason eReason);

static void RVCALLCONV AppSubsNotifyEvHandler( IN  RvSipSubsHandle    hSubs,
                                       IN  RvSipAppSubsHandle hAppSubs,
                                       IN  RvSipNotifyHandle  hNotification,
                                       IN  RvSipAppNotifyHandle  hAppNotification,
                                       IN  RvSipSubsNotifyStatus eNotifyStatus,
                                       IN  RvSipSubsNotifyReason eNotifyReason,
                                       IN  RvSipMsgHandle     hNotifyMsg);

static RvStatus RVCALLCONV AppSubsMsgReceivedEvHandler(
                                    IN  RvSipSubsHandle      hSubs,
                                    IN  RvSipAppSubsHandle   hAppSubs,
                                    IN  RvSipNotifyHandle    hNotify,
                                    IN  RvSipAppNotifyHandle hAppNotify,
                                    IN  RvSipMsgHandle       hMsg);

static RvStatus RVCALLCONV AppSubsMsgToSendEvHandler(
                                  IN  RvSipSubsHandle      hSubs,
                                  IN  RvSipAppSubsHandle   hAppSubs,
                                  IN  RvSipNotifyHandle    hNotify,
                                  IN  RvSipAppNotifyHandle hAppNotify,
                                  IN  RvSipMsgHandle       hMsg);
/*
static void RVCALLCONV AppSubsSubscriptionExpiredEvHandler(
                                    IN  RvSipSubsHandle            hSubs,
                                    IN  RvSipAppSubsHandle         hAppSubs);
*/
static void RVCALLCONV AppSubsExpirationAlertEvHandler(
                                    IN  RvSipSubsHandle            hSubs,
                                    IN  RvSipAppSubsHandle         hAppSubs);


static RV_Status handleNotification(RvSipMsgHandle      hMsg);

/*--------------------U T I L I T Y   F U N C T I O N S -------------------*/

static const RvChar*  AppGetSubsStateName (
                           IN  RvSipSubsState  eState);


static int  OSPrintf(IN const char *format,... );


/*===============================================================================*/
/*===================    S U B S C R I B E    F U N C T I O N S    ==============*/
/*===============================================================================*/

/***************************************************************************
 * rvIppSampleSipMwiSetStackCfg
 * ------------------------------------------------------------------------
 * General: Initializing the stack and allocating the application memory pool.
 *          When initializing we first set the configuration struct to the
 *          default values and then change some of the configuration parameters.
 *          We then use RvSipStackConstruct to initialize the stack.
 ***************************************************************************/
void rvIppSampleSipMwiSetStackCfg( RvSipStackCfg* stackCfg)
{
    stackCfg->maxSubscriptions = 5;
    stackCfg->subsAutoRefresh = RV_FALSE;
}

/***************************************************************************
 * rvMtfSampleSipMwiInit
 * ------------------------------------------------------------------------
 * General: Set application call back functions in the subscription manager.
 *          Also initializes a few internal handles
 ***************************************************************************/
void rvMtfSampleSipMwiInit( RvIppSampleSipMwiCfg* subsCfg )
{
    RV_Status rv;
    RvSipSubsEvHandlers appEvHandlers;

    /*store cfg data*/
    g_cfg.stackHandle               = subsCfg->stackHandle          ;
    strcpy(g_cfg.localAddress,      subsCfg->localAddress)          ;
    strcpy(g_cfg.registrarAddress,  subsCfg->registrarAddress)      ;
    g_cfg.registrarPort             = subsCfg->registrarPort        ;
    g_cfg.stackUdpPort              = subsCfg->stackUdpPort         ;
    strcpy(g_cfg.user,				subsCfg->user)       ;
    strcpy(g_cfg.subsServerName,    subsCfg->subsServerName)        ;

    if(strcmp(subsCfg->registrarAddress,""))
        sprintf( g_cfg.from, "sip:%s@%s:%d", subsCfg->user,subsCfg->registrarAddress, ((subsCfg->registrarPort)? subsCfg->registrarPort :5060) );
    else
        sprintf( g_cfg.from, "sip:%s@%s:%d", subsCfg->user,subsCfg->localAddress, subsCfg->stackUdpPort );

    sprintf( g_cfg.to, "sip:%s", g_cfg.subsServerName);


    /*getting handles for the internal modules*/
    RvSipStackGetSubsMgrHandle(g_cfg.stackHandle, &g_hSubsMgr);

    /*getting handles for the internal modules*/
    RvSipStackGetSubsMgrHandle(g_cfg.stackHandle, &g_hSubsMgr);
    RvSipStackGetLogHandle(g_cfg.stackHandle,&g_hLog);


    /*Construct a pool of memory for the application.
    * We're forced to construct one here because there is no access to such an object
    * constructed in sipMgr.c file of Toolkit
    */
    g_appMwiPool = RPOOL_Construct(1024,10,g_hLog,RV_FALSE,"ApplicationPool");


    /*Reset the appEvHandlers since not all callbacks are set by this sample*/
    memset(&appEvHandlers,0,sizeof(RvSipSubsEvHandlers));

    /*Set application callbacks in the structure*/
    appEvHandlers.pfnSubsCreatedEvHandler  = AppSubsCreatedEvHandler;
    appEvHandlers.pfnStateChangedEvHandler = AppSubsStateChangedEvHandler;
    appEvHandlers.pfnMsgReceivedEvHandler  = AppSubsMsgReceivedEvHandler;
    appEvHandlers.pfnMsgToSendEvHandler    = AppSubsMsgToSendEvHandler;
    appEvHandlers.pfnNotifyEvHandler       = AppSubsNotifyEvHandler;
    appEvHandlers.pfnExpirationAlertEvHandler = AppSubsExpirationAlertEvHandler;

    /*Set the structure in the subscription manager*/
    rv = RvSipSubsMgrSetEvHandlers(g_hSubsMgr,
                                      &appEvHandlers,
                                      sizeof(RvSipSubsEvHandlers));
    if(rv != RV_OK)
    {
        IppLogMessage(RV_TRUE, "Sample Subs::Failed to set application callbacks");
    }

}

void rvMtfSampleSipMwiEnd(void)
{
    RPOOL_Destruct(g_appMwiPool);
}


/*
 *  Start subscription per terminal.
 *  Can support maximum 1 terminal currently
 */
void rvMtfSampleSipSendSubscribe( RvIppTerminalHandle   termination)
{
    g_subsPerTerm[0].term = termination;

    /*3. Create a subscription.*/
    if ((termination) && (strcmp(g_cfg.subsServerName, "")))
    {
        sampleSubscribe( &g_subsPerTerm[0]);
    }
}


/***************************************************************************
 * sampleSubscribe
 * ------------------------------------------------------------------------
 * General: Create a subscription.
 *          To Create a subscription the application should:
 *          1. create a new subscription using RvSipSubsMgrCreateSubscription().
 *          2. call RvSipSubsInitStr(), to set mandatory parameters.
 *          3. call RvSipSubsSubscribe(). This will cause the subscribe message
 *             to be sent to the destination.
 *----------------------------------------------------------------------
 *
 ***************************************************************************/

static void sampleSubscribe( SubscribePerTerminal* subsPerTerm)
{
    RvSipSubsHandle         hSubs;
    RvStatus               rv;

    /*--------------------------
      creating a new subscription
    ----------------------------*/
    rv = RvSipSubsMgrCreateSubscription(g_hSubsMgr, NULL, NULL, &hSubs);
    if(rv != RV_OK)
    {
        IppLogMessage(RV_TRUE, "Sample Subs::Failed to create new subscription");
        return;
    }
    IppLogMessage(RV_FALSE, "Sample Subs::Subscriber subscription %x was created\n\n",(int)hSubs);

    /*------------------------------------------------------------
      Call the init function with the To and From addresses, event
      and expires values, in order to init and send the subscription.
    -------------------------------------------------------------*/
    rv = RvSipSubsInitStr(hSubs, g_cfg.from, g_cfg.to, EXPIRES, EVENT);
    if(rv != RV_OK)
    {
        IppLogMessage(RV_TRUE, "Sample Subs::Subscription init failed.");
        return;
    }

    IppLogMessage(RV_FALSE, "Sample Subs::Sending SUBSCRIBE: \n\t%s -> %s\n\n", g_cfg.from, g_cfg.to);
    rv = RvSipSubsSubscribe(hSubs);
    if(rv != RV_OK)
    {
        IppLogMessage(RV_TRUE, "Sample Subs::subscribing failed.");
        return;
    }

    subsPerTerm->hSubs = hSubs;
}

/*===============================================================================*/
/*==============    C A L L B A C K     I M P L E M E N T A T I O N S  ==========*/
/*===============================================================================*/
/***************************************************************************
 * AppSubsCreatedEvHandler
 * ------------------------------------------------------------------------
 * General:  Notifies that a new subscription was created.
 *           This application does not exchange handles with the subscription.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs - The new sip stack subscription handle
 * Output:  phAppSubs - The application handle for this subscription.
 ***************************************************************************/
static void RVCALLCONV AppSubsCreatedEvHandler(
                                               IN  RvSipSubsHandle    hSubs,
                                               IN  RvSipCallLegHandle hCallLeg,
                                               IN  RvSipAppCallLegHandle hAppCallLeg,
                                               OUT RvSipAppSubsHandle *phAppSubs)
{
    RV_UNUSED_ARG(hCallLeg);
    RV_UNUSED_ARG(hAppCallLeg);

    IppLogMessage(RV_FALSE, "Sample Subs::Notifier subscription %x was created\n\n",(int)hSubs);
    *phAppSubs = NULL;  /*the application handle is set to NULL*/
}


/***************************************************************************
 * AppSubsStateChangedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application of a subscription state change.
 *          For all states indicating a new incoming requests (subs_rcvd,
 *          refresh_rcvd, ubsubscribe_rcvd) - accept the request, and send
 *          a notify request immediately.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          eState -      The new subscription state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
static void RVCALLCONV AppSubsStateChangedEvHandler(
                                    IN  RvSipSubsHandle            hSubs,
                                    IN  RvSipAppSubsHandle         hAppSubs,
                                    IN  RvSipSubsState             eState,
                                    IN  RvSipSubsStateChangeReason eReason)
{
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(eReason);

    /*print the new state on screen*/
    IppLogMessage(RV_FALSE,  "Sample Subs::Subscription %x - State changed to %s\n\n",
           (int)hSubs, AppGetSubsStateName(eState));

    switch(eState)
    {
    case RVSIP_SUBS_STATE_REFRESHING:
    /*-------------------------------------------------------------------
      set bSendUnsubscribe to true, so next request will be an unsubscribe.
      -------------------------------------------------------------------*/
        /* never unsubscribe
            bSendUnsubscribe = RV_TRUE;
            */
        break;

    default:
        break;
    }
}

/***************************************************************************
 * AppSubsNotifyEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the SubsNotifyEv event handler.
 *          If the new status is request_rcvd - accept the notify request
 *          with RvSipNotifyAccept().
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs         - The sip stack subscription handle
 *          hAppSubs      - The application handle for this subscription.
 *          hNotification - The new created notification object handle.
 *          hAppNotification - The application handle for this notification.
 *          eNotifyStatus - Status of the notification object.
 *          eNotifyReason - Reason to the indicated status.
 *          hNotifyMsg    - The received notify msg.
 ***************************************************************************/
static void RVCALLCONV AppSubsNotifyEvHandler(
                                     IN  RvSipSubsHandle        hSubs,
                                     IN  RvSipAppSubsHandle     hAppSubs,
                                     IN  RvSipNotifyHandle      hNotification,
                                     IN  RvSipAppNotifyHandle   hAppNotification,
                                     IN  RvSipSubsNotifyStatus  eNotifyStatus,
                                     IN  RvSipSubsNotifyReason  eNotifyReason,
                                     IN  RvSipMsgHandle         hNotifyMsg)
{
    RvStatus rv;

    RV_UNUSED_ARG(hSubs);
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(hAppNotification);
    RV_UNUSED_ARG(eNotifyReason);
    RV_UNUSED_ARG(hNotifyMsg);

    switch (eNotifyStatus)
    {
        case RVSIP_SUBS_NOTIFY_STATUS_REQUEST_RCVD:
        /*----------------------
          Accept notify request.
          ----------------------*/
            IppLogMessage(RV_FALSE, "Sample Subs::Notify received - Accepting the notify request\n\n");
            handleNotification(hNotifyMsg);
            rv = RvSipNotifyAccept(hNotification);
            if(rv != RV_OK)
            {
                IppLogMessage(RV_TRUE, "Sample Subs::Failed to accept the notify");
            }
            break;
        case RVSIP_SUBS_NOTIFY_STATUS_2XX_RCVD:
            IppLogMessage(RV_FALSE, "Sample Subs::2xx on Notify %x received\n\n", (int)hNotification);
            break;
        case RVSIP_SUBS_NOTIFY_STATUS_REJECT_RCVD:
        case RVSIP_SUBS_NOTIFY_STATUS_REDIRECTED:
        case RVSIP_SUBS_NOTIFY_STATUS_UNAUTHENTICATED:
            IppLogMessage(RV_FALSE, "Sample Subs::non - 2xx on Notify %x received\n\n", (int)hNotification);
            break;
        case RVSIP_SUBS_NOTIFY_STATUS_TERMINATED:
            IppLogMessage(RV_FALSE, "Sample Subs::Notify %x was terminated\n\n", (int)hNotification);
            break;
        default:
            break;
    }
}


/***************************************************************************
* AppSubsExpirationAlertEvHandler
* ------------------------------------------------------------------------
* General: Application implementation to the Expiration Alert event handler.
*          If no refresh was sent, send a refresh using RvSipSubsRefresh(),
*          Otherwise - send an unsubscribe using RvSipSubsRefresh() with
*          expires header value 0.
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:    hSubs    - The sip stack subscription handle
*           hAppSubs - The application handle for this subscription.
***************************************************************************/
static void RVCALLCONV AppSubsExpirationAlertEvHandler(
                                        IN  RvSipSubsHandle            hSubs,
                                        IN  RvSipAppSubsHandle         hAppSubs)
{
    RvStatus             rv;
    RvSipSubscriptionType eType;

    IppLogMessage(RV_FALSE, "Sample Subs::Subscription %x alert!!!\n",(int)hSubs);
    rv = RvSipSubsGetSubsType(hSubs, &eType);

    if(eType == RVSIP_SUBS_TYPE_SUBSCRIBER)
    {
        if(bSendUnsubscribe == RV_FALSE)
        {
            /*----------------------
              Send a refresh request.
              ----------------------*/
            IppLogMessage(RV_FALSE, "Sample Subs::AlertEv - Subscription %x - send REFRESH\n\n",(int)hSubs);
            rv = RvSipSubsRefresh(hSubs, REFRESH_EXPIRES);
            if(rv != RV_OK)
            {
                IppLogMessage(RV_TRUE, "Sample Subs::Subscription %x - Failed to send refresh\n", (int)hSubs);
            }
        }
        else /* send unsubscribe */
        {
            /*---------------------------
              Send an unsubscribe request.
              ---------------------------*/
            IppLogMessage(RV_FALSE, "Sample Subs::Unsubscribing the call\n\n");
            rv = RvSipSubsUnsubscribe(hSubs);
            if(rv != RV_OK)
            {
                IppLogMessage(RV_TRUE, "Sample Subs::Subscription %x - Failed to send unsubscribe\n",(int)hSubs);
            }
        }
    }
    RV_UNUSED_ARG(hAppSubs);
}

/***************************************************************************
 * AppSubsMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RV_Status RVCALLCONV AppSubsMsgReceivedEvHandler(
                                        IN  RvSipSubsHandle      hSubs,
                                        IN  RvSipAppSubsHandle   hAppSubs,
                                        IN  RvSipNotifyHandle    hNotify,
                                        IN  RvSipAppNotifyHandle hAppNotify,
                                        IN  RvSipMsgHandle       hMsg)
{
    IppLogMessage(RV_FALSE,  "Sample Subs::<-- Message Received (subscription %x)\n",(int)hSubs);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(hAppNotify);
    RV_UNUSED_ARG(hNotify);
    return RV_OK;
}

/***************************************************************************
 * AppSubsMsgToSendEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppSubsMsgToSendEvHandler(
                                          IN    RvSipSubsHandle      hSubs,
                                          IN    RvSipAppSubsHandle   hAppSubs,
                                          IN    RvSipNotifyHandle    hNotify,
                                          IN    RvSipAppNotifyHandle hAppNotify,
                                          IN    RvSipMsgHandle       hMsg)
{
    IppLogMessage(RV_FALSE, "Sample Subs::--> Message Sent (subscription %x)\n",(int)hSubs);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(hAppNotify);
    RV_UNUSED_ARG(hNotify);
    return RV_OK;
}

/***************************************************************************
 * AppPrintMessage
 * ------------------------------------------------------------------------
 * General: Prints a message on the screen. For doing this we need to
 *          encode the message and then copy the result to a consecutive
 *          buffer.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg -  Handle to the message.
 ***************************************************************************/
static void AppPrintMessage(IN RvSipMsgHandle hMsg)
{
    RvStatus   rv;
    HPAGE       hPage;
    RvChar     *msgBuf;
    RvUint32   msgSize;

    /* getting the encoded message on an rpool page.*/
    rv = RvSipMsgEncode(hMsg, g_appMwiPool, &hPage, &msgSize);
    if (rv != RV_OK)
    {
        IppLogMessage(RV_TRUE, "Sample Subs::Message encoding failed");
    }
    /*allocate a consecutive buffer - use UTILS since malloc doesn't work on all OS's */
    msgBuf = (RvChar *)RvSipMidMemAlloc(msgSize+1);

    /* copy the encoded message to an external consecutive buffer*/
    rv = RPOOL_CopyToExternal(g_appMwiPool,
        hPage,
        0,
        (void*)msgBuf,
        msgSize);
    /*terminate the buffer with null*/
    msgBuf[msgSize] = '\0';
    if(rv != RV_OK)
    {
        IppLogMessage(RV_TRUE, "Sample Subs::Message encoding failed");
        /*free the page the encode function allocated*/
        RPOOL_FreePage(g_appMwiPool, hPage);
        RvSipMidMemFree(msgBuf);
        exit(1);
    }
    OSPrintf("%s",msgBuf);
    /*free the page the encode function allocated*/
    RPOOL_FreePage(g_appMwiPool, hPage);
    RvSipMidMemFree(msgBuf);
}


/*===============================================================================*/
/*===================    U T I L I T Y    F U N C T I O N S    ==================*/
/*===============================================================================*/


/***************************************************************************
 * AppGetSubsStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetSubsStateName (
                          IN  RvSipSubsState  eState)
{

    switch(eState)
    {
    case RVSIP_SUBS_STATE_IDLE:
        return "Idle";
    case RVSIP_SUBS_STATE_SUBS_SENT:
        return "Subs Sent";
    case RVSIP_SUBS_STATE_REDIRECTED:
        return "Redirected";
    case RVSIP_SUBS_STATE_UNAUTHENTICATED:
        return "Unauthenticated";
    case RVSIP_SUBS_STATE_NOTIFY_BEFORE_2XX_RCVD:
        return "Notify Before 2xx Rcvd";
    case RVSIP_SUBS_STATE_2XX_RCVD:
        return "2xx Rcvd";
    case RVSIP_SUBS_STATE_REFRESHING:
        return "Refreshing";
    case RVSIP_SUBS_STATE_REFRESH_RCVD:
        return "Refresh Rcvd";
    case RVSIP_SUBS_STATE_UNSUBSCRIBING:
        return "Unsubscribing";
    case RVSIP_SUBS_STATE_UNSUBSCRIBE_RCVD:
        return "Unsubscribe Rcvd";
    case RVSIP_SUBS_STATE_UNSUBSCRIBE_2XX_RCVD:
        return "Unsubscribe 2xx Rcvd";
    case RVSIP_SUBS_STATE_SUBS_RCVD:
        return "Subs Rcvd";
    case RVSIP_SUBS_STATE_ACTIVATED:
        return "Subs Activated";
    case RVSIP_SUBS_STATE_TERMINATING:
        return "Subs Terminating";
    case RVSIP_SUBS_STATE_PENDING:
        return "Subs Pending";
    case RVSIP_SUBS_STATE_ACTIVE:
        return "Subs Active";
    case RVSIP_SUBS_STATE_TERMINATED:
        return "Subs Terminated";
    default:
        return "Undefined";
    }
}

/***************************************************************************
 * OSPrintf
 * ------------------------------------------------------------------------
 * General: Impelementation of printf for different Operating Systems.
 *          (Print formatted output to the standard output stream.)
 * Return Value: The number of characters printed, or a negative value
 *               if an error occurs.
 *-------------------------------------------------------------------------
 * Arguments:
 * Input: format - Format control.
 *        There might be additional parameteres according to the format.
 *-------------------------------------------------------------------------
 ***************************************************************************/
static int OSPrintf(IN const char *format,... )
{
    int      charsNo;
    va_list  ap;
#if (RV_OS_TYPE == RV_OS_TYPE_WINCE)
    RvChar  cbuf[MAX_PRINT_LEN];

    /*************************************
     Print message to the buffer first
    **************************************/
    va_start(ap,format);
    charsNo = vsprintf (cbuf, format, ap);
    va_end(ap);

    /************************************************
     Using default output window for printing
    *************************************************/
    charsNo = OSWinCEPrintf(NULL,0,cbuf);
#else
    va_start(ap,format);
    charsNo = vprintf(format,ap);
    va_end(ap);

#endif

    return charsNo;
}
#endif /* #ifndef RV_SIP_PRIMITIVES*/


/***************************************************************************
 * handleNotification
 * ------------------------------------------------------------------------
 * General: Application implementation to the SubsNotifyEv event handler.
 *          If the new status is request_rcvd - accept the notify request
 *          with RvSipNotifyAccept().
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:      hMsg    - The received notify msg.
 ***************************************************************************/
static RV_Status handleNotification( RvSipMsgHandle hMsg)
{
    RV_Status rc;
    RvSipBodyHandle     hBody;
    RV_CHAR             *rawBuffer, *szTok;
    RV_UINT32           length;
    RvBool              bNewMsg = rvFalse;

    hBody = RvSipMsgGetBodyObject( hMsg);
    if(hBody == NULL)
        return RV_Success;

    length =  RvSipBodyGetBodyStrLength( hBody);

    rvMtfAllocatorAlloc(length+1, (void**)&rawBuffer);

    rc = RvSipBodyGetBodyStr( hBody, rawBuffer, length, &length);
    /*
     *  the simplest parsing of body
     */
    for( szTok = strtok( rawBuffer, "\t\n "); szTok; szTok = strtok( NULL, "\t\n "))
    {
        if(strcmp( szTok, "Messages-Waiting:") ==0)
        {
            szTok = strtok( NULL, "\t\n ");
            if(szTok)
            {
                bNewMsg = (strcmp(szTok,"yes")==0) ? rvTrue: rvFalse;
            }
            break;
        }
    }
    /*
     *  User sends packages to terminal directly
     */
    {
        char logstr[RV_SHORT_STR_SZ];
        /*find terminal linked to current hSubs*/
        RvIppTerminalHandle hTerm = g_subsPerTerm[0].term;
		RvEppClientEndpoint *ece = NULL;
		
		rvMtfTerminationGetAppHandle(hTerm, ( RvMtfTerminalAppHandle*)&ece);
		
		if (ece == NULL)
		{
			return RV_ERROR_UNKNOWN;
		}

        if(bNewMsg)
        {			
            /*1st indication*/
            rvMtfGuiSetTextDisplay( ece, "New message arrived", 1, 0);

            /*2st indication*/
            {
                rvMtfGuiStartMwiTone( ece);
            }
            /*3st indication*/
            {
				rvMtfGuiSetMwiIndicator( ece, RV_MTF_SIGNAL_STATE_ON);
    
            }

            RvSnprintf(logstr,sizeof(logstr),"IPP-->Start Signal: MWI,term(%p)",hTerm);
        }
		else
        {
            /*1st indication*/
            rvMtfGuiSetTextDisplay( ece, "No messages", 1, 0);
            /*3st indication*/
            {
                rvMtfGuiSetMwiIndicator( ece, RV_MTF_SIGNAL_STATE_OFF);
            }

        }

    }

    rvMtfAllocatorDealloc(rawBuffer, length+1);
    return RV_Success;
}

#endif/* SAMPLE_MWI*/


