/******************************************************************************
Filename:    rvMtfSampleCfw.c
Description: This file contains the Call Forward implementation of MTF sample application.
			 User application may use this file as an example and make the necessary
			 changes to adjust it to application's needs.
*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#include "IppStdInc.h"
#include "rvMtfSample.h"
#include "rvMtfExtControlApi.h"
#include "rvstr.h"

//rvDefineMap(RvString, RvString);

/*===============================================================================*/
/*==============    GLOBALS  ==========*/
extern RvMtfSampleParams	 g_sampleParams;

/*===============================================================================*/
/*===================    P R I V A T E	  F U N C T I O N S    ==================*/
/*===============================================================================*/

static char emptyFullLine[24] = {"                  "};

static void clearCfwRaw(RvEppClientEndpoint* ece, int raw)
{
	rvMtfGuiSetTextDisplay(ece, emptyFullLine, raw, 0);
	rvMtfGuiSetTextDisplay(ece, emptyFullLine, raw+1, 0);
}

static void rvIppRemoveScheme(char* str, char* address)
{
	char *p = strchr(str, ':');

	if (p != NULL)
	{
		strcpy(address, p+1);

	}
	else
		address[0]='\0';
}

static RvBool findPhoneNumber(IN char* address, OUT char* phoneNumber)
{
	RvMapIter(RvString, RvString) iter = NULL;
	
	for (iter = rvMapBegin(RvString, RvString)(&g_sampleParams.addressList);
			iter != rvMapEnd(RvString, RvString)(&g_sampleParams.addressList);
			iter = rvMapIterNext(iter))
	{
		RvString* destAddress = rvMapIterGetValue(RvString, RvString)(iter);
		const char* number = *rvMapIterGetKey(RvString, RvString)(iter);

		if (strstr(rvStringGetData(destAddress), address))
		{
			strcpy(phoneNumber, number);
			return rvTrue;
		}
	}

	return rvFalse;

}

static void rvCCCfwActivateTypesDisplay(
    IN RvEppClientEndpoint*	ece, 
	IN RvIppCfwType			cfwType,
	IN const RvChar*		cfwDestination)
{
	RvChar cfwDisplayString[RV_NAME_STR_SZ];
		
	g_sampleParams.callForwardTypeIsActive[cfwType] = RV_TRUE;
	
	switch (cfwType)
	{
		case  RV_IPP_CFW_TYPE_UNCONDITIONAL:
			RvSprintf(cfwDisplayString, "CFW-U: %s", cfwDestination);
			rvMtfGuiSetTextDisplay(ece, cfwDisplayString, (int)RVIPP_RAW_CFWU, 0);
			break;
		case RV_IPP_CFW_TYPE_BUSY:
			RvSprintf(cfwDisplayString, "CFW-B: %s", cfwDestination);
			rvMtfGuiSetTextDisplay(ece, cfwDisplayString, (int)RVIPP_RAW_CFWB, 0);
			break;
		case RV_IPP_CFW_TYPE_NO_REPLY:
			RvSprintf(cfwDisplayString, "CFW-NR: %s", cfwDestination);
			rvMtfGuiSetTextDisplay(ece, cfwDisplayString, (int)RVIPP_RAW_CFWNR, 0);
			break;
        case RV_IPP_CFW_TYPE_NONE:    
		default:
			IppLogMessage(RV_TRUE, "cfwActivateCompleteCB - Unknown CFW Type: %d", cfwType);
	}
}

static void rvCCCfwDeactivateTypesDisplay(
    IN RvEppClientEndpoint*	ece, 
	IN RvIppCfwType			cfwType)
{
	g_sampleParams.callForwardTypeIsActive[cfwType] = rvFalse;

	switch (cfwType)
	{
		case  RV_IPP_CFW_TYPE_UNCONDITIONAL:
			clearCfwRaw(ece, (int)RVIPP_RAW_CFWU);
			break;
		case RV_IPP_CFW_TYPE_BUSY:
			clearCfwRaw(ece, (int)RVIPP_RAW_CFWB);
			break;
		case RV_IPP_CFW_TYPE_NO_REPLY:
			clearCfwRaw(ece, (int)RVIPP_RAW_CFWNR);
			break;
        case RV_IPP_CFW_TYPE_NONE:    
		default:
			IppLogMessage(RV_TRUE, "cfwActivateCompleteCB - Unknown CFW Type: %d", cfwType);
	}
}

/*===============================================================================*/
/*=======C F W    C A L L B A C K		I M P L E M E N T A T I O N S  ==========*/
/*===============================================================================*/

void rvIppSampleCfwActivateCompletedCB(
							RvIppTerminalHandle		hTerm, 
							RvIppCfwType			cfwType,
							char*					cfwDestination,
							RvIppCfwReturnReasons	returnCode) 
{
	if (returnCode == RV_IPP_CFW_SUCCESS)
	{
		char phoneNumber[RV_NAME_STR_SZ];
		char address[RV_NAME_STR_SZ];
		RvEppClientEndpoint* ece = NULL;
		
		rvMtfTerminationGetAppHandle(hTerm, (RvMtfTerminalAppHandle*)&ece);

		/*Remove "sip:" from the address*/
		rvIppRemoveScheme(cfwDestination, address);

		/* Update the text display - phone number if found, or address if not*/
  		if (findPhoneNumber(address, phoneNumber) == rvTrue)
		{
			rvCCCfwActivateTypesDisplay(ece, cfwType, phoneNumber);
		}
		else
		{
			rvCCCfwActivateTypesDisplay(ece, cfwType, address);
		}
		IppLogMessage(RV_FALSE, "cfwActivateCompleteCB on type %d Succeeded", cfwType);
	}
	else
	{
		IppLogMessage(RV_FALSE, "cfwActivateCompleteCB Failed on type %d, returnCode = %d", cfwType, returnCode);
	}
}

void rvIppSampleCfwDeactivateCompletedCB(
							RvIppTerminalHandle		hTerm, 
							RvIppCfwType 	 		cfwType,
							RvIppCfwReturnReasons	returnCode) 
{
	RvEppClientEndpoint* ece = NULL;

	rvMtfTerminationGetAppHandle(hTerm, (RvMtfTerminalAppHandle*)&ece);

	if ((returnCode == RV_IPP_CFW_SUCCESS) || (returnCode == RV_IPP_CFW_INVALID_DEACTIVATION))
	{
		/* Update the text display*/
		rvCCCfwDeactivateTypesDisplay(ece, cfwType);
		IppLogMessage(RV_FALSE, "cfwDeactivateCompleteCB on type %d Succeeded", cfwType);
	}
	else
	{
		IppLogMessage(RV_FALSE, "cfwDeactivateCompleteCB Failed on type %d, returnCode = %d", cfwType, returnCode);
	}
}


