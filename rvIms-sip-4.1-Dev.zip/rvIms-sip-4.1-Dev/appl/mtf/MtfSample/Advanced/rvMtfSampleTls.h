/******************************************************************************
Filename:    rvMtfSampleTls.h
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifdef RV_CFLAG_TLS

#ifndef USER_SAMPLE_TLS_H
#define USER_SAMPLE_TLS_H

#include "rvSipTlsApi.h"

#define TLS_MAX_CA			8
#define FILENAME_LEN		256

typedef struct  {
	RvChar			privateKeyFileName[256]; 
	RvChar			caCertFileName[TLS_MAX_CA][FILENAME_LEN]; /* Certification file name */
}RvIppKeyTlsCfg;

void rvMtfSampleLoadTlsTransportParams(RvIppTransportTlsCfg*, char*, char*);
void rvMtfSampleLoadTlsKepParams(RvIppKeyTlsCfg*, char*, char*);
void rvMtfSampleLoadTlsConfigParams(RvIppTransportTlsCfg*, RvIppSipPhoneCfg*);

void loadSipStackTlsParams(char* params, char* var,  RvSipStackCfg* stackCfg);


void userRegisterIppSipTlsExt(void);


RvBool userSipTlsGetBuffer(IN    RvIppTlsBufferType bufferType,
						   OUT	RvChar			*tlsBuffer, 
						   OUT	RvUint32		*tlsBufferLen);

void userSipTlsPostConnectionAssertion(IN    RvSipTransportConnectionHandle		hConnection,
									   IN    RvSipTransportConnectionAppHandle	hAppConnection,
									   IN    RvChar*							strHostName,
									   IN    RvSipMsgHandle						hMsg,
									   OUT   RvBool*							pbAsserted);


#endif /* USER_SAMPLE_TLS_H */ 
 
#endif /*RV_CFLAG_TLS*/
