/******************************************************************************
Filename:    rvMtfSampleUtils.c
Description: This file includes utility functions for MTF sample application.
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "IppStdInc.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "rvMtfSampleUtils.h"
#include "rvMtfSampleCfw.h"
#include "rvhost.h"
#include "rvstr.h"

extern RvMtfSampleParams			g_sampleParams;

typedef struct
{
    const char* strValue;
    RvInt32    enumValue;
} ConvertValue;


static ConvertValue rvSampleMtfLogFilters[] =
{
    {"exception",	(RvInt32)RV_LOGLEVEL_EXCEP},
    {"error",       (RvInt32)RV_LOGLEVEL_ERROR},
    {"warning",		(RvInt32)RV_LOGLEVEL_WARNING},
    {"info",		(RvInt32)RV_LOGLEVEL_INFO},
    {"debug",		(RvInt32)RV_LOGLEVEL_DEBUG},
    {"enter",		(RvInt32)RV_LOGLEVEL_ENTER},
    {"leave",		(RvInt32)RV_LOGLEVEL_LEAVE},
    {"sync",		(RvInt32)RV_LOGLEVEL_SYNC},
    {NULL,          (RvInt32)0}
};


static ConvertValue rvSampleSipLogFilters[] =
{
    {"debug",      (RvInt32)RVSIP_LOG_DEBUG_FILTER},
    {"info",       (RvInt32)RVSIP_LOG_INFO_FILTER},
    {"warning",    (RvInt32)RVSIP_LOG_WARN_FILTER},
    {"error",      (RvInt32)RVSIP_LOG_ERROR_FILTER},
    {"exception",  (RvInt32)RVSIP_LOG_EXCEP_FILTER},
    {"lockdbg",    (RvInt32)RVSIP_LOG_LOCKDBG_FILTER},
    {NULL,         (RvInt32)0}
};



/* Defines the different modules of the RADVISION SIP stack. */
static ConvertValue cvLogDebugSipModules[] =
{
    {"callLogFilters",          (RvInt32)RVSIP_CALL},
    {"transactionLogFilters",   (RvInt32)RVSIP_TRANSACTION},
    {"msgLogFilters",           (RvInt32)RVSIP_MESSAGE},
    {"transportLogFilters",     (RvInt32)RVSIP_TRANSPORT},
    {"parserLogFilters",        (RvInt32)RVSIP_PARSER},
    {"stackLogFilters",         (RvInt32)RVSIP_STACK},
    {"msgBuilderLogFilters",    (RvInt32)RVSIP_MSGBUILDER},
    {"authenticatorLogFilters", (RvInt32)RVSIP_AUTHENTICATOR},
    {"regClientLogFilters",     (RvInt32)RVSIP_REGCLIENT},
    {"subscriptionLogFilters",  (RvInt32)RVSIP_SUBSCRIPTION},
	{"compartmentLogFilters",	(RvInt32)RVSIP_COMPARTMENT},
	{"transmitterLogFilters",	(RvInt32)RVSIP_TRANSMITTER},
	{"ads_rlistLogFilters",		(RvInt32)RVSIP_ADS_RLIST},
	{"ads_raLogFilters",		(RvInt32)RVSIP_ADS_RA},
	{"ads_rpoolLogFilters",		(RvInt32)RVSIP_ADS_RPOOL},
	{"ads_hashLogFilters",		(RvInt32)RVSIP_ADS_HASH},
	{"ads_pqueueLogFilters",	(RvInt32)RVSIP_ADS_PQUEUE},
	{"core_semaphoreLogFilters",(RvInt32)RVSIP_CORE_SEMAPHORE},
	{"core_mutexLogFilters",	(RvInt32)RVSIP_CORE_MUTEX},
	{"core_lockLogFilters",		(RvInt32)RVSIP_CORE_LOCK},
	{"core_memoryLogFilters",	(RvInt32)RVSIP_CORE_MEMORY},
	{"core_threadLogFilters",	(RvInt32)RVSIP_CORE_THREAD},
	{"core_queueLogFilters",	(RvInt32)RVSIP_CORE_QUEUE},
	{"core_timerLogFilters",	(RvInt32)RVSIP_CORE_TIMER},
	{"core_timestampLogFilters",(RvInt32)RVSIP_CORE_TIMESTAMP},
	{"core_clockLogFilters",	(RvInt32)RVSIP_CORE_CLOCK},
	{"core_tmLogFilters",		(RvInt32)RVSIP_CORE_TM},
	{"core_socketLogFilters",	(RvInt32)RVSIP_CORE_SOCKET},
	{"core_portrangeLogFilters",(RvInt32)RVSIP_CORE_PORTRANGE},
	{"core_selectLogFilters",	(RvInt32)RVSIP_CORE_SELECT},
	{"core_hostLogFilters",		(RvInt32)RVSIP_CORE_HOST},
	{"core_tlsLogFilters",		(RvInt32)RVSIP_CORE_TLS},
	{"core_aresLogFilters",		(RvInt32)RVSIP_CORE_ARES},
	{"coreLogFilters",			(RvInt32)RVSIP_CORE},
	{"adsLogFilters",			(RvInt32)RVSIP_ADS},
    {NULL,                      (RvInt32)0}
};

/*===============================================================================*/
/*===================    P R I V A T E	  F U N C T I O N S    ==================*/
/*===============================================================================*/

/************************************************************************************
 * getDefaultHost
 * ----------------------------------------------------------------------------------
 * General: Get ip address of the default local host as received from the operating
 *          system. The default host will be chosen from the list of local hosts
 *          according to parameters localIpPrefix & localIpMask.
 *          If no address that matches localIpPrefix & localIpMask was found, the
 *          chosen address will be the first one on the list.
 *          Opening a socket with ip 0 will cause listening to all local IP addresses,
 *          including the one returned here.
 * Return Value: RvStatus - RvStatus
 *                           RV_ERROR_UNKNOWN
 * ----------------------------------------------------------------------------------
 * Arguments:
 * Input:   pTransportMgr - pointer to transport instance
 *          eAddressType - indicates the class of address we want to get ipv4/ipv6
 *          localIpPrefix - prefix of the desired local ip address to be chosen
 *                          from the list of local addresses
 *          localIpMask - mask of the desired local ip address
 *
 * Output:  pAddr - The default local address
 ***********************************************************************************/
static RvStatus getDefaultHost(
                                        IN    RvLogMgr*     pLogMgr,
                                        IN    RvInt         eAddressType,
                                        IN    char*         localIpPrefix,
                                        IN    char*         localIpMask,
                                        INOUT RvAddress*    pAddr)
{

    RvStatus      crv         = RV_OK;
    RvUint32      numofAddresses = 10;
    RvUint        i              = 0;
    RvAddress     addresses[RV_HOST_MAX_ADDRS];
    RvAddress     maskAddr, netAddr;
    RV_BOOL       localIpPrefixFound = RV_FALSE;

#if(RV_NET_TYPE & RV_NET_IPV6)
    if (RV_ADDRESS_TYPE_IPV6 == eAddressType)
        numofAddresses = RV_HOST_MAX_ADDRS;
#endif /*(RV_NET_TYPE & RV_NET_IPV6)*/

    crv = RvHostLocalGetAddress(pLogMgr,&numofAddresses,addresses);
    if (RV_OK != crv)
    {
        IppLogMessage(RV_TRUE, "getDefaultHost - Failed to get default address");
        return crv;
    }

    RvAddressConstruct(RV_ADDRESS_TYPE_IPV4, &maskAddr);
    RvAddressSetString(localIpMask, &maskAddr);

    RvAddressConstruct(RV_ADDRESS_TYPE_IPV4, &netAddr);
    RvAddressSetString(localIpPrefix, &netAddr);

    /* Go through list of local ip addresses and choose the one that matches
       localIpPrefix & localIpMask */
    for (i=0 ; i<numofAddresses ; i++)
    {
        RvAddress* addr = &addresses[i];
        if ( (RvAddressIpv4GetIp(&addr->data.ipv4) &
              RvAddressIpv4GetIp(&maskAddr.data.ipv4)) == RvAddressIpv4GetIp(&netAddr.data.ipv4))
        {
            localIpPrefixFound = RV_TRUE;
            break;
        }
    }

    /* If the desired prefix was not found, take the first address on the list
       (it's as good as the others */
    if (localIpPrefixFound == RV_FALSE)
        i=0;

    /* Get the local hosts array from the core layer*/
    if (RV_ADDRESS_TYPE_IPV4 == eAddressType)
    {
        if (RV_ADDRESS_TYPE_IPV6 == RvAddressGetType(&addresses[0]))
        {
            IppLogMessage(RV_TRUE,
                      "getDefaultHost - Failed to get default IPv4 address, computer supports only ipv6 addresses");
            return RV_ERROR_BADPARAM;
        }
    }
#if(RV_NET_TYPE & RV_NET_IPV6)
    if (RV_ADDRESS_TYPE_IPV6 == eAddressType)
    {
        static RvUint8 localLinkAddr[16] = {0xfe,0x80,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x01};

        while (RV_ADDRESS_TYPE_IPV4 == RvAddressGetType(&addresses[i]))
            i++;
        if (RV_ADDRESS_TYPE_IPV6 != RvAddressGetType(&addresses[i]))
        {
            return RV_ERROR_BADPARAM;
        }
        while (0 != memcmp(addresses[i].data.ipv6.ip,localLinkAddr,2) ||
               0 == memcmp(addresses[i].data.ipv6.ip,localLinkAddr,16))
        {
            i++;
            if (i > numofAddresses)
            {
                return RV_ERROR_NOT_FOUND;
            }
        }

    }
#endif /* (RV_NET_TYPE & RV_NET_IPV6) */
    RvAddressCopy(&addresses[i],pAddr);
    return RV_OK;
}

/***************************************************************************************
 * replaceZeroWithLocal
 * -------------------------------------------------------------------------------------
 * General:   This function replaces zero ip address 0.0.0.0 to the local address
 * Return Value: None
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 sampleParams        - a pointer to sample parameters
 *           len				 - the length of addressString
 * Output:   addressString       - The local address
 **************************************************************************************/
static void replaceZeroWithLocal(
				 IN RvMtfSampleParams*	sampleParams,
                 OUT RvChar*			addressString,
                 IN RvSize_t            len)
{
    RvAddress localAdd;

    if (!strcmp(addressString,"0.0.0.0"))
    {
        if (RV_OK != getDefaultHost(NULL, RV_ADDRESS_TYPE_IPV4,
			sampleParams->localIpPrefix,
			sampleParams->localIpMask, &localAdd))
        {
            printf("error in calling getDefaultHost(RV_ADDRESS_TYPE_IPV4)");
            return;
        }
        RvAddressGetString(&localAdd, len, addressString);
    }
    else if (!strcmp(addressString,"0:0:0:0:0:0:0:0"))
    {
        if (RV_OK != getDefaultHost(NULL, RV_ADDRESS_TYPE_IPV6,
			sampleParams->localIpPrefix,
			sampleParams->localIpMask, &localAdd))
        {
            printf("error in calling getDefaultHost(RV_ADDRESS_TYPE_IPV6)");
            return;
        }
        RvAddressGetString(&localAdd, len, addressString);
    }
}

/***************************************************************************************
* logString2Enum
* -------------------------------------------------------------------------------------
* General:  Convert a string value to its enumeration value
*           Used as a general conversion function
* Return Value: Parameter enumeration value
* -------------------------------------------------------------------------------------
* Arguments:
* Input: 	 string     - String parameter to convert
*           cvTable    - Conversion table to use
* Output:   none
**************************************************************************************/
static RvInt32 logString2Enum(IN const RvChar* string, IN ConvertValue* cvTable)
{
    ConvertValue* val = cvTable;

    while (val->strValue != NULL)
    {
        if (strcmp(string, val->strValue) == 0)
            return val->enumValue;
        val++;
    }

    return -1;
}

/***************************************************************************
 * logFilterToInt
 * ------------------------------------------------------------------------
 * General: calculates the numeric value of the filter string
 * Return Value: RV_Succes on success and RV_Failure otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	strValue -    The filter string
 *          iValue-       The returned calculated value
 ***************************************************************************/
static RvBool logFilterToInt(IN APITYPE api_type, IN const char*  strValue, OUT RvInt8* iValue)
{
    char     strSeperateValue[80]; /*a single enum string*/
	int			index = 0;

    *iValue=0;

    /*break strValue into separate strings*/

    while(0 != strValue[0])
    {
        for(;' ' == strValue[0] || ',' == strValue[0];++strValue);
        while(' ' != strValue[0] && ',' != strValue[0] && '\0' != strValue[0])
        {
            strSeperateValue[index]=(char)tolower(strValue[0]);
            ++strValue;
            ++index;
        }
        if (0 == strSeperateValue[0])
        {
            break;
        }
        strSeperateValue[index]=0;

        /*add the new separated string to the value calculated
          so far*/

		switch(api_type)
		{
		case SIP_API_TYPE:
			*iValue=(RvInt8)(*iValue | (RvInt8)logString2Enum(strSeperateValue, rvSampleSipLogFilters));
			break;
		case IPP_API_TYPE:
			*iValue=(RvInt8)(*iValue | (RvInt8)logString2Enum(strSeperateValue, rvSampleMtfLogFilters));
			break;
		default:
			return rvFalse;

		}
		index = 0;
    }
    return rvTrue;
}

/***************************************************************************************
 * logStringToStackModule
 * -------------------------------------------------------------------------------------
 * General:   converts a string to Sip stack module ID
 * Return Value: the module ID
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the string to be converted
 * Output:   none
 **************************************************************************************/
static RvBool logStringToStackModule(const char* str, RvSipStackModule* module){

	*module= logString2Enum(str,cvLogDebugSipModules);
	if ((*module) == (RvSipStackModule)(-1))
		    return rvFalse;

	return rvTrue;

}

/***************************************************************************************
 * buf2sdp
 * -------------------------------------------------------------------------------------
 * General:   converts a buffer to sdp message
 * Return Value: True if successful, False if not.
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 bufSdp - the buffer to be converted
 * Output:   sdpMsg - the sdp object
 **************************************************************************************/
static RvBool buf2sdp( IN char* bufSdp, OUT RvSdpMsg* sdpMsg)
{
    RvSdpMsg            tempSdpMsg;
	RvSdpParseStatus	stat	=	RV_SDPPARSER_STOP_ZERO;
	RvUint				actlen	=	0;

	actlen	=	strlen( bufSdp);

	if (actlen ==0) /*No SDP message was sent*/
		return rvTrue;


	if (actlen!=0)
	{
        /* Parse buffer into a local sdp message, which will be copied to the output
           sdp message*/
		if ((rvSdpMsgConstructParseA(&tempSdpMsg, bufSdp, (int *)&actlen, &stat, userDefaultAlloc)) != NULL)
		{
            /* sdpMsg should have been constructed before this function was called */
            rvSdpMsgCopy(sdpMsg, &tempSdpMsg);
            /* Local sdp message can be released now*/
            rvSdpMsgDestruct(&tempSdpMsg);
			return rvTrue;
		}
		else
			return rvFalse;
	}
	else
		return rvFalse;
}

/***************************************************************************************
 * sampleUtilFile2Sdp
 * -------------------------------------------------------------------------------------
 * General:   Seek for a section titled [MediaParameters{index}], say  [MediaParameters1].
 *				Convert contents of the section to RvSdpMsgList
 * Return Value: True is succeeded, False if failed
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the buffer
 *			 string - section name
 * Output:   RvBool - success/failure
 **************************************************************************************/
static RvBool sampleUtilFile2Sdp(IN const char* buffer, IN const char* szSectionName, OUT RvSdpMsg* sdpMsg)
{
	char		    szPureSdpBuf[4096];
	const RvChar*   ptrFirst;
	const RvChar*	ptrLast;

	/*
	 *	find the first char of a section content.
	 */
	ptrFirst = strstr(buffer, szSectionName);
	if (ptrFirst == NULL)
		return RV_FALSE;
	ptrFirst += strlen(szSectionName) + 1;

	/*
	 *	find the first char after end of a section content.
	 */
	ptrLast = strchr( ptrFirst, '[');
	if (!ptrLast)
		ptrLast = (char*)buffer + strlen(buffer);

	/*
	 *	copy a filtered section content to szPureSdpBuf.
	 */
	{
		RvChar*	        to = szPureSdpBuf;
		const RvChar*	from = ptrFirst;
		RvBool	        bLineStart = RV_TRUE;

		while ((from < ptrLast) && (to < szPureSdpBuf + sizeof(szPureSdpBuf)))
		{
			if (bLineStart)
			{
				if (*from == '#')
				{
					from = strchr(from, '\n') + 1;
					continue;
				}
			}
			else
			{
				if (*from == '\n')
				{
					bLineStart = rvTrue;
					continue;
				}
			}
			*to = *from;
			to++;
            from++;
		}

		*to = '\0';
	}

	/* Convert pure buffer to sdp structure, sdpMsg should be a constructed object*/
	buf2sdp(szPureSdpBuf, sdpMsg);

	return RV_TRUE;
}

#ifdef RV_SIP_IMS_ON
/***************************************************************************
 * convertAkaAuthOpStrToArray
 * ------------------------------------------------------------------------
 * General: Convert a string with 16 hex values seperated by ',' to an array of
 *          uint8 values.
 *          The string contains values that are used when calculating AKA
 *          RES shared secret parameter.
 *          Example for this string in the config file:
 *          AkaAuth_op=0x63,0xbf,0xa5,0x0e,0xe6,0x52,0x33,x65,0xff,0x14,0xc1,0xf4,0x5f,0x88,0x73,0x7d
 *
 ***************************************************************************/
static void convertAkaAuthOpStrToArray(IN RvUint8* akaAuthOpArray, IN RvChar* akaAuthOpStr)
{
	char* token;
    RvStrTok commaTokenizer;
	RvInt8   i = 0;

    rvStrTokConstruct(&commaTokenizer, ",", akaAuthOpStr);
    while ((token = rvStrTokGetToken(&commaTokenizer)) != NULL)
	{
		if (i == AKA_OP_ARRAY_SIZE)
		{
			printf("\nToo many elements (> %d) in configuration parameter akaAuth_op \n", AKA_OP_ARRAY_SIZE);
			IppLogMessage(RV_FALSE,"convertAkaAuthOpStrToArray:: More than %d elements in configuration parameter akaAuth_op", AKA_OP_ARRAY_SIZE);
			break;
		}

        akaAuthOpArray[i] = (RvUint8)strtol(token, NULL, 0);
		i++;
	}

	if (i < AKA_OP_ARRAY_SIZE)
	{
		printf("\nOnly %d elements out of %d were configured in akaAuth_op array.\n", i, AKA_OP_ARRAY_SIZE);
		IppLogMessage(RV_FALSE,"convertAkaAuthOpStrToArray:: Only %d elements out of %d were configured in akaAuth_op array.", i, AKA_OP_ARRAY_SIZE);
		for (; i < AKA_OP_ARRAY_SIZE; i++ )
			akaAuthOpArray[i] = 0x00;

	}

	rvStrTokDestruct(&commaTokenizer);
}
#endif

/***************************************************************************
 * loadMediaParams
 * ------------------------------------------------------------------------
 * General: Loads default audio IO device
 *
 ***************************************************************************/
static char* loadMediaParams( RvMtfSampleParams* sampleParams, char* configBuf)
{
    char line[160]="";
    char params[80]="",val[80]="" ;
    char * ptr = configBuf;
    char * last = NULL;
    char* token;
    RvStrTok t;


    while(rvMtfSampleUtilGetNextLine(configBuf,&ptr)!=NULL)
    {
        /* new section */
        if(ptr[0]=='[')
            return last;
        last = ptr;

        /* read name and value */
        sscanf(ptr,"%s",line);
        rvStrTokConstruct(&t,"= ",line);
        if ((token = rvStrTokGetToken(&t)) == NULL)
            continue;
        strcpy(params, token);
        if ((token = rvStrTokGetToken(&t)) == NULL)
            continue;
        strcpy(val, token);

        if(!strcmp(params,"DefaultDevice") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->mediaParam.mfControlParams.defDevice = tmp;
        }
        else if(!strcmp(params,"RTPAddress") )
        {
            strncpy(sampleParams->mediaParam.mfControlParams.RTPAddress, val, sizeof(sampleParams->mediaParam.mfControlParams.RTPAddress)-1);
            sampleParams->mediaParam.mfControlParams.RTPAddress[sizeof(sampleParams->mediaParam.mfControlParams.RTPAddress)-1] = '\0';
        }

        else if(!strcmp(params,"RTPPortRange") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->mediaParam.mfControlParams.max_num_portLocal = (RvUint16)tmp;
        }
        else if(!strcmp(params,"VideoFrameSize") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->mediaParam.mfControlParams.nFrameSize = tmp;
        }
        else if(!strcmp(params,"VideoFrameRate") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->mediaParam.mfControlParams.nFrameRatePerSecVideo = tmp;
        }
        else if(!strcmp(params,"RecvAudioPolling_ms") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->mediaParam.mfControlParams.recv_aud_cntx_poll_interval_msec = tmp;
        }
        else if(!strcmp(params,"RecvVideoPolling_ms") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->mediaParam.mfControlParams.recv_vid_cntx_poll_interval_msec = tmp;
        }

        else if(!strcmp(params,"PlayAudioPolling_ms") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->mediaParam.mfControlParams.play_aud_cntx_poll_interval_msec = tmp;
        }
        else if(!strcmp(params,"PlayVideoPolling_ms") )
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->mediaParam.mfControlParams.play_vid_cntx_poll_interval_msec = tmp;
        }
        else if(!strcmp(params,"MfLogFilters") )
        {
            /* get the log filters for the MF logs */
            RvInt8      tmp;
            strcpy(val, token);

            if (!logFilterToInt(IPP_API_TYPE, val, &tmp))
            {
                printf("failed to determine Filter for the following line\n%s", line);
                break;
            }
            sampleParams->mediaParam.mfControlParams.mfcLogMask = (RvLogMessageType)tmp;
        }
    }
    return NULL;
}
#ifdef RV_MTF_H323
/***************************************************************************
* rvMtfSampleE164PhoneNumbersAdd
* ------------------------------------------------------------------------
* General: Loads a phone number to E164 list
* Return Value: RvStatus
* ------------------------------------------------------------------------
* Arguments:
* Params:  INOUT  RvMtfH323E164List  - a pointer to Mtf E164 List
*          IN  number - a number to be added to the list
***************************************************************************/
static RvStatus rvMtfSampleE164PhoneNumbersAdd(
	INOUT RvMtfH323E164List*  x,
	IN const RvChar*          number)
{
	RvUint i;
	RvSize_t strLen;

	if (number == NULL)
		return RV_ERROR_NULLPTR;

	strLen = strlen(number);
	if ((strLen == 0) || (strLen >= RV_NAME_STR_SZ))
		return RV_ERROR_OUTOFRANGE;

	if (x->phoneNumbersNum >= RV_MTF_H323_E164_NUM)
		return RV_ERROR_OUTOFRESOURCES;

	/* Don't add if number is already in list */
	for (i=0; i < x->phoneNumbersNum; i++)
	{
		if (!strcmp(x->phoneNumbers[i], number))
			return RV_OK;   /* number is already in list */
	}

	/* * Add the number in end of list */
	strcpy(x->phoneNumbers[x->phoneNumbersNum], number);
	x->phoneNumbersNum++;

	return RV_OK;
}

/***************************************************************************
 * loadIppH323GatewayParams
 * ------------------------------------------------------------------------
 * General: Loads gateway parameters from configuration buffer
 *
 ***************************************************************************/
static char* loadIppH323GatewayParams(RvMtfSampleParams* sampleParams, char* configBuf)
{
    char line[160]="";
    char params[80]="",val[120]="" ;
    char* token;
    char * ptr = configBuf;
    char * last = NULL;
    RvStrTok t,t1; 
	
    sampleParams->cfwCallCfg.cfwCallBacks.activateCompleted = rvIppSampleCfwActivateCompletedCB;
    sampleParams->cfwCallCfg.cfwCallBacks.deactivateCompleted = rvIppSampleCfwDeactivateCompletedCB;

    while (rvMtfSampleUtilGetNextLine(configBuf,&ptr)!=NULL)
	{
		/* new section */
		if(ptr[0]=='[')
			return last;
		last = ptr;

		/* read name and value */
	    sscanf(ptr,"%159s",line);
        rvStrTokConstruct(&t,"= ",line);
        if ((token = rvStrTokGetToken(&t)) == NULL)
            continue;
        strcpy(params, token);
        if ((token = rvStrTokGetToken(&t)) == NULL)
            continue;
        strcpy(val, token);

		if(!strcmp(params,"LocalAddress") ){
			rvStringAssign(&sampleParams->localH323Address, val);
		}
		else if(!strcmp(params,"q931SignalingPort")) {
			sscanf(val,"%d",&sampleParams->q931SignalingPort);
		}
		else if(!strcmp(params,"maxCalls")) {
			sscanf(val,"%d",&sampleParams->h323MaxCalls);
		}
		else if(!strcmp(params,"GatekeeperAddress")) {
			rvStringAssign(&sampleParams->gkAddress, val);
		}
		else if(!strcmp(params,"GatekeeperPort")) {
			sscanf(val,"%d",&sampleParams->gkPort);
		}
		else if(!strcmp(params,"h323TermId")) {
			rvStringAssign(&sampleParams->h323TermId, val);
		}
		else if(!strcmp(params,"e164List")) {
			char * aliasPtr;
			sampleParams->e164PhoneList.phoneNumbersNum = 0; 
			rvStrTokConstruct(&t1,",", val);
			while((aliasPtr=rvStrTokGetToken(&t1))!=NULL) {
				rvMtfSampleE164PhoneNumbersAdd(&sampleParams->e164PhoneList, aliasPtr); 
			}
		}
		else if(!strcmp(params,"DebugLevel")) {
			sscanf(val,"%d",&sampleParams->debugLevel);
		}
		else if(!strcmp(params,"FastStart")) {
			sscanf(val,"%d",&sampleParams->fastStart);
		}
		else if(!strcmp(params,"DialToneDuration")) {
			sscanf(val,"%d",&sampleParams->dialToneDuration);
		}
		else if(!strcmp(params,"dtmfRelay")){
			sscanf(val,"%d",&sampleParams->dtmfRelay );
		}
		else if(!strcmp(params,"OutgoingRequestNoResponseTimeout")) {
			sscanf(val,"%d",&sampleParams->h323OutgoingRequestNoResponseTimeout);
		}
		else if(!strcmp(params,"OutgoingCallNoAnswerTimeout")) {
			sscanf(val,"%d",&sampleParams->h323OutgoingCallNoAnswerTimeout);
		}
	}
	return NULL;
}
#endif /* RV_MTF_H323 */

/***************************************************************************
 * loadIppSipGatewayParams
 * ------------------------------------------------------------------------
 * General: Loads gateway parameters from configuration buffer
 *
 ***************************************************************************/
static char* loadIppSipGatewayParams(RvMtfSampleParams* sampleParams, char* configBuf)
{
    char line[160]="";
    char params[80]="",val[120]="" ;
    char* token;
    char * ptr = configBuf;
    char * last = NULL;
    RvStrTok t;

    sampleParams->cfwCallCfg.cfwCallBacks.activateCompleted = rvIppSampleCfwActivateCompletedCB;
    sampleParams->cfwCallCfg.cfwCallBacks.deactivateCompleted = rvIppSampleCfwDeactivateCompletedCB;

    while (rvMtfSampleUtilGetNextLine(configBuf,&ptr)!=NULL)
    {
        /* new section */
        if(ptr[0]=='[')
            return last;
        last = ptr;

        /* read name and value */
        sscanf(ptr,"%159s",line);
        rvStrTokConstruct(&t,"= ",line);
        if ((token = rvStrTokGetToken(&t)) == NULL)
            continue;
        strcpy(params, token);
        if ((token = rvStrTokGetToken(&t)) == NULL)
            continue;
        strcpy(val, token);

        if(!strcmp(params,"UserDomain"))
        {
            rvStringAssign(&sampleParams->userDomain, val);
        }
        else if(!strcmp(params,"LocalAddress") )
        {
            replaceZeroWithLocal(sampleParams, val, sizeof(val));

            strncpy(sampleParams->localAddress, val, sizeof(sampleParams->localAddress)-1);
            sampleParams->localAddress[sizeof(sampleParams->localAddress)-1] = '\0';

            /* Place the IP address as the endpoint ID unless we got one already */
            if (sampleParams->eppIp[0] == '\0')
            {
                strncpy(sampleParams->eppIp, val, sizeof(sampleParams->eppIp)-1);
                sampleParams->eppIp[sizeof(sampleParams->eppIp)-1] = '\0';
            }
        }
        else if(!strcmp(params,"EppIp") )
        {
            strncpy(sampleParams->eppIp, val, sizeof(sampleParams->eppIp)-1);
            sampleParams->eppIp[sizeof(sampleParams->eppIp)-1] = '\0';
        }
        else if(!strcmp(params,"localIpPrefix") )
        {
            strncpy(sampleParams->localIpPrefix, val, sizeof(sampleParams->localIpPrefix)-1);
            sampleParams->localIpPrefix[sizeof(sampleParams->localIpPrefix)-1] = '\0';
        }
        else if(!strcmp(params,"localIpMask") )
        {
            strncpy(sampleParams->localIpMask, val, sizeof(sampleParams->localIpMask)-1);
            sampleParams->localIpMask[sizeof(sampleParams->localIpMask)-1] = '\0';
        }
        else if(!strcmp(params,"RegistrarAddress"))
        {
            replaceZeroWithLocal(sampleParams, val,sizeof(val));
            rvStringAssign(&sampleParams->registrarAddress, val);
        }
        else if(!strcmp(params,"RegistrarPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->registrarPort = (RvUint16)tmp;
        }
        else if(!strcmp(params,"OutboundProxyAddress"))
        {
            rvStringAssign(&sampleParams->outboundProxyAddress,val);
        }
        else if(!strcmp(params,"OutboundProxyPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->outboundProxyPort = (RvUint16)tmp;
        }
        else if(!strcmp(params,"EppPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->eppPort = (RvUint16)tmp;

			/* set the portLocalBase according to the EPP port */
			/* This is done in order to make sure that when running more than one MTF in the same
			   machine, each with different EPP port, the portLocalBase will differ as well.
			   When running two MTFs with the same portLocalBase one of the GUIs may crash.
			   The way to caclculate the portLocalBase:
			    5000 + EPP Port + (last 2 EPP Port digit * 100)
			   e.g.: EPP port = 3045
			   portLocalBase = 5000 + 3045 + 4500 = 12545 */
			sampleParams->mediaParam.mfControlParams.portLocalBase = (RvUint16)(5000 + tmp + (tmp % 100)*100);
        }
        else if(!strcmp(params,"disableGuiMedia"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->mediaParam.bDisableMedia = (RvBool)tmp;
        }
		else if(!strcmp(params,"NumberOfLines"))
		{
			RvUint    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->numberOfLines = tmp;
		}
#ifdef RV_SIP_IMS_ON
        else if(!strcmp(params,"PAccessNetworkInfo"))
        {
            strcpy(sampleParams->imsSampleParams.PAccessNetworkInfo,val);
        }
        else if(!strcmp(params,"ipsecPortC"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->imsSampleParams.ipsecPortC = (RvUint16)tmp;
        }
        else if(!strcmp(params,"ipsecPortS"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->imsSampleParams.ipsecPortS = (RvUint16)tmp;
        }
        else if(!strcmp(params,"ipsecSpiRangeStart"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->imsSampleParams.ipsecSpiRangeStart = (RvUint16)tmp;
        }
        else if(!strcmp(params,"ipsecSpiRangeEnd"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->imsSampleParams.ipsecSpiRangeEnd = (RvUint16)tmp;
        }
		else if (!strcmp(params, "DisableAkaAuthentication"))
        {
            sscanf(val,"%d",&sampleParams->imsSampleParams.disableAkaAuthentication);
        }
		else if(!strcmp(params,"AkaAuth_op"))
        {
			convertAkaAuthOpStrToArray(&sampleParams->imsSampleParams.akaAuth_op[0], val);
			sampleParams->imsSampleParams.isAkaAuthOpConfigured = RV_TRUE;
        }
		else if (!strcmp(params, "DisableSecAgree"))
        {
            sscanf(val,"%d",&sampleParams->imsSampleParams.disableSecAgree);
		}
#endif

#ifdef RV_MTF_STUN
        else if(!strcmp(params,"StunServerAddress"))
        {
            strncpy(sampleParams->stunServerAddress, val, sizeof(sampleParams->stunServerAddress)-1);
            sampleParams->stunServerAddress[sizeof(sampleParams->stunServerAddress)-1] = '\0';
        }
        else if(!strcmp(params,"StunServerPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->stunServerPort =(RvUint16)tmp;
        }
        else if(!strcmp(params,"StunClientResponsePort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->stunClientResponsePort =(RvUint16)tmp;
        }
        else if(!strcmp(params,"StunNeedMask"))
        {
            rvStringAssign(&sampleParams->stunNeedMask,val);
        }
#endif
        else if(!strcmp(params,"termId"))
        {
            rvStringAssign(&sampleParams->termId, val);
        }
        else if(!strcmp(params,"username"))
        {
            rvStringAssign(&sampleParams->username, val);
        }
        else if(!strcmp(params,"password"))
        {
            rvStringAssign(&sampleParams->password, val);
        }
        else if(!strcmp(params,"TransportType"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->transportType = (RvSipTransport)tmp;
        }
        else if(!strcmp(params,"TcpPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->stackTcpPort =(RvUint16)tmp;
        }
        else if(!strcmp(params,"UdpPort"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->stackUdpPort =(RvUint16)tmp;
        }
        else if (!strcmp(params, "MaxCallLegs"))
        {
            sscanf(val,"%d",&sampleParams->maxCallLegs);
        }
        else if (!strcmp(params, "AutoRegistration"))
        {
            sscanf(val,"%d",&sampleParams->autoRegister);
        }
        else if (!strcmp(params, "RegistrationExpire"))
        {
            sscanf(val,"%d",&sampleParams->registrationExpire);
        }
		else if (!strcmp(params, "UnregistrationExpire"))
        {
            sscanf(val,"%d",&sampleParams->unregistrationExpire);
        }
		else if (!strcmp(params, "MaxAuthenticateRetries"))
        {
            sscanf(val,"%d",&sampleParams->maxAuthenticateRetries);
        }
		else if (!strcmp(params, "RemoveOldAuthHeaders"))
        {
            sscanf(val,"%d",&sampleParams->removeOldAuthHeaders);
        }
        else if (!strcmp(params, "ReferTimeout"))
        {
            sscanf(val,"%d",&sampleParams->referTimeout);
        }
		else if (!strcmp(params, "OutgoingRequestNoResponseTimeout"))
        {
            sscanf(val,"%d",&sampleParams->outgoingRequestNoResponseTimeout);
        }
		else if (!strcmp(params, "OutgoingCallNoAnswerTimeout"))
        {
            sscanf(val,"%d",&sampleParams->outgoingCallNoAnswerTimeout);
        }
        else if (!strcmp(params, "CallWaitingReply"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->callWaitingReply =(RvCallWaitingReply)tmp;
        }
		else if (!strcmp(params, "disableCallWaiting"))
		{
			RvUint32    tmp;
			sscanf(val,"%d",&tmp);
			sampleParams->disableCallWaiting = (tmp != 0);
        }
		else if (!strcmp(params, "persistentRegisterEnabled"))
		{
			RvUint32    tmp;
			sscanf(val,"%d",&tmp);
			sampleParams->persistentRegisterEnabled = (tmp != 0);
		}
		else if (!strcmp(params, "persistentRegisterRetryInterval"))
		{
			sscanf(val,"%d",&sampleParams->persistentRegisterRetryInterval);
		}
		else if (!strcmp(params, "registerCompleteTimeout"))
		{
			sscanf(val,"%d",&sampleParams->registerCompleteTimeout);
		}
        else if (!strcmp(params, "MaxRegisterClients"))
        {
            sscanf(val,"%d",&sampleParams->maxRegClients);
        }
        else if (!strcmp(params, "TcpEnabled"))
        {
            sscanf(val,"%d",&sampleParams->tcpEnabled);
        }
        else if(!strcmp(params,"DialToneDuration"))
        {
            sscanf(val,"%d",&sampleParams->dialToneDuration);
        }
        else if(!strcmp(params,"DtmfRelay"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->dtmfRelay = (RvRtpDtmfRelay)tmp;
        }
        else if(!strcmp(params,"WatchdogInterval"))
        {
            sscanf(val,"%d",&sampleParams->watchdogTimeout);
        }
        else if(!strcmp(params,"displayName"))
        {
            strncpy((char*)&sampleParams->displayName, val, sizeof(sampleParams->displayName)-1);
        }

        else if (!strcmp(params, "CallForwardNoReplyTimeout"))
        {
			RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->callForwardNoReplyTimeout = tmp;
        }
        else if(!strcmp(params,"EppUseTCP"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->bConfigTCP = (tmp != 0);
        }
        else if(!strcmp(params,"EnableSdpLogs"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->enableSdpLogs = (tmp != 0);
        }
        else if (!strcmp(params,"connectMediaOn180"))
        {
            RvUint32    tmp;
            sscanf(val,"%d",&tmp);
            sampleParams->connectMediaOn180 = (tmp != 0);
        }
		else if (!strcmp(params,"addUserAgentHeader"))
		{
			RvUint32    tmp;
			sscanf(val,"%d",&tmp);
			sampleParams->addUserAgentHeader = (tmp != 0);
		}

		else if (!strcmp(params,"manufacturerId"))
		{
			strncpy((char*)&sampleParams->manufacturerId, val, sizeof(sampleParams->manufacturerId)-1);
		}
		else if (!strcmp(params,"productId"))
		{
			strncpy((char*)&sampleParams->productId, val, sizeof(sampleParams->productId)-1);
		}
		else if (!strcmp(params,"productVersion"))
		{
			strncpy((char*)&sampleParams->productVersion, val, sizeof(sampleParams->productVersion)-1);
		}



		else if (!strcmp(params,"digitMapPatterns"))
		{
			strncpy((char*)&sampleParams->digitMapPatterns, val, sizeof(sampleParams->digitMapPatterns )- 1);
		}
		else if (!strcmp(params,"sendOldHoldFormat"))
        {
			sscanf(val,"%d",&sampleParams->sendOldHoldFormat);
        }
		/* Parameters for UPDATE method support */
		/* ------------------------------------ */
		else if (!strcmp(params,"AddUpdateSupport"))
        {
			sscanf(val,"%d",&sampleParams->addUpdateSupport);
        }
		else if (!strcmp(params,"UpdateRetryAfterTimeout"))
        {
            RvInt n;
			sscanf(val,"%d",&n);
            sampleParams->updateRetryAfterTimeout = (RvUint8) n;
        }
		else if (!strcmp(params,"CallerUpdateResendTimeout"))
        {
            RvInt n;
            sscanf(val,"%d",&n);
			sampleParams->callerUpdateResendTimeout = (RvUint8) n;
        }
		else if (!strcmp(params,"CalleeUpdateResendTimeout"))
        {
            RvInt n;
            sscanf(val,"%d",&n);
			sampleParams->calleeUpdateResendTimeout = (RvUint8) n;
        }

		else if (!strcmp(params,"sessionTimerRefreshByUpdate"))
        {
			sscanf(val,"%d",&sampleParams->sessionTimerRefreshByUpdate);
        }
		else if (!strcmp(params,"sessionTimerMinimumAllowed"))
        {
			RvUint32    tmp;
            sscanf(val,"%d",&tmp);
			sampleParams->sessionTimerMinimumAllowed = (RvUint16)tmp ;
        }
		else if (!strcmp(params,"sessionTimerSessionExpires"))
        {
			RvUint32    tmp;
            sscanf(val,"%d",&tmp);
			sampleParams->sessionTimerSessionExpires = (RvUint16)tmp ;
        }
		else if (!strcmp(params,"autoAnswer"))
        {
            RvUint32    n;
            sscanf(val,"%d",&n);
            sampleParams->autoAnswer = (n != 0);
        }
		else if (!strcmp(params,"autoDisconnect"))
        {
            RvUint32    n;
            sscanf(val,"%d",&n);
            sampleParams->autoDisconnect = (n != 0);
        }
		else if (!strcmp(params,"acceptCallWhenUserNotFound"))
        {
            RvUint32    n;
            sscanf(val,"%d",&n);
            sampleParams->acceptCallWhenUserNotFound = (n != 0);
        }
		else if (!strcmp(params,"defaultProtocolType"))
		{
			RvUint32    n;
			sscanf(val,"%d",&n);
			sampleParams->defaultProtocolType = (n != 0);
		}

#ifdef SAMPLE_MWI
        else if(!strcmp(params,"SubsServerName"))
        {
            rvStringAssign(&sampleParams->subsServerName, val);
        }
#endif
#ifdef RV_CFLAG_TLS
        else
        {
            rvMtfSampleLoadTlsTransportParams(&sampleParams->transportTlsCfg, params, val);
            rvMtfSampleLoadTlsKepParams(&sampleParams->keyTlsCfg, params, val);
        }
#endif
    }
    return NULL;
}

#ifdef RV_MTF_H323
/***************************************************************************
 * loadH323LogOptions
 * ------------------------------------------------------------------------
 * General: Get names of LOG options to print in output device.
 * Return Value: None 
 * ------------------------------------------------------------------------
 * Arguments:
 * Params: 	IN  configBuffer        - buffer that contains options, specified by user
 *          OUT RvMdmUtilH323LogOprions - log options structure
 ***************************************************************************/
void loadH323LogOptions(RvIppH323LogOptions *h323log, char* configBuf)
{
	char   * ptr =NULL;/*initializing to NULL is used by rvIppSampleUtilGetNextLine() below*/
	char   line[512];
	RvStrTok t;
	char param[80]="",val[80]="" ;
        static RvBool inLogOptionSection=rvFalse;

	memset( h323log, 0, sizeof(RvIppH323LogOptions));
	while(rvMtfSampleUtilGetNextLine(configBuf,&ptr)!=NULL)
    {

        sscanf(ptr, "%s", line);

        if (!inLogOptionSection)
        {
            /* detect [LogOptions] section */
		    if(!strcmp(line,"[H323LogOptions]"))
            {
               inLogOptionSection = rvTrue;
               h323log->num=0;
            }

        }
        else
        {
		    if(ptr[0]=='[')
			    return;

		    sscanf(ptr,"%s",line);

			/* read debug level first */
			rvStrTokConstruct(&t, "= ", line);
			strcpy(param, rvStrTokGetToken(&t));
			if(!strcmp(param, "debLevel") )
			{
				strcpy(val, rvStrTokGetToken(&t));
				sscanf(val,"%d", &h323log->level);
			}
			else if(!strcmp(param, "msgdeb") )
			{
				strcpy(val, rvStrTokGetToken(&t));
				sscanf(val,"%d", &h323log->msgDeb);
			}
			else if(!strcmp(param, "msgfile") )
			{
				strcpy(val, rvStrTokGetToken(&t));
				sscanf(val,"%d", &h323log->msgFile);
			}
			/* read options */
			else
			{
				strcpy((char *)h323log->options[h323log->num], line);
				++h323log->num;
			}
        }

	}
}

#endif /* RV_MTF_H323 */
/***************************************************************************
 * loadSIPLogOptions
 * ------------------------------------------------------------------------
 * General: Get names of LOG options to print in output device.
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Params:  IN  configBuf  - buffer containing options, specified by user
 *          OUT logOptions  - log options structure
 ***************************************************************************/
static void loadSIPLogOptions(RvIppSipLogOptions* logOptions, char* configBuf)
{
    char   * ptr = NULL;
    char   line[512];
    char module[80]="",filterString[80]="";
    RvStrTok t;
    RvSipStackModule moduleId;
    RvInt8  filter;
    char* token;

    while (rvMtfSampleUtilGetNextLine(configBuf,&ptr) != NULL)
    {
        static RvBool inLogOptionSection=rvFalse;

        sscanf(ptr, "%511s", line);

        if (!inLogOptionSection)
        {
            /* detect [LogOptions] section */
            if(!strcmp(line,"[SipLogOptions]"))
            {
               inLogOptionSection = rvTrue;
               logOptions->num =0;
            }
        }
        else
        {
            if(ptr[0]=='[')
                return;

            /* read module name and filter string */
            sscanf(ptr,"%511s",line);
            rvStrTokConstruct(&t,"= ",line);
            if ((token = rvStrTokGetToken(&t)) == NULL)
                continue;
            strcpy(module, token);
            if ((token = rvStrTokGetToken(&t)) == NULL)
                continue;
            strcpy(filterString, token);

            if (logStringToStackModule(module,&moduleId) != rvTrue)
            {
                printf("failed to determine Module for the following line\n%s", line);
                break;
            }

            if (logFilterToInt(SIP_API_TYPE, filterString, &filter) != rvTrue)
            {
                printf("failed to determine Filter for the following line\n%s", line);
                break;
            }

            logOptions->filters[logOptions->num].moduleId = moduleId;
            logOptions->filters[logOptions->num].filter = (RvUint8)filter;
            logOptions->num++;
        }
    }
}

/***************************************************************************
 * loadPhoneNumbersList
 * ------------------------------------------------------------------------
 * General: Loads phone numbers list from configuration file to MTF sample.
 * Return Value: a pointer to the end of phone numbers section
 * ------------------------------------------------------------------------
 * Arguments:
 * Params:  IN  sampleParams  - a pointer to sample parameters
 *          IN  configBuf - configuration buffer
 ***************************************************************************/
static char* loadPhoneNumbersList(IN RvMtfSampleParams* sampleParams, IN char* configBuf)
{
	char line[128];
	RvString address, dialString;
	char * ptr = configBuf;
	char * last = NULL;
	char *ind;
	char* token;
	RvStrTok t;
	RvSize_t tokenLen;

	/*load the mapping list between dial string and address (URI)*/
	rvStringConstruct(&address, "", userDefaultAlloc);
	rvStringConstruct(&dialString, "", userDefaultAlloc);

	while(rvMtfSampleUtilGetNextLine(configBuf,&ptr)!=NULL)
    {
		if(ptr[0]=='[')
        {
            ptr=last;
            break;
        }
		last = ptr;

		/* Find display state and value*/
		tokenLen = (RvSize_t)(rvStrFindFirstOf(ptr,"\n") - ptr);

		/* Make sure it doesn't exceed line length*/
		if (tokenLen >= sizeof(line))
			tokenLen = sizeof(line)-1;

		/* copy to line and make sure it's NULL terminated*/
		strncpy(line, ptr, tokenLen);
		line[tokenLen] = '\0';

		ind = strchr(line,'\r');
		if (ind)
			*ind='\0';

		if (!strcmp(line,""))
		  break;

		rvStrTokConstruct(&t," ",line);
		if ((token = rvStrTokGetToken(&t)) == NULL)
			continue;
		rvStringAssign(&dialString, token);
		if ((token = rvStrTokGetToken(&t)) == NULL)
			continue;
		rvStringAssign(&address, token);
		rvMapSetValue(RvString, RvString)(&sampleParams->addressList, &dialString, &address);
		memset(line, 0, 128);
	}
	rvStringDestruct(&address);
	rvStringDestruct(&dialString);

	return ptr;
}

/*===============================================================================*/
/*================      U T I L S		F U N C T I O N S   =====================*/
/*===============================================================================*/

/***************************************************************************
 * rvMtfSampleUtilLoadMtfLogOptions
 * ------------------------------------------------------------------------
 * General: Get names of LOG options to print in output device.
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Params:  IN  configBuf  - buffer containing options, specified by user
 *          IN  numLogOptions - Number of options in the logOptions array
 *          OUT logOptions  - log options structure
 ***************************************************************************/
void rvMtfSampleUtilLoadMtfLogOptions(
    OUT IppLogSourceFilterElm*  logOptions,
    IN  RvSize_t                numLogOptions,
    IN  RvChar*                 configBuf)
{
    RvChar*     ptr = NULL;
    RvChar      line[512];
    RvChar      module[80]="";
    RvChar      filterString[80]="";
    RvStrTok    t;
    RvInt8      filter;
    RvSize_t    index = 0;
    RvChar*     token;
    RvBool      inLogOptionSection = RV_FALSE;

    while (rvMtfSampleUtilGetNextLine(configBuf, &ptr) != NULL)
    {
        sscanf(ptr, "%511s", line);

        if (!inLogOptionSection)
        {
            /* detect [LogOptions] section */
            if(!strcmp(line, "[IppLogOptions]"))
               inLogOptionSection = RV_TRUE;
        }
        else
        {
            if (ptr[0] == '[')
                break; /* We're done */

            /* read module name and filter string */
            sscanf(ptr, "%511s", line);
            rvStrTokConstruct(&t, "= ", line);
            if ((token = rvStrTokGetToken(&t)) == NULL)
                continue;

            strcpy(module, token);
            if ((token = rvStrTokGetToken(&t)) == NULL)
                continue;

            strcpy(filterString, token);

            if (!logFilterToInt(IPP_API_TYPE, filterString, &filter))
            {
                printf("failed to determine Filter for the following line\n%s", line);
                break;
            }

            if (index == numLogOptions)
            {
                printf("Too many filters...\n");
                break;
            }

            strncpy(logOptions[index].logSrcName, module, sizeof(logOptions[index].logSrcName)-1);
            logOptions[index].logSrcName[sizeof(logOptions[index].logSrcName)-1] = '\0';
            logOptions[index].messageMask = (RvLogMessageType)filter;
            index++;
        }
    }
}

/***************************************************************************************
 * rvMtfSampleUtilLoadFile
 * -------------------------------------------------------------------------------------
 * General:   Opens a file and copies the content of the file to a buffer.
 * Return Value: RV_OK on success, other on failure.
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 buf        - The buffer to fill in.
 *			 bufsize    - Maximum size of the buffer.
 *           fileName   - Name of file to load to memory.
 * Output:   buf        - The filled buffer (NULL terminated).
 **************************************************************************************/
RvStatus rvMtfSampleUtilLoadFile(
    IN RvChar*          buf,
    IN RvSize_t         bufsize,
    IN const RvChar*    fileName)
{
	FILE*       file;
	RvChar      line[512];
    RvSize_t    lineLength;
    RvSize_t    cnt = 0;
    RvChar      *p;
    RvChar      *pEnd;

	if ((file = fopen(fileName, "r")) == NULL)
    {
		printf("ERROR: %s File Not Found", fileName);
		return RV_ERROR_NOT_FOUND;
	}

    memset(buf, 0, bufsize);

    /* Read the file line by line */
	while (fgets(line, sizeof(line)-1, file) != NULL)
	{
        /* Skip whitespaces */
        line[sizeof(line)-1] = '\0';
        p = line;
        while (*p && isspace((RvInt)*p))
            p++;

		/* Kill comments */
        pEnd = strchr(p, (int)'#');
        if (pEnd != NULL)
            *pEnd = '\0';

        /* Remove trailing whitespaces */
        pEnd = p + strlen(p) - 1;
        while ((pEnd > p) && isspace((RvInt)*pEnd))
            *pEnd--;

        if (pEnd <= p)
            continue; /* We ended up with an empty line */

        /* Add the darn line to what we already have */
        lineLength = pEnd - p + 2;
        *(pEnd+1) = '\n';
        *(pEnd+2) = '\0';
		if (cnt + lineLength < bufsize)
		{
            strcpy(buf + cnt, p);
	        cnt += lineLength;
		}
		else
		{
			fclose(file);
    		printf("ERROR: %s File too big to fit in memory (%d)", fileName, (RvInt)bufsize);
			return RV_ERROR_OUTOFRESOURCES;
		}
	}

	fclose(file);
	return RV_OK;
}


/***************************************************************************************
 * rvMtfSampleUtilGetNextLine
 * -------------------------------------------------------------------------------------
 * General:   Goes through the received buffer, and returns the beginning of the next line.
 * Return Value: Returns a pointer to the beginning of the next line
 * Note: This function assumes all lines have info in them, and that they are already
 *       trimmed on both sides.
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the buffer to be parsed
 * Output:   string pointer - pointer to the beginning of the next line
 **************************************************************************************/
RvChar* rvMtfSampleUtilGetNextLine(IN RvChar* buf, OUT RvChar** p)
{
    RvChar *tmp = *p;

	if (*p == NULL)
    {
        /* We're at the beginning - give the first line */
		*p = buf;
		return buf;
	}

	/* Skip current line by getting to the next new line */
    while (*tmp && (*tmp != '\n'))
        tmp++;
    if (*tmp == '\n')
        tmp++;
    *p = tmp;

    if (!*tmp)
        return NULL; /* We're done */

	return *p;
}

/***************************************************************************************
 * rvMtfSampleUtilLoadMediaParams
 * -------------------------------------------------------------------------------------
 * General:   Seek for a section titled [MediaParameters0], [MediaParameters1] and [MediaParametersFull],
 *			  Convert contents of the section to RvSdpMsg
 * Return Value: True is succeeded, False if failed
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 string - the buffer
 *			 integer - index part of section name
 * Output:   None.
 **************************************************************************************/
RvBool rvMtfSampleUtilLoadMediaParams(IN const char* buffer, OUT RvMtfSampleParams* sampleParams)
{
	RvSdpMsg	sdpMsg;
	RV_BOOL     res = RV_TRUE;

	rvSdpMsgConstructA(&sdpMsg, userDefaultAlloc);
	/* get media for initial INVITE */
	/* If this media is not configured it will be filled by the media full caps later */
	if(sampleUtilFile2Sdp( buffer, "[MediaParameters0]", &sdpMsg))
	{
		sampleParams->sdpForInitialInvite = rvSdpMsgConstructCopyA(sampleParams->sdpForInitialInvite, &sdpMsg, userDefaultAlloc);
		rvSdpMsgDestruct(&sdpMsg);
		rvSdpMsgConstructA(&sdpMsg, userDefaultAlloc);
	}

    /*
    * load SDP with full capability from [MediaParametersFull] section. If it doesn't exist get it from
	* [MediaParameters0] section.
    */
	if(sampleUtilFile2Sdp( buffer, "[MediaParametersFull]", &sdpMsg ))

	{
		sampleParams->sdpOfFullCaps = rvSdpMsgConstructCopyA(sampleParams->sdpOfFullCaps, &sdpMsg, userDefaultAlloc);

		if (sampleParams->sdpForInitialInvite == NULL)
		{
			/* [mediaparameters0] was not configured, point to media full caps instead */
			sampleParams->sdpForInitialInvite = sampleParams->sdpOfFullCaps;
		}
	}
	else
	{
		if (sampleParams->sdpForInitialInvite != NULL)
		{

			/* point to the sdp of initial invite */
			sampleParams->sdpOfFullCaps =  sampleParams->sdpForInitialInvite;
		}
		else
		{
			IppLogMessage(RV_TRUE, "rvIppSampleLoadMediaParamsFromBuffer - no sdp for initial INVITE or full caps");
			res = RV_FALSE;
		}

	}

	rvSdpMsgDestruct(&sdpMsg);

	return res;
}

/***************************************************************************************
 * rvMtfSampleUtilCleanParam
 * -------------------------------------------------------------------------------------
 * General:   This function removes the "" from a string, if exist (used for EPP messages sent from GUI)
 * Return Value: None
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 str - the buffer with ""
 *
 * Output:   str - the buffer with no ""
 **************************************************************************************/
void rvMtfSampleUtilCleanParam(INOUT RvChar* str)
{
    RvInt i=0;

	if (str == NULL)
	{
		return;
	}

    if (str[0] != '"')
	{
        return;
	}

    while (str[i] != '\0')
	{
        str[i] = str[i+1];
        ++i;
    }

    str[i-2] = '\0';

}

/***************************************************************************
 * rvMtfSampleUtilPrintConfigParams
 * ------------------------------------------------------------------------
 * General: Prints MTF Sample configuration parameters.
 * Note: The parameters that are printed here are internal for sample only.
 * Other MTF parameters of the config file are printed in MTF code.
 *
 ***************************************************************************/
void rvMtfSampleUtilPrintConfigParams(IN RvMtfSampleParams *sampleParams)
{
    IppLogMessage(RV_FALSE,"************************************************************");
    IppLogMessage(RV_FALSE,"*********** MTF Sample Configuration Parameters: ***********");
    IppLogMessage(RV_FALSE,"**********termId		     : %s", sampleParams->termId);
    IppLogMessage(RV_FALSE,"**********Dtmf Relay         : %d", sampleParams->dtmfRelay);
    IppLogMessage(RV_FALSE,"**********Auto Answer        : %d", sampleParams->autoAnswer);
    IppLogMessage(RV_FALSE,"**********EppIp              : %s", sampleParams->eppIp);
    IppLogMessage(RV_FALSE,"**********EppPort            : %d", sampleParams->eppPort);
    IppLogMessage(RV_FALSE,"**********localIpPrefix      : %s", sampleParams->localIpPrefix);
    IppLogMessage(RV_FALSE,"**********localIpMask        : %s", sampleParams->localIpMask);
    IppLogMessage(RV_FALSE,"**********displayName        : %s", sampleParams->displayName);
#ifdef SAMPLE_MWI
    IppLogMessage(RV_FALSE,"**********SubsServerName     : %s", sampleParams->subsServerName);
#endif
    IppLogMessage(RV_FALSE,"**********callForwardNoReplyTimeout: %d", sampleParams->callForwardNoReplyTimeout);

#ifdef RV_MTF_STUN
    IppLogMessage(RV_FALSE,"**********StunServerAddress   : %s", sampleParams->stunServerAddress);
    IppLogMessage(RV_FALSE,"**********StunServerPort      : %d", sampleParams->stunServerPort);
    IppLogMessage(RV_FALSE,"**********StunNeedMask        : %s", sampleParams->stunNeedMask);
    IppLogMessage(RV_FALSE,"**********StunClientResponsePort: %d", sampleParams->stunClientResponsePort);
#endif
    IppLogMessage(RV_FALSE,"********************************************************\r\n");
}


/***************************************************************************
 * rvMtfSampleUtilLoadConfigParams
 * ------------------------------------------------------------------------
 * General: This function loads configuration parameters from configuration file.
 * Return Value: None
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 configBuf - configuration buffer
 *
 * Output:   sampleParams - structure with configuration parameters
 *
 ***************************************************************************/
void rvMtfSampleUtilLoadConfigParams(
    OUT RvMtfSampleParams*	sampleParams,
    IN RvChar*              configBuf)
{
    RvChar *ptr = NULL;
    RvChar line[512];

    while (rvMtfSampleUtilGetNextLine(configBuf, &ptr) != NULL)
    {
        /* Get a single line */
        sscanf(ptr, "%511s", line);

        /* Map to a given group of parameters */
        if(!strcmp(line,"[SIPParameters]"))
		{
            ptr = loadIppSipGatewayParams(sampleParams, ptr);
		}
#ifdef RV_MTF_H323 
        else if(!strcmp(line,"[H323Parameters]"))
		{
            ptr = loadIppH323GatewayParams(sampleParams, ptr);
		}
#endif /* RV_MTF_H323 */
        else if(!strcmp(line,"[PhoneNumbers]"))
		{
            ptr = loadPhoneNumbersList(sampleParams, ptr);
		}
        else if(!strcmp(line, "[MediaParam]"))
		{
            ptr = loadMediaParams( sampleParams, ptr);
		}
    }

    loadSIPLogOptions(&(sampleParams->logOptions), configBuf);
#ifdef RV_MTF_H323
    loadH323LogOptions(&(sampleParams->h323LogOptions), configBuf);
#endif /* RV_MTF_H323 */
}

/***************************************************************************
 * rvMtfSampleUtilDigitToEnum
 * ------------------------------------------------------------------------
 * General: This function maps digit character to digit enumerator.
 * Return Value: None
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input: 	 configBuf - configuration buffer
 *
 * Output:   sampleParams - structure with configuration parameters
 *
 ***************************************************************************/
RvMtfDigit rvMtfSampleUtilDigitToEnum(RvChar digit)
{
	switch (digit)
	{
		case '0':       return RV_MTF_DIGIT_0;
		case '1':       return RV_MTF_DIGIT_1;
		case '2':       return RV_MTF_DIGIT_2;
		case '3':       return RV_MTF_DIGIT_3;
		case '4':       return RV_MTF_DIGIT_4;
		case '5':       return RV_MTF_DIGIT_5;
		case '6':       return RV_MTF_DIGIT_6;
		case '7':       return RV_MTF_DIGIT_7;
		case '8':       return RV_MTF_DIGIT_8;
		case '9':       return RV_MTF_DIGIT_9;
		case '*':       return RV_MTF_DIGIT_STAR;
		case '#':       return RV_MTF_DIGIT_POUND;
		default:
			return RV_MTF_DIGIT_NONE;
	}

	return RV_MTF_DIGIT_NONE;
}

/***************************************************************************************
* rvMtfSampleUtilParseRegisterParams
* -------------------------------------------------------------------------------------
* General:  This function gets a string with terminal data sent by the terminal at
*           registration time, parses it and converts it into char* or int format.
*           An example for terminal data string:
*           register <term id> analog <GUI address> <GUI port>,RegistrarAddress=172.0.0.0,
*            RegistrarPort=9999,OutboundProxyAddress=172.0.0.0,OutboundProxyPort=8888,
*			 Username=alice,Password=radvision,RegisterExpires=3600
*
*           The input string may contain one or more of the data items.
* Return Value: - None
* -------------------------------------------------------------------------------------
* Arguments:
* Input:  regParams - a string with terminal data
*
* Output: termProperties - A data structure the stores the data after parsing
**************************************************************************************/
void rvMtfSampleUtilParseRegisterParams(
								IN RvChar*					regParams,
								OUT RvMtfTerminationConfig*	termConfig)
{
	char* token;
	RvStrTok commaTokenizer;

	if (regParams == NULL)
	{
		IppLogMessage(RV_FALSE, "parseRegData:: No Registration parameters supplied");
		return;
	}

    rvStrTokConstruct(&commaTokenizer, ",", regParams);
	while ((token = rvStrTokGetToken(&commaTokenizer)) != NULL)
	{
	   RvStrTok equalTokenizer;
	   char* name;
	   char* value;
	   RvUint32  tempVal;
	   rvStrTokConstruct(&equalTokenizer, "=", token);
	   name = rvStrTokGetToken(&equalTokenizer);
	   value = rvStrTokGetToken(&equalTokenizer);
	   if (rvStrIcmp(name, "username") == 0)
	   {
		    strncpy(termConfig->username, value, sizeof(termConfig->username)-1);
			termConfig->username[sizeof(termConfig->username)-1] = '\0';
	   }
	   else if (rvStrIcmp(name, "password") == 0)
	   {
		   	strncpy(termConfig->password, value, sizeof(termConfig->password)-1);
			termConfig->password[sizeof(termConfig->password)-1] = '\0';
	   }
	   else if (rvStrIcmp(name, "displayName") == 0)
	   {
		   strncpy(termConfig->displayName, value, sizeof(termConfig->displayName)-1);
		   termConfig->displayName[sizeof(termConfig->displayName)-1] = '\0';
	   }
	   else if (rvStrIcmp(name, "registrarAddress") == 0)
	   {
			strncpy(termConfig->registrarAddress, value, sizeof(termConfig->registrarAddress)-1);
			termConfig->registrarAddress[sizeof(termConfig->registrarAddress)-1] = '\0';
	   }
	   else if (rvStrIcmp(name, "registrarPort") == 0)
	   {
		   /* use the tempVal to convert from uint32 (the result of sscanf) to
		      the size of registrarPort field = uint16. sscanf'ing right to
		      termProperties->registrarPort will cause memory overrun. */
			sscanf(value,"%d",&tempVal);
			termConfig->registrarPort = (RvUint16)tempVal;
	   }
	   else if (rvStrIcmp(name, "outBoundProxyAddress") == 0)
	   {
			strncpy(termConfig->outboundProxyAddress, value, sizeof(termConfig->outboundProxyAddress)-1);
			termConfig->outboundProxyAddress[sizeof(termConfig->outboundProxyAddress)-1] = '\0';
	   }
	   else if (rvStrIcmp(name, "outBoundProxyPort") == 0)
	   {
		   /* use the tempVal to convert from uint32 (the result of sscanf) to
		      the size of outboundProxyPort field = uint16. sscanf'ing right to
		      termProperties->outboundProxyPort will cause memory overrun. */
		   sscanf(value,"%d",&tempVal);
		   termConfig->outboundProxyPort = (RvUint16)tempVal;
	   }
#ifdef RV_CFLAG_TLS
	    else if (rvStrIcmp(name, "registrarTlsPort") == 0)
	   {
		   /* use the tempVal to convert from uint32 (the result of sscanf) to
		      the size of registrarTlsPort field = uint16. sscanf'ing right to
		      termProperties->registrarTlsPort will cause memory overrun. */
		   sscanf(value,"%d",&tempVal);
		   termConfig->registrarTlsPort = (RvUint16)tempVal;
	   }
#endif
#ifdef RV_SIP_IMS_ON
	   else if (rvStrIcmp(name, "PAccessNetworkInfo") == 0)
	   {
		   strncpy(termConfig->PAccessNetworkInfo, value, sizeof(termConfig->PAccessNetworkInfo)-1);
		   termConfig->PAccessNetworkInfo[sizeof(termConfig->PAccessNetworkInfo)-1] = '\0';
	   }
	   else if (rvStrIcmp(name, "ipsecPortC") == 0)
	   {
		   /* use the tempVal to convert from uint32 (the result of sscanf) to
		      the size of ipsecPortC field = uint16. sscanf'ing right to
		      termProperties->ipSecPortC will cause memory overrun. */
		   sscanf(value,"%d",&tempVal);
		   termConfig->ipsecPortC = (RvUint16)tempVal;
	   }
	   else if (rvStrIcmp(name, "ipsecPortS") == 0)
	   {
		   /* use the tempVal to convert from uint32 (the result of sscanf) to
		      the size of ipsecPortC field = uint16. sscanf'ing right to
		      termProperties->ipsecPortC will cause memory overrun. */
		   sscanf(value,"%d",&tempVal);
		   termConfig->ipsecPortS = (RvUint16)tempVal;
	   }
#endif
	   else if (rvStrIcmp(name, "registerExpires") == 0)
	   {
		   sscanf(value,"%d",&tempVal);
		   termConfig->registerExpires = tempVal;
	   }
	   else if (rvStrIcmp(name, "TransportTcp") == 0)
	   {
		   sscanf(value, "%d", &tempVal);
		   termConfig->transportType = (RvSipTransport)tempVal;

		   if ((!g_sampleParams.tcpEnabled) && (termConfig->transportType == RVSIP_TRANSPORT_UNDEFINED))
		   {
			   IppLogMessage(RV_FALSE, "Warning: parseRegisterParams: transport type is TCP while TCP is disabled (tcpEnabled=0)", name);
		   }
	   }
	   else
	   {
		   IppLogMessage(RV_TRUE, "parseRegisterParams: Unknown registration parameter %s", name);
	   }
	   rvStrTokDestruct(&equalTokenizer);
	}

    rvStrTokDestruct(&commaTokenizer);

}


/*---------------------------------------------------------------------------*
 *                              DIGIT MAP PARSER PROCS                       *
 *---------------------------------------------------------------------------*/
static void createDigitPosition(RvMdmDigitPosition *pos, RvMdmDigitPositionTimerMode timerMode)
{
	/* Initialize the digit position stucture. There is no memory allocation */
	rvMdmDigitPositionConstruct(pos);
	rvMdmDigitPositionSetTimerMode(pos, timerMode);
}

static void storeDigitPositonEvent( RvMdmDigitPosition*  pos,
							 RvChar               c1,
                             RvChar               c2,
							 RvMdmDigitString*    digitString,
							 RvMdmDigitPositionTimerMode timerMode)
{
	if (pos->events != 0)
	{
		/* store the previous digit position before starting a new one */
		rvMdmDigitStringAddElement(digitString, pos );
		createDigitPosition(pos, timerMode);
	}
	rvMdmDigitPositionAddEvents(pos, c1, c2);
}

/***************************************************************************************
* rvMtfSampleUtilBuildDigitMap
* -------------------------------------------------------------------------------------
* General:  This function gets a string with digit dial patterns. It parses it into
*           a digitMap structure.
*           An example for an input string:
*           [2-8]xxxxxx|18xxxxxxxxx|0xxxxxxxxx|9xxxx|1[0-9]x|E|F|x.F|[0-9].L
*           Legend:
*           '|' - seperator between patterns.
*           'x' or 'X' - any digit in the range 0-9
*           [<digit>-<digit>] - a digit within the defined range
*           '.'  - zero or more repetions of the last dial event
*           'E' or 'e' - stands for  '*' key
*           'F' or 'f' - stands for  '#' key
*           'T' - The length of time allowed to dial the first digit from the time a
*                  dialtone is applied
*           'S' - Short interdigit timer
*           'L' - Long interdigit timer
*           The input string may contain one or more patterns.
*           NOTE: This is a simple parser therefore it does not handle errors. Make sure
*           that the dial patterns string is legal.
*
* Return Value: - None
* -------------------------------------------------------------------------------------
* Arguments:
* Input:  termProperties - a structure that holds the built digit map
*         digitMapString - a dial petterns string to parse
* Output:   none
**************************************************************************************/
void rvMtfSampleUtilBuildDigitMap(
				INOUT RvMdmDigitMap*	    digitMap,
				IN    char*					digitMapString )
{
	RvMdmDigitString   digitString;
	RvMdmDigitPosition pos1;

	int bStringIsEmpty = 1;
	char* currDigit;
    RvMdmDigitPositionTimerMode timerMode = RV_MDMDIGITPOSITION_NOCHANGE;

	IppLogMessage(RV_FALSE, "rvMtfSampleUtilBuildDigitMap: Creating a digit map with patterns %s", digitMapString);

	/* Set digitmap timeouts */
	/* --------------------- */
	rvMdmDigitMapSetStartTimeout( digitMap, 100 );
	rvMdmDigitMapSetShortTimeout( digitMap, 5 );
	rvMdmDigitMapSetLongTimeout( digitMap, 10 );

	/* Construct digitmap objects */
	/* -------------------------- */
	rvMdmDigitStringConstruct( &digitString );
	createDigitPosition(&pos1, timerMode);

	/* Point to the first character of the given digitmap string */
	currDigit = digitMapString;

	while( *currDigit )
	{

		/* Handle X */
		/* -------- */
		if( *currDigit == 'x' || *currDigit == 'X' )
		{
			storeDigitPositonEvent(&pos1, (char) '0', (char) '9', &digitString, timerMode);

			/* Pattern is not ended yet. */
			bStringIsEmpty = 0;
		}

		/* Handle digits */
		/* ------------- */
		else if ((*currDigit == '0') || (*currDigit == '1') || (*currDigit == '2') ||
				 (*currDigit == '3') || (*currDigit == '4') || (*currDigit == '5') ||
				 (*currDigit == '6') || (*currDigit == '7') || (*currDigit == '8') ||
				 (*currDigit == '9'))
		{

			storeDigitPositonEvent(&pos1, (char)(*currDigit), (char)(*currDigit), &digitString, timerMode);
			/* Pattern is not ended yet. */
			bStringIsEmpty = 0;
		}

		/* Handle '*' */
		/* ---------- */
		else if (*currDigit == '*' || *currDigit == 'e' || *currDigit == 'E')
		{

			storeDigitPositonEvent(&pos1, (char) 'e', (char) 'e', &digitString, timerMode);
			/* Pattern is not ended yet. */
			bStringIsEmpty = 0;
		}

		/* Handle '#' */
		/* ---------- */
		else if (*currDigit == '#'|| *currDigit == 'f' || *currDigit == 'F')
		{
			storeDigitPositonEvent(&pos1, (char) 'f', (char) 'f', &digitString, timerMode);
			/* Pattern is not ended yet. */
			bStringIsEmpty = 0;
		}

		/* Handle dot */
		/* ---------- */
		else if (*currDigit == '.')
		{
			rvMdmDigitPositionSetMultipleFlag(&pos1, RV_TRUE);
			/* Pattern is not ended yet. */
			bStringIsEmpty = 0;
		}

		/* Handle '|' */
		/* ---------- */
		else if( ( *currDigit ) == '|' )
		{
				/*  A pattern has ended */
			if (pos1.events != 0)
			{
				/* store the previous digit position before starting a new one */
				rvMdmDigitStringAddElement( &digitString, &pos1 );
				createDigitPosition(&pos1, timerMode);
			}
			/* Add a new pattern */
			rvMdmDigitMapAddPattern( digitMap, &digitString );
			rvMdmDigitStringDestruct( &digitString );
			rvMdmDigitStringConstruct( &digitString );

			/* The '|' indicates the end of pattern. */
			bStringIsEmpty = 1;
		}

		/* Handle [9-9] */
		/* ------------- */
		else if( ( *currDigit ) == '[' )
		{
			/* Add first character (currDigit+1), skip the dash (-) and add the second character (currDigit+3). */
			storeDigitPositonEvent(&pos1, *(currDigit+1), *(currDigit+3), &digitString, timerMode);
			/* Skip to the next character */
			currDigit += 4;
			/* Pattern is not ended yet. */
			bStringIsEmpty = 0;
		}

		/* Handle 'S' */
		/* ------------- */
		/* this is the short timer to wait between digits */
		else if( ( *currDigit ) == 'S' )
		{
			rvMdmDigitPositionSetTimerMode(&pos1, RV_MDMDIGITPOSITION_SHORTTIMER );
			timerMode = RV_MDMDIGITPOSITION_SHORTTIMER;

			/* Pattern is not ended yet. */
			bStringIsEmpty = 0;
		}

		/* Handle 'L' */
		/* ------------- */
		/* this is the short timer to wait between digits */
		else if( ( *currDigit ) == 'L' )
		{
			rvMdmDigitPositionSetTimerMode(&pos1, RV_MDMDIGITPOSITION_LONGTIMER );
			timerMode = RV_MDMDIGITPOSITION_LONGTIMER;

			/* Pattern is not ended yet. */
			bStringIsEmpty = 0;
		}

		/* Skip to the next character */
		currDigit++;
	}

	/* Add new pattern */
	/* --------------- */
	if( !bStringIsEmpty )
	{
		/* Add the last digit position and the last pattern. */
		rvMdmDigitStringAddElement( &digitString, &pos1 );
		rvMdmDigitMapAddPattern( digitMap, &digitString );
	}


	/* Destruct digitmap objects */
	/* ------------------------- */
	rvMdmDigitStringDestruct( &digitString );
	rvMdmDigitPositionDestruct( &pos1 );
}


