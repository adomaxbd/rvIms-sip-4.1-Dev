/******************************************************************************
Filename:    rvMtfSampleEpp.c
Description: This file includes the following functionality:
			 1. Construct and destruct sample application internal object
			 2. Implementations of EPP callbacks - these callbacks are called
			    whenever an EPP message arrives from GUI.
			 3. Sending signals to GUI (start dial tone etc.) - by building an
			    EPP message and send it to GUI.

			 Note:
			 This file is based on MTF sample specific implementation, and will
			 usualy not be useful to application. It is useful to application only
			 when it uses EPP for seperating MTF process and GUI process. If MTF
			 and GUI are running in one process, then there is no need for EPP.
*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "IppStdInc.h"
#include "rvMtfSample.h"
#include "rvMtfSampleMediaCallbacks.h"
#include "rvMtfEventsApi.h"
#include "rvMtfSampleUtils.h"
#include "rvMtfExtControlApi.h"
#include "rvMdmControlApi.h"
#include "ippthread.h"
#include "ippmisc.h"
#include "rvstr.h"
#include "rvcctext.h"

#ifdef SAMPLE_MWI
#include "rvMtfSampleMWI.h"
#endif

#define RV_UNREGISTER_AND_SHUTDOWN      1
#define RV_UNREGISTER_AND_RESTART       2

RV_BOOL notifyToStartWarmRestart = RV_FALSE;
RV_BOOL notifyToStartShutdown = RV_FALSE;
RV_BOOL unegisteredTerminationsLeft = RV_TRUE;

extern RvMtfSampleParams			g_sampleParams;


/*===============================================================================*/
/*===================    P R I V A T E	  F U N C T I O N S    ==================*/
/*===============================================================================*/

/*
RvPhoneLink *rvPhoneLinkConstruct(RvPhoneLink *x,  RvEppClientEndpoint *ece)
{
    x->endpoint = ece;
    return x;
}

void rvPhoneLinkDestruct(RvPhoneLink *x)
{
    RV_UNUSED_ARG(x);
}
*/

static RvUint32 parseLineId(const RvChar* line)
{
    RvInt id = (line[1]-'0')*100 + (line[2]-'0')*10 + (line[3]-'0');
    return id;
}

static RvChar mapIdToDigit(RvChar* id)
{
    if (!strcmp(id, "k0"))        return '0';
    if (!strcmp(id, "k1"))        return '1';
    if (!strcmp(id, "k2"))        return '2';
    if (!strcmp(id, "k3"))        return '3';
    if (!strcmp(id, "k4"))        return '4';
    if (!strcmp(id, "k5"))        return '5';
    if (!strcmp(id, "k6"))        return '6';
    if (!strcmp(id, "k7"))        return '7';
    if (!strcmp(id, "k8"))        return '8';
    if (!strcmp(id, "k9"))        return '9';
    if (!strcmp(id, "ks"))        return '*';
    if (!strcmp(id, "ko"))        return '#';

    return '0';
}

static void mapIndicatorStateToStr(RvMtfSignalState state, RvChar* strState)
{
    switch (state)
    {
    case RV_MTF_SIGNAL_STATE_ON:
        strcpy(strState, "on");
        break;
    case RV_MTF_SIGNAL_STATE_OFF:
        strcpy(strState, "off");
        break;
    case RV_MTF_SIGNAL_STATE_BLINK:
        strcpy(strState, "blink");
        break;
    case RV_MTF_SIGNAL_STATE_FAST_BLINK:
        strcpy(strState, "fast_blink");
        break;
    default:
        strcpy(strState, "");
        break;
    }
}

static RvStatus mapDigitEnumToStr(IN RvMtfDigit digit, OUT RvChar* digitEvent)
{
    switch (digit)
    {
    case RV_MTF_DIGIT_0:
        strcpy(digitEvent, "d0");
        break;
    case RV_MTF_DIGIT_1:
        strcpy(digitEvent, "d1");
        break;
    case RV_MTF_DIGIT_2:
        strcpy(digitEvent, "d2");
        break;
    case RV_MTF_DIGIT_3:
        strcpy(digitEvent, "d3");
        break;
    case RV_MTF_DIGIT_4:
        strcpy(digitEvent, "d4");
        break;
    case RV_MTF_DIGIT_5:
        strcpy(digitEvent, "d5");
        break;
    case RV_MTF_DIGIT_6:
        strcpy(digitEvent, "d6");
        break;
    case RV_MTF_DIGIT_7:
        strcpy(digitEvent, "d7");
        break;
    case RV_MTF_DIGIT_8:
        strcpy(digitEvent, "d8");
        break;
    case RV_MTF_DIGIT_9:
        strcpy(digitEvent, "d9");
        break;
    case RV_MTF_DIGIT_STAR:
        strcpy(digitEvent, "ds");
        break;
    case RV_MTF_DIGIT_POUND:
        strcpy(digitEvent, "do");
        break;
    default:
        return RV_ERROR_BADPARAM;
        break;
    }

    return RV_OK;
}

/*===============================================================================*/
/*=============    S A M P L E		I N T E R N A L		O B J E C T   ===========*/
/*===============================================================================*/

RvStatus rvMtfSampleEppConstruct(
						 IN RvMtfSampleEpp*			mgr,
						 IN RvMtfHandle				mtfHandle,
						 IN RvBool					bConfigTCP,
						 IN const RvChar*			eppClientIp,
						 IN RvUint16				eppPort)
{
    static RvEppClient eppClient;
    RvStatus status;

    g_sampleParams.mtfHandle = mtfHandle;

    status = rvEppClientConstruct(
					&eppClient,
					bConfigTCP,
					eppClientIp,
					eppPort,
					rvMtfSampleEppOnRegister,
					rvMtfSampleEppOnEvent,
					rvMtfSampleEppOnUnregister,
					mgr);

    if (status != RV_OK)
	{
        return status;
	}

    mgr->eppClient = &eppClient;

    return RV_OK;
}

void rvMtfSampleEppDestruct(RvMtfSampleEpp *mgr)
{
    rvEppClientDestruct(mgr->eppClient);
}

/*===============================================================================*/
/*=======E P P     C A L L B A C K		I M P L E M E N T A T I O N S  ==========*/
/*===============================================================================*/

void rvMtfSampleEppOnEvent(
                RvEppClient*            ec,
                RvEppClientEndpoint*    ece,
                const RvChar*             eventName,
				RvChar*                   eventParams,
                void*                   data)
{
	RvIppTerminalHandle     hTerm;
//    RvMtfEvent              event;

	RvStrTok                tokenizer;
	RvChar *pkg=NULL, *id=NULL;
	RvChar* keyId = NULL;

	RV_UNUSED_ARG(ec);
	RV_UNUSED_ARG(data);

	hTerm = (RvIppTerminalHandle)rvEppClientEndpointGetUserData(ece);

	if (hTerm == NULL)
	{
		return;
	}

	rvStrTokConstruct(&tokenizer, "/", (RvChar*)eventName);
	pkg = rvStrTokGetToken(&tokenizer);
	id = rvStrTokGetToken(&tokenizer);

	if ((id == NULL) || (pkg == NULL))
	{
		rvStrTokDestruct(&tokenizer);
		return;
	}

	rvStrTokConstruct(&tokenizer, ",", eventParams);
	keyId = rvStrTokGetToken(&tokenizer);
	rvMtfSampleUtilCleanParam(keyId);

	if (!strcmp(pkg, "kf"))
	{
		if (!strcmp(id, "ku"))
		{
			if(!rvStrIcmp(keyId,"kh"))
            {
                /* Send On Hook event */
                /* ------------------ */
                rvMtfSampleOnHookEvent(hTerm);
            }
			else if(!rvStrIcmp(keyId,"kl"))
            {
                /* Send Hold event */
                /* --------------- */
                rvMtfSampleHoldEvent(hTerm);
            }
			else if(!rvStrIcmp(keyId,"kc"))
            {
                /* Send Conference event */
                /* --------------------- */
                rvMtfSampleConferenceEvent(hTerm);
            }
			else if(!rvStrIcmp(keyId,"kt"))
            {
                /* Send Transfer event */
                /* ------------------- */
                rvMtfSampleTransferEvent(hTerm);
            }
			else if(!rvStrIcmp(keyId,"kbt"))
            {
                /* Send Blind Transfer event */
                /* ------------------------- */
                rvMtfSampleBlindTransferEvent(hTerm);
            }
			else if(!rvStrIcmp(keyId,"mu"))
            {
                /* Send Mute event */
                /* --------------- */
                rvMtfSampleMuteEvent(hTerm);
            }
			else if(!rvStrIcmp(keyId,"hf") )
            {
                /* Send Speaker event */
                /* ------------------ */
                rvMtfSampleSpeakerEvent(hTerm);
            }
			else if(!rvStrIcmp(keyId,"ht"))
            {
                /* Send Headset event */
                /* ------------------ */
                rvMtfSampleHeadesetEvent(hTerm);
            }
			else if(!rvStrIcmp(keyId,"redial"))
            {
                /* Send Redial event */
                /* ----------------- */
                rvMtfSampleRedialEvent(hTerm);
            }

			/*Note: make case insensitive*/
			else if(!strncmp(keyId,"l",1))
			{
                /* Send Line event */
                /* --------------- */
				RvUint32  lineId = parseLineId(keyId);
                rvMtfSampleLineEvent(hTerm, lineId);
			}

			/* Send Call Forward event */
            /* ----------------------- */
			else if (!rvStrIcmp("ku", id))
			{
				RvIppCfwType typeNumber;
				if ((typeNumber = rvCCCfwGetTypeNumber(eventParams)) != RV_IPP_CFW_TYPE_NONE) /* cfw type */
				{
					rvMtfSampleCallForwardEvent(hTerm, typeNumber);
				}
			}
		}

		if(!rvStrIcmp(id,"kd"))
		{
			if(!rvStrIcmp(keyId,"kh"))
            {
                /* Send Off Hook event */
                /* ------------------- */
                rvMtfSampleOffHookEvent(hTerm);
            }
		}

	}
	else if(!rvStrIcmp(pkg,"kp"))
	{
		if(!rvStrIcmp(id,"ce"))
		{
            /* Send Dial Compeleted event */
            /* -------------------------- */
            rvMtfSampleDialCompletedEvent(hTerm);
		}
		else if(!rvStrIcmp(id,"kd"))
		{
            /* Send Digit Down event */
            /* --------------------- */
			RvChar digit = mapIdToDigit(keyId);

            rvMtfSampleDigitDownEvent(hTerm, digit);
		}
		/* Use later to control stop playing DTMF tone
		   when dialing digits*/
		else if(!rvStrIcmp(id,"ku"))
		{
            /* Send Digit Up event */
            /* ------------------- */
			RvChar digit = mapIdToDigit(keyId);

            rvMtfSampleDigitUpEvent(hTerm, digit);
		}
	}

	/*Radvision Internal package - Gateway active event*/
	else if(!rvStrIcmp(pkg,"rvcc"))
	{
	/* Send Reject call event */
    /* ---------------------- */
		if(!rvStrIcmp(id,"reject"))
        {
            RvUint32	lineId = parseLineId(keyId);
            rvMtfSampleRejectCallEvent(hTerm, lineId);
        }
	}

    /* Dynamic media change - send Re-Invite*/
    else if (!rvStrIcmp(pkg, "modify_media"))
    {
        if (!rvStrIcmp(id, "reinvite"))
        {
			RvChar              sdpStr[1024];

			rvMtfSampleUtilCleanParam(id);

			strcpy(sdpStr, eventParams);
			rvMtfSampleUtilCleanParam(sdpStr);

			rvMtfSampleModifyMediaByReInvite(hTerm, sdpStr, strlen(sdpStr));
        }
		/* Send dynamic SDP received in EPP message */
        else if (!rvStrIcmp(id, "update"))
        {
			RvChar              sdpStr[1024];

			rvMtfSampleUtilCleanParam(id);

			strcpy(sdpStr, eventParams);
			rvMtfSampleUtilCleanParam(sdpStr);

			rvMtfSampleModifyMediaByUpdate(hTerm, sdpStr, strlen(sdpStr));
        }
		/* Check if we are in process of sending or receiving Update */
        else if (!rvStrIcmp(id, "is_in_process"))
        {
			RvBool			bIsUpdateInProcess;

			rvMtfTerminationIsUpdateInProcess(hTerm, NULL, &bIsUpdateInProcess);
			if (bIsUpdateInProcess == RV_TRUE)
			{
				IppLogMessage(RV_FALSE, "====== Update is in process");
			}
			else
			{
				IppLogMessage(RV_FALSE, "====== Update is not in process");

			}
        }
		/* Check if Update can be sent out */
        else if (!rvStrIcmp(id, "is_feasible"))
        {
			RvBool			bIsUpdateFeasible;

			rvMtfTerminationIsUpdateFeasible(hTerm, NULL, &bIsUpdateFeasible);
			if (bIsUpdateFeasible == RV_TRUE)
			{
				IppLogMessage(RV_FALSE, "====== Update is feasible");
			}
			else
			{
				IppLogMessage(RV_FALSE, "====== Update is not feasible");

			}

        }
		/* Check if Update is allowed */
        else if (!rvStrIcmp(id, "is_allowed"))
        {
			RvBool			bIsUpdateAllowed;

			rvMtfTerminationIsUpdateAllowedByRemoteParty(hTerm, NULL, &bIsUpdateAllowed);
			if (bIsUpdateAllowed == RV_TRUE)
			{
				IppLogMessage(RV_FALSE, "====== Update is allowed");
			}
			else
			{
				IppLogMessage(RV_FALSE, "====== Update is not allowed");

			}
        }

		/* Get Update state */
        else if (!rvStrIcmp(id, "get_state"))
        {
			RvMtfOfferAnswerState		state;

			rvMtfTerminationGetOfferAnswerState(hTerm, NULL, &state);
			IppLogMessage(RV_FALSE, "====== Offer/Answer state = %s", rvMtfTextOfferAnswerState(state));
        }
    }

	/* Make Call */
    /* --------- */
    else if (!rvStrIcmp(pkg, "call"))
    {
        if (!rvStrIcmp(id, "make"))
        {
            char    destination[1024];

            strcpy(destination, eventParams);
            rvMtfSampleUtilCleanParam(destination);

			/* Note: off hook event should be sent before calling this function*/
            rvMtfTerminalMakeCall(hTerm, destination);

        }
    }

    /* Register to SIP Registrar */
    /* ------------------------- */
    else if (!rvStrIcmp(pkg, "register"))
    {
        /* Register this terminal to SIP Registrar */
        if (!rvStrIcmp(id, "network"))
        {
			rvMtfRegisterTerminationToSipServer(g_sampleParams.mtfHandle, hTerm);

        }
        /* Register all terminals to SIP Registrar */
        else if (!rvStrIcmp(id, "all"))
        {
            rvMtfRegisterAllTerminationsToSipServer(g_sampleParams.mtfHandle);

        }
    }

    /* Change terminal parameters */
    /* -------------------------- */
    else if (!rvStrIcmp(pkg, "set"))
    {
        if (!rvStrIcmp(id, "registrar_address"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "registrar_port"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "proxy_address"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "proxy_port"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "expires"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "username"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
        if (!rvStrIcmp(id, "password"))
        {
            // CHANGE TERMINAL PARAMETERS DYNAMICALLY
            printf(eventParams);

        }
    }

    /* Unregister from SIP Registrar */
    /* ----------------------------- */
    else if (!rvStrIcmp(pkg, "unregister"))
    {
        if (!rvStrIcmp(id, "network"))
        {
            rvMtfUnregisterTerminationFromSipServer(g_sampleParams.mtfHandle, hTerm);

        }
    }

	rvStrTokDestruct(&tokenizer);
}

RvBool rvMtfSampleEppOnRegister(RvEppClientEndpoint *ece, void *params)
{
    RvIppTerminalHandle			hTerm = NULL;
    char*						termId			= rvEppClientEndpointGetName(ece);
    RvBool						rc				= RV_TRUE;

    IppLogMessage(RV_FALSE, "rvMtfSampleEppOnRegister(ece:%p, params:%p)", ece, params);

	/* Register UI hTerm */
	/* ----------------------- */
    if (!strcmp(termId, "ui"))
    {
		/* We pass a pointer to EPP client as our user data */
		rvMtfSampleRegisterIPPhone((char*)rvStringGetData(&g_sampleParams.termId), (void*)ece, &hTerm);

#ifdef SAMPLE_MWI
		if (hTerm != NULL)
		{
			rvMtfSampleSipSendSubscribe( hTerm);
		}
#endif
    }

#ifdef RV_MTF_VIDEO
	/* Register Camera hTerm */
	/* --------------------------- */
    else if ( strstr( termId,"vt/cam"))
    {
		rvMtfSampleRegisterVideo((void*)ece);
    }
#endif /* RV_MTF_VIDEO */

	/* Register Analog hTerm */
	/* --------------------------- */
    else if (rvEppClientEndpointGetProfile(ece) == EP_PROFILE_ANALOG)
    {
		rvMtfSampleRegisterAnalog(termId, params, ece, &hTerm);
    }

    return rc;
}

void rvMtfSampleEppOnUnregister(
							RvEppClient*				ec,
                            RvEppClientEndpoint*		ece,
                            void*						data,
                            RvChar*						params)
{
    RvIppTerminalHandle hTerm = (RvIppTerminalHandle)rvEppClientEndpointGetUserData(ece);
	char*				termId			= rvEppClientEndpointGetName(ece);

    RV_UNUSED_ARG(ec);
    RV_UNUSED_ARG(data);

   /*
     *  remove reference to phoneLink from hTerm
     *  remove reference to hTerm from ece
     */
    if (hTerm != NULL)
    {
        rvMtfTerminationSetAppHandle(hTerm, NULL);
    }

    rvEppClientEndpointSetUserData(ece, NULL);

    if (params != NULL)
    {
        rvMtfSampleUtilCleanParam(params);

        if (atoi(params) == RV_UNREGISTER_AND_RESTART)
        {
            /* This will cause main loop to stop sleeping and restart MTF */
            notifyToStartWarmRestart = RV_TRUE;
        }
        else if (atoi(params) == RV_UNREGISTER_AND_SHUTDOWN)
        {
            /* This will cause main loop to stop sleeping and shutdown MTF */
            notifyToStartShutdown = RV_TRUE;
        }
    }

    if (ec->numEndpoints == 1)
    {
        unegisteredTerminationsLeft = RV_FALSE;
    }

    /*
     * unregister and delete hTerm
     */
    if (hTerm != NULL)
    {
		/* Unregister IPPhone */
		/* ------------------ */
		if (!strcmp(termId, "ui"))
		{
			rvMtfSampleUnregisterIPPhone(hTerm);
		}

		/* Unregister Analog */
		/* ----------------- */
		else
		{
			/* only analog terminals will be unregister in this case */
			if(strcmp( termId,"vt/cam")!=0 )
			{
				rvMtfSampleUnregisterAnalog(hTerm);
			}
		}
    }
#ifdef RV_MTF_VIDEO
	/* Unregister Video */
	/* ---------------- */
	if ( !strcmp( termId,"vt/cam"))
	{
		rvMtfSampleUnregisterVideo();
	}
#endif /* RV_MTF_VIDEO */

 /*
     * destroy and delete phoneLink
     */
//MARKA     rvPhoneLinkDestruct(phoneLink);
//MARKA     rvMtfAllocatorDealloc(phoneLink);
}



/*===============================================================================*/
/*=======  S I G N A L   C A L L B A C K S    I M P L E N T A T I O N S =========*/
/*===============================================================================*/
void rvMtfGuiStartDialTone(RvEppClientEndpoint*		ece)
{
	RvBool res;

	res = rvEppClientStart( ece, "cg/dt");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStartDialTone() - failed to start dial tone in GUI");
	}

}

void rvMtfGuiStartRingbackTone(
							   RvEppClientEndpoint*		ece, 
							   char*                    signalInfo)
{
	RvBool res;
	char   signalLine[256];


	if (!strcmp(signalInfo, "")) 
        sprintf(signalLine, "cg/rt");
    else
        sprintf(signalLine, "cg/rt \"%s\"", signalInfo);

	res = rvEppClientStart( ece, signalLine);


	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStartRingbackTone() - failed to start ringback tone in GUI");
	}
}

void rvMtfGuiStartRingingTone(
							  RvEppClientEndpoint*		ece, 
							  char*                     signalInfo)
{
	RvBool res;
	char   signalLine[256];

	if (!strcmp(signalInfo, "")) 
        sprintf(signalLine, "ind/is \"ir\",\"on\"");
    else
        sprintf(signalLine, "ind/is \"ir\",\"on\",\"%s\"", signalInfo);

	res = rvEppClientStart( ece, signalLine);

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStartRingingTone() - failed to start ringing tone in GUI");
	}

}

void rvMtfGuiStartCallWaitingTone(RvEppClientEndpoint*		ece)
{
	RvBool res;

	res = rvEppClientStart( ece, "cg/cr");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStartCallWaitingTone() - failed to start call waiting tone in GUI");
	}
}

void rvMtfGuiStartCallWaitingCalleeTone(RvEppClientEndpoint*		ece)
{
	RvBool res;

	res = rvEppClientStart( ece, "cg/cw");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStartCallWaitingCalleeTone() - failed to start call waiting callee tone in GUI");
	}
}

void rvMtfGuiStartBusyTone(RvEppClientEndpoint*		ece)
{
	RvBool res;

	res = rvEppClientStart( ece, "cg/bt");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStartBusyTone() - failed to start busy tone in GUI");
	}
}

void rvMtfGuiStartWarningTone(RvEppClientEndpoint*		ece)
{
	RvBool res;

	res = rvEppClientStart( ece, "cg/wt");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStartWarningTone() - failed to start warning tone in GUI");
	}
}

void rvMtfGuiStartDigitTone(
						RvEppClientEndpoint*	ece,
						RvMtfDigit				digit)
{
	RvChar signalLine[256];
    RvChar param[128];
	RvStatus rv;
	RvBool res;

	strcpy(signalLine, "");

	rv = mapDigitEnumToStr(digit, param);
	if (rv != RV_OK)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStartDigitTone() - unrecognized digit");
		return;
	}

    sprintf(signalLine, "dg/%s \"%d\"", param, 0);

	res = rvEppClientStart( ece, signalLine);

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStartDigitTone() - failed to start digit tone in GUI");
	}

}

void rvMtfGuiSetLineIndicator(
						RvEppClientEndpoint*	ece,
						RvMtfSignalState        signalState,
						RvUint32				lineId)
{
	RvChar signalLine[256];
    RvChar param[128];
	RvBool res;

	strcpy(signalLine, "");

	mapIndicatorStateToStr(signalState, param);
    sprintf(signalLine, "ind/is \"l00%d\",\"%s\"", lineId, param);

	res = rvEppClientStart( ece, signalLine);

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiSetLineIndicator() - failed to set line indicator in GUI");
	}

}

void rvMtfGuiSetHoldIndicator(
						RvEppClientEndpoint*	ece,
						RvMtfSignalState        signalState)
{
	RvChar signalLine[256];
    RvChar param[128];
	RvBool res;

	strcpy(signalLine, "");

 	mapIndicatorStateToStr(signalState, param);
    sprintf(signalLine, "ind/is \"il\",\"%s\"", param);

	res = rvEppClientStart( ece, signalLine);

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiSetHoldIndicator() - failed to set hold indicator in GUI");
	}

}

void rvMtfGuiSetMuteIndicator(
						RvEppClientEndpoint*	ece,
						RvMtfSignalState        signalState)
{
	RvChar signalLine[256];
    RvChar param[128];
	RvBool res;

	strcpy(signalLine, "");

	mapIndicatorStateToStr(signalState, param);
	sprintf(signalLine, "ind/is \"mu\",\"%s\"", param);

	res = rvEppClientStart( ece, signalLine);

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiSetMuteIndicator() - failed to set mute indicator in GUI");
	}

}

void rvMtfGuiSetSpeakerIndicator(
						RvEppClientEndpoint*	ece,
						RvMtfSignalState        signalState)
{
	RvChar signalLine[256];
    RvChar param[128];
	RvBool res;

	strcpy(signalLine, "");

	mapIndicatorStateToStr(signalState, param);
    sprintf(signalLine, "ind/is \"hs\",\"%s\"", param);

	res = rvEppClientStart( ece, signalLine);

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiSetSpeakerIndicator() - failed to set speaker indicator in GUI");
	}

}

void rvMtfGuiSetHeadsetIndicator(
						RvEppClientEndpoint*	ece,
						RvMtfSignalState        signalState)
{

	RvChar signalLine[256];
    RvChar param[128];
	RvBool res;

	strcpy(signalLine, "");

	mapIndicatorStateToStr(signalState, param);
    sprintf(signalLine, "ind/is \"ht\",\"%s\"", param);

	res = rvEppClientStart( ece, signalLine);

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiSetHeadsetIndicator() - failed to set headset indicator in GUI");
	}

}

void rvMtfGuiStopDialTone(
						 RvEppClientEndpoint*	ece)
{
	RvBool res;

	res = rvEppClientStop( ece, "cg/dt");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStopDialTone() - failed to stop dial tone in GUI");
	}

}

void rvMtfGuiStopRingbackTone(
							  RvEppClientEndpoint*	ece)
{
	RvBool res;

	res = rvEppClientStop( ece, "cg/rt");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStopRingbackTone() - failed to stop ringback tone in GUI");
	}

}

void rvMtfGuiStopRingingTone(
							  RvEppClientEndpoint*	ece)
{
	RvBool res;

	res = rvEppClientStart( ece, "ind/is \"ir\",\"off\"");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStopRingingTone() - failed to stop ringing tone in GUI");
	}

}

void rvMtfGuiStopCallWaitingTone(
							  RvEppClientEndpoint*	ece)
{
	RvBool res;

	res = rvEppClientStop( ece, "cg/cr");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStopCallWaitingTone() - failed to stop call waiting tone in GUI");
	}

}

void rvMtfGuiStopCallWaitingCalleeTone(
							  RvEppClientEndpoint*	ece)
{
	RvBool res;

	res = rvEppClientStop( ece, "cg/cw");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStopCallWaitingCalleeTone() - failed to stop call waiting callee tone in GUI");
	}

}

void rvMtfGuiStopBusyTone(
							  RvEppClientEndpoint*	ece)
{
	RvBool res;

	res = rvEppClientStop( ece, "cg/bt");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStopBusyTone() - failed to stop busy tone in GUI");
	}

}
void rvMtfGuiStopWarningTone(
							  RvEppClientEndpoint*	ece)
{
	RvBool res;

	res = rvEppClientStop( ece, "cg/wt");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStopWarningTone() - failed to stop warning tone in GUI");
	}

}

void rvMtfGuiSetTextDisplay(
							RvEppClientEndpoint*	ece,
							RvChar* 				text,
							RvUint 					column,
							RvUint 					row)
{
	RvChar signalLine[256];
	RvBool res;

	if (text == NULL)
    {
        res = rvEppClientStart(  ece, "dis/cld");
    }
    else
    {
		sprintf(signalLine, "dis/di \"%s\",\"%d\",\"%d\"", text, column, row);
		res = rvEppClientStart(  ece, signalLine);
    }

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiSetTextDisplay() - failed to set display in GUI");
	}

}


void rvMtfGuiClearTextDisplay(RvEppClientEndpoint*	ece)
{
	RvBool res;

    res = rvEppClientStart(  ece, "dis/cld");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiClearTextDisplay() - failed to clear display in GUI");
	}
}

void rvMtfGuiSetMwiIndicator(
					 RvEppClientEndpoint*		ece,
					 RvMtfSignalState			signalState)
{
	RvChar signalLine[256];
    RvChar param[128];
	RvBool res;

	strcpy(signalLine, "");

	mapIndicatorStateToStr(signalState, param);
    sprintf(signalLine, "mwi/msg \"im\",\"%s\"", param);

	res = rvEppClientStart( ece, signalLine);

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiSetMwiIndicator() - failed to set MWI indicator in GUI");
	}
}

void rvMtfGuiStartMwiTone(RvEppClientEndpoint*	ece)
{
	RvBool res;

    res = rvEppClientStart(  ece, "mwi/msg");

	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiStartMwiTone() - failed to start MWI tone in GUI");
	}
}


/* Display line indication in the GUI settings->call window */
#ifdef RV_MTF_N_LINES 
void rvMtfGuiSetTextNLineStatus(
								RvEppClientEndpoint*	ece,							
								RvUint 					lineID,
								RvChar* 				text)
{
	RvChar signalLine[256];
	RvBool res;
	
	if (text == NULL)
    {
        res = rvEppClientStart(  ece, "dis/cld");
    }
    else
    {
		sprintf(signalLine, "dis/lis \"%d\",\"%s\"", lineID, text);
		res = rvEppClientStart(  ece, signalLine);
    }
	
	if (res == RV_FALSE)
	{
		IppLogMessage(RV_TRUE, "rvMtfGuiSetTextNLineStatus() - failed to set display in GUI");
	}	
}
#endif
