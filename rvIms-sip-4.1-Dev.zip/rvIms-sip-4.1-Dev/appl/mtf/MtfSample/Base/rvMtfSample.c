/******************************************************************************
Filename:    rvMtfSample.c
Description: This file demonstrates how MTF APIs can be used. The file includes
			 a the following functionality:
			 1. Initialization and shut down of MTF and sample application
			 2. Registration and un-registration of terminations
			 3. Sending events to MTF
			 4. Implementations of MTF signal callbacks
			 5. Implementations of MTF termination callbacks
			 6. Other APIs

			 Note:
			 For media integration see implementations of MTF media callbacks
			 in file rvMtfSampleMediaCallbacls.c.
*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "IppStdInc.h"
#include "ippthread.h"
#include "rvMtfSample.h"
#include "rvMtfSampleSipControl.h"
#include "rvMtfSampleCallControl.h"
#include "rvMtfSampleUtils.h"
#include "rvMtfSampleMediaNegotiate.h"
#include "rvMtfSampleMediaCallbacks.h"
#include "rvMtfExtControlApi.h"
#include "rvMdmControlApi.h"
#include "rvstr.h"
#include "rvmtfalloc.h"

#ifdef RV_CFLAG_TLS
#include "rvMtfSampleTls.h"
#endif

#ifdef SAMPLE_MWI
#include "rvMtfSampleMWI.h"
#endif

#ifdef RV_MTF_STUN
#include "rvSipStunApi.h"
#include "rvMtfSampleStunRvClient.h"
#endif

#ifdef RV_MTF_VIDEO
#include "rvMtfSampleVideoFastUpdate.h"
#endif

#include "MfControl.h"
#ifndef RV_MTF_MEDIA
#include "mediaControl.h"
#endif

#ifdef RV_SIP_IMS_ON
#include "rvMtfImsTypes.h"
#include "rvMtfSampleIms.h"
#endif

#ifdef RV_MTF_H323
#include "rvH323ControlApi.h"
#include "rvMtfSampleH323Control.h"
#endif /* RV_MTF_H323 */

#ifdef RV_MTF_SECOND_VIDEO
#include "rvMtfSecondVideoApi.h"
#endif

/*============================================================================================*/
/*=================================   G L O B A L S  =========================================*/
/*============================================================================================*/
extern RvMtfSampleParams	g_sampleParams;
extern RV_BOOL				notifyToStartWarmRestart;
extern RV_BOOL				notifyToStartShutdown;
extern RV_BOOL				unegisteredTerminationsLeft;
extern RV_BOOL				notifyToStartWarmRestart;
extern RV_BOOL				startWarmRestart;
extern RV_BOOL				startShutdown;

rvDefineMap(RvString, RvString);

/*===============================================================================*/
/*=============    C A L L B A C K		I M P L M E N T A T I O N S  ============*/
/*===============================================================================*/
/*****************************************************************************
*  mtfSampleRegisterAnalogTermCompletedCB()
* -----------------------------------------------------------------------------
*  General :    This is an implementation of RvMtfRegisterAnalogTermCompletedEv().
*				This callback is called after application registers Analog termination
*				to MTF (by calling rvMtfRegisterAnalogTermination()) to indicate
*				the registration is complete.
*				Note:
*				When RV_MTF_MEDIA is not defined (meaning, media engine is handled
*				by the GUI), we start and stop media when terminal registers and unregisters.
*
*  Arguments:
*  Input:          hTerm		    - Handle to terminal
*				   hAppTerm			- Handle to application data associated with the terminal.
*
*  Output:          None
*
*  Return Value:    None.
*****************************************************************************/
void RVCALLCONV mtfSampleRegisterAnalogTermCompletedCB(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm)
{
    RvEppClientEndpoint* ece =  (RvEppClientEndpoint *)hAppTerm;

    if( ece == NULL)
	{
        return;
	}

	IppLogMessage(RV_FALSE,"mtfSampleRegisterAnalogTermCompletedCB() - hTerm = %p", hTerm);

	/* Set termination handle as user data of EPP client. */
	rvEppClientEndpointSetUserData(ece, (void*)hTerm);

	/* Reset GUI interface */
	/* ------------------- */
	/* GW_ACTIVE event will be processed by sample application and will cause a reset of
	   tones, indicators and display in the GUI. */
    if (hTerm != NULL)
    {
       rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_GW_ACTIVE, NULL);
	}

	/* Start media engine */
	/* ------------------ */
#ifndef RV_MTF_MEDIA
    /* If RV_MTF_MEDIA is defined, it means we called rvMtfMediaStart() earlier, see rvMtfSampleConstruct().
	   If RV_MTF_MEDIA is not defined, this means media engine is handled by GUI, and we can send the GUI
	   messages only after termination was registered.*/
    {
        if(RV_OK != rvMtfMediaStart((void*)hAppTerm))
        {
            IppLogMessage(rvTrue,"RvMfControlInit Failed");
            return;
        }
    }
#endif

}

/******************************************************************************
*  mtfSampleRegisterIPPhoneTermsCompletedCB
* -----------------------------------------------------------------------------
*  General :    This is an implementation of RvMtfRegisterIPPhoneTermsCompletedEv().
*				This callback is called after application registers IPPhone terminations
*				to MTF (by calling rvMtfRegisterIPPhoneTerminations()) to indicate
*				the registration is complete.
*				Note:
*				When RV_MTF_MEDIA is not defined (meaning, media engine is handled
*				by the GUI), we start and stop media when terminal registers and unregisters.
*
*  Arguments:
*  Input:          hTerm		    - Handle to terminal
*				   hAppTerm			- Handle to application data associated with the terminal.
*
*  Output:          None
*
*  Return Value:    None.
*****************************************************************************/
void RVCALLCONV mtfSampleRegisterIPPhoneTermsCompletedCB(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm)
{
	RvEppClientEndpoint* ece =  (RvEppClientEndpoint *)hAppTerm;

    if( ece == NULL)
	{
        return;
	}

	IppLogMessage(RV_FALSE,"mtfSampleRegisterIPPhoneTermsCompletedCB() - hTerm = %p", hTerm);

	/* Set termination handle as user data of EPP client. */
	rvEppClientEndpointSetUserData(ece, (void*)hTerm);

	/* Reset GUI interface */
	/* ------------------- */
	/* GW_ACTIVE event will be processed by sample application and will cause a reset of
	   tones, indicators and display in the GUI. */
    if (hTerm != NULL)
    {
       rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_GW_ACTIVE, NULL);
	}

	/* Start media engine */
	/* ------------------ */
#ifndef RV_MTF_MEDIA
    /* If RV_MTF_MEDIA is defined, it means we called rvMtfMediaStart() earlier, see rvMtfSampleConstruct().
	   If RV_MTF_MEDIA is not defined, this means media engine is handled by GUI, and we can send the GUI
	   messages only after termination was registered.*/
    {
        if(RV_OK != rvMtfMediaStart((void*)hAppTerm))
        {
            IppLogMessage(rvTrue,"RvMfControlInit Failed");
            return;
        }
    }
#endif

}

/******************************************************************************
*  mtfSampleRegisterVideoTermsCompletedCB()
* -----------------------------------------------------------------------------
*  General :    This is an implementation of RvMtfRegisterVideoTermsCompletedEv().
*				This callback is called after application registers Video terminations
*				to MTF (by calling rvMtfRegisterVideoTerminations()) to indicate
*				the registration is complete.
*
*  Arguments:
*  Input:          hTerm		    - Handle to terminal
*				   hAppTerm			- Handle to application data associated with the terminal.
*
*  Output:          None
*
*  Return Value:    None.
*****************************************************************************/
void RVCALLCONV mtfSampleRegisterVideoTermsCompletedCB(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm)
{
	RvEppClientEndpoint* ece =  (RvEppClientEndpoint *)hAppTerm;

	/* Set termination handle as user data of EPP client. */
	rvEppClientEndpointSetUserData(ece, (void*)hTerm);

	IppLogMessage(RV_FALSE,"mtfSampleRegisterVideoTermsCompletedCB() - hTerm = %p", hTerm);
}

/******************************************************************************
*  mtfSampleUnregisterAnalogTermCompletedCB()
* -----------------------------------------------------------------------------
*  General :    This is an implementation of RvMtfUnregisterAnalogTermCompletedEv().
*				This callback is called after application un-registers Analog termination
*				to MTF (by calling rvMtfUnregisterAnalogTermination()) to indicate
*				the un-registration is complete.
*				Note:
*				When RV_MTF_MEDIA is not defined (meaning, media engine is handled
*				by the GUI), we start and stop media when terminal registers and unregisters.
*
*  Arguments:
*  Input:          hTerm		    - Handle to terminal
*				   hAppTerm			- Handle to application data associated with the terminal.
*
*  Output:          None
*
*  Return Value:    None.
*****************************************************************************/
void RVCALLCONV mtfSampleUnregisterAnalogTermCompletedCB(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm)
{
	RV_UNUSED_ARG(hAppTerm);

	IppLogMessage(RV_FALSE,"mtfSampleUnregisterAnalogTermCompletedCB() - hTerm = %p", hTerm);

	/* Shutdown/WarmRestart if required by user */
	/* ---------------------------------------- */

	if (unegisteredTerminationsLeft == RV_FALSE)
    {
        if (notifyToStartWarmRestart == RV_TRUE)
        {
            /* This will cause main loop to stop sleeping and restart MTF */
            startWarmRestart = RV_TRUE;
            notifyToStartWarmRestart = RV_FALSE;
            unegisteredTerminationsLeft = RV_TRUE;
        }
        else if (notifyToStartShutdown == RV_TRUE)
        {
            /* This will cause main loop to stop sleeping and restart MTF */
            startShutdown = RV_TRUE;
            notifyToStartShutdown = RV_FALSE;
            unegisteredTerminationsLeft = RV_TRUE;
        }
    }

	/* Stop media engine */
	/* ----------------- */

#ifndef RV_MTF_MEDIA
    /* If RV_MTF_MEDIA is defined, we will call rvMtfMediaStop() during shutdown, see rvMtfSampleDestruct() */
	/* If RV_MTF_MEDIA is not defined, we start and stop media when terminal registers and unregisters.*/
    /* This callback is called twice in some cases, therefore we may get here when hAppTerm is NULL. */
    if (hAppTerm != NULL)
	{
		rvMtfMediaStop((void*)hAppTerm);

    }


#endif

}

/******************************************************************************
*  mtfSampleUnregisterIPPhoneTermsCompletedCB()
* -----------------------------------------------------------------------------
*  General :    This is an implementation of RvMtfUnregisterIPPhoneTermsCompletedEv().
*				This callback is called after application un-registers IPPhone terminations
*				to MTF (by calling rvMtfUnregisterIPPhoneTerminations()) to indicate
*				the un-registration is complete.
*				Notes:
*				1. Unlike UnregisterAnalogTermCompleted(), here we stop media first and
*				   then check if warm restart is necessary.
*				2. When RV_MTF_MEDIA is not defined (meaning, media engine is handled
*				   by the GUI), we start and stop media when terminal registers and unregisters.
*
*  Arguments:
*  Input:          hTerm		    - Handle to terminal
*				   hAppTerm			- Handle to application data associated with the terminal.
*
*  Output:          None
*
*  Return Value:    None.
*****************************************************************************/
void RVCALLCONV mtfSampleUnregisterIPPhoneTermsCompletedCB(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm)
{

	IppLogMessage(RV_FALSE,"mtfSampleUnregisterIPPhoneTermsCompletedCB() - hTerm = %p", hTerm);

	/* Stop media engine */
	/* ----------------- */

#ifndef RV_MTF_MEDIA
    /* If RV_MTF_MEDIA is defined, we will call rvMtfMediaStop() during shutdown, see rvMtfSampleDestruct() */
	/* If RV_MTF_MEDIA is not defined, we start and stop media when terminal registers and unregisters.*/
	/* This callback is called twice in some cases, therefore we may get here when hAppTerm is NULL. */
    if (hAppTerm != NULL)
	{
		rvMtfMediaStop((void*)hAppTerm);

    }
#else
	RV_UNUSED_ARG(hAppTerm);
#endif

	/* Shutdown/WarmRestart if required by user */
	/* ---------------------------------------- */

	if (unegisteredTerminationsLeft == RV_FALSE)
    {
        if (notifyToStartWarmRestart == RV_TRUE)
        {
            /* This will cause main loop to stop sleeping and restart MTF */
            startWarmRestart = RV_TRUE;
            notifyToStartWarmRestart = RV_FALSE;
            unegisteredTerminationsLeft = RV_TRUE;
        }
        else if (notifyToStartShutdown == RV_TRUE)
        {
            /* This will cause main loop to stop sleeping and restart MTF */
            startShutdown = RV_TRUE;
            notifyToStartShutdown = RV_FALSE;
            unegisteredTerminationsLeft = RV_TRUE;
        }
    }

}

/******************************************************************************
*  mtfSampleUnregisterVideoTermsCompletedCB()
* -----------------------------------------------------------------------------
*  General :    This is an implementation of RvMtfUnregisterVideoTermsCompletedEv().
*				This callback is called after application un-registers Video terminations
*				to MTF (by calling rvMtfUnregisterVideoTerminations()) to indicate
*				the un-registration is complete.
*
*  Arguments:
*  Input:          hTerm		    - Handle to terminal
*				   hAppTerm			- Handle to application data associated with the terminal.
*
*  Output:          None
*
*  Return Value:    None.
*****************************************************************************/
void RVCALLCONV mtfSampleUnregisterVideoTermsCompletedCB(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm)
{
	/* Nothing to do here. */

	RV_UNUSED_ARG(hAppTerm);

	IppLogMessage(RV_FALSE,"mtfSampleUnregisterVideoTermsCompletedCB() - hTerm = %p", hTerm);

}


/******************************************************************************
*  mtfSampleUnregisterTermFromServerCompletedCB()
* -----------------------------------------------------------------------------
*  General :    This is an implementation of RvMtfUnregisterTermFromServerCompletedEv().
*				This callback is called after application registers termination
*				to SIP server (either Analog or IPPhone) to indicate the registration
*				is complete (either reply was received from server or timeout occurred).
*				Application registers a termination to SIP Registrar by calling
*				rvMtfRegisterTerminationToSipServer().
*
*  Arguments:
*  Input:          hTerm		    - Handle to terminal
*				   hAppTerm			- Handle to application data associated with the terminal.
*
*  Output:          None
*
*  Return Value:    None.
*****************************************************************************/
void RVCALLCONV mtfSampleUnregisterTermFromServerCompletedCB(
									IN RvIppTerminalHandle      hTerm,
									IN RvMtfTerminalAppHandle	hAppTerm)
{
	/* Nothing to do here. */

	RV_UNUSED_ARG(hAppTerm);

	IppLogMessage(RV_FALSE,"mtfSampleUnregisterTermFromServerCompletedCB() - hTerm = %p", hTerm);

}

/* This function is an implementation of callback....
It checks if the dialed phone numbers is in the list of phone numbers */
RvStatus RVCALLCONV rvMtfSampleMapDialStringToAddressCB(
											 IN  RvIppTerminalHandle		hTerm,
											 IN  RvMtfTerminalAppHandle		hAppTerm,
											 IN  RvChar*					dialString,
											 OUT RvChar*					address)
{
    /* TODO: Change implementation so it doesn't use RvMap and it is easy to read...*/
    /* TODO: Comment while at it...*/

	/*	RvMap(RvString, RvString)* getAddressList();*/
	RvMap(RvString, RvString)* addressList = &g_sampleParams.addressList;
	RvMapIter(RvString, RvString) iter = rvMapBegin(RvString, RvString)(addressList);
	int i;
	int j;

	RV_UNUSED_ARG(hTerm);
	RV_UNUSED_ARG(hAppTerm);

	while(iter)
	{
		const char* key = rvStringGetData(rvMapIterGetKey(RvString, RvString)(iter));

		for (i=0;key[i];i++)
		{
			switch(key[i])
			{
			case '0':case '1':case '2':case '3':case '4':
			case '5':case '6':case '7':case '8':case '9':
			case '*':case '#':
				if (dialString[i]==key[i])
					continue;
				break;
			case '.':
				continue;
            default:
                break;
			}
			break;
		}
		if (!key[i])
		{/*key found*/
			const char* value = rvStringGetData(rvMapIterGetValue(RvString, RvString)(iter));
			for (i=0,j=0;key[i];i++)
			{
				if (key[i]=='.')
					for (;value[j];j++)
					{
						if (value[j]=='\\')
						{
							address[j++]=dialString[i];
							break;
						}
						else
							address[j]=value[j];
					}
			}
			for (;value[j];j++)
			{
				if (value[j]=='\\')
				{
					address[j]='.';
					break;
				}
				else
					address[j]=value[j];
			}
			address[j]='\0';
            RvAssert(j < 64); /* If this isn't true, we have a buffer overrun... */
			return RV_OK;
		}
		iter = rvMapIterNext(iter);
	}

	return RV_ERROR_NOT_FOUND;
}

/******************************************************************************
*  rvMtfSampleStartSignalCB
* -----------------------------------------------------------------------------
*  General :    This is an implementation of callback RvMtfStartSignalEv().
*				This callback is called by MTF when application is required to
*				update terminal interface, by applying a tone or indicator.
*				For example: start playing dial tone, turn on/off Hold indicator,  etc.
*				Note:
*				Some signals are stopped by calling this callback and not by calling
*				RvMtfStopSignalEv, see signal state.
*				In this implementation we send EPP message to GUI for starting the signal.
*				Application should call directly its own system for starting the signal instead.
*
*  Arguments:
*  Input:          hTerm		- Handle to terminal
*                  signalType   - type of signal
*				   signalState	- state of signal
*				   signalParams	- signal parameters
*
*  Output:          None
*
*  Return Value:    None.
*****************************************************************************/
void RVCALLCONV rvMtfSampleStartSignalCB(
                RvIppTerminalHandle	    hTerm,
			    RvMtfTerminalAppHandle  hAppTerm,
                RvMtfSignalType		    signalType,
                RvMtfSignalState        signalState,
                RvMtfSignalParams*		signalParams)
{
	RvEppClientEndpoint *ece = (RvEppClientEndpoint*)hAppTerm;

	RV_UNUSED_ARG(hTerm);

	if (ece == NULL)
	{
		return;
	}

	switch (signalType)
    {
		case RV_MTF_SIGNAL_DIALTONE:
			rvMtfGuiStartDialTone(ece);
			break;
		case RV_MTF_SIGNAL_RINGBACK:
			if (signalParams != NULL)
			{
				rvMtfGuiStartRingbackTone(ece , signalParams->distictiveTone);
			}
			else
			{
				/* In analog lines there is no signalParams */
				rvMtfGuiStartRingbackTone(ece , "");
			}
			break;
		case RV_MTF_SIGNAL_RINGING:
			if (signalParams != NULL)
			{
				rvMtfGuiStartRingingTone(ece, signalParams->distictiveTone);
			}
			else
			{
				/* In analog lines there is no signalParams */
				rvMtfGuiStartRingingTone(ece, "");
			}
			break;
		case RV_MTF_SIGNAL_CALLWAITING_CALLER:
			rvMtfGuiStartCallWaitingTone(ece);
			break;
		case RV_MTF_SIGNAL_CALLWAITING_CALLEE:
			rvMtfGuiStartCallWaitingCalleeTone(ece);
			break;
		case RV_MTF_SIGNAL_BUSY:
			rvMtfGuiStartBusyTone(ece);
			break;
		case RV_MTF_SIGNAL_WARNING:
			rvMtfGuiStartWarningTone(ece);
			break;
        case RV_MTF_SIGNAL_DIGIT:
            rvMtfGuiStartDigitTone(ece, signalParams->digit);
            break;
        case RV_MTF_SIGNAL_IND_LINE:
            rvMtfGuiSetLineIndicator(ece, signalState, signalParams->lineId);
            break;
        case RV_MTF_SIGNAL_IND_HOLD:
            rvMtfGuiSetHoldIndicator(ece, signalState);
            break;
        case RV_MTF_SIGNAL_IND_MUTE:
            rvMtfGuiSetMuteIndicator(ece, signalState);
            break;
        case RV_MTF_SIGNAL_IND_HANDSFREE:
            rvMtfGuiSetSpeakerIndicator(ece, signalState);
            break;
        case RV_MTF_SIGNAL_IND_HEADSET:
            rvMtfGuiSetHeadsetIndicator(ece, signalState);
            break;
		default:
			IppLogMessage(RV_TRUE,"rvMtfSampleStartSignalCB() - unknown signal type = %d", signalType);
			break;
		}
}

/******************************************************************************
*  rvMtfSampleStopSignalCB
* -----------------------------------------------------------------------------
*  General :    This is an implementation of callback RvMtfStopSignalEv().
*				This callback is called by MTF when application is required to
*				update terminal interface, by stop playing a tone or indicator.
*				For example: stop playing dial tone,  etc.
*				In this implementation we send EPP message to GUI for stopping the signal.
*				Application should call directly its own system for stopping the signal instead.
*
*  Arguments:
*  Input:          hTerm		- Handle to terminal
*                  signalType   - type of signal
*				   signalState	- state of signal
*				   signalParams	- signal parameters
*
*  Output:          None
*
*  Return Value:    None.
*****************************************************************************/
void RVCALLCONV rvMtfSampleStopSignalCB(
					RvIppTerminalHandle		hTerm,
					RvMtfTerminalAppHandle  hAppTerm,
					RvMtfSignalType			signal)
{
	RvEppClientEndpoint *ece = (RvEppClientEndpoint*)hAppTerm;

	RV_UNUSED_ARG(hTerm);

	if (!ece)
	{
		return;
	}

	switch (signal)
    {
		case RV_MTF_SIGNAL_DIALTONE:
			rvMtfGuiStopDialTone(ece);
			break;
		case RV_MTF_SIGNAL_RINGBACK:
			rvMtfGuiStopRingbackTone(ece);
			break;
		case RV_MTF_SIGNAL_RINGING:
			rvMtfGuiStopRingingTone(ece);
			break;
		case RV_MTF_SIGNAL_CALLWAITING_CALLER:
			rvMtfGuiStopCallWaitingTone(ece);
			break;
		case RV_MTF_SIGNAL_CALLWAITING_CALLEE:
			rvMtfGuiStopCallWaitingCalleeTone(ece);
			break;
		case RV_MTF_SIGNAL_BUSY:
			rvMtfGuiStopBusyTone(ece);
			break;
		case RV_MTF_SIGNAL_WARNING:
			rvMtfGuiStopWarningTone(ece);
			break;
		default:
			IppLogMessage(RV_TRUE,"rvMtfSampleStopSignalCB() - unknown signal type = %d", signal);
		}
}

/*===============================================================================*/
/*===================    P R I V A T E    F U N C T I O N S    ==================*/
/*===============================================================================*/

static void constructGatewayParams(RvMtfSampleParams *sampleParams)
{
	memset(sampleParams, 0, sizeof(RvMtfSampleParams));

	sampleParams->bConfigTCP = rvFalse;
	sampleParams->eppPort = 3044;
	sampleParams->numberOfLines = 2;

    strcpy(sampleParams->localIpPrefix, "");
    strcpy(sampleParams->localIpMask, "");

	sampleParams->autoRegister = RV_TRUE;

	rvMapConstruct(RvString, RvString)(&sampleParams->addressList, userDefaultAlloc);

	/* The following sdpMsgs are constructed in proc rvIppSampleLoadMediaParamsFromBuffer */
	sampleParams->sdpForInitialInvite = NULL;
	sampleParams->sdpOfFullCaps = NULL;

    rvStringConstruct(&sampleParams->userDomain, "Radvision.com", userDefaultAlloc);
    rvStringConstruct(&sampleParams->registrarAddress, "", userDefaultAlloc);
    rvStringConstruct(&sampleParams->outboundProxyAddress, "", userDefaultAlloc);
    rvStringConstruct(&sampleParams->termId, "", userDefaultAlloc);
    rvStringConstruct(&sampleParams->username, "", userDefaultAlloc);
    rvStringConstruct(&sampleParams->password, "", userDefaultAlloc);

	strncpy(&sampleParams->digitMapPatterns[0], "NotAssigned", 11);

#ifdef RV_MTF_STUN
    rvStringConstruct(&sampleParams->stunNeedMask, "", userDefaultAlloc);
#endif

#ifdef SAMPLE_MWI
    rvStringConstruct(&sampleParams->subsServerName, "", userDefaultAlloc);
#endif
#ifdef RV_MTF_H323
	rvStringConstruct(&sampleParams->localH323Address, "", userDefaultAlloc);
	sampleParams->q931SignalingPort = 0;
	sampleParams->h323MaxCalls = 5;
	rvStringConstruct(&sampleParams->gkAddress, "", userDefaultAlloc);
	sampleParams->gkPort = 0;
	rvStringConstruct(&sampleParams->h323TermId, "", userDefaultAlloc);
	memset(&sampleParams->e164PhoneList, 0, sizeof(RvMtfH323E164List));

	memset(&sampleParams->logOptions, 0, sizeof(RvIppSipLogOptions));
	memset(&sampleParams->h323LogOptions, 0, sizeof(RvIppH323LogOptions));
	sampleParams->fastStart = rvFalse;
	sampleParams->debugLevel = 0;
	sampleParams->dialToneDuration = 0;
	sampleParams->h323OutgoingRequestNoResponseTimeout = DEFAULT_Q931_RESPONSE_TO * 1000; /* milliseconds */
	sampleParams->h323OutgoingCallNoAnswerTimeout= DEFAULT_Q931_CONNECT_TO * 1000;  /* milliseconds */
#endif /* RV_MTF_H323 */
}

static void destructGatewayParams(RvMtfSampleParams *sampleParams)
{
    rvMapDestruct(&sampleParams->addressList);

	if (sampleParams->sdpOfFullCaps !=  sampleParams->sdpForInitialInvite)
	{
		rvSdpMsgDestruct(sampleParams->sdpOfFullCaps);
	}

	if (sampleParams->sdpForInitialInvite != NULL)
	{
		rvSdpMsgDestruct(sampleParams->sdpForInitialInvite);
	}

    rvStringDestruct(&sampleParams->userDomain);
    rvStringDestruct(&sampleParams->registrarAddress);
    rvStringDestruct(&sampleParams->outboundProxyAddress);

    rvStringDestruct(&sampleParams->termId);
    rvStringDestruct(&sampleParams->username);
    rvStringDestruct(&sampleParams->password);

#ifdef RV_MTF_STUN
    rvStringDestruct(&sampleParams->stunNeedMask);
#endif

#ifdef SAMPLE_MWI
    rvStringDestruct(&sampleParams->subsServerName);
#endif
#ifdef RV_MTF_H323
	rvStringDestruct(&sampleParams->localH323Address);
	rvStringDestruct(&sampleParams->gkAddress);
	rvStringDestruct(&sampleParams->h323TermId);
#endif /* RV_MTF_H323 */
}

#ifdef RV_MTF_H323
static void loadH323ConfigParams(RvMtfSampleParams *sampleParams, RvMtfH323PhoneCfg* cfg)
{
	/* Override any configuration parameters that were already set to the struct */
	cfg->localAddress			= (char *)rvStringGetData(&sampleParams->localH323Address);
	strcpy(cfg->gkCfg.gatekeepers.gkAddress,	(char *)rvStringGetData(&sampleParams->gkAddress));
	switch(cfg->gkCfg.gatekeepers.gkAddress[0])
	{
		case '*':	cfg->gkCfg.mode	= AutoDiscoverGk;break;
		case '\0':	cfg->gkCfg.mode	= NoGk;break;
		default:   	cfg->gkCfg.mode	= ManualyDiscoverGk;break;
	}
    cfg->gkCfg.gatekeepers.gkPort       = sampleParams->gkPort;
    cfg->q931SignalingPort				= sampleParams->q931SignalingPort;
    cfg->useFastStart					= sampleParams->fastStart;
	cfg->e164PhoneList					= sampleParams->e164PhoneList;

	cfg->logOptions						= &(sampleParams->h323LogOptions);
	cfg->maxCalls						= sampleParams->h323MaxCalls;
	cfg->outgoingRequestNoResponseTimeout = sampleParams->h323OutgoingRequestNoResponseTimeout;
	cfg->outgoingCallNoAnswerTimeout = sampleParams->h323OutgoingCallNoAnswerTimeout;
	/* ----------------------------------------------------------------------*
	 *   Common params to SIP and H.323 - should be set in both cfg structs  *
	 * ----------------------------------------------------------------------*/
	/* the product ID and version are stored both in H323 and SIP cfg for initialization 
	   of both protocols */
	if (sampleParams->productId[0] != '\0')
	{
		cfg->productId               = sampleParams->productId;
	}

	if (sampleParams->productVersion[0] != '\0')
	{
		cfg->productVersion          = sampleParams->productVersion;
	}

	cfg->persistentRegisterRetryInterval = sampleParams->persistentRegisterRetryInterval;
	cfg->persistentRegisterEnabled     = sampleParams->persistentRegisterEnabled;

 /*   cfg->debugLevel             = sampleParams->debugLevel;*/

}
#endif /* RV_MTF_H323 */

static void loadSipConfigParams(RvMtfSampleParams *sampleParams, RvMtfSipPhoneCfg* cfg)
{
	/* Override any configuration parameters that were already set to the struct */
	cfg->userDomain             = (char *)rvStringGetData(&sampleParams->userDomain);
	cfg->displayName            = sampleParams->displayName;
	cfg->localAddress           = sampleParams->localAddress;
	cfg->stackTcpPort           = sampleParams->stackTcpPort;
	cfg->stackUdpPort           = sampleParams->stackUdpPort;
	cfg->registrarAddress       = (char *)rvStringGetData(&sampleParams->registrarAddress);
	cfg->registrarPort          = sampleParams->registrarPort;
	cfg->outboundProxyAddress   = (char *)rvStringGetData(&sampleParams->outboundProxyAddress);
	cfg->outboundProxyPort      = sampleParams->outboundProxyPort;
	cfg->username               = (char *)rvStringGetData(&sampleParams->username);
	cfg->password               = (char *)rvStringGetData(&sampleParams->password);
	cfg->priority               = RV_THREAD_PRIORITY_DEFAULT;
	cfg->transportType          = sampleParams->transportType;
	cfg->autoRegister           = sampleParams->autoRegister;
	if (sampleParams->registrationExpire)
		cfg->registrationExpire     = sampleParams->registrationExpire;
	if (sampleParams->unregistrationExpire)
		cfg->unregistrationExpire   = sampleParams->unregistrationExpire;
	cfg->maxAuthenticateRetries = sampleParams->maxAuthenticateRetries;
	cfg->removeOldAuthHeaders = sampleParams->removeOldAuthHeaders;
#ifdef RV_SIP_IMS_ON
	/* handle IMS params */
	if (sampleParams->imsSampleParams.disableAkaAuthentication)
		cfg->disableAkaAuthentication   = sampleParams->imsSampleParams.disableAkaAuthentication;
	if (sampleParams->imsSampleParams.isAkaAuthOpConfigured)
		cfg->akaAuth_op             = sampleParams->imsSampleParams.akaAuth_op;
	cfg->imsSipPhoneCfg.disableSecAgree = sampleParams->imsSampleParams.disableSecAgree;
	strcpy(cfg->imsSipPhoneCfg.PAccessNetworkInfo, sampleParams->imsSampleParams.PAccessNetworkInfo);
	cfg->imsSipPhoneCfg.ipsecPortC   = sampleParams->imsSampleParams.ipsecPortC;
	cfg->imsSipPhoneCfg.ipsecPortS   = sampleParams->imsSampleParams.ipsecPortS;
	cfg->imsSipPhoneCfg.ipsecSpiRangeStart   = sampleParams->imsSampleParams.ipsecSpiRangeStart;
	cfg->imsSipPhoneCfg.ipsecSpiRangeEnd   = sampleParams->imsSampleParams.ipsecSpiRangeEnd;
#endif
	cfg->outgoingRequestNoResponseTimeout =  sampleParams->outgoingRequestNoResponseTimeout ;
	cfg->outgoingCallNoAnswerTimeout      =  sampleParams->outgoingCallNoAnswerTimeout;
	cfg->referTimeout           = sampleParams->referTimeout;
	cfg->dialToneDuration       = sampleParams->dialToneDuration;
	cfg->logOptions             = &(sampleParams->logOptions);
	cfg->maxCallLegs            = sampleParams->maxCallLegs;
	cfg->maxRegClients          = sampleParams->maxRegClients;
	cfg->tcpEnabled             = sampleParams->tcpEnabled;
	cfg->callWaitingReply       = sampleParams->callWaitingReply;
	cfg->disableCallWaiting       = sampleParams->disableCallWaiting;
	cfg->registerCompleteTimeout       = sampleParams->registerCompleteTimeout;
	cfg->watchdogTimeout        = sampleParams->watchdogTimeout;
	cfg->outOfBandDtmf          = (sampleParams->dtmfRelay == RV_IPP_DTMF_RELAY_OOB);
	cfg->connectMediaOn180      = sampleParams->connectMediaOn180;
	cfg->addUserAgentHeader      = sampleParams->addUserAgentHeader;
	if (sampleParams->manufacturerId[0] != '\0')
	{
		cfg->manufacturerId          = sampleParams->manufacturerId;
	}

	cfg->sendOldHoldFormat      = sampleParams->sendOldHoldFormat;
	cfg->addUpdateSupport       = sampleParams->addUpdateSupport;
	cfg->sessionTimerRefreshByUpdate = sampleParams->sessionTimerRefreshByUpdate;
	cfg->sessionTimerMinimumAllowed = sampleParams->sessionTimerMinimumAllowed;
	cfg->sessionTimerSessionExpires = sampleParams->sessionTimerSessionExpires;
	cfg->updateRetryAfterTimeout    = sampleParams->updateRetryAfterTimeout;
	cfg->callerUpdateResendTimeout  = sampleParams->callerUpdateResendTimeout;
	cfg->calleeUpdateResendTimeout  = sampleParams->calleeUpdateResendTimeout;
	cfg->autoAnswer				= sampleParams->autoAnswer;
	cfg->autoDisconnect			= sampleParams->autoDisconnect;
	cfg->acceptCallWhenUserNotFound = sampleParams->acceptCallWhenUserNotFound;
	cfg->cfwCallCfg.cfwCallBacks.activateCompleted = sampleParams->cfwCallCfg.cfwCallBacks.activateCompleted;
	cfg->cfwCallCfg.cfwCallBacks.deactivateCompleted = sampleParams->cfwCallCfg.cfwCallBacks.deactivateCompleted;
	/* Disable SDP logging */
	if (sampleParams->enableSdpLogs == RV_FALSE)
	{
		cfg->sdpStackCfg.disableSdpLogs = RV_TRUE;
		cfg->sdpStackCfg.logManagerPtr = NULL;
	}
	/* Enable SDP logging (this is actually not mandatory since this is also the deafult setting) */
	else
	{
		cfg->sdpStackCfg.disableSdpLogs = RV_FALSE;
		cfg->sdpStackCfg.logManagerPtr = IppLogMgr();
	}

	cfg->defaultProtocolType		= sampleParams->defaultProtocolType;
	cfg->displayName =   sampleParams->displayName;
	cfg->numberOfLines			= sampleParams->numberOfLines;

	/* ----------------------------------------------------------------------*
	 *   Common params to SIP and H.323 - should be set in both cfg structs  *
	 * ----------------------------------------------------------------------*/
	/* the product ID and version are stored both in H323 and SIP cfg for initialization 
	of both protocols */
	if (sampleParams->productId[0] != '\0')
	{
		cfg->productId               = sampleParams->productId;
	}

	if (sampleParams->productVersion[0] != '\0')
	{
		cfg->productVersion          = sampleParams->productVersion;
	}

	cfg->persistentRegisterRetryInterval = sampleParams->persistentRegisterRetryInterval;
	cfg->persistentRegisterEnabled      = sampleParams->persistentRegisterEnabled;


}

static void initSampleParamsWithDefaultValues(RvMtfSampleParams *sampleParams, RvIppSipPhoneCfg* cfg)
{
    /* Copy any configuration parameters that were already set at initialization of cfg */
   
    sampleParams->stackTcpPort                = cfg->stackTcpPort;
    sampleParams->stackUdpPort                = cfg->stackUdpPort;
    sampleParams->registrarPort               = cfg->registrarPort;
    sampleParams->outboundProxyPort           = cfg->outboundProxyPort;
    sampleParams->transportType               = cfg->transportType;
    sampleParams->autoRegister                = cfg->autoRegister;
    sampleParams->registrationExpire          = cfg->registrationExpire;
    sampleParams->unregistrationExpire        = cfg->unregistrationExpire;
	sampleParams->maxAuthenticateRetries      = cfg->maxAuthenticateRetries;
	sampleParams->removeOldAuthHeaders        = cfg->removeOldAuthHeaders;
    sampleParams->referTimeout                = cfg->referTimeout;
	sampleParams->outgoingRequestNoResponseTimeout   = cfg->outgoingRequestNoResponseTimeout;
	sampleParams->outgoingCallNoAnswerTimeout        = cfg->outgoingCallNoAnswerTimeout;
    sampleParams->dialToneDuration            = cfg->dialToneDuration;
    sampleParams->maxCallLegs                 = cfg->maxCallLegs;
    sampleParams->maxRegClients               = cfg->maxRegClients;
    sampleParams->tcpEnabled                  = cfg->tcpEnabled;
    sampleParams->callWaitingReply            = cfg->callWaitingReply;
    sampleParams->watchdogTimeout             = cfg->watchdogTimeout;
	sampleParams->disableCallWaiting          = cfg->disableCallWaiting;
	sampleParams->persistentRegisterRetryInterval = cfg->persistentRegisterRetryInterval;
	sampleParams->persistentRegisterEnabled      = cfg->persistentRegisterEnabled;
	sampleParams->registerCompleteTimeout        = cfg->registerCompleteTimeout;
    sampleParams->connectMediaOn180           = cfg->connectMediaOn180;
	sampleParams->addUserAgentHeader          = cfg->addUserAgentHeader;
	sampleParams->sendOldHoldFormat           = cfg->sendOldHoldFormat;
	sampleParams->addUpdateSupport            = cfg->addUpdateSupport;
	sampleParams->sessionTimerRefreshByUpdate = cfg->sessionTimerRefreshByUpdate;
	sampleParams->sessionTimerMinimumAllowed  = cfg->sessionTimerMinimumAllowed;
	sampleParams->sessionTimerSessionExpires  = cfg->sessionTimerSessionExpires;
	sampleParams->updateRetryAfterTimeout     = cfg->updateRetryAfterTimeout;
	sampleParams->callerUpdateResendTimeout   = cfg->callerUpdateResendTimeout;
	sampleParams->calleeUpdateResendTimeout   = cfg->calleeUpdateResendTimeout;
	sampleParams->autoAnswer                  = cfg->autoAnswer;
	sampleParams->autoDisconnect              = cfg->autoDisconnect;
	sampleParams->numberOfLines               = cfg->numberOfLines;
    sampleParams->cfwCallCfg.cfwCallBacks.activateCompleted = cfg->cfwCallCfg.cfwCallBacks.activateCompleted;
    sampleParams->cfwCallCfg.cfwCallBacks.deactivateCompleted = cfg->cfwCallCfg.cfwCallBacks.deactivateCompleted;	

#ifdef RV_SIP_IMS_ON

	sampleParams->imsSampleParams.disableAkaAuthentication = cfg->disableAkaAuthentication;
	sampleParams->imsSampleParams.disableSecAgree = cfg->imsSipPhoneCfg.disableSecAgree;
	sampleParams->imsSampleParams.ipsecPortC = cfg->imsSipPhoneCfg.ipsecPortC;
	sampleParams->imsSampleParams.ipsecPortS = cfg->imsSipPhoneCfg.ipsecPortS;
	sampleParams->imsSampleParams.ipsecSpiRangeStart = cfg->imsSipPhoneCfg.ipsecSpiRangeStart;
	sampleParams->imsSampleParams.ipsecSpiRangeEnd = cfg->imsSipPhoneCfg.ipsecSpiRangeEnd;

#endif /* RV_SIP_IMS_ON */


	sampleParams->manufacturerId[0] = '\0';
	sampleParams->productId[0] = '\0';
	sampleParams->productVersion[0] = '\0';
	
}

#ifdef RV_MTF_H323
static void initSampleParamsWithDefaultValuesH323(RvMtfSampleParams *sampleParams, RvMtfH323PhoneCfg* cfg)
{
	/* Copy any configuration parameters that were already set at initialization of cfg */

	sampleParams->q931SignalingPort					= cfg->q931SignalingPort;
	sampleParams->gkPort							= cfg->gkCfg.gatekeepers.gkPort;
	sampleParams->h323MaxCalls						= cfg->maxCalls;
	sampleParams->fastStart							= cfg->useFastStart;
}
#endif /* RV_MTF_H323*/


/*===============================================================================*/
/*=============   S A M P L E	C O N S T R U C T / D E S T R U C T  ============*/
/*===============================================================================*/

RvStatus rvMtfSampleConstruct(OUT RvMtfSampleParams *sampleParams, IN char* configBuf)
{
    IppLogSourceFilterElm   ippLogOptions[30];
#ifdef RV_MTF_H323
    RvMtfH323PhoneCfg       h323Cfg;
	RvIppH323ExtClbks       h323ExtClbks;
#endif /* RV_MTF_H323 */
    RvMtfSipPhoneCfg        sipCfg;
    RvMtfMdmClbks	        mdmClbks;
    RvMtfMediaClbks         mediaClbks;
	RvMtfConnMediaClbks     connMediaClbks;
    RvMtfCallControlClbks	mdmExtClbks;
    RvMtfSipControlClbks	sipExtClbks;
#ifdef RV_MTF_SECOND_VIDEO
	RvMtfSecondVideoClbks   secondVideoClbks;
#endif
	RvMdmDigitMap	        digitMap;
    RvStatus                rv;

#ifdef RV_MTF_VIDEO
    RvIppMdmVideoExtClbks			videoClbks;
	RvIppMdmVideoConnExtClbks		videoConnClbks;
	RvIppMdmVideoStreamConnExtClbks	videoStreamConnClbks;
#endif
#ifdef SAMPLE_MWI
    RvIppSampleSipMwiCfg    subsCfg;
#endif

#ifdef RV_SIP_IMS_ON
	RvMtfImsClbks			imsClbks;
#endif

    /* ------------------ */
    /* Initialize Logger  */
    /* ------------------ */

    memset(ippLogOptions, 0, sizeof(ippLogOptions));

    /* Load logging configuration from buffer */
    rvMtfSampleUtilLoadMtfLogOptions(ippLogOptions, 30, configBuf);

    /* Initialize log before we do anything else*/
	rv = IppLogInit(ippLogOptions, MTF_LOG_PATH);
    if (rv != RV_OK)
	{
		printf("rvMtfSampleConstruct() - failed to initialize logger, status=%d\n", rv);
        return rv;
	}

    /* ------------------------------ */
    /* Initialize MTF Sample objects  */
    /* ------------------------------ */

    /* Construct sample parameters with empty values*/
    constructGatewayParams(sampleParams);

    /* --------------------------------- */
    /* Load MF configuration parameters */
    /* --------------------------------- */
    /* Initialize Media configuration structure with default values*/
    rvMtfMediaInitConfig( &sampleParams->mediaParam);

#ifdef RV_MTF_H323

	/* --------------------------------- */
	/* Load MTF H.323 configuration parameters */
	/* --------------------------------- */

    /* Initialize MTF configuration structure with default values*/
    rvMtfH323InitConfig(&h323Cfg);

	/* Load sample params with H.323 default values */
	initSampleParamsWithDefaultValuesH323(sampleParams, &h323Cfg);

#endif /* RV_MTF_H323 */

	/* --------------------------------- */
	/* Load MTF SIP configuration parameters */
	/* --------------------------------- */

    /* Initialize MTF configuration structure with default values*/
    rvIppSipInitConfig(&sipCfg);

	/* Load sample params with default values */
	initSampleParamsWithDefaultValues(sampleParams, &sipCfg);

	/* Load parameters to sample parameters*/
	rvMtfSampleUtilLoadConfigParams(sampleParams, configBuf);

	/* Load configuration parameters to MTF configuration structure*/
    loadSipConfigParams(sampleParams, &sipCfg);

#ifdef RV_MTF_H323

	/* Load configuration parameters to MTF configuration structure*/
	loadH323ConfigParams(sampleParams, &h323Cfg);

	/* Register H323 callbacks */
	memset(&h323ExtClbks, 0, sizeof(RvIppH323ExtClbks));
	h323ExtClbks.regEventF	   = rvMtfSampleH323ExtRegEvent;
	h323ExtClbks.recvFlowControlF = rvMtfSampleH323ExtFlowControl;
	rvIppH323RegisterExtClbks(&h323ExtClbks);
#endif /* RV_MTF_H323 */

    /* --------------------------- */
    /* Initialize TLS			   */
    /* --------------------------- */

#ifdef RV_CFLAG_TLS
    userRegisterIppSipTlsExt();

    /* Initialize TLS part of IPP configuration structure with default values*/
    rvIppSipTlsInitConfig(&sipCfg);

    /* Load TLS configuration parameters from sample parameters to MTF configuration structure*/
    rvMtfSampleLoadTlsConfigParams(&sampleParams->transportTlsCfg, &sipCfg);
#endif

    rvMtfSampleUtilPrintConfigParams(sampleParams);

    /* --------------------------- */
    /* Set SIP Extension callbacks */
    /* --------------------------- */
    memset(&sipExtClbks, 0, sizeof(RvMtfSipControlClbks));
    sipExtClbks.stackConfigCB					= rvMtfSampleSipStackConfig;
    sipExtClbks.registerStackEventsCB			= rvMtfSampleRegisterSipStackEvents;
    sipExtClbks.preCallLegCreatedIncomingCB		= rvMtfSamplePreCallLegCreatedIncoming;
    sipExtClbks.postCallLegCreatedIncomingCB	= rvMtfSamplePostCallLegCreatedIncoming;
    sipExtClbks.preCallLegCreatedOutgoingCB		= rvMtfSampleSipPreCallLegCreatedOutgoing;
    sipExtClbks.postCallLegCreatedOutgoingCB	= rvMtfSampleSipPostCallLegCreatedOutgoing;
    sipExtClbks.preStateChangedCB				= rvMtfSampleSipPreStateChanged;
    sipExtClbks.postStateChangedCB				= rvMtfSampleSipPostStateChanged;
	sipExtClbks.postMsgToSendCB					= rvMtfSampleSipMsgToSend;
    sipExtClbks.preMsgReceivedCB				= rvMtfSampleSipPreMsgReceived;
    sipExtClbks.postMsgReceivedCB				= rvMtfSampleSipPostMsgReceived;
    sipExtClbks.regClientStateChangedCB			= rvMtfSampleSipRegClientStateChanged;
	sipExtClbks.regClientMsgToSendCB			= rvMtfSampleSipExtRegClientMsgToSend;
	sipExtClbks.regClientMsgReceivedCB			= rvMtfSampleSipExtRegClientMsgReceived;
	sipExtClbks.regExpResolutionNeededCB		= rvMtfSampleSipExtRegExpResolutionNeeded;

    rvMtfRegisterSipExtCallbacks(&sipExtClbks);

	/* --------------------------- */
    /* Build digit Map			   */
    /* --------------------------- */
	/* check if digit map patterns are configured */
	if (strncmp(sampleParams->digitMapPatterns, "NotAssigned", 11))
	{
		rvMdmDigitMapConstruct(&digitMap);
		rvMtfSampleUtilBuildDigitMap(&digitMap, sampleParams->digitMapPatterns);
		sipCfg.digitMapPtr = &digitMap;
	}

    /* ---------------------- */
    /* Initialize MTF         */
    /* ---------------------- */
	rv = rvMtfSipConstruct(&sampleParams->mtfHandle, &sipCfg);
    if (rv != RV_OK)
    {
		printf("rvMtfSampleConstruct() - failed to construct MTF SIP, status=%d\n", rv);
        return rv;
    }

	if (strncmp(sampleParams->digitMapPatterns, "NotAssigned", 11))
	{
		/* Now that the MTF is updated with the configuration parameters we can destruct the
		   digit map */
		rvMdmDigitMapDestruct(&digitMap);
	}
#ifdef RV_MTF_H323
	rv = rvMtfAddH323(sampleParams->mtfHandle, &h323Cfg);
    if (rv != RV_OK)
    {
        printf("rvMtfSampleConstruct() - failed to add H323, status=%d\n", rv);
        return rv;
    }
#endif /* RV_MTF_H323 */

	/* ----------------------- */
	/* Get handle to SIP stack */
	/* ----------------------- */
	rvMtfGetSipStackHandle(sampleParams->mtfHandle, &sampleParams->sipStackHandle);

	/* ------------------ */
    /* For ENUM/Tel-Uri   */
    /* ------------------ */
	rv = RegExpMgrConstruct((RV_LOG_Handle)IppLogMgr(), &sampleParams->regExpMgr);
    if (rv != RV_OK)
    {
        printf("rvMtfSampleConstruct() - failed to initialize Regular Expression Manager (for ENUM/Tel-URI)\n");
        return rv;
    }

    /* ----------------------- */
    /* Load Media Capabilities */
    /* ----------------------- */

    /*Load media capabilities from configuration file*/
    if (rvMtfSampleUtilLoadMediaParams(configBuf, sampleParams) != RV_TRUE)
    {
        IppLogMessage(RV_TRUE, "rvMtfSampleConstruct() - failed to load media parameters");
        return RV_ERROR_UNKNOWN;
    }

    rv = rvMtfLoadMediaCapabilities(sampleParams->mtfHandle, sampleParams->sdpOfFullCaps);
	if (rv != RV_OK)
    {
        IppLogMessage(RV_TRUE, "rvMtfSampleConstruct() - failed to load media capabilities to MTF, status=%d", rv);
        return rv;
    }

	/* ---------------------- */
    /* Register MDM callbacks */
	/* ---------------------- */

    mdmClbks.startSignalCB = rvMtfSampleStartSignalCB;
    mdmClbks.stopSignalCB = rvMtfSampleStopSignalCB;
    mdmClbks.mapDialStringToAddressCB = rvMtfSampleMapDialStringToAddressCB;
	mdmClbks.mapAddressToTerminationCB = NULL; /* We will use MTF default for this one. */
	mdmClbks.matchDialStringToPatternCB = NULL;
    mdmClbks.registerAnalogTermCompletedCB = mtfSampleRegisterAnalogTermCompletedCB;
    mdmClbks.registerIPPhoneTermsCompletedCB = mtfSampleRegisterIPPhoneTermsCompletedCB;
	mdmClbks.registerVideoTermsCompletedCB = mtfSampleRegisterVideoTermsCompletedCB;
	mdmClbks.unregisterAnalogTermCompletedCB = mtfSampleUnregisterAnalogTermCompletedCB;
	mdmClbks.unregisterIPPhoneTermsCompletedCB = mtfSampleUnregisterIPPhoneTermsCompletedCB;
	mdmClbks.unregisterVideoTermsCompletedCB = mtfSampleUnregisterVideoTermsCompletedCB;
    mdmClbks.unregisterTermFromServerCompletedCB = mtfSampleUnregisterTermFromServerCompletedCB;

    rvMtfRegisterMdmCallbacks(sampleParams->mtfHandle, &mdmClbks);

	/* ------------------------ */
    /* Register media callbacks */
	/* ------------------------ */

    memset(&mediaClbks, 0, sizeof(mediaClbks));
	/* use connMediaClbks.connCreateMediaStreamCB instead of  mediaClbks.createMediaStreamCB
	 * use connMediaClbks.connModifyMediaStreamCB instead of mediaClbks.modifyMediaStreamCB
	 * mediaClbks.createMediaStreamCB = rvMtfSampleCreateMediaCB;  
     *  mediaClbks.modifyMediaStreamCB = rvMtfSampleModifyMediaCB; */
    mediaClbks.destroyMediaStreamCB = rvMtfSampleDestroyMediaCB;
    mediaClbks.connectMediaCB = rvMtfSampleConnectMediaCB;
    mediaClbks.disconnectMediaCB = rvMtfSampleDisconnectMediaCB;
    mediaClbks.modifyMediaCompletedCB = rvMtfSampleModifyMediaCompletedCB;
    mediaClbks.startPhysicalDeviceCB = rvMtfSampleStartPhysicalDeviceCB;
    mediaClbks.stopPhysicalDeviceCB = rvMtfSampleStopPhysicalDeviceCB;

#ifdef RV_MTF_N_LINES
	mediaClbks.connectMultiStreamsCB = rvMtfSampleConnectMultiStreams;
    mediaClbks.disconnectMultiStreamsCB = rvMtfSampleDisconnectMultiStreams;
#endif //RV_MTF_N_LINES

    rvMtfRegisterMediaCallbacks(sampleParams->mtfHandle, &mediaClbks);

	/* -------------------------------------- */
    /* Register media callbacks by connection */
	/* -------------------------------------- */

	/* This is only a place holder and example for the media by connetion registration.
	   Currently there are no real sample callbacks of this type */

	memset(&connMediaClbks, 0, sizeof(connMediaClbks));

	connMediaClbks.connCreateMediaStreamCB = rvMtfSampleCreateMediaCB;
	connMediaClbks.connModifyMediaStreamCB = rvMtfSampleModifyMediaCB;
#ifdef RV_MTF_SECOND_VIDEO
	connMediaClbks.connModifySpecificMediaStreamCB = rvMtfSampleConnModifySpecificMediaStreamCB;
#endif
	rvMtfRegisterConnMediaCallbacks(sampleParams->mtfHandle, &connMediaClbks);

	/* ------------------------------- */
	/* Register second video callbacks */
	/* ------------------------------- */
#ifdef RV_MTF_SECOND_VIDEO
	memset(&secondVideoClbks, 0, sizeof(secondVideoClbks));
	secondVideoClbks.RvMtfPresentationTokenMsgReceivedCB = rvMtfSamplePresentationTokenMsgReceivedCB;
	rvMtfRegisterSecondVideoCallbacks(sampleParams->mtfHandle, &secondVideoClbks);
#endif

	/* ---------------------------------------- */
    /* Register MDM Extension Control callbacks */
	/* ---------------------------------------- */

	mdmExtClbks.updateTextDisplayCB = rvMtfSampleSetDisplayCB;
    mdmExtClbks.preProcessEventCB = rvMtfSamplePreProcessEventCB;
	mdmExtClbks.connStateChangedCB = rvMtfSampleConnStateChangedCB;
	mdmExtClbks.termRegistrationStateChangedCB = rvMtfSampleTermRegistrationStateChangedCB;
    mdmExtClbks.postProcessEventCB = rvMtfSamplePostProcessEventCB;

    rvMtfRegisterMdmExtCallbacks(&mdmExtClbks);

#ifdef RV_MTF_VIDEO
    /* Set MDM Extension callbacks*/
    rvMtfSampleLoadVideoCallbacks(&videoClbks, &videoConnClbks, &videoStreamConnClbks);
    rvIppMdmVideoRegisterExtClbks(&videoClbks);
#endif

	/* ---------------------- */
    /* Register IMS callbacks */
	/* ---------------------- */
#ifdef RV_SIP_IMS_ON
	imsClbks.secAgreeNegCompletedEv = RvMtfHandleSecAgreeNegCompletedEv;
	rvMtfRegisterImsCallbacks(sampleParams->mtfHandle, &imsClbks);
#endif

	/* --------------------------- */
	/* Initialize MWI			   */
	/* --------------------------- */

#ifdef SAMPLE_MWI
    /* After stack was initialized, we can use stack handle in order to construct SipSubsMgr object - responsible for
    * SUBSCRIBE/NOTIFY maintenance */

    subsCfg.stackHandle             = sampleParams->sipStackHandle;
    subsCfg.localAddress            = sampleParams->localAddress;
    subsCfg.registrarAddress        = sampleParams->registrarAddress;
    subsCfg.registrarPort           = sampleParams->registrarPort;
    subsCfg.stackUdpPort            = sampleParams->stackUdpPort;
    subsCfg.user					= sampleParams->termId;
    subsCfg.subsServerName          = sampleParams->subsServerName;

    rvMtfSampleSipMwiInit(&subsCfg);
#endif

    /* ---------------------- */
    /* Initialize EPP client  */
    /* ---------------------- */

    /* Make sure we have our socket connection to the GUI application */
	rv = rvMtfSampleEppConstruct(
							&sampleParams->mtfSampleEpp,
							sampleParams->mtfHandle,
							sampleParams->bConfigTCP,
							sampleParams->eppIp,
							sampleParams->eppPort);
    if (rv != RV_OK)
    {
        IppLogMessage(RV_TRUE, "rvMtfSampleConstruct() - failed to construct EPP, status=%d", rv);
        return rv;
    }

	/* ----------------- */
    /* Init Media engine */
	/* ----------------- */
    sampleParams->mediaParam.mtfHandle = sampleParams->mtfHandle;
    sampleParams->mediaParam.sdpFullCaps = sampleParams->sdpOfFullCaps;
	sampleParams->mediaParam.sdpForInvite = sampleParams->sdpForInitialInvite;

    rvMtfMediaInit( &sampleParams->mediaParam);

#ifdef RV_MTF_MEDIA
        if (RV_OK != rvMtfMediaStart(NULL))
		{
            IppLogMessage(RV_TRUE, "rvMtfSampleConstruct() - failed to initialize media");
		}
#else
        /* we call rvMtfMediaStart() when GUI is registered in toolkit, see TermCompletedCB() */

        /* initialize proxy replacement of MfControl library */
        RvMediaControlCreate( sampleParams->mtfSampleEpp.eppClient);
#endif

	/* ---------------- */
	/* Init STUN client */
	/* ---------------- */
#ifdef RV_MTF_STUN
    rv = stunClientInit(sampleParams);
	if (rv != RV_OK)
    {
        IppLogMessage(RV_TRUE, "rvMtfSampleConstruct() - failed to initialize STUN client, status=%d", rv);
        return rv;
    }
#endif

return RV_OK;
}


void rvMtfSampleDestruct(RvMtfSampleParams *sampleParams)
{

	/* Let current processing finish. */
    IppThreadSleep(1,0);

	/* Stop STUn client. */
#ifdef RV_MTF_STUN
    stunClientEnd();
#endif

	/* Release MWI resources. */
#ifdef SAMPLE_MWI
    rvMtfSampleSipMwiEnd();
#endif

	/* Stop processing events. */
    rvMtfStop(sampleParams->mtfHandle);

	/* Destruct EPP client */
	rvMtfSampleEppDestruct(&sampleParams->mtfSampleEpp);

	/* Release all resources. */
    rvMtfSipDestruct(sampleParams->mtfHandle);

	/* Destruct Regular Expression Manager (for Tel-URI). */
	RegExpMgrDestruct(sampleParams->regExpMgr);

	/* Stop media engine. */
#ifdef RV_MTF_MEDIA
    rvMtfMediaStop(NULL);
#endif
    destructGatewayParams(sampleParams);
}

void rvMtfSampleRegisterIPPhone(
						IN RvChar*						termId,
						IN void*						userData,
						OUT RvIppTerminalHandle*		hTerm)
{
	RvStatus					rv;

	rv = rvMtfRegisterIPPhoneTerminations (
			  g_sampleParams.mtfHandle,
			  termId,
			  (RvMtfTerminalAppHandle)userData,  /* Our user data is a pointer to EPP client */
			  hTerm);

	if (rv != RV_OK)
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleRegisterIPPhone() - failed to register IP Phone, rv = %d", rv);
	}
	else
	{
		IppLogMessage(RV_FALSE, "rvMtfSampleRegisterIPPhone() - IP Phone was registered successfully, termId=%s", termId);
	}

	/* For Message Waiting Indication only - send Subscribe message */
#ifdef SAMPLE_MWI
	if (hTerm != NULL)
	{
		rvMtfSampleSipSendSubscribe(*hTerm);
	}
#endif

}

void rvMtfSampleUnregisterIPPhone(
						IN RvIppTerminalHandle		termination)
{
	RvChar			termId[RV_NAME_STR_SZ];
	RvStatus		rv;

	rv = rvMtfUnregisterIPPhoneTerminations(g_sampleParams.mtfHandle, termination);

	rvMtfTerminationGetId(termination, termId, RV_NAME_STR_SZ);

	if (rv != RV_OK)
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleUnregisterIPPhone() - failed to unregister IP Phone, termId=%s, rv=%d",
			termId, rv);
	}
	else
	{
		IppLogMessage(RV_FALSE, "rvMtfSampleUnregisterIPPhone() - IP Phone was unregistered successfully, termId=%s",
			termId);
	}

}

#ifdef RV_MTF_VIDEO
void rvMtfSampleRegisterVideo(
						IN void*	userData)
{
	RvStatus	rv;

	rv = rvMtfRegisterVideoTerminations (g_sampleParams.mtfHandle, (RvMtfTerminalAppHandle)userData);

	if (rv != RV_OK)
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleRegisterIPPhone() - failed to register Video, rv=%d", rv);
	}
	else
	{
		IppLogMessage(RV_FALSE, "rvMtfSampleRegisterVideo() - Video was registered successfully");
	}
}

void rvMtfSampleUnregisterVideo(void)
{
	RvStatus	rv;

	rv = rvMtfUnregisterVideoTerminations (g_sampleParams.mtfHandle);

	if (rv != RV_OK)
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleUnregisterVideo() - failed to unregister Video, rv=%d", rv);
	}
	else
	{
		IppLogMessage(RV_FALSE, "rvMtfSampleUnregisterVideo() - Video was unregistered successfully");
	}
}
#endif /* RV_MTF_VIDEO */

/*strParams is in format: register <term id> analog <GUI address> <GUI port>,RegistrarAddress=172.0.0.0,
*            RegistrarPort=9999,OutboundProxyAddress=172.0.0.0,OutboundProxyPort=8888,
*			 Username=alice,Password=radvision,RegisterExpires=3600 */
void rvMtfSampleRegisterAnalog(
				IN RvChar*					termId,
				IN RvChar*					strParams,
				IN void*					userData,
				OUT RvIppTerminalHandle*	termination)
{
	RvMtfTerminationConfig      termConfig;
	RvStatus					rv;

	/* Set terminal configuration with default values */
	rvMtfTerminationInitConfig(&termConfig);

	rvMtfSampleUtilParseRegisterParams(strParams, &termConfig);

	strncpy(termConfig.displayName, g_sampleParams.displayName, sizeof(termConfig.displayName)-1);
	termConfig.displayName[sizeof(termConfig.displayName)-1] = '\0';

#ifdef RV_MTF_N_LINES
	termConfig.numberOfLines = g_sampleParams.numberOfLines;
#endif /*RV_MTF_N_LINES*/

	rv = rvMtfRegisterAnalogTermination (
		g_sampleParams.mtfHandle,
		termId,
		&termConfig,
		userData, /* Our user data is a pointer to EPP client */
        termination);

	if (rv != RV_OK)
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleRegisterAnalog() - failed to register analog termination, termId=%d, rv=%d",
			termId, rv);
	}
	else
	{
		IppLogMessage(RV_FALSE, "rvMtfSampleRegisterAnalog() - Analog was registered successfully, termId=%s", termId);
	}
}

void rvMtfSampleUnregisterAnalog(RvIppTerminalHandle		termination)
{
	RvStatus	rv;

	rv = rvMtfUnregisterAnalogTermination (g_sampleParams.mtfHandle, termination);

	if (rv != RV_OK)
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleUnregisterVideo() - failed to unregister Analog, rv=%d", rv);
	}
	else
	{
		IppLogMessage(RV_FALSE, "rvMtfSampleUnregisterVideo() - Analog was unregistered successfully");
	}
}

void rvMtfSampleOnHookEvent(
						IN RvIppTerminalHandle     hTerm)
{
	rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_ONHOOK, NULL);
}

void rvMtfSampleOffHookEvent(
						IN RvIppTerminalHandle     hTerm)
{
	rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_OFFHOOK, NULL);
}

void rvMtfSampleHoldEvent(
						IN RvIppTerminalHandle     hTerm)
{
	rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_HOLD, NULL);
}

void rvMtfSampleConferenceEvent(
						IN RvIppTerminalHandle     hTerm)
{
    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_CONFERENCE, NULL);
}

void rvMtfSampleTransferEvent(
						IN RvIppTerminalHandle     hTerm)
{
    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_TRANSFER, NULL);
}

void rvMtfSampleBlindTransferEvent(
						IN RvIppTerminalHandle     hTerm)
{
    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_BLIND_TRANSFER, NULL);
}

void rvMtfSampleMuteEvent(
						IN RvIppTerminalHandle     hTerm)
{
    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_MUTE, NULL);
}

void rvMtfSampleSpeakerEvent(
						IN RvIppTerminalHandle     hTerm)
{
    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_HANDSFREE, NULL);
}

void rvMtfSampleHeadesetEvent(
					IN RvIppTerminalHandle     hTerm)
{
    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_HEADSET, NULL);
}

void rvMtfSampleRedialEvent(
					IN RvIppTerminalHandle     hTerm)
{
    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_REDIAL, NULL);
}

void rvMtfSampleLineEvent(
					 IN RvIppTerminalHandle     hTerm,
					 IN RvUint32				lineId)
{
	RvMtfEventInfo eventInfo;

	memset(&eventInfo, 0, sizeof(RvMtfEventInfo));

	eventInfo.lineId = lineId;

    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_LINE, &eventInfo);
}


void rvMtfSampleCallForwardEvent(
					   IN RvIppTerminalHandle		hTerm,
					   IN RvIppCfwType				cfwType)
{
	RvMtfEventInfo eventInfo;

	memset(&eventInfo, 0, sizeof(RvMtfEventInfo));

	/* Activate CFW (currently it is deactivated)*/
	if (g_sampleParams.callForwardTypeIsActive[cfwType] == rvFalse)
	{
		eventInfo.cfwActivate = RV_TRUE;
		if (cfwType == RV_IPP_CFW_TYPE_NO_REPLY) /* update with timeout value in case of cfw no reply */
		{
			eventInfo.cfwNoReplyTimeout = g_sampleParams.callForwardNoReplyTimeout;
		}
		g_sampleParams.callForwardTypeIsActive[cfwType] = rvTrue;
	}
	/* Deactivate CFW (currently it is activated)*/
	else
	{
		eventInfo.cfwActivate = RV_FALSE;
		g_sampleParams.callForwardTypeIsActive[cfwType] = rvFalse;
	}

	/* Set CFW type: RV_IPP_CFW_TYPE_NO_REPLY, RV_IPP_CFW_TYPE_BUSY or RV_IPP_CFW_TYPE_UNCONDITIONAL*/
	eventInfo.cfwType = cfwType;
	rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_CFW, &eventInfo);
}

void rvMtfSampleDialCompletedEvent(
							   IN RvIppTerminalHandle     hTerm)
{
    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_DIALCOMPLETED, NULL);
}

void rvMtfSampleDigitDownEvent(
								IN RvIppTerminalHandle      hTerm,
								IN RvChar					digit)
{
	RvMtfEventInfo eventInfo;

	memset(&eventInfo, 0, sizeof(RvMtfEventInfo));

	eventInfo.digit = rvMtfSampleUtilDigitToEnum(digit);
    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_DIGITS, &eventInfo);
}

void rvMtfSampleDigitUpEvent(
								IN RvIppTerminalHandle      hTerm,
								IN RvChar					digit)
{
	RvMtfEventInfo eventInfo;

	memset(&eventInfo, 0, sizeof(RvMtfEventInfo));

	eventInfo.digit = rvMtfSampleUtilDigitToEnum(digit);
    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_DIGIT_END, &eventInfo);
}

void rvMtfSampleRejectCallEvent(
								  IN RvIppTerminalHandle		hTerm,
								  IN RvUint32					lineId)
{
	RvMtfEventInfo eventInfo;

	memset(&eventInfo, 0, sizeof(RvMtfEventInfo));

	eventInfo.lineId = lineId;
    rvMtfSendKeyEvent(hTerm, RV_CCTERMEVENT_REJECT_KEY, &eventInfo);
}

/* Dynamic media change - send Re-Invite*/
void rvMtfSampleModifyMediaByReInvite(
						 IN RvIppTerminalHandle		hTerm,
						 IN RvChar*					sdpBuffer,
					 	 IN RvInt					sdpBufferLen)
{
	RvSdpParseStatus    status;
	RvSdpMsg            sdpMsg;
    RvInt               len = sdpBufferLen;

	if ((rvSdpMsgConstructParse(&sdpMsg, sdpBuffer, &len, &status)) != NULL)
	{
		rvMtfMediaStartModify( hTerm, &sdpMsg, RV_MTF_MODIFYMEDIA_BY_REINVITE);
		rvSdpMsgDestruct(&sdpMsg);
    }
	else
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleModifyMediaByReInvite() - failed to parse sdp buffer: %s", sdpBuffer);
	}
}

/* Dynamic media change - send Re-Invite*/
void rvMtfSampleModifyMediaByUpdate(
						  IN RvIppTerminalHandle		hTerm,
						  IN RvChar*					sdpBuffer,
					 	 IN RvInt					sdpBufferLen)
{
	RvSdpParseStatus    status;
	RvSdpMsg            sdpMsg;
    RvInt               len = sdpBufferLen;

	if ((rvSdpMsgConstructParse(&sdpMsg, sdpBuffer, &len, &status)) != NULL)
	{
		rvMtfMediaStartModify( hTerm, &sdpMsg, RV_MTF_MODIFYMEDIA_BY_UPDATE);
		rvSdpMsgDestruct(&sdpMsg);
    }
	else
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleModifyMediaByUpdate() - failed to parse sdp buffer: %s", sdpBuffer);
	}
}

void rvMtfSampleMakeCall(
						   IN RvIppTerminalHandle		hTerm,
						   IN RvChar*					destination)
{
	RvStatus rv;

	rv = rvMtfTerminalMakeCall(hTerm, destination);

	if (rv != RV_OK)
	{
		IppLogMessage(RV_TRUE, "rvMtfSampleMakeCall() - failed to make call to: %s", destination);
	}
}






