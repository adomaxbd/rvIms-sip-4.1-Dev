/******************************************************************************
Filename:    rvMtfSampleH323Control.c

Description: This file contains implementations of MTF callbacks for H323 Extensibility
             defined in structure RvIppH323ExtClbks.
			 These callbacks enables accessing H323 messages and controlling H323 stack.

*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "IppStdInc.h"

#ifdef RV_MTF_H323
#include "rvMtfSample.h"

/****************************************************************************
*  rvMtfSampleH323ExtRegEvent()
* ---------------------------------------------------------------------------
* This is an implementation of H323 callback RvMtfH323RegEventCB().
* This implementation does nothing.
*****************************************************************************/
RvBool RVCALLCONV rvMtfSampleH323ExtRegEvent(
	    IN      RvMtfHandle		         hMtf,
		IN      cmRegState               regState,
        IN      cmRegEvent               regEvent,
		IN      int                      regEventHandle)
{
	RV_UNUSED_ARG(hMtf);
	RV_UNUSED_ARG(regState);
	RV_UNUSED_ARG(regEvent);
	RV_UNUSED_ARG(regEventHandle);

	return RV_TRUE;
}

/****************************************************************************
*  rvMtfSampleH323ExtFlowControl
* ---------------------------------------------------------------------------
* This is an implementation of H323 callback RvMtfH323FlowControlRecvCB().
* This implementation just returns RV_OK, In case of received FlowControlCommand
* message this will result in sending back to the remote FlowControlIndication
*****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleH323ExtFlowControl( 
	IN		RvIppConnectionHandle			hConn,
	IN		RvMtfConnAppHandle				hAppConn,
	IN		RvIppTerminalHandle				hTerm,
	IN		RvMtfTerminalAppHandle			hAppTerm,
	IN		RvMtfMediaStreamHandle			hStream,
	IN		RvMtfMediaStreamAppHandle		hAppStream,
	IN		RvMtfMediaType					mediaType,
	INOUT   RvMtfH323FlowControlMsgParams*	msgParams)
{
	RV_UNUSED_ARG(hAppConn)
	RV_UNUSED_ARG(hAppTerm)
	RV_UNUSED_ARG(hAppStream)

	IppLogMessage(RV_FALSE, 
	"rvMtfSampleH323ExtFlowControl(): hConn=%p hTerm=%p hStream=%d mediaType=%d msgType=%d bitRate=%d",
	hConn, hTerm, hStream, mediaType, msgParams->msgType, msgParams->bitRate);

	return RV_OK;
}

#endif /* RV_MTF_H323 */



