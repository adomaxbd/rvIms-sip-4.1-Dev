/******************************************************************************
Filename:    rvMtfSampleSipControl.c

Description: This file contains implementations of MTF callbacks for SIP Extensibility
             defined in structure RvMtfSipControlClbks.
			 These callbacks enables accessing SIP messages and controlling SIP stack.

*******************************************************************************
				Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "IppStdInc.h"
#include "rvMtfSample.h"
#include "rvMtfSampleSipControl.h"
#include "rvMtfExtControlApi.h"
#include "RvSipStack.h"
#include "RvSipCallLeg.h"
#include "RvSipContactHeader.h"
#include "RvSipRegClientTypes.h"
#include "rvcctext.h"
#include "rvansi.h"
#include "rvMtfSampleUtils.h"
#include "rvstr.h"

#define MAX_DOMAIN_STRING_SIZE 50
#ifdef SAMPLE_MWI
#include "rvMtfSampleMWI.h"
#endif

#ifdef RV_CFLAG_TLS
#include "rvMtfSampleTls.h"
#endif

/*===============================================================================*/
/*===============		 G L O B A L	V A R I A B L E S		=================*/
/*===============================================================================*/
extern char g_displayRegisterStatus[RV_MEDIUM_STR_SZ];
extern RvMtfSampleParams	g_sampleParams;

char supportedExtensionList[48] = "";
char outboundProxyHostName[48] = "";
char strDialPlanSuffix[48] = "";

static char* loadSipStackParams(RvSipStackCfg* stackCfg, char* configBuf);
static void loadStackParams(RvSipStackCfg* stackCfg, char* configBuf);

/*===============================================================================*/
/*=============		 C A L L B A C K		I M P L E M N T A T I O N S   =======*/
/*===============================================================================*/

/***************************************************************************
 * rvMtfSampleSipTransportBadSyntaxMsgEv
 * ------------------------------------------------------------------------
 * General:  This is an implementation of SIP callback RvSipTransportBadSyntaxMsgEv().
 *			 This callback notifies the application that a new bad-syntax message is received.
 *           The application can fix the message in this callback and no later.
 *           The application should use the eAction parameter to decide how
 *           stack will handle this message: discard it, continue with message
 *           processing, or send 400 response (in case of request message).
 *           see the RvSipTransportBsAction definition for more details.
 *           If application did not implemented this callback, the bad-syntax
 *           message will be discard.
 * Return Value: RV_Success.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	hTransportMgr    - A handle to the transport manager object.
 *   	    hAppTransportMgr - The application handle. You supply this handle
 *                             when setting the event handles
 *          hMsgReveived     - The received bad-syntax message.
 * Output:  peAction         - User decision of stack way of handling this message.
 ***************************************************************************/
RV_Status RVCALLCONV rvMtfSampleSipTransportBadSyntaxMsgEv(
                      IN    RvSipTransportMgrHandle    hTransportMgr,
                      IN    RvSipAppTransportMgrHandle hAppTransportMgr,
                      IN    RvSipMsgHandle             hMsgReceived,
                      OUT   RvSipTransportBsAction    *peAction)
{
	/*Inform the stack to continue and process the message*/
	*peAction = RVSIP_TRANSPORT_BS_ACTION_CONTINUE_PROCESS;

	RV_UNUSED_ARG(hTransportMgr);
    RV_UNUSED_ARG(hAppTransportMgr);
	RV_UNUSED_ARG(hMsgReceived);


	return RV_Success;
}


/***************************************************************************
* rvMtfSampleSipNestedInitialReqRcvdEv
* ------------------------------------------------------------------------
* General:	This is an implementation of SIP callback RvSipCallLegNestedInitialReqRcvdEv().
*			This callback indicates that a nested (second or more) INVITE request
*			was received, on a call-leg that is not connected yet.
*			(The second INVITE request has a different cseq value,
*			so it was not rejected by the transaction layer, according to
*			transaction merging rules).
*			When this callback is called the application can order the stack
*			whether to create a new call-leg for this nested request,
*			or not, and then the request will be rejected by the stack.
*
* Return Value: RvStatus. If the application returns a value other then
*               RV_OK the message will not be sent.
* ------------------------------------------------------------------------
* Arguments:
* Input:     hExistCallLeg     - The exists call-leg handle.
*            hExistAppCallLeg  - The application handle for the exists call-leg.
*            hRcvdMsg          - The handle to the nested INVITE message.
* Output:    pbCreateCallLeg   - RV_TRUE will cause the creation of a new call-leg.
*                                RV_FALSE will cause the rejection of the nested INVITE.
***************************************************************************/
void RVCALLCONV rvMtfSampleSipNestedInitialReqRcvdEv(
                                              IN  RvSipCallLegHandle     hExistCallLeg,
                                              IN  RvSipAppCallLegHandle  hExistAppCallLeg,
                                              IN  RvSipMsgHandle         hRcvdMsg,
                                              OUT RvBool                 *pbCreateCallLeg)
{
    RV_UNUSED_ARG(hExistCallLeg);
    RV_UNUSED_ARG(hExistAppCallLeg);
    RV_UNUSED_ARG(hRcvdMsg);

    /* When forking is done to the same point (meaning we receive 2 Invite messages
    with the same From, CSeq and CallId headers. In this case according to
    standard the second Invite should be rejected by 482. However, if there is a
    need to accept this Invite, the stack will create new call leg for the second
    Invite if bDisableMerging is set to True, and this parameter in this callback
    returns True.*/
    *pbCreateCallLeg = RV_TRUE;
}

/****************************************************************************
*  rvMtfSampleSipStackConfig()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfChangeSipStackConfigEv().
* This implementation reads SIP parameters from MTF sample configuration file (SIPPhone.cfg).
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipStackConfig(RvSipStackCfg* stackCfg)
{
	char* configFileName= PHONE_CONFIGURATION_PATH;
	char configBuf[PHONE_CONFIGURATION_FILE_SIZE] = "";
	/*read all parameters again to configBuf*/
	if (rvMtfSampleUtilLoadFile(configBuf,sizeof(configBuf),configFileName) != RV_OK)
	{
		IppLogMessage(RV_TRUE, "failed to read configuration file (%s)", configFileName);
		return;
	}

	loadStackParams(stackCfg, configBuf);

#ifdef SAMPLE_MWI
/*
* We set SUBSCRIBE/NOTIFY related parameters of Stack cfg.
*/
	rvIppSampleSipMwiSetStackCfg( stackCfg);
#endif
}

/****************************************************************************
*  rvMtfSampleRegisterSipStackEvents()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfRegisterSipStackEventsEv().
* This implementation registers application implementation for Transport and
* call-leg callbacks.
****************************************************************************/
void RVCALLCONV rvMtfSampleRegisterSipStackEvents(
					IN RvSipStackHandle				hSipStack,
					IN RvIppSipStackCallbacks*		sipStackClbks)
{

	RV_Status					rv;

	/* -------------------------------- */
	/* Register SIP Transport callbacks */
	/* -------------------------------- */
	{

		RvSipTransportMgrHandle			hTransportMgr;


		/* If callback is not NULL, it means that MTF registered its implementation to this callback.
		   If we proceed, we will override MTF implementation, which is not recommended.*/
		if(sipStackClbks->sipTransportEvHandlers.pfnEvBadSyntaxMsg != NULL)
		{
			IppLogMessage(RV_TRUE, "Application overrides MTF transport callback (BadSyntaxMsg)");
		}

		/* Register application implementation to SIP stack directly */
		sipStackClbks->sipTransportEvHandlers.pfnEvBadSyntaxMsg = rvMtfSampleSipTransportBadSyntaxMsgEv;
		RvSipStackGetTransportMgrHandle( hSipStack, &hTransportMgr);
		rv = RvSipTransportMgrSetEvHandlers( hTransportMgr,
											  NULL,
											  &sipStackClbks->sipTransportEvHandlers,
			   								  sizeof(RvSipTransportMgrEvHandlers));

		if (rv != RV_OK)
		{
			IppLogMessage(RV_TRUE, "Failed to set application transport callbacks");
			return;
		}
	}

    /* ------------------------------ */
	/* Register SIP CallLeg callbacks */
	/* ------------------------------ */

	{
		RvSipCallLegMgrHandle   hCallLegMgr;

		/* If callback is not NULL, it means that MTF registered its implementation to this callback.
		   If we proceed, we will override MTF implementation, which is not recommended.*/
		if(sipStackClbks->sipCallLegEvHandlers.pfnNestedInitialReqRcvdEvHandler !=NULL)
		{
			IppLogMessage(RV_TRUE, "Application overrides MTF transport callback (NestedInitialReqRcvd)");
		}

		/* Register application implementation to SIP stack directly */
		sipStackClbks->sipCallLegEvHandlers.pfnNestedInitialReqRcvdEvHandler =	rvMtfSampleSipNestedInitialReqRcvdEv;
		RvSipStackGetCallLegMgrHandle( hSipStack, &hCallLegMgr);
		rv = RvSipCallLegMgrSetEvHandlers( hCallLegMgr,
			&sipStackClbks->sipCallLegEvHandlers,
			sizeof(RvSipCallLegEvHandlers));

		if(rv != RV_Success)
		{
			IppLogMessage(RV_TRUE, "Failed to set application call-leg callbacks");
			return;
		}
	}
}

/****************************************************************************
*  rvMtfSamplePreCallLegCreatedIncoming()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfPreCallCreatedIncomingEv().
* This implementation does nothing. It indicates MTF to keep the default processing.
****************************************************************************/
RvMtfMsgProcessType	RVCALLCONV rvMtfSamplePreCallLegCreatedIncoming(
				IN  RvSipCallLegHandle      hCallLeg,
				IN  RvMtfAppHandle			hAppMtf)
{
	RvMtfMsgProcessType	type = RV_MTF_DONT_IGNORE;

    IppLogMessage(RV_FALSE, "rvMtfSamplePreCallLegCreatedIncoming(hCallLeg=%p, hAppMtf=%p)=%d",
		hCallLeg, hAppMtf, type);

    return type;
}

/****************************************************************************
*  rvMtfSamplePostCallLegCreatedIncoming()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfPostCallCreatedIncomingEv().
* This implementation does nothing.
*****************************************************************************/
void RVCALLCONV rvMtfSamplePostCallLegCreatedIncoming(
			IN RvSipCallLegHandle			hCallLeg,
			OUT RvMtfConnAppHandle*			hConnApp)
{
	IppLogMessage(RV_FALSE, "rvMtfSamplePostCallLegCreatedIncoming(hCallLeg=%p, hConnApp=%p)",
		hCallLeg, hConnApp);
}

/****************************************************************************
*  rvMtfSampleSipPreCallLegCreatedOutgoing()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfPreCallCreatedOutgoingEv().
* This implementation does nothing.
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipPreCallLegCreatedOutgoing(
			IN RvSipCallLegHandle			hCallLeg,
			IN RvIppConnectionHandle		hConn,
			INOUT RvChar*					to,
			INOUT RvChar*					from,
			OUT RvMtfConnAppHandle*			hConnApp)
{
	IppLogMessage(RV_FALSE, "rvMtfSampleSipPreCallLegCreatedOutgoing(hCallLeg=%p, hConn=%p, to=%s, from=%s, hConnApp=%p)",
		hCallLeg, hConn, to, from, hConnApp);

}

/****************************************************************************
*  rvMtfSampleSipPostCallLegCreatedOutgoing()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfPostCallCreatedOutgoingEv().
* This implementation does nothing.
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipPostCallLegCreatedOutgoing(
				IN RvSipCallLegHandle       hCallLeg,
				IN RvIppConnectionHandle    hConn,
				IN RvMtfConnAppHandle       hConnApp)
{
	IppLogMessage(RV_FALSE, "rvMtfSampleSipPostCallLegCreatedOutgoing(hCallLeg=%p, hConn=%p, hConnApp=%p)",
		hCallLeg, hConn, hConnApp);

}

/****************************************************************************
*  rvMtfSampleSipPreStateChanged()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfPreCallLegStateChangedEv().
* This implementation does nothing.
*****************************************************************************/
RvMtfMsgProcessType RVCALLCONV rvMtfSampleSipPreStateChanged(
    IN RvSipCallLegHandle               hCallLeg,
    IN RvIppConnectionHandle            hConn,
    IN RvMtfConnAppHandle				hConnApp,
    IN RvSipCallLegState                eState,
    IN RvSipCallLegStateChangeReason    eReason)
{
    RvMtfMsgProcessType	type = RV_MTF_DONT_IGNORE;

    IppLogMessage(RV_FALSE, "rvMtfSampleSipPreStateChanged(hCallLeg=%p, hConn=%p, eState=%d, eReason=%d, hConnApp=%p)=%d",
		hCallLeg, hConn, eState, eReason, hConnApp, type);

    return type;
}

/****************************************************************************
*  rvMtfSampleSipPostStateChanged()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfPostCallLegStateChangedEv().
* This implementation does nothing.
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipPostStateChanged(
					IN RvSipCallLegHandle               hCallLeg,
					IN RvIppConnectionHandle            hConn,
					IN RvMtfConnAppHandle				hConnApp,
					IN RvSipCallLegState                eState,
					IN RvSipCallLegStateChangeReason    eReason)
{

    if ((eState == RVSIP_CALL_LEG_STATE_DISCONNECTED) && (eReason = RVSIP_CALL_LEG_REASON_DISCONNECTED))
    {
        /* Note: connHndl is not valid now, already destructed*/
    }

	IppLogMessage(RV_FALSE, "rvMtfSampleSipPreMsgReceived(hCallLeg=%p, hConn=%p, eState=%d, eReason=%d, hConnApp=%p)",
		hCallLeg, hConn, eState, eReason, hConnApp);

}


/****************************************************************************
*  rvMtfSampleSipMsgToSend()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfMsgToSendEv().
* This implementation does nothing.
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipMsgToSend(
    IN RvSipCallLegHandle       hCallLeg,
    IN RvIppConnectionHandle    hConn,
    IN RvMtfConnAppHandle		hConnApp,
    IN RvSipMsgHandle           hMsg)
{
	IppLogMessage(RV_FALSE, "rvMtfSampleSipPreMsgReceived(hCallLeg=%p, hConn=%p, hConnApp=%p, hMsg=%p)",
		hCallLeg, hConn, hConnApp, hMsg);

}

/****************************************************************************
*  rvMtfSampleSipPreMsgReceived()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfPreMsgReceivedEv().
* This implementation does nothing.
*****************************************************************************/
RvMtfMsgProcessType RVCALLCONV rvMtfSampleSipPreMsgReceived(
    IN RvSipCallLegHandle       hCallLeg,
    IN RvIppConnectionHandle    hConn,
    IN RvMtfConnAppHandle		hConnApp,
    IN RvSipMsgHandle           hMsg)
{
	RvMtfMsgProcessType	type = RV_MTF_DONT_IGNORE;

    IppLogMessage(RV_FALSE, "rvMtfSampleSipPreMsgReceived(hCallLeg=%p, hConn=%p, hConnApp=%p, hMsg=%p)=%d",
		hCallLeg, hConn, hConnApp, hMsg, type);

    return type;
}

/****************************************************************************
*  rvMtfSampleSipPostMsgReceived()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfPostMsgReceivedEv().
* This implementation does nothing.
*****************************************************************************/
void RVCALLCONV rvMtfSampleSipPostMsgReceived(
    IN RvSipCallLegHandle       hCallLeg,
    IN RvIppConnectionHandle    hConn,
    IN RvMtfConnAppHandle		hConnApp,
    IN RvSipMsgHandle           hMsg)
{
	IppLogMessage(RV_FALSE, "rvMtfSampleSipPostMsgReceived(hCallLeg=%p, hConn=%p, hConnApp=%p, hMsg=%p)",
		hCallLeg, hConn, hConnApp, hMsg);
}

/****************************************************************************
*  rvMtfSampleSipRegClientStateChanged()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfRegClientStateChangedEv().
* This implementation updates text display with the status of registration with SIP server.
*****************************************************************************/
RvMtfMsgProcessType RVCALLCONV rvMtfSampleSipRegClientStateChanged(
			IN RvSipRegClientHandle             hRegClient,
			IN RvIppTerminalHandle              hTerm,
			IN RvMtfTerminalAppHandle           hAppTerminal,
			IN RvSipRegClientState              eState,
			IN RvSipRegClientStateChangeReason  eReason)
{
	char regStatusLine[RV_MEDIUM_STR_SZ];
    char termId[RV_MEDIUM_STR_SZ];
    char regAddress[RV_MEDIUM_STR_SZ] = "";
    RV_BOOL     needToUpdateDisplay = RV_TRUE;
    char emptyLine[50] = {"                              "};

	rvMtfTerminationGetId(hTerm, termId, RV_MEDIUM_STR_SZ);

    IppLogMessage(RV_FALSE, "rvMtfSampleSipRegClientStateChanged(hRegClient=%p, hTerm=%p (%s), eState=%d, eReason=%d)",
		hRegClient, hTerm, termId, eState, eReason);

	/* Copy Registrar address to a temporary string */
	strncpy(regAddress, g_sampleParams.registrarAddress, sizeof(regAddress));
	regAddress[sizeof(regAddress)-1] = '\0';

    if (!strcmp(g_sampleParams.registrarAddress, ""))
	{
        strcpy(regAddress, "(None)");
	}

    /* We limit address length to 30 because of display window limit*/
    regAddress[30] = '\0';

    sprintf(regStatusLine, "%s <%s> ", RVIPP_DISPLAY_REG_PREFIX, regAddress);

    switch (eState)
    {
        case RVSIP_REG_CLIENT_STATE_IDLE:
            strcat(regStatusLine, "Idle");
            break;
        case RVSIP_REG_CLIENT_STATE_REGISTERING:
            strcat(regStatusLine, "Sending...");
            break;
        case RVSIP_REG_CLIENT_STATE_UNAUTHENTICATED:
            strcat(regStatusLine, "Unauth");
            break;
        case RVSIP_REG_CLIENT_STATE_REGISTERED:
            strcat(regStatusLine, "OK      ");
            break;
        case RVSIP_REG_CLIENT_STATE_REDIRECTED:
            strcat(regStatusLine, "Redirected");
            break;
        case RVSIP_REG_CLIENT_STATE_FAILED:
            strcat(regStatusLine, "Failed   ");
            break;
        case RVSIP_REG_CLIENT_STATE_MSG_SEND_FAILURE:
            strcat(regStatusLine, "Msg Failed");
            break;
        default:
            needToUpdateDisplay = RV_FALSE;
            break;
    }

    if (needToUpdateDisplay == RV_TRUE)
    {
        /* Store registration status in a global string for later since we may not
           be connected yet with GUI at this point...*/
        strcpy(g_displayRegisterStatus, regStatusLine);
        /* Clear line first */
        rvMtfGuiSetTextDisplay((RvEppClientEndpoint*)hAppTerminal, emptyLine, RVIPP_RAW_REGISTER_STATUS, 0);
        /* Display current status */
        rvMtfGuiSetTextDisplay((RvEppClientEndpoint*)hAppTerminal, regStatusLine, RVIPP_RAW_REGISTER_STATUS, 0);
    }

	return RV_MTF_DONT_IGNORE;
}

/****************************************************************************
*  rvMtfSampleSipRegClientCreated()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfRegClientCreatedEv().
* This implementation updates text display with the status of registration with SIP server.
*****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleSipRegClientCreated(
			IN RvSipRegClientHandle             hRegClient)
{

		IppLogMessage(RV_FALSE, "rvMtfSampleSipRegClientCreated(hRegClient=%p)", hRegClient);
		return RV_OK;
	
}

/****************************************************************************
* rvMtfSampleSipExtRegClientMsgToSend
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfRegClientMsgToSendEv().
* This implementation does nothing.
*****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleSipExtRegClientMsgToSend(
	IN RvSipRegClientHandle				hRegClient,
	IN RvIppTerminalHandle				hTerminal,
	IN RvMtfTerminalAppHandle			hAppTerminal,
	IN RvSipMsgHandle					hMsg)
{
	IppLogMessage(RV_FALSE, "rvMtfSampleSipExtRegClientMsgToSend(hRegClient=%p, hTerminal=%p, hAppTerminal=%p, hMsg=%p)",
		                                 hRegClient, hTerminal, hAppTerminal, hMsg);
	return RV_OK;
}

/****************************************************************************
* rvMtfSampleSipExtRegClientMsgReceived
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfRegClientMsgReceivedEv().
* This implementation does nothing.
*****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleSipExtRegClientMsgReceived(
	IN RvSipRegClientHandle				hRegClient,
	IN RvIppTerminalHandle				hTerminal,
	IN RvMtfTerminalAppHandle			hAppTerminal,
	IN RvSipMsgHandle					hMsg)
{
	IppLogMessage(RV_FALSE, "rvMtfSampleSipExtRegClientMsgReceived(hRegClient=%p, hTerminal=%p, hAppTerminal=%p, hMsg=%p)",
		hRegClient, hTerminal, hAppTerminal, hMsg);
	return RV_OK;
}

/****************************************************************************
*  rvMtfSampleSipExtRegExpResolutionNeeded()
* ---------------------------------------------------------------------------
* This is an implementation of SIP callback RvMtfRegExpResolutionNeededEv().
* This implementation is calling an external library for regular expression resolution.
*****************************************************************************/
RvStatus RVCALLCONV rvMtfSampleSipExtRegExpResolutionNeeded(
                IN  RvSipTransmitterMgrHandle                   hTrxMgr,
				IN  RvSipTransmitterHandle                      hTrx,
				INOUT RvSipTransmitterRegExpResolutionParams*   pRegExpParams)
{
    RvStatus rv = RV_OK;

    RV_UNUSED_ARG(hTrx);
    RV_UNUSED_ARG(hTrxMgr);

    IppLogMessage(RV_FALSE, "userSipExtRegExpResolutionNeeded: regexp:%s string:%s\n\n",
					pRegExpParams->strRegExp,pRegExpParams->strString);

    rv = RegExpMgrRegExecResult(
							g_sampleParams.regExpMgr,
							pRegExpParams->strRegExp,
							pRegExpParams->strString,
							pRegExpParams->matchSize,
							pRegExpParams->eFlags,
							pRegExpParams->pMatches);

    return rv;


}


/*===============================================================================*/
/*==========		P R I V A T E			F U N C T I O N S		=============*/
/*===============================================================================*/

/****************************************************************************
*  loadSipStackParams()
*****************************************************************************/
static char* loadSipStackParams(RvSipStackCfg* stackCfg, char* configBuf)
{
	char line[160]="";
	char params[80]="",val[80]="" ;
	char * ptr = configBuf;
	char * last = NULL;
	char *ind;
	RvStrTok t;

	while(rvMtfSampleUtilGetNextLine(configBuf,&ptr)!=NULL)
	{
		/* new section */
		if(ptr[0]=='[')
			return last;
		last = ptr;

		strncpy(line,ptr,rvStrFindFirstOf(ptr,"\n")-ptr);
		line[sizeof(line)-1] = '\0';

		ind = strchr(line,'\r');
		if (ind)
			*ind='\0';
		if (!strcmp(line,""))
		  break;

		rvStrTokConstruct(&t,"= ",line);
		strcpy(params,rvStrTokGetToken(&t));
		strcpy(val,rvStrTokGetToken(&t));

		if(!strcmp(params,"maxCallLegs") ){
			sscanf(val,"%d",&stackCfg->maxCallLegs);
		}

		if(!strcmp(params,"maxTransactions") ){
			sscanf(val,"%d",&stackCfg->maxTransactions);
		}

		if(!strcmp(params,"maxRegClients") ){
			sscanf(val,"%d",&stackCfg->maxRegClients);
		}

		if(!strcmp(params,"messagePoolNumofPages") ){
			sscanf(val,"%d",&stackCfg->messagePoolNumofPages);
		}

		if(!strcmp(params,"messagePoolPageSize") ){
			sscanf(val,"%d",&stackCfg->messagePoolPageSize);
		}

		if(!strcmp(params,"generalPoolNumofPages") ){
			sscanf(val,"%d",&stackCfg->generalPoolNumofPages);
		}

		if(!strcmp(params,"generalPoolPageSize") ){
			sscanf(val,"%d",&stackCfg->generalPoolPageSize);
		}

		if(!strcmp(params,"sendReceiveBufferSize") ){
			sscanf(val,"%d",&stackCfg->sendReceiveBufferSize);
		}

		if(!strcmp(params,"localUdpAddress") ){
			rvStrCopy(stackCfg->localUdpAddress, val);
		}

		if(!strcmp(params,"localUdpPort") )
		{
			RvUint32	tmp;
			sscanf(val,"%d",&tmp);
			stackCfg->localUdpPort = (RvUint16)tmp;
		}

		if(!strcmp(params,"outboundProxyIpAddress") ){
			rvStrCopy(stackCfg->outboundProxyIpAddress, val);
		}

		if(!strcmp(params,"outboundProxyPort") )
		{
			RvUint32	tmp;
			sscanf(val,"%d",&tmp);
			stackCfg->outboundProxyPort =(RvUint16)tmp;
		}

		if (!strcmp(params,"numOfDnsDomains") )
		{
			RvInt32		tmp		= 0;
			RvUint16	index	= 0;
			sscanf(val,"%d",&tmp);
			if ((tmp > 0) && (tmp < 1000))
			{
				RvUint16 dnsDomainSize;

				stackCfg->numOfDnsDomains = tmp;
				stackCfg->pDnsDomains   = malloc(sizeof(RvChar*)*1);
				dnsDomainSize = sizeof(RvChar)*(MAX_DOMAIN_STRING_SIZE);
				stackCfg->pDnsDomains[index] = malloc(dnsDomainSize);
				memset(stackCfg->pDnsDomains[index],0,dnsDomainSize);
			}
		}

		if(!strcmp(params,"dnsDomain") )
		{
			rvStrCopy(stackCfg->pDnsDomains[0], val);
		}

		if(!strcmp(params,"numOfDnsServers") )
		{
			RvInt32 tmp = 0;
			sscanf(val,"%d",&tmp);
			if(tmp > 0)
			{
				stackCfg->numOfDnsServers = tmp;
				stackCfg->pDnsServers = malloc(sizeof(RvSipTransportAddr)*tmp);
				memset(stackCfg->pDnsServers,0,sizeof(RvSipTransportAddr)*tmp);
			}
		}

		if(strstr(params,"dnsAddress") )
		{
			char* ptr;
			char  paramName[11] = "dnsAddress";
			RvInt num;

			/*When numOfDnsServers=0, pDnsServers structure is not allocated*/
			if (stackCfg->numOfDnsServers > 0)
			{
			ptr = strstr(params,paramName);
			ptr+=sizeof(paramName)-1;
			num = atoi(ptr);
			if ((num > 0) && (num <= stackCfg->numOfDnsServers))
				rvStrCopy(stackCfg->pDnsServers[num-1].strIP, val);
		    }
		}

		if(strstr(params,"dnsPort") )
		{
			char*		ptr;
			char		paramName[8] = "dnsPort";
			RvInt		num;

			/*When numOfDnsServers=0, pDnsServers structure is not allocated*/
			if (stackCfg->numOfDnsServers > 0)
			{
			ptr = strstr(params,paramName);
			ptr+=sizeof(paramName)-1;
			num = atoi(ptr);
			if ((num > 0) && (num <= stackCfg->numOfDnsServers))
				stackCfg->pDnsServers[num-1].port = (RvUint16)atoi(val);
			}
		}

		if(!strcmp(params,"retransmissionT1") ){
			sscanf(val,"%d",&stackCfg->retransmissionT1);
		}

		if(!strcmp(params,"retransmissionT2") ){
			sscanf(val,"%d",&stackCfg->retransmissionT2);
		}

		if(!strcmp(params,"generalLingerTimer") ){
			sscanf(val,"%d",&stackCfg->generalLingerTimer);
		}

		if(!strcmp(params,"inviteLingerTimer") ){
			sscanf(val,"%d",&stackCfg->inviteLingerTimer);
		}

		if(!strcmp(params,"provisionalTimer") ){
			sscanf(val,"%d",&stackCfg->provisionalTimer);
		}

		if(!strcmp(params,"defaultLogFilters") ){
			sscanf(val,"%d",&stackCfg->defaultLogFilters);
		}

		if(!strcmp(params,"coreLogFilters") ){
			sscanf(val,"%d",&stackCfg->coreLogFilters);
		}

		if(!strcmp(params,"msgLogFilters") ){
			sscanf(val,"%d",&stackCfg->msgLogFilters);
		}

		if(!strcmp(params,"transportLogFilters") ){
			sscanf(val,"%d",&stackCfg->transportLogFilters);
		}

		if(!strcmp(params,"callLogFilters") ){
			sscanf(val,"%d",&stackCfg->callLogFilters);
		}

		if(!strcmp(params,"parserLogFilters") ){
			sscanf(val,"%d",&stackCfg->parserLogFilters);
		}

		if(!strcmp(params,"stackLogFilters") ){
			sscanf(val,"%d",&stackCfg->stackLogFilters);
		}

		if(!strcmp(params,"msgBuilderLogFilters") ){
			sscanf(val,"%d",&stackCfg->msgBuilderLogFilters);
		}

		if(!strcmp(params,"authenticatorLogFilters") ){
			sscanf(val,"%d",&stackCfg->authenticatorLogFilters);
		}

		if(!strcmp(params,"regClientLogFilters") ){
			sscanf(val,"%d",&stackCfg->regClientLogFilters);
		}


		if(!strcmp(params,"pfnPrintLogEntryEvHandler") )
		{
			sscanf(val,"%p",&stackCfg->pfnPrintLogEntryEvHandler);
		}

		if(!strcmp(params,"logContext") )
		{
			sscanf(val,"%p",&stackCfg->logContext);
		}

		if(!strcmp(params,"bOldInviteHandling") )
		{
			sscanf(val,"%d",&stackCfg->bOldInviteHandling);
		}

#ifndef EXPRESS_EXTRA_LEAN
		if(!strcmp(params,"localTcpAddress") ){
			rvStrCopy(stackCfg->localTcpAddress, val);
		}

		if(!strcmp(params,"localTcpPort") )
		{
			RvUint32	tmp;
			sscanf(val,"%d",&tmp);
			stackCfg->localTcpPort = (RvUint16)tmp;
		}

		if(!strcmp(params,"maxConnections") ){
			sscanf(val,"%d",&stackCfg->maxConnections);
		}

		if(!strcmp(params,"tcpEnabled") ){
			sscanf(val,"%d",&stackCfg->tcpEnabled);
		}

		if(!strcmp(params,"supportedExtensionList") ){
			rvStrCopy(supportedExtensionList, val);
			stackCfg->supportedExtensionList = supportedExtensionList;
		}

		if(!strcmp(params,"rejectUnsupportedExtensions") ){
			sscanf(val,"%d",&stackCfg->rejectUnsupportedExtensions);
		}

		if(!strcmp(params,"manualAckOn2xx") ){
			sscanf(val,"%d",&stackCfg->manualAckOn2xx);
		}

		if(!strcmp(params,"isProxy") ){
			sscanf(val,"%d",&stackCfg->isProxy);
		}

		if(!strcmp(params,"proxy2xxRcvdTimer") ){
			sscanf(val,"%d",&stackCfg->proxy2xxRcvdTimer);
		}

		if(!strcmp(params,"proxy2xxSentTimer") ){
			sscanf(val,"%d",&stackCfg->proxy2xxSentTimer);
		}
/*
		if(!strcmp(params,"localUdpAddresses") ){
			sscanf(val,"%d",&stackCfg->localUdpAddresses);
		}

		if(!strcmp(params,"localUdpPorts") ){
			sscanf(val,"%d",&stackCfg->localUdpPorts);
		}

		if(!strcmp(params,"localTcpAddresses") ){
			sscanf(val,"%d",&stackCfg->localTcpAddresses);
		}

		if(!strcmp(params,"localTcpPorts") ){
			sscanf(val,"%d",&stackCfg->localTcpPorts);
		}
*/
		if(!strcmp(params,"numOfExtraUdpAddresses") ){
			sscanf(val,"%d",&stackCfg->numOfExtraUdpAddresses);
		}

		if(!strcmp(params,"numOfExtraTcpAddresses") ){
			sscanf(val,"%d",&stackCfg->numOfExtraTcpAddresses);
		}

		if(!strcmp(params,"enableServerAuth") ){
			sscanf(val,"%d",&stackCfg->enableServerAuth);
		}

		if(!strcmp(params,"addSupportedListToMsg") ){
			sscanf(val,"%d",&stackCfg->addSupportedListToMsg);
		}
#endif /* #ifndef EXPRESS_EXTRA_LEAN */

		if(!strcmp(params,"enableInviteProceedingTimeoutState") ){
			sscanf(val,"%d",&stackCfg->enableInviteProceedingTimeoutState);
		}

		if(!strcmp(params,"retransmissionT4") ){
			sscanf(val,"%d",&stackCfg->retransmissionT4);
		}

		if(!strcmp(params,"cancelGeneralNoResponseTimer") ){
			sscanf(val,"%d",&stackCfg->cancelGeneralNoResponseTimer);
		}

		if(!strcmp(params,"cancelInviteNoResponseTimer") ){
			sscanf(val,"%d",&stackCfg->cancelInviteNoResponseTimer);
		}

		if(!strcmp(params,"generalRequestTimeoutTimer") ){
			sscanf(val,"%d",&stackCfg->generalRequestTimeoutTimer);
		}

		if(!strcmp(params,"maxElementsInSingleDnsList") ){
			sscanf(val,"%d",&stackCfg->maxElementsInSingleDnsList);
		}

		if(!strcmp(params,"numberOfProcessingThreads") ){
			sscanf(val,"%d",&stackCfg->numberOfProcessingThreads);
		}

		if(!strcmp(params,"processingQueueSize") ){
			sscanf(val,"%d",&stackCfg->processingQueueSize);
		}

		if(!strcmp(params,"numOfReadBuffers") ){
			sscanf(val,"%d",&stackCfg->numOfReadBuffers);
		}

		if(!strcmp(params,"processingTaskPriority") ){
			sscanf(val,"%d",&stackCfg->processingTaskPriority);
		}

		if(!strcmp(params,"processingTaskStackSize") ){
			sscanf(val,"%d",&stackCfg->processingTaskStackSize);
		}

		if(!strcmp(params,"subscriptionLogFilters") ){
			sscanf(val,"%d",&stackCfg->subscriptionLogFilters);
		}
#ifndef EXPRESS_EXTRA_LEAN
		if(!strcmp(params,"maxSubscriptions") ){
			sscanf(val,"%d",&stackCfg->maxSubscriptions);
		}

		if(!strcmp(params,"subsAlertTimer") ){
			sscanf(val,"%d",&stackCfg->subsAlertTimer);
		}

		if(!strcmp(params,"subsNoNotifyTimer") ){
			sscanf(val,"%d",&stackCfg->subsNoNotifyTimer);
		}

		if(!strcmp(params,"subsAutoRefresh") ){
			sscanf(val,"%d",&stackCfg->subsAutoRefresh);
		}

		if(!strcmp(params,"sessionExpires") ){
			sscanf(val,"%d",&stackCfg->sessionExpires);
		}

		if(!strcmp(params,"minSE") ){
			sscanf(val,"%d",&stackCfg->minSE);
		}

		if(!strcmp(params,"manualSessionTimer") ){
			sscanf(val,"%d",&stackCfg->manualSessionTimer);
		}

		if(!strcmp(params,"manualBehavior") ){
			sscanf(val,"%d",&stackCfg->manualBehavior);
		}
#endif /* #ifndef EXPRESS_EXTRA_LEAN */

		if(!strcmp(params,"bUseRportParamInVia") ){
			sscanf(val,"%d",&stackCfg->bUseRportParamInVia);
		}
#ifndef EXPRESS_EXTRA_LEAN
		if(!strcmp(params,"ePersistencyLevel") ){
			sscanf(val,"%d",(int*)&stackCfg->ePersistencyLevel);
		}

		if(!strcmp(params,"serverConnectionTimeout") ){
			sscanf(val,"%d",&stackCfg->serverConnectionTimeout);
		}
#endif /* #ifndef EXPRESS_EXTRA_LEAN */
		if(!strcmp(params,"outboundProxyHostName") ){
			rvStrCopy(outboundProxyHostName, val);
			stackCfg->outboundProxyHostName = outboundProxyHostName;
		}

		if(!strcmp(params,"eOutboundProxyTransport") ){
			sscanf(val,"%d",(int*)&stackCfg->eOutboundProxyTransport);
		}
#ifdef RV_CFLAG_TLS
		loadSipStackTlsParams((char *)params, val, stackCfg);
#endif
/*
		if(!strcmp(params,"headerPoolNumofPages") ){
			sscanf(val,"%d",&stackCfg->headerPoolNumofPages);
		}

		if(!strcmp(params,"headerPoolPageSize") ){
			sscanf(val,"%d",&stackCfg->headerPoolPageSize);
		}
*/
#ifndef EXPRESS_EXTRA_LEAN
		if(!strcmp(params,"bDynamicInviteHandling") ){
			sscanf(val,"%d",&stackCfg->bDynamicInviteHandling);
		}
#endif /* EXPRESS_EXTRA_LEAN*/

		if(!strcmp(params,"bDisableRefer3515Behavior") ){
			sscanf(val,"%d",&stackCfg->bDisableRefer3515Behavior);
		}

		if(!strcmp(params,"maxSubscriptions") ){
			sscanf(val,"%d",&stackCfg->maxSubscriptions);
		}

		if(!strcmp(params,"subsAutoRefresh") ){
			sscanf(val,"%d",&stackCfg->subsAutoRefresh);
		}

        if(!strcmp(params,"bDisableMerging") )
        {
            sscanf(val,"%d",&stackCfg->bDisableMerging);
        }

        if(!strcmp(params,"strDialPlanSuffix") )
        {
            rvStrCopy(strDialPlanSuffix, val);
            stackCfg->strDialPlanSuffix = strDialPlanSuffix;
        }

#ifdef RV_SIP_IMS_ON
		if(!strcmp(params,"maxSecAgrees") ){
			sscanf(val,"%d",&stackCfg->maxSecAgrees);
		}
		if(!strcmp(params,"ipsecSpiRangeStart") ){
			sscanf(val,"%d",&stackCfg->spiRangeStart);
		}
		if(!strcmp(params,"ipsecSpiRangeEnd") ){
			sscanf(val,"%d",&stackCfg->spiRangeEnd);
		}
#endif
		memset(line, 0, 128);
	}
	return ptr;
}

/****************************************************************************
*  loadStackParams()
*****************************************************************************/
static void loadStackParams(RvSipStackCfg* stackCfg, char* configBuf)
{
	char * ptr = NULL;
	char line[512]="";

	while (rvMtfSampleUtilGetNextLine(configBuf,&ptr)!=NULL)
	{
		sscanf(ptr, "%511s", line);
		if(!strcmp(line,"[SIPStackParameters]"))
			ptr=loadSipStackParams(stackCfg,ptr);
	}
}






