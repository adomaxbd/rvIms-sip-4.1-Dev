/******************************************************************************
Filename:    rvMtfSampleCallControl.h
*******************************************************************************
                Copyright (c) 2008 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef RV_CALL_CONTROL_EXT_H
#define RV_CALL_CONTROL_EXT_H


void RVCALLCONV rvMtfSampleSetDisplayCB(
				IN RvIppConnectionHandle    hConn,
				IN RvMtfConnAppHandle		hConnApp,
				IN RvMtfConnectionState		connState,
				IN RvIppTerminalHandle      hTerm,
				IN RvMtfEvent		        eventId,
				IN RvMtfReason				reason);


void RVCALLCONV rvMtfSamplePreProcessEventCB(
				IN      RvIppConnectionHandle   hConn,
				IN		RvMtfConnAppHandle		hConnApp,
				IN		RvMtfConnectionState	connState,
				IN		RvMtfEvent				eventId,
				OUT		RvMtfEvent*				newEventId,
				INOUT   RvMtfReason*			reason);

void RVCALLCONV rvMtfSamplePostProcessEventCB(
				IN  RvIppConnectionHandle   hConn,
				IN	RvMtfConnAppHandle		hConnApp,
				IN	RvMtfConnectionState	connState,
				IN  RvMtfEvent		        eventId,
				IN  RvMtfReason				reason);

void RVCALLCONV rvMtfSampleConnStateChangedCB(
				IN  RvIppConnectionHandle   hConn,
				IN	RvMtfConnAppHandle		hConnApp,
				IN	RvMtfConnectionState	connState,
				IN  RvMtfCallStateReason	reason);

void RVCALLCONV rvMtfSampleTermRegistrationStateChangedCB(
				IN RvIppTerminalHandle              hTerminal,
				IN RvMtfTerminalAppHandle           hAppTerminal,
				IN RvMtfRegisterReportType          reportType,
				IN RvMtfTermRegistrationStatus*     pData);

#endif /*RV_CALL_CONTROL_EXT_H */

