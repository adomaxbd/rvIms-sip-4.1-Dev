/***********************************************************************
Filename   : SigCompAlgorithmNull.c
Description: SigComp Null Algorithm (testing/sample) source file

    Author                         Date
    ------                        ------
    Gil Keini                     20040118

************************************************************************
      Copyright (c) 2001,2002 RADVISION Inc. and RADVISION Ltd.
************************************************************************
NOTICE:
This document contains information that is confidential and proprietary
to RADVISION Inc. and RADVISION Ltd.. No part of this document may be
reproduced in any form whatsoever without written prior approval by
RADVISION Inc. or RADVISION Ltd..

RADVISION Inc. and RADVISION Ltd. reserve the right to revise this
publication and make changes without obligation to notify any person of
such revisions or changes.
***********************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"
#ifdef RV_SIGCOMP_ON /* only compile this file if sigcomp is on */

#include "ImsCom_SigCompAlgorithmNull.h"
#include <string.h> /* for memset & memcpy */


/*-----------------------------------------------------------------------*/
/*                   Definitions & Constants                             */
/*-----------------------------------------------------------------------*/
static RvUint8 decompressionBytecode[] = {
    0x1c, 0x01, 0x86, 0x09, 0x22,
    0x86, 0x01, 0x16, 0xf9, 0x23
};

/*-----------------------------------------------------------------------*/
/*                    Static Helper Functions                            */
/*-----------------------------------------------------------------------*/
static RvStatus RVCALLCONV SigCompAlgNullCompress(
                                  IN    RvSigCompMgrHandle         hSigCompMgr,
                                  IN    RvSigCompCompartmentHandle hCompartment,
                                  IN    RvSigCompCompressionInfo   *pCompressionInfo,
                                  IN    RvSigCompMessageInfo       *pMsgInfo,
                                  IN    RvSigCompAlgorithm         *pAlgStruct,
                                  INOUT RvUint8                    *pInstanceContext,
                                  INOUT RvUint8                    *pAppContext);

/*-----------------------------------------------------------------------*/
/*                    Common Functions                                   */
/*-----------------------------------------------------------------------*/

/*************************************************************************
* SigCompAlgNullInit
* ------------------------------------------------------------------------
* General: Initialize the Null algorithm's structure
*
* Return Value: RvStatus
* ------------------------------------------------------------------------
* Arguments:
* Input:    hSigCmpMgr  - handle to the sigComp manager
*           algStructSize - size of the structure containing information about the algorithm
*           *pAlgStruct - pointer a structure containing information about the algorithm
*
* Output:   *pAlgStruct - The same structure with info filled in
*************************************************************************/

RvStatus RVCALLCONV SigCompAlgNullInit(IN    RvSigCompMgrHandle  hSigCmpMgr,
                                       IN    RvUint32            algStructSize,
                                       INOUT RvSigCompAlgorithm *pAlgStruct)
{
    RvSigCompAlgorithm internalAlgStruct;
    /* using an internal AlgStruct in case of size mismatch due to different versions */
    
    if ((NULL == pAlgStruct) ||
        (0 == algStructSize) ||
        (NULL == hSigCmpMgr))
    {
        return(RV_ERROR_NULLPTR);
    }

    memset(pAlgStruct, 0, algStructSize);
    memset(&internalAlgStruct, 0, sizeof(internalAlgStruct));

    memcpy(internalAlgStruct.algorithmName, NULL_ALGORITHM_NAME, sizeof(internalAlgStruct.algorithmName));
    internalAlgStruct.bSharedCompression  = RV_FALSE;
    internalAlgStruct.contextSize         = 0;
    internalAlgStruct.decompBytecodeAddr  = 128;
    internalAlgStruct.decompBytecodeInst  = 128;
    internalAlgStruct.pDecompBytecode     = decompressionBytecode;
    internalAlgStruct.decompBytecodeSize  = sizeof(decompressionBytecode);
    internalAlgStruct.decompCPB           = 1;
    internalAlgStruct.decompDMS           = 8192;
    internalAlgStruct.decompSMS           = 0; /* can be stateless */
    internalAlgStruct.decompVer           = 0x01;
    /* internalAlgStruct.dictionaryHandle is zeroed */
    /* internalAlgStruct.sharedStateID    is zeroed */
    internalAlgStruct.pfnCompressionFunc  = SigCompAlgNullCompress;

    memcpy(pAlgStruct, &internalAlgStruct, algStructSize);

    return(RV_OK);
}


/*************************************************************************
* SigCompAlgNullCompress
* ------------------------------------------------------------------------
* General: The algorithm's compression function
*
* Return Value: RvStatus
* ------------------------------------------------------------------------
* Arguments:
* Input:    *pMsgInfo - pointer a structure containing the data buffer and target buffer
*           *pDictionary - pointer to a dictionary
*           *pAlgStruct - structure holding the algorithm's information (such as bytecode)
*           *pSize - input the header size (used bytes in the compressed message buffer)
*           *pContext - pointer the algorithm's context
*           hCompartment - handle (pointer) to the compartment for accessing and modifying)
*                           flags and data passed from the UDVM / remote-EP
*
* Output:   *pSize - output the size of the compressed data in bytes
*           *pContext - pointer the algorithm's context
*           hCompartment - handle (pointer) to the compartment for accessing and modifying)
*                           flags and data passed from the UDVM / remote-EP
*           *partialIdLen - length of partial state ID (6/9/12) or 0 if bytecode is included
*************************************************************************/

static RvStatus RVCALLCONV SigCompAlgNullCompress(
                                  IN    RvSigCompMgrHandle         hSigCompMgr,
                                  IN    RvSigCompCompartmentHandle hCompartment,
                                  IN    RvSigCompCompressionInfo   *pCompressionInfo,
                                  IN    RvSigCompMessageInfo       *pMsgInfo,
                                  IN    RvSigCompAlgorithm         *pAlgStruct,
                                  INOUT RvUint8                    *pInstanceContext,
                                  INOUT RvUint8                    *pAppContext)
{
    RvUint8  *pCompBuf;
    RvStatus rv;
    RvUint32 headerSize;


    /* the following arguments should be used in "real" compression algorithms
        but are not meaningful in this NULL-compression context
    */
    RV_UNUSED_ARG(pAlgStruct);
    RV_UNUSED_ARG(pAppContext);
    RV_UNUSED_ARG(hSigCompMgr);
    RV_UNUSED_ARG(pCompressionInfo);
    RV_UNUSED_ARG(pInstanceContext);

    if ((NULL == pMsgInfo) ||
        (NULL == hCompartment))
    {
        /* pContext and pDictionary CAN be null */
        return(RV_ERROR_NULLPTR);
    }
    pCompBuf = pMsgInfo->pCompressedMessageBuffer;

    /* initialize var to the allocated output buffer size */
    headerSize = pMsgInfo->compressedMessageBuffSize;

    rv = RvSigCompGenerateHeader(hCompartment,
                                 decompressionBytecode, 
                                 sizeof(decompressionBytecode), 
                                 128,
                                 pCompBuf, 
                                 &headerSize);

    /* headerSize var now contains the actual number of bytes used for the header */
    if (rv != RV_OK) 
    {
        return rv;
    }

    /* copy plain message to compressed-message buffer */
    memcpy(&pCompBuf[headerSize],
           pMsgInfo->pPlainMessageBuffer,
           pMsgInfo->plainMessageBuffSize);

    pMsgInfo->compressedMessageBuffSize = headerSize + pMsgInfo->plainMessageBuffSize;
    return(RV_OK);
}


#endif /* #ifdef RV_SIGCOMP_ON  */ 

