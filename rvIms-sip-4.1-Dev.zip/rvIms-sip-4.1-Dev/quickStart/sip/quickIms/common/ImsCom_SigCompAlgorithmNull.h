/***********************************************************************
Filename   : SigCompAlgorithmNull.h
Description: SigComp Null Algorithm (testing/sample) header file

    Author                         Date
    ------                        ------
    Gil Keini                     20040118
************************************************************************
      Copyright (c) 2001,2002 RADVISION Inc. and RADVISION Ltd.
************************************************************************
NOTICE:
This document contains information that is confidential and proprietary
to RADVISION Inc. and RADVISION Ltd.. No part of this document may be
reproduced in any form whatsoever without written prior approval by
RADVISION Inc. or RADVISION Ltd..

RADVISION Inc. and RADVISION Ltd. reserve the right to revise this
publication and make changes without obligation to notify any person of
such revisions or changes.

***********************************************************************/

#ifndef SIGCOMP_ALGORITHM_NULL_H
#define SIGCOMP_ALGORITHM_NULL_H

#ifdef __cplusplus
extern "C" {
#endif
    
/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "RV_SIP_DEF.h"
#ifdef RV_SIGCOMP_ON 
	
#include "RvSigComp.h"

/*-----------------------------------------------------------------------*/
/*                   Definitions & Constants                             */
/*-----------------------------------------------------------------------*/
#define NULL_ALGORITHM_NAME "Null"
	
/*-----------------------------------------------------------------------*/
/*                    Static Helper Functions                            */
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                    Common Functions                                   */
/*-----------------------------------------------------------------------*/

/*************************************************************************
* SigCompAlgNullInit
* ------------------------------------------------------------------------
* General: Initialize the Null algorithm's structure
*
* Return Value: RvStatus
* ------------------------------------------------------------------------
* Arguments:
* Input:    hSigCmpMgr  - handle to the sigComp manager
*           algStructSize - size of the structure containing information about the algorithm
*           *pAlgStruct - pointer a structure containing information about the algorithm
*
* Output:   *pAlgStruct - The same structure with info filled in
*************************************************************************/

RvStatus RVCALLCONV SigCompAlgNullInit(
						   IN    RvSigCompMgrHandle hSigCmpMgr,
                           IN    RvUint32           algStructSize,
                           INOUT RvSigCompAlgorithm *pAlgStruct);

#endif /* #ifdef RV_SIGCOMP_ON */

#ifdef __cplusplus
}
#endif

#endif /* end of: SIGCOMP_ALGORITHM_NULL_H */
