/*********************************************************************************
 *                              <ImsComSigComp.h>
 * 
 *   This file defines SigComp utility functions to enable sigcomp
 *   compression in outgoing messages. SigComp is used by 3GPP to compress
 *   messages sent upon ipsec security-associations
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifndef IMSUE_SIG_COMP_H
#define IMSUE_SIG_COMP_H

#ifdef RV_SIP_IMS_ON
#ifdef RV_SIGCOMP_ON
#include "RvSigCompTypes.h"

/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                   SIGCOMP UTILITY FUNCTION HEADERS                    */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppInitSigComp
 * ------------------------------------------------------------------------
 * General: Initializes the SigComp module, which is an external dll and
 *          enable the compression and decompression of SIP messages.
 * Return Value: RV_OK - if successful. error code o/w
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 * Output:  (-)
 ***************************************************************************/
RvStatus AppInitSigComp(void);

/***************************************************************************
 * AppGetMsgCompTypeName
 * ------------------------------------------------------------------------
 * General: Returns the message compression type as a string.
 * Return Value: The string which represents message compression type name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eMsgCompType - The message compression type as enum
 * Output:  (-)
 ***************************************************************************/
const RvChar* AppGetMsgCompTypeName(IN RvSipTransmitterMsgCompType eMsgCompType);


#endif /* RV_SIGCOMP_ON */

#endif /* #ifdef RV_SIP_IMS_ON */

#endif /* #ifndef IMSUE_SIG_COMP_H */


