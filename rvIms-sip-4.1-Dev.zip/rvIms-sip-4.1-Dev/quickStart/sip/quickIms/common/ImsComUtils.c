/*********************************************************************************
 *                              <ImsComUtils.c>
 * 
 *   This file defines general utility functions for the quickstart Ims application
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include <stdio.h>
#include "RV_SIP_DEF.h"

#if (RV_OS_TYPE == RV_OS_TYPE_WINCE) || (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
#include "simpleOSUtils.h"
#endif

#ifdef RV_SIP_IMS_ON
#include "RvSipMid.h"
#include "ImsComUtils.h"

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/

/*Handle to the application memory pool */
extern HRPOOL                g_appPool;

/*-----------------------------------------------------------------------*/
/*                       UTILITY FUNCTIONS                               */
/*-----------------------------------------------------------------------*/
/***************************************************************************
 * AppPrintMessage
 * ------------------------------------------------------------------------
 * General: Prints a message on the screen. For doing this we need to
 *          encode the message and then copy the result to a consecutive
 *          buffer.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg -  Handle to the message.
 ***************************************************************************/
void AppPrintMessage(IN RvSipMsgHandle hMsg)
{
    RvStatus   rv;
    HPAGE       hPage;
    RvChar     *msgBuf;
    RvUint32   msgSize;

    /* getting the encoded message on an rpool page.*/
    rv = RvSipMsgEncode(hMsg, g_appPool, &hPage, &msgSize);
    if (rv != RV_OK)
    {
        OSPrintf("\nMessage encoding failed\n");
        exit(1);
    }
    /*allocate a consecutive buffer - use UTILS since malloc doesn't work on all OS's */
    msgBuf = (RvChar *)RvSipMidMemAlloc(msgSize+1);

    /* copy the encoded message to an external consecutive buffer*/
    rv = RPOOL_CopyToExternal(g_appPool,
                              hPage,
                              0,
                              (void*)msgBuf,
                              msgSize);
    /*terminate the buffer with null*/
    msgBuf[msgSize] = '\0';
    if(rv != RV_OK)
    {
        OSPrintf("\nMessage encoding failed\n");
        /*free the page the encode function allocated*/
        RPOOL_FreePage(g_appPool, hPage);
        RvSipMidMemFree(msgBuf);
        exit(1);
    }
    OSPrintf("\n%s\n",msgBuf);
    /*free the page the encode function allocated*/
    RPOOL_FreePage(g_appPool, hPage);
    RvSipMidMemFree(msgBuf);
}

/***************************************************************************
 * AppExitOnError
 * ------------------------------------------------------------------------
 * General: prints an error message and exits.
  ***************************************************************************/
void AppExitOnError(RvChar* str)
{
    OSPrintf("%s\n",str);
    exit(1);
}

#endif /* #ifdef RV_SIP_IMS_ON */

/***************************************************************************
 * OSPrintf
 * ------------------------------------------------------------------------
 * General: Implementation of printf for different Operating Systems.
 *          (Print formatted output to the standard output stream.)
 * Return Value: The number of characters printed, or a negative value
 *               if an error occurs.
 *-------------------------------------------------------------------------
 * Arguments:
 * Input: format - Format control.
 *        There might be additional parameters according to the format.
 *-------------------------------------------------------------------------
 ***************************************************************************/
int OSPrintf(IN const char *format,... )
{
    int      charsNo;
    va_list  ap;
#if (RV_OS_TYPE == RV_OS_TYPE_WINCE)
    RvChar  cbuf[MAX_PRINT_LEN];

    /*************************************
     Print message to the buffer first
    **************************************/
    va_start(ap,format);
    charsNo = vsprintf (cbuf, format, ap);
    va_end(ap);

    /************************************************
     Using default output window for printing
    *************************************************/
    charsNo = OSWinCEPrintf(NULL,0,cbuf);
#else
    va_start(ap,format);
    charsNo = vprintf(format,ap);
    va_end(ap);

#endif

    return charsNo;
}

