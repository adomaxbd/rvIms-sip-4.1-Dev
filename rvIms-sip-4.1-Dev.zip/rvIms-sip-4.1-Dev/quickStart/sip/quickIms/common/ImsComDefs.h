/*********************************************************************************
 *                              <quickImsDefs.h>
 * This file contains the common definitions for the quick Ims sample application,
 * including Aka definitions, expiration intervals definitions, URI definitions, etc. 
 * --------------------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Ofra Wachsman                  June 2006
 *********************************************************************************/
/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifndef QUICK_IMS_DEFS_H
#define QUICK_IMS_DEFS_H

#include "RvSipStackTypes.h"
#include "RvSipStack.h"
#include "RvSipSecAgreeTypes.h"
#include "RvSipUserConfig.h"

#include "IMSCOM_AKA_Auc.h"

/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

/* =============================
   Global definitions 
   ============================= */
/* Choose the Gm Interface standard supported by this sample application:
   RVSIP_SEC_AGREE_SPECIAL_STANDARD_TISPAN_283003
   RVSIP_SEC_AGREE_SPECIAL_STANDARD_3GPP_24229
   RVSIP_SEC_AGREE_SPECIAL_STANDARD_PKT_2
*/
#define GM_INTERFACE_STANDARD RVSIP_SEC_AGREE_SPECIAL_STANDARD_PKT_2


/* =============================
   Authentication definitions
   ============================= */
#define USER1_NAME "User1"
#define USER1_PW   "pw1"

#define REALM "SimpleRealm"
#define USER_NAME_LEN 20
#define DOMAIN "sip:SimpleDomain@2.2.2.2"
#define LOCAL_OPAQUE "SimpleOpaque"

/* the functions in AKA_Auc file expect a constant length for the
   AKA parameters */
#define USER_KEY_LEN   16
#define AKA_AUTN_LEN   16
#define AKA_RES_LEN    16
#define AKA_RAND_LEN   16
#define AKA_AUTS_LEN   14
#define AKA_AUTS_B64_ENCODED_LEN 20
#define AKA_SQN_LEN     6

#define AMF "11" /* Authentication Key and Management Field. 2 bytes */

/* =============================
   Expiration definitions
   ============================= */
#define REG_AWAIT_AUTH   240
#define REG_EXPIRES      10 /* The default value is 600000, but we are using a shorter interval for demonstration */
#define SUBS_EXPIRES     600000

/* =============================
   Sigcomp definitions
   ============================= */
/* The max. number of retransmissions for compressed SigComp messages */
#define MAX_RETRANS_NO 3

/* =============================
   Addresses definitions
   ============================= */
#define CLIENT_IP		  "127.0.0.1"
#define CLIENT_PORT		  6070
#define CLIENT_TLS_PORT   (CLIENT_PORT+1)
#define CLIENT_IPV6_SCOPE 4    /* This value is relevant only for IPv6 addresses */

#define SERVER_IP		  "127.0.0.1"
#define SERVER_PORT		  6060
#define SERVER_TLS_PORT   (SERVER_PORT+1)
#define SERVER_IPV6_SCOPE 4    /* This value is relevant only for IPv6 addresses */

#define PUB_ID          "UE1"
#define REMOTE_PUB_ID   "UE2"
#define CONTACT_LEN		64

/* Allows you to set an outbound proxy (default is none) */
#define OUTBOUND_PROXY_IP   ""
#define OUTBOUND_PROXY_PORT UNDEFINED

/* =============================
   TLS definitions
   ============================= */
#if (RV_OS_TYPE != RV_OS_TYPE_SYMBIAN)
#define CA_CERT_FILE            "./cacert.pem"
#define SERVER_KEY_N_CERT_FILE  "./localhost.key-cert.pem"
#else
#define CA_CERT_FILE            "C:/DATA/cacert.pem"
#define SERVER_KEY_N_CERT_FILE  "C:/DATA/localhost.key-cert.pem"
#endif
#define MAX_STRING_SIZE             2048

/* ==========================================================
   Interface macros - Please do NOT edit the following lines
   ========================================================== */
#define IS_IPSEC_GM_INTERFACE \
             (GM_INTERFACE_STANDARD == RVSIP_SEC_AGREE_SPECIAL_STANDARD_3GPP_24229 || \
              GM_INTERFACE_STANDARD == RVSIP_SEC_AGREE_SPECIAL_STANDARD_TISPAN_283003)

#ifdef RV_SIGCOMP_ON
#define IS_SIGCOMP_GM_INTERFACE \
             (GM_INTERFACE_STANDARD == RVSIP_SEC_AGREE_SPECIAL_STANDARD_3GPP_24229 || \
              GM_INTERFACE_STANDARD == RVSIP_SEC_AGREE_SPECIAL_STANDARD_PKT_2)
#else
#define IS_SIGCOMP_GM_INTERFACE RV_FALSE
#endif /* RV_SIGCOMP_ON */

#define IS_IPV6_GM_INTERFACE(addr)  (strchr(addr,':') != NULL &&\
                                     strchr(addr,'[') != NULL &&\
                                     strchr(addr,']') != NULL)
#endif /* #ifndef QUICK_IMS_DEFS_H */

