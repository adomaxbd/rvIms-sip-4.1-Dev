/*********************************************************************************
 *                              <ImsUEUtils.c>
 * 
 *   This file defines general utility functions for the Ims UE application
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifdef RV_SIP_IMS_ON
#include "RvSipMsg.h"
#include "RvSipSecAgree.h"
#include "RvSipContactHeader.h"
#include "RvSipPAccessNetworkInfoHeader.h"
#include "RvSipPUriHeader.h"
#include "RvSipOtherHeader.h"
#include "RvSipViaHeader.h"
#include "ImsComUtils.h"
#include "quickImsUE.h"

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/

/* Handle to the global Ims UE object */
extern ImsUE                 g_ImsUE;

/* Global parameters for command line arguments */
extern RvChar g_pServerIP[MAX_STRING_SIZE];

/*-----------------------------------------------------------------------*/
/*                       UTILITY FUNCTIONS                               */
/*-----------------------------------------------------------------------*/
/***************************************************************************
 * AppMsgToSendUpdateContact
 * ------------------------------------------------------------------------
 * General: Sets the local port-s to the Contact header of the message
 *          Set comp=sigcomp when needed
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 ***************************************************************************/
void AppMsgToSendUpdateContact(IN  RvSipMsgHandle      hMsg)
{
	RvSipContactHeaderHandle   hContact;
	RvSipHeaderListElemHandle  hListElem;
	RvSipAddressHandle         hAddr;
	RvStatus                   rv;

	hContact = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_CONTACT, RVSIP_FIRST_HEADER, &hListElem);
	if (hContact == NULL)
	{
		return;
	}

	hAddr = RvSipContactHeaderGetAddrSpec(hContact);
	if (hAddr == NULL)
	{
		return;
	}
	
    /* According to 5.1.2A.1 in the TS document: "If the UE did not insert a GRUU in the 
       Contact header, then the UE shall include the protected server port in the 
       address in the Contact header." */ 
    if (IS_IPSEC_GM_INTERFACE)
    {
	    if (g_ImsUE.g_portS != UNDEFINED)
	    {
		    rv = RvSipAddrUrlSetPortNum(hAddr, g_ImsUE.g_portS);
		    if (RV_OK != rv)
		    {
			    AppExitOnError("\nFailed to set port-s to contact header");
		    }
	    }
    }
    else 
    {  
        rv = RvSipAddrUrlSetPortNum(hAddr, CLIENT_TLS_PORT);
        if (RV_OK != rv)
        {
            AppExitOnError("\nFailed to set local port to contact header");
	    }  
    }

	if (g_ImsUE.g_eCompType == RVSIP_COMP_SIGCOMP)
	{
		rv = RvSipAddrUrlSetCompParam(hAddr, RVSIP_COMP_SIGCOMP, NULL);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to set comp=sigcomp to contact header");
		}
        rv = RvSipAddrUrlSetSigCompIdParam(hAddr,CLT_SIGCOMP_ID_STR); 
        if (RV_OK != rv)
        {
            AppExitOnError("\nFailed to set sigcomp-id to contact header");
		}
	}

}

/***************************************************************************
 * AppMsgToSendAddCompParam
 * ------------------------------------------------------------------------
 * General: Sets sigcomp-id to the Via header of the message
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 *         eCompType - The compression type
 ***************************************************************************/
void AppMsgToSendAddCompParam(IN  RvSipMsgHandle hMsg)
{
	RvSipHeaderListElemHandle  hListElem;
	RvSipViaHeaderHandle       hViaHeader;
	RvStatus                   rv;

	hViaHeader = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_VIA, RVSIP_FIRST_HEADER, &hListElem);
	if (hViaHeader == NULL)
	{
		AppExitOnError("\nMissing Via header");
	}

    rv = RvSipViaHeaderSetSigCompIdParam(hViaHeader,CLT_SIGCOMP_ID_STR);
    if (RV_OK != rv)
    {
        AppExitOnError("\nFailed to set sigcomp-id parameter to Via header");
	}
}

/***************************************************************************
 * AppMsgToSendUpdateReqUri
 * ------------------------------------------------------------------------
 * General: Sets comp=sigcomp to the Request-Uri of the message
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 *         eCompType - The compression type
 ***************************************************************************/
void AppMsgToSendUpdateReqUri(IN  RvSipMsgHandle      hMsg,
							  IN  RvSipCompType       eCompType)
{
	RvSipAddressHandle     hAddr;

	if (eCompType != RVSIP_COMP_SIGCOMP)
	{
		return;
	}

	if (RvSipMsgGetMsgType(hMsg) != RVSIP_MSG_REQUEST)
	{
		return;
	}

	hAddr = RvSipMsgGetRequestUri(hMsg);
	if (hAddr == NULL)
	{
		AppExitOnError("\nMissing Request-Uri");
	}

}

/***************************************************************************
 * AppMsgToSendSetPAccessNetworkInfo
 * ------------------------------------------------------------------------
 * General: Sets the P-Access-Network-Info header into the given message
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 ***************************************************************************/
void AppMsgToSendSetPAccessNetworkInfo(IN  RvSipMsgHandle      hMsg)
{
	RvSipPAccessNetworkInfoHeaderHandle hPAccess;
	RvStatus                            rv;

	rv = RvSipPAccessNetworkInfoHeaderConstructInMsg(hMsg, RV_FALSE, &hPAccess);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to construct P-Access-Network-Info header in message");
	}

    switch (GM_INTERFACE_STANDARD)
    {
    case RVSIP_SEC_AGREE_SPECIAL_STANDARD_3GPP_24229:
        /* This application supports 3GPP, therefore the access info demonstrated here is UTRAN */
        rv = RvSipPAccessNetworkInfoHeaderParse(hPAccess, 
												"P-Access-Network-Info: 3GPP-UTRAN-TDD;utran-cell-id-3gpp=234151D0FCE11");
        break; 
    case RVSIP_SEC_AGREE_SPECIAL_STANDARD_TISPAN_283003:
        /* This application supports TISPAN, therefore the access info demonstrated here is UTRAN */
        rv = RvSipPAccessNetworkInfoHeaderParse(hPAccess, 
												"P-Access-Network-Info: ADSL;dsl-location=\"1.2.3.4\"");
        break; 
    case RVSIP_SEC_AGREE_SPECIAL_STANDARD_PKT_2:
        /* This application supports TISPAN, therefore the access info demonstrated here is UTRAN */
        rv = RvSipPAccessNetworkInfoHeaderParse(hPAccess, 
												"P-Access-Network-Info: DOCSIS;i-wlan-node-id=234151D0FCE11");
        break; 
    default:
        AppExitOnError("\nFound unsupported GM_INTERFACE_STANDARD - P-Access-Network-Info cannot be determined");
    }
	
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to parse P-Access-Network-Info header ");
	}
}

/***************************************************************************
 * AppMsgToSendSetPPreferredIdentity
 * ------------------------------------------------------------------------
 * General: Sets the P-Preferred-Identity header into the given message
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 ***************************************************************************/
void AppMsgToSendSetPPreferredIdentity(IN  RvSipMsgHandle      hMsg)
{
	RvSipPUriHeaderHandle  hPPrefId;
	RvChar                 helper[256];
	RvStatus               rv;

	if (RvSipMsgGetMsgType(hMsg) != RVSIP_MSG_REQUEST ||
		(RvSipMsgGetRequestMethod(hMsg) != RVSIP_METHOD_INVITE &&
		 RvSipMsgGetRequestMethod(hMsg) != RVSIP_METHOD_SUBSCRIBE))
	{
		return;
	}

	rv = RvSipPUriHeaderConstructInMsg(hMsg, RV_FALSE, &hPPrefId);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to construct P-Preferred-Identity header");
	}
	
	sprintf(helper, "P-Preferred-Identity: <sip:%s@%s>", PUB_ID, g_pServerIP);

	rv = RvSipPUriHeaderParse(hPPrefId, helper);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to parse P-Preferred-Identity header");
	}
}

/***************************************************************************
 * AppMsgToSendSetAcceptRegInfo
 * ------------------------------------------------------------------------
 * General: Sets the Accept: application/reginfo+xml header into the given message
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 ***************************************************************************/
void AppMsgToSendSetAcceptRegInfo(IN  RvSipMsgHandle      hMsg)
{
	RvSipOtherHeaderHandle   hAccept;
	RvStatus                 rv;

	if (RvSipMsgGetMsgType(hMsg) != RVSIP_MSG_REQUEST ||
		RvSipMsgGetRequestMethod(hMsg) != RVSIP_METHOD_SUBSCRIBE)
	{
		return;
	}

	rv = RvSipOtherHeaderConstructInMsg(hMsg, RV_FALSE, &hAccept);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to construct Accept header");
	}

	rv = RvSipOtherHeaderParse(hAccept, "Accept: application/reginfo+xml");
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to parse Accept header");
	}
}

#endif /* #ifdef RV_SIP_IMS_ON */

