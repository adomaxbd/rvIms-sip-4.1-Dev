/*********************************************************************************
 *                              <ImsUERegClient.c>
 *
 *   This file implements register-client functionality for registering, authenticating
 *   and de-registering to the server, as well as reacting on register-client events.
 *
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifdef RV_SIP_IMS_ON
#include "RvSipOtherHeader.h"
#include "ImsUERegClient.h"
#include "ImsComUtils.h"
#include "ImsUEUtils.h"
#include "ImsUEAuth.h"
#include "ImsUESecAgree.h"
#include "ImsUECallLeg.h"
#include "ImsUESubs.h"
#include "ImsUEServiceRoute.h"
#include "ImsComDefs.h"
#include "ImsComSigComp.h"
#include "quickImsUE.h"

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/

/*Handle to the register-client manager */
extern RvSipRegClientMgrHandle g_hRegClientMgr;

/*Handle to the message manager. */
extern RvSipMsgMgrHandle g_hMsgMgr;

/*Handle to the application memory pool.*/
extern HRPOOL            g_appPool;

/* Handle to the global Ims UE object */
extern ImsUE                 g_ImsUE;

/* Global parameters for command line arguments */
extern RvUint16 g_clientPort;
extern RvUint16 g_serverPort;
extern RvChar g_pClientIP[MAX_STRING_SIZE];
extern RvChar g_pServerIP[MAX_STRING_SIZE];

/*-----------------------------------------------------------------------*/
/*                      STATIC FUNCTIONS PROTOTYPES			 */
/*-----------------------------------------------------------------------*/

static const RvChar*  AppGetRegClientStateName(IN  RvSipRegClientState  eState);

static void AppRegClientSetPortS(IN  RvSipRegClientHandle  hRegClient);


/*-----------------------------------------------------------------------*/
/*                       REG-CLIENT CONTROL				 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppRegClientMake
 * ------------------------------------------------------------------------
 * General: Invokes initial registration
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSecAgree - The security-agreement to be set to the new register-client
 ***************************************************************************/
void AppRegClientMake(IN  RvSipSecAgreeHandle  hSecAgree)
{
	RvSipRegClientHandle  hRegClient;
	RvChar                strTo[256];
	RvChar                strFrom[256];
	RvChar                strContact[256];
	RvChar                strRegistrar[256];
	RvStatus              rv;

	/* =============================================
        Create a reg-client object.
        Set the client security-agreement in the reg-client.
        Set Initial Authorization header for AKA.
        Send REGISTER.
       ============================================= */

	/* Create a new register-client */
    rv = RvSipRegClientMgrCreateRegClient(g_hRegClientMgr,(RvSipAppRegClientHandle)&g_ImsUE,&hRegClient);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to create new register-client");
    }
    OSPrintf("\nRegister-client %p was created\n\n",hRegClient);

    rv = RvSipRegClientSetSecAgree(hRegClient, hSecAgree);
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to set client security-agreement to register-client");
    }


    /* The initial Authorization header is essential */
    rv = AppRegClientInsertInitialAuthorizationToMessage(hRegClient);
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to set initial Authorization header to register-client");
    }


	g_ImsUE.g_regClient = hRegClient;

	AppRegClientSetExpires(REG_EXPIRES);

	sprintf(strTo, "To: <sip:%s@%s>", PUB_ID, g_pServerIP);
	sprintf(strFrom, "From: <sip:%s@%s>", PUB_ID, g_pServerIP);
	sprintf(strContact, "Contact: <sip:%s@%s>", PUB_ID, g_pClientIP);
	sprintf(strRegistrar, "sip:%s:%d", g_pServerIP, g_serverPort);
	rv = RvSipRegClientMake(hRegClient,strFrom,strTo,strRegistrar,strContact);
    if(rv != RV_OK)
    {
        AppExitOnError("Register request failed for register-client");
    }
}

/***************************************************************************
 * AppRegClientAuthenticate
 * ------------------------------------------------------------------------
 * General: Invokes registration authentication
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 ***************************************************************************/
void AppRegClientAuthenticate()
{
	RvStatus   rv;

	AppRegClientSetExpires(REG_EXPIRES);
    rv = RvSipRegClientAuthenticate(g_ImsUE.g_regClient);
    if(rv != RV_OK)
    {
        AppExitOnError("\nFailed to Authenticate the register-client\n");
    }
}

/***************************************************************************
 * AppRegClientDeregister
 * ------------------------------------------------------------------------
 * General: Invokes de-registration
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 ***************************************************************************/
void AppRegClientDeregister()
{
	RvStatus   rv;

	AppRegClientSetExpires(0);
	rv = RvSipRegClientRegister(g_ImsUE.g_regClient);
	if(rv != RV_OK)
    {
        AppExitOnError("Failed to de-register to the server");
    }
}

/***************************************************************************************
* AppRegClientInsertInitialAuthorizationToMessage
* -------------------------------------------------------------------------------------
* General:  Construct an initial authorization header in the reg-client object,
*           and fill it with user name and realm information. All other parameters should
*           be empty.
*           We use the initial authorization header to tell the private user identity to
*           the server. (The server will generate the Authentication Vector that matches
*           the specific user).
* Return Value: -
* -------------------------------------------------------------------------------------
* Arguments:
* Input:    hRegClient- Handle to the reg-client object.
* Output:   none
**************************************************************************************/
RvStatus AppRegClientInsertInitialAuthorizationToMessage(INOUT RvSipRegClientHandle hRegClient)
{
    RvSipAuthorizationHeaderHandle hAuthorization;
    RvStatus rv = RV_OK;
    RvChar userName[USER_NAME_LEN];
    RvChar realm[20];

    /* Construct Authorization header in the reg-client object */
    rv = RvSipRegClientGetNewMsgElementHandle(hRegClient,
                                        RVSIP_HEADERTYPE_AUTHORIZATION,
                                        RVSIP_ADDRTYPE_UNDEFINED,
                                        (void**)&hAuthorization);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed in getting new Authorization header from reg-client");
    }


    /* the user-name and realm should be set as quoted strings */
    sprintf(userName,"\"%s\"",USER1_NAME);
    sprintf(realm,"\"%s\"",REALM);

    /* set the user name, realm, and other basic parameters to the header */
    rv = RvSipAuthorizationHeaderSetUserName(hAuthorization, userName);
    if(rv == RV_OK)
        rv = RvSipAuthorizationHeaderSetRealm(hAuthorization, realm);
    if(rv == RV_OK)
        rv = RvSipAuthorizationHeaderSetAuthScheme(hAuthorization, RVSIP_AUTH_SCHEME_DIGEST, NULL);
    if(rv == RV_OK)
        rv = RvSipAuthorizationHeaderSetHeaderType(hAuthorization, RVSIP_AUTH_AUTHORIZATION_HEADER);

    /* reset the algorithm parameter to the header */
    if(rv == RV_OK)
        rv = RvSipAuthorizationHeaderSetAuthAlgorithm(hAuthorization, RVSIP_AUTH_ALGORITHM_UNDEFINED, NULL);

    /* add also the URI parameter */
    if(rv == RV_OK)
    {
        RvSipAddressHandle hUri;
        HPAGE   tempPage;

        RPOOL_GetPage(g_appPool, 0, &tempPage);

        rv = RvSipAddrConstruct(g_hMsgMgr, g_appPool, tempPage, RVSIP_ADDRTYPE_URL, &hUri);
        if(rv == RV_OK)
            rv = RvSipAddrUrlSetHost(hUri, g_pServerIP);
        if(rv == RV_OK)
            rv = RvSipAddrUrlSetPortNum(hUri, g_serverPort);
        if(rv == RV_OK)
            rv = RvSipAuthorizationHeaderSetDigestUri(hAuthorization, hUri);

        RPOOL_FreePage(g_appPool, tempPage);
    }

    if(rv != RV_OK)
    {
        AppExitOnError("Failed build initial Authorization header");
    }

    /* Set the new header to the reg-client object */
    rv = RvSipRegClientSetInitialAuthorization(hRegClient, hAuthorization);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set the initial Authorization header in reg-client");
    }
    return RV_OK;
}


/***************************************************************************
 * AppRegClientSetExpires
 * ------------------------------------------------------------------------
 * General: Sets the given expires value to the outbound message of the reg-client
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
void AppRegClientSetExpires(IN  RvInt32  expires)
{
	RvSipMsgHandle				hMsg;
	RvSipExpiresHeaderHandle	hExpiresHeader;
	RvStatus					rv;

	/* Get the outbound message from the reg-client */
    rv = RvSipRegClientGetOutboundMsg(g_ImsUE.g_regClient, &hMsg);
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to get outbound message from reg-client");
	}

	/* Construct new Expires header in the outbound message */
	rv = RvSipExpiresHeaderConstructInMsg(hMsg, RV_TRUE, &hExpiresHeader);
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to construct Expires header in message");
	}

	/* Set the given expires value to the Expires header */
	rv = RvSipExpiresHeaderSetDeltaSeconds(hExpiresHeader, expires);
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to set delta seconds to Expires header");
	}

	g_ImsUE.g_clientExpires = expires;
}

/***************************************************************************
 * AppRegClientGetExpires
 * ------------------------------------------------------------------------
 * General: Gets the expires value that was received in the response from
 *          the server
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
RvUint32 AppRegClientGetExpires()
{
	RvSipMsgHandle				hMsg;
	RvSipExpiresHeaderHandle	hExpiresHeader;
	RvSipHeaderListElemHandle   hListElem;
	RvUint32                    expires;
	RvStatus					rv;

	/* Get the outbound message from the reg-client */
    rv = RvSipRegClientGetReceivedMsg(g_ImsUE.g_regClient, &hMsg);
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to get received message from reg-client");
	}

	/* Get the Expires header from the message */
	hExpiresHeader = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_EXPIRES,
						 RVSIP_FIRST_HEADER, &hListElem);

	if (hExpiresHeader == NULL)
	{
		return UNDEFINED;
	}

	/* Get the expires value from the Expires header */
	rv = RvSipExpiresHeaderGetDeltaSeconds(hExpiresHeader, &expires);
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to get delta seconds from Expires header");
	}

	return expires;
}

/*-----------------------------------------------------------------------*/
/*                       REG-CLIENT CALLBACKS                            */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * RvSipRegClientStateChangedEv
 * ------------------------------------------------------------------------
 * General: Notifies the application of a register-client state change.
 *          Prints the new state.
 *          If the new state is Unauthenticated:
 *              1. Get the authentication-object from the reg-client object.
 *              2. Use the Authentication header to generate the Authentication-Vector.
 *              3. Complete the security agreement activation, using the information
 *                 of the Authentication-Vector.
 *              4. Authenticate the request, using RvSipRegClientAuthenticate().
 *          If the new state is Failed, terminate the register-client.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -    The sip stack register-client handle
 *          hAppRegClient - The application handle for this register-client.
 *          eState -        The new register-client state
 *          eReason -       The reason for the state change.
 ***************************************************************************/
void RVCALLCONV AppClientRegClientStateChangedEvHandler(
                                   IN  RvSipRegClientHandle            hRegClient,
                                   IN  RvSipAppRegClientHandle         hAppRegClient,
                                   IN  RvSipRegClientState             eState,
                                   IN  RvSipRegClientStateChangeReason eReason)
{
    RvStatus             rv;
    RvSipAuthObjHandle   hAuthobj;
	RvSipMsgHandle       hMsg;

    /*print the new state on screen*/
    OSPrintf("\nRegister-client %p - State changed to %s\n\n",
             hRegClient,AppGetRegClientStateName(eState));

    switch(eState)
    {
    /*-------------------------------------------------------------------------
      Authenticate the register-client when it changes state to Unauthenticated.
      Complete the security negotiation before sending the request.
      -------------------------------------------------------------------------*/
    case RVSIP_REG_CLIENT_STATE_UNAUTHENTICATED:

        /* Generate the AKA Authentication vector  (not required in Packet Cable) */
        if (IS_IPSEC_GM_INTERFACE)
        {
            rv = RvSipRegClientAuthObjGet(hRegClient, RVSIP_FIRST_ELEMENT, NULL, &hAuthobj);
            if(rv != RV_OK)
            {
                AppExitOnError("\nFailed to get Authentication object from the register-client\n");
            }
            rv = AppClientGenerateClientAV(hAuthobj);
            if(rv != RV_OK)
            {
                AppExitOnError("\nFailed to generate Authenticate Vector\n");
            }
        }

        /* The Unauthenticated state is a result of a 401 response.
           In this case the 401 response is part of the security agreement negotiation,
           therefore we must complete the security agreement activation before resending
           the REGISTER request. */
        OSPrintf("Choose security before Authenticating REGISTER\n\n");
        AppClientSecAgreeChooseSecurity(g_ImsUE.g_clientSecAgree);

        if (IS_IPSEC_GM_INTERFACE)
        {
		    /* Set ipsec port-s to the contact header of the register-client */
		    AppRegClientSetPortS(hRegClient);
        }

		/* Authenticate the registration */
        OSPrintf("Authenticating REGISTER request\n\n");
        AppRegClientAuthenticate();

		break;
    /*-------------------------------------------------------------
      Terminate the register-client when it changes state to Failed
      -------------------------------------------------------------*/
    case RVSIP_REG_CLIENT_STATE_FAILED:
        OSPrintf("Terminate the register-client due to failure\n\n");
        rv = RvSipRegClientTerminate(hRegClient);
        if(rv != RV_OK)
        {
            AppExitOnError("Failed to terminate the register-client");
        }
        break;
    /*------------------------------------------------
      Notify that the registration succeeded
      ------------------------------------------------*/
    case RVSIP_REG_CLIENT_STATE_REGISTERED:
		if (AppRegClientGetExpires() != 0)
		{
			OSPrintf("The registration succeeded\n\n");

			/* retrieve the received message and store the received Service-Route list */
			rv = RvSipRegClientGetReceivedMsg(hRegClient,&hMsg);
			if(rv != RV_OK)
			{
				AppExitOnError("Failed to Get RegClient Received Msg");
			}
			AppServiceRouteListStore(hMsg);
			/* ----------------------------------------
			   Upon successful registration, subscribe
			   to the registration-state event at the
			   server
			   ---------------------------------------- */
			AppSubscribe();
		}
		else /* the received expires is 0 */
		{
			OSPrintf("The de-registration succeeded, terminate reg-client %p\n\n", hRegClient);
			rv = RvSipRegClientTerminate(hRegClient);
			if (RV_OK != rv)
			{
				AppExitOnError("Failed to terminate the reg-client");
			}
		}

        break;
	case RVSIP_REG_CLIENT_STATE_TERMINATED:
		/* ----------------------------------------------------------
		   The registration terminated. The security-associations
		   will no longer be used. Terminate the security-agreement.
		   ---------------------------------------------------------- */
		AppClientSecAgreeTerminate();
		/* -----------------------------------------------------
		   Since all public user identities are de-registered and the
		   security-association is removed we can assume the subscription
		   canceled. Terminate the subscription object.
		   ----------------------------------------------------- */
		AppSubsTerminate();
		/*free route list and its global page */
        AppResetRouteHopHeaderList();
		break;
    default:
        break;
    }
    RV_UNUSED_ARG(hAppRegClient);
    RV_UNUSED_ARG(eReason);
}

/***************************************************************************
 * AppClientRegClientMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -  The sip stack register-client handle
 *          hRegClient -  The application handle for this register-client.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppClientRegClientMsgReceivedEvHandler(
                                    IN  RvSipRegClientHandle          hRegClient,
                                    IN  RvSipAppRegClientHandle       hAppRegClient,
                                    IN  RvSipMsgHandle                hMsg)
{
    OSPrintf("<-- Message Received (register-client %p)\n",hRegClient);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppRegClient);
    return RV_OK;
}

/***************************************************************************
 * AppClientRegClientMsgToSendEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we set Ims headers to the outgoing message.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -    The sip stack register-client handle
 *          hAppRegClient - The application handle for this register-client.
 *          hMsg -          Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppClientRegClientMsgToSendEvHandler(
                                    IN  RvSipRegClientHandle          hRegClient,
                                    IN  RvSipAppRegClientHandle       hAppRegClient,
                                    IN  RvSipMsgHandle                hMsg)
{
	RvSipHeaderListElemHandle  hListElem;
	RvSipExpiresHeaderHandle   hExpires;
	RvUint32                   deltaSeconds;
	RvSipOtherHeaderHandle     hOtherHeader;
	RvSipContactHeaderHandle   hContactHeader;
	RvSipSecAgreeState         eState;
	RvStatus                   rv;

	hExpires = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_EXPIRES, RVSIP_FIRST_HEADER, &hListElem);
	if (hExpires == NULL)
	{
		AppExitOnError("Failed to get expires header from message");
	}
	rv = RvSipExpiresHeaderGetDeltaSeconds(hExpires, &deltaSeconds);
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to get expires value from header");
	}

	/* Insert comp=sigcomp to the Request-Uri of the outgoing message */
	AppMsgToSendUpdateReqUri(hMsg, g_ImsUE.g_eCompType);

	/* Insert P-Access-Network-Info to the outgoing message, only if the
	   message is secured (i.e., the security-agreement is ACTIVE) */
	rv = RvSipSecAgreeGetState(g_ImsUE.g_clientSecAgree, &eState);
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to get security-agreement state");
	}
	if (eState == RVSIP_SEC_AGREE_STATE_ACTIVE)
	{
		AppMsgToSendSetPAccessNetworkInfo(hMsg);
	}

	if (deltaSeconds != 0)
	{
		/* ----------------------------------
		   Insert headers to outgoing message
		   1. Port-S to Contact
		   2. Supported
		   3. P-Access-Network-Info
		   ---------------------------------- */

		/* Insert port-s and comp=sigcomp to the Contact header of the outgoing message */
		AppMsgToSendUpdateContact(hMsg);

		/* Insert Supported header with path value to the outgoing message */
		rv = RvSipOtherHeaderConstructInMsg(hMsg, RV_FALSE, &hOtherHeader);
		if (RV_OK != rv)
		{
			AppExitOnError("Failed to construct other header in message");
		}

		rv = RvSipOtherHeaderParse(hOtherHeader, "Supported: path");
		if (RV_OK != rv)
		{
			AppExitOnError("Failed to parse Supported header");
		}
	}
	else /* deltaSeconds == 0 */
	{
		/* Set Contact:* to the message in order to de-register from the server */
		hContactHeader = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_CONTACT,
												 RVSIP_FIRST_HEADER, &hListElem);
		if (hContactHeader != NULL)
		{
			rv = RvSipContactHeaderSetStar(hContactHeader);
			if (RV_OK != rv)
			{
				AppExitOnError("Failed to set star contact header");
			}
		}
	}

	OSPrintf("--> Message Sent (register-client %p)\n",hRegClient);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppRegClient);
    return RV_OK;
}

/***************************************************************************
 * AppRegClientFinalDestResolvedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the dest resolved event handler.
 *          Here we add comp=sigcomp to the Via header if needed
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hRegClient     - Handle to the register client.
 *            hAppRegClient  - The application handle for this register client.
 *            hTransc        - The transaction handle
 *            hMsgToSend     - The handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppRegClientFinalDestResolvedEvHandler(
                      IN  RvSipRegClientHandle    hRegClient,
                      IN  RvSipAppRegClientHandle hAppRegClient,
                      IN  RvSipTranscHandle       hTransc,
                      IN  RvSipMsgHandle          hMsgToSend)
{
	/* Add comp=sigcomp to Via header for 3GPP TS 24229 */
	if (IS_SIGCOMP_GM_INTERFACE)
    {
		AppMsgToSendAddCompParam(hMsgToSend);
	}

    RV_UNUSED_ARG(hRegClient)
    RV_UNUSED_ARG(hAppRegClient)
    RV_UNUSED_ARG(hTransc)

	return RV_OK;
}

#ifdef RV_SIGCOMP_ON
/***************************************************************************
 * RvSipRegClientSigCompMsgNotRespondedEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the SigComp message not responded
 *          event handler. Here we decide if a retransmission will take
 *          place and if so, whether the next sent message is compressed
 *
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hRegClient    - Handle to the register client.
 *            hAppRegClient - The application handle for this reg-client.
 *            hTransc       - The transaction handle.
 *            retransNo     - The number of retransmissions of the request
 *                            until now.
 *            ePrevMsgComp  - The type of the previous not responded request
 * Output:    peNextMsgComp - The type of the next request to retransmit (
 *                            RVSIP_TRANSMITTER_MSG_COMP_TYPE_UNDEFINED means that the
 *                            application wishes to stop sending requests).
 ***************************************************************************/
RvStatus RVCALLCONV AppRegClientSigCompMsgNotRespondedEv(
                     IN  RvSipRegClientHandle         hRegClient,
                     IN  RvSipAppRegClientHandle      hAppRegClient,
                     IN  RvSipTranscHandle            hTransc,
                     IN  RvInt32                      retransNo,
                     IN  RvSipTransmitterMsgCompType  ePrevMsgComp,
                     OUT RvSipTransmitterMsgCompType *peNextMsgComp)
{
	if (retransNo < MAX_RETRANS_NO)
    {
        /* Continue re-sending SigComp message (with no bytecode) */
        *peNextMsgComp = RVSIP_TRANSMITTER_MSG_COMP_TYPE_SIGCOMP_COMPRESSED;
    }
    else
    {
        /* Return to the default retransmissions mechanism */
        *peNextMsgComp = RVSIP_TRANSMITTER_MSG_COMP_TYPE_UNCOMPRESSED;
    }
    OSPrintf("\nSigComp msg not responded (reg-client: %p). retransNo=%d, prev msg=%s, next msg=%s\n",
             hRegClient,
             retransNo,
             AppGetMsgCompTypeName(ePrevMsgComp),
             AppGetMsgCompTypeName(*peNextMsgComp));

    RV_UNUSED_ARG(hAppRegClient);
	RV_UNUSED_ARG(hTransc);

    return RV_OK;
}
#endif /* RV_SIGCOMP_ON */

/*-----------------------------------------------------------------------*/
/*                          STATIC FUNCTIONS				 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppGetRegClientStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetRegClientStateName(IN  RvSipRegClientState  eState)
{
    switch (eState)
    {
    case RVSIP_REG_CLIENT_STATE_IDLE:
        return "Idle";
    case RVSIP_REG_CLIENT_STATE_TERMINATED:
        return "Terminated";
    case RVSIP_REG_CLIENT_STATE_REGISTERING:
        return "Registering";
    case RVSIP_REG_CLIENT_STATE_REDIRECTED:
        return "Redirected";
    case RVSIP_REG_CLIENT_STATE_UNAUTHENTICATED:
        return "Unauthenticated";
    case RVSIP_REG_CLIENT_STATE_REGISTERED:
        return "Registered";
    case RVSIP_REG_CLIENT_STATE_FAILED:
        return "Failed";
    default:
        return "Undefined";
    }
}

/***************************************************************************
 * AppRegClientSetPortS
 * ------------------------------------------------------------------------
 * General: Sets port-s to the contact header of the register-client
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient - The reg-client object
 ***************************************************************************/
static void AppRegClientSetPortS(IN  RvSipRegClientHandle  hRegClient)
{
	RvSipContactHeaderHandle  *phContact;
	RvSipAddressHandle         hAddr;
	RvStatus                   rv;

	phContact = RvSipRegClientGetFirstContactHeader(hRegClient);
	if (*phContact != NULL)
	{
		hAddr = RvSipContactHeaderGetAddrSpec(*phContact);
		if (hAddr != NULL)
		{
			rv = RvSipAddrUrlSetPortNum(hAddr, g_ImsUE.g_portS);
			if (RV_OK != rv)
			{
				AppExitOnError("Failed to set port-s to contact header");
			}
		}
	}
}


#endif /* #ifdef RV_SIP_IMS_ON */
