/*********************************************************************************
 *                              <ImsUECallLeg.c>
 *
 *   This file implements call-leg functionality for connecting a dialog and
 *   reacting on call-leg events.
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifdef RV_SIP_IMS_ON
#include "ImsUECallLeg.h"
#include "ImsComUtils.h"
#include "ImsUEUtils.h"
#include "ImsUERegClient.h"
#include "ImsComSigComp.h"
#include "ImsUEServiceRoute.h"
#include "ImsComDefs.h"
#include "quickImsUE.h"

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/
/*Handle to the call-leg manager. */
extern RvSipCallLegMgrHandle g_hCallLegMgr;

/* Handle to the global Ims UE object */
extern ImsUE                 g_ImsUE;

/* Global parameters for command line arguments */
extern RvUint16 g_serverPort;
extern RvChar g_pClientIP[MAX_STRING_SIZE];
extern RvChar g_pServerIP[MAX_STRING_SIZE];

/*-----------------------------------------------------------------------*/
/*                      STATIC FUNCTIONS PROTOTYPES			 */
/*-----------------------------------------------------------------------*/

static const RvChar*  AppGetCallLegStateName (IN  RvSipCallLegState  eState);

static const RvChar*  AppGetDirectionName(IN RvSipCallLegDirection eDirection);

/*-----------------------------------------------------------------------*/
/*                       CALL LEG CONTROL				 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppClientConnectCall
 * ------------------------------------------------------------------------
 * General: Connects a call.
 *          The function is called when the sec-agree object informed of
 *          state active.
 *          The function sets the already created sec-agree object,
 *          and its related ip-sec connection to the new call-leg.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 ***************************************************************************/
void AppClientConnectCall()
{
    RvSipCallLegHandle     hCallLeg; /*handle to the call-leg*/
	RvSipMsgHandle         hOutboundMsg;
	RvChar                 strFrom[256];
	RvChar                 strUE2[256];
	RvChar                 strContact[256];
	RvSipAddressHandle     hAddr;
    RvStatus               rv;

    /* create a new call-leg */
    rv = RvSipCallLegMgrCreateCallLeg(g_hCallLegMgr,(RvSipAppCallLegHandle)&g_ImsUE,&hCallLeg);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to create new call-leg");
    }
    OSPrintf("\nOutgoing call-leg %p was created\n",hCallLeg);

    /* set the client sec-agree object to the call-leg */
    rv = RvSipCallLegSetSecAgree(hCallLeg, g_ImsUE.g_clientSecAgree);
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to set security-agreement to call-leg");
    }

	/* Set outbound proxy if needed */
	if (strlen(OUTBOUND_PROXY_IP) > 0)
	{
		rv = RvSipCallLegSetForceOutboundAddrFlag(hCallLeg, RV_TRUE);
		if (rv != RV_OK)
		{
			AppExitOnError("Failed to set outbound-proxy to call-leg");
		}
	}

	/* Get the outbound message of the call-leg in order to insert preloaded route information*/
    rv = RvSipCallLegGetOutboundMsg(hCallLeg,&hOutboundMsg);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to get new Outbound Message in AppConnectCall()");
    }

	/* Insert preloaded route information obtained by Service-Route into the outbound message */
	if (AppRouteHopListInsertToMsg(hOutboundMsg) == RV_TRUE)
	{
	    rv = RvSipCallLegUseFirstRouteForInitialRequest(hCallLeg);
        if(rv != RV_OK)
        {
            AppExitOnError("Failed to set send to first route indication in the call-leg");
        }
	}

	g_ImsUE.g_CallLeg = hCallLeg;

    /*------------------------------------------------------------
      Call the make function with the To and From addresses in order
      to connect the call.
    -------------------------------------------------------------*/
	/* Set local contact to the call-leg */
	sprintf(strContact, "sip:%s@%s", PUB_ID, g_pClientIP);
    rv = RvSipCallLegGetNewMsgElementHandle(hCallLeg, RVSIP_HEADERTYPE_UNDEFINED,
											RVSIP_ADDRTYPE_URL, (void**)&hAddr);
	if (RV_OK == rv)
	{
		rv = RvSipAddrParse(hAddr, strContact);
		if (RV_OK == rv)
		{
			rv = RvSipCallLegSetLocalContactAddress(hCallLeg, hAddr);
		}
	}
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to set local contact address to call-leg");
	}

    sprintf(strFrom, "From: <sip:%s@%s>", PUB_ID, g_pServerIP);
	sprintf(strUE2, "To: <sip:%s@%s:%d>", REMOTE_PUB_ID, g_pServerIP, g_serverPort);

	OSPrintf("\nConnecting a call: \n\t%s -> %s\n\n",strFrom,strUE2);

	rv = RvSipCallLegMake(hCallLeg,strFrom,strUE2);
    if(rv != RV_OK)
    {
        AppExitOnError("Connect failed for call-leg");
    }
}


/*-----------------------------------------------------------------------*/
/*                       CALL LEG CALLBACK                               */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppCallLegStateChangedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application of a call-leg state change.
 *          In this sample we just print the new state to screen.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          eState -      The new call-leg state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
void RVCALLCONV AppCallLegStateChangedEvHandler(
                                   IN  RvSipCallLegHandle            hCallLeg,
                                   IN  RvSipAppCallLegHandle         hAppCallLeg,
                                   IN  RvSipCallLegState             eState,
                                   IN  RvSipCallLegStateChangeReason eReason)
{
    RvSipCallLegDirection eDirection;

    RvSipCallLegGetDirection(hCallLeg,&eDirection);

    /*print the new state on screen*/
    OSPrintf("\n%s call-leg %p - State changed to %s\n\n",
             AppGetDirectionName(eDirection),
             hCallLeg,AppGetCallLegStateName(eState));

    RV_UNUSED_ARG(hAppCallLeg);
    RV_UNUSED_ARG(eReason);
}

/***************************************************************************
 * AppCallLegMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppCallLegMsgReceivedEvHandler(
                                    IN  RvSipCallLegHandle            hCallLeg,
                                    IN  RvSipAppCallLegHandle         hAppCallLeg,
                                    IN  RvSipMsgHandle                hMsg)
{
    OSPrintf("<-- Message Received (call-leg %p)\n",hCallLeg);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppCallLeg);
    return RV_OK;
}

/***************************************************************************
 * AppCallLegMsgToSendEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we set Ims headers to the outgoing message.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppCallLegMsgToSendEvHandler(
                                    IN  RvSipCallLegHandle            hCallLeg,
                                    IN  RvSipAppCallLegHandle         hAppCallLeg,
                                    IN  RvSipMsgHandle                hMsg)
{
	/* Insert Port-S and comp=sigcomp to the Contact header of the outgoing message */
	AppMsgToSendUpdateContact(hMsg);

	/* Insert P-Access-Netwrok-Info to the outgoing message */
	AppMsgToSendSetPAccessNetworkInfo(hMsg);

	/* Insert P-Preferred-Identity to the outgoing message */
	AppMsgToSendSetPPreferredIdentity(hMsg);

    OSPrintf("--> Message Sent (call-leg %p)\n",hCallLeg);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppCallLeg);
    return RV_OK;
}

/***************************************************************************
 * AppCallLegFinalDestResolvedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the dest resolved event handler.
 *          Here we add sigcomp-id to the Via header if needed
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hCallLeg       - The SIP Stack call-leg handle.
 *            hAppCallLeg    - The application handle for this call-leg.
 *            hTransc        - The transaction handle.
 *            hAppTransc     - The application handle for this transaction.
 *                             For INVITE/BYE the hAppTransc is NULL.
 *            hMsgToSend     - The handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppCallLegFinalDestResolvedEvHandler(
                      IN  RvSipCallLegHandle     hCallLeg,
                      IN  RvSipAppCallLegHandle  hAppCallLeg,
                      IN  RvSipTranscHandle      hTransc,
                      IN  RvSipAppTranscHandle   hAppTransc,
                      IN  RvSipMsgHandle         hMsgToSend)
{
	/* Add comp=sigcomp to Via header for 3GPP TS 24229 or Packet Cable 2.0 */
	if (IS_SIGCOMP_GM_INTERFACE)
    {
		AppMsgToSendAddCompParam(hMsgToSend);
	}

    RV_UNUSED_ARG(hCallLeg)
    RV_UNUSED_ARG(hAppCallLeg)
    RV_UNUSED_ARG(hTransc)
    RV_UNUSED_ARG(hAppTransc)

	return RV_OK;
}

#ifdef RV_SIGCOMP_ON
/***************************************************************************
 * AppCallLegSigCompMsgNotRespondedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the SigComp message not responded
 *          event handler. Here we decide if a retransmission will take
 *          place and if so, whether the next sent message is compressed
 *
 * Return Value: RV_OK.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hCallLeg       - The sip stack call-leg handle
 *            hAppCallLeg    - The application handle for this call-leg.
 *            hTransc        - The transaction handle.
 *            hAppTransc     - The transaction application handle.
 *            retransNo      - The number of retransmissions of the request
 *                             until now.
 *            ePrevMsgComp   - The type of the previous not responded request
 * Output:    peNextMsgComp  - The type of the next request to retransmit (
 *                             RVSIP_TRANSC_MSG_TYPE_UNDEFINED means that the
 *                             application wishes to stop sending requests).
 ***************************************************************************/
RvStatus RVCALLCONV AppCallLegSigCompMsgNotRespondedEvHandler(
                     IN  RvSipCallLegHandle           hCallLeg,
                     IN  RvSipAppCallLegHandle        hAppCallLeg,
                     IN  RvSipTranscHandle            hTransc,
                     IN  RvSipAppTranscHandle         hAppTransc,
                     IN  RvInt32                      retransNo,
                     IN  RvSipTransmitterMsgCompType  ePrevMsgComp,
                     OUT RvSipTransmitterMsgCompType *peNextMsgComp)
{
    if (retransNo < MAX_RETRANS_NO)
    {
        /* Continue re-sending SigComp message (with no bytecode) */
        *peNextMsgComp = RVSIP_TRANSMITTER_MSG_COMP_TYPE_SIGCOMP_COMPRESSED;
    }
    else
    {
        /* Return to the default retransmissions mechanism */
        *peNextMsgComp = RVSIP_TRANSMITTER_MSG_COMP_TYPE_UNCOMPRESSED;
    }
    OSPrintf("\nSigComp msg not responded (call-leg: %p). retransNo=%d, prev msg=%s, next msg=%s\n",
             hCallLeg,
             retransNo,
             AppGetMsgCompTypeName(ePrevMsgComp),
             AppGetMsgCompTypeName(*peNextMsgComp));

    RV_UNUSED_ARG(hAppCallLeg);
    RV_UNUSED_ARG(hTransc);
    RV_UNUSED_ARG(hAppTransc);

    return RV_OK;
}
#endif /* RV_SIGCOMP_ON */

/*-----------------------------------------------------------------------*/
/*                          STATIC FUNCTIONS				 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppGetCallLegStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetCallLegStateName (IN  RvSipCallLegState  eState)
{
    switch(eState)
    {
    case RVSIP_CALL_LEG_STATE_ACCEPTED:
        return "Accepted";
    case RVSIP_CALL_LEG_STATE_CONNECTED:
        return "Connected";
    case RVSIP_CALL_LEG_STATE_DISCONNECTED:
        return "Disconnected";
    case RVSIP_CALL_LEG_STATE_DISCONNECTING:
        return "Disconnecting";
    case RVSIP_CALL_LEG_STATE_IDLE:
        return "Idle";
    case RVSIP_CALL_LEG_STATE_INVITING:
        return "Inviting";
    case RVSIP_CALL_LEG_STATE_OFFERING:
        return "Offering";
    case RVSIP_CALL_LEG_STATE_REDIRECTED:
        return "Redirected";
    case RVSIP_CALL_LEG_STATE_TERMINATED:
        return "Terminated";
    default:
        return "Undefined";
    }
}

/***************************************************************************
 * AppGetDirectionName
 * ------------------------------------------------------------------------
 * General: Returns a call-leg direction as a string.
 * Return Value: The string with the direction name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The direction as enum
 ***************************************************************************/
static const RvChar*  AppGetDirectionName(IN RvSipCallLegDirection eDirection)
{
    switch(eDirection)
    {
    case RVSIP_CALL_LEG_DIRECTION_INCOMING:
        return "INCOMING";
    case RVSIP_CALL_LEG_DIRECTION_OUTGOING:
        return "OUTGOING";
    default:
        return "Undefined";
    }
}

#endif /* #ifdef RV_SIP_IMS_ON */

