/*********************************************************************************
 *                              <ImsUESubs.>
 * 
 *   This file implements subscription functionality for subscribing to the
 *   registration-state event, reacting on subscription events, and processing
 *   incoming notification. 
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifdef RV_SIP_IMS_ON
#ifdef RV_SIP_SUBS_ON
#include "ImsUESubs.h"
#include "ImsComUtils.h"
#include "ImsUEUtils.h"
#include "ImsUESecAgree.h"
#include "ImsUECallLeg.h"
#include "ImsUERegClient.h"
#include "ImsUEServiceRoute.h"
#include "ImsComSigComp.h"
#include "ImsComDefs.h"
#include "quickImsUE.h"

/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/
#define EVENT "reg"

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/

/*Handle to the Subscription manager */
extern RvSipSubsMgrHandle g_hSubsMgr;

/* Handle to the global Ims UE object */
extern ImsUE                 g_ImsUE;

/* Global parameters for command line arguments */
extern RvChar g_pClientIP[MAX_STRING_SIZE];
extern RvChar g_pServerIP[MAX_STRING_SIZE];

/*-----------------------------------------------------------------------*/
/*                      STATIC FUNCTIONS PROTOTYPES			 */
/*-----------------------------------------------------------------------*/

static void  AppProcessNotify (IN  RvSipMsgHandle         hMsg,
                               OUT RvBool                *pbRegTerminated);

static const RvChar*  AppGetSubsStateName (IN  RvSipSubsState  eState);

/*-----------------------------------------------------------------------*/
/*                       SUBSCRIPTION CONTROL				 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppSubscribe
 * ------------------------------------------------------------------------
 * General: Create a subscription.
 *          To Create a subscription the application should:
 *          1. create a new subscription using RvSipSubsMgrCreateSubscription().
 *          2. call RvSipSubsInitStr(), to set mandatory parameters.
 *          3. call RvSipSubsSubscribe(). This will cause the subscribe message
 *             to be sent to the destination.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 ***************************************************************************/
void AppSubscribe(void)
{
    RvSipSubsHandle				hSubs;
	RvSipCallLegHandle			hDialog;
	RvSipMsgHandle				hOutboundMsg;
	RvChar						strTo[256];
	RvChar						strFrom[256];
	RvChar						strLocalContact[256];
	RvStatus					rv;

    /*--------------------------
      creating a new subscription
    ----------------------------*/
    rv = RvSipSubsMgrCreateSubscription(g_hSubsMgr, NULL, (RvSipAppSubsHandle)&g_ImsUE, &hSubs);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to create new subscription");
    }
    OSPrintf("\nSubscriber subscription %p was created\n\n",hSubs);

    /*------------------------------------------------------------
      Call the init function with the To and From addresses, event
      and expires values, in order to init and send the subscription.
    -------------------------------------------------------------*/
    sprintf(strTo, "<sip:%s@%s>", PUB_ID, g_pServerIP);
	sprintf(strFrom, "<sip:%s@%s>", PUB_ID, g_pServerIP);
	rv = RvSipSubsInitStr(hSubs, strFrom, strTo, SUBS_EXPIRES, EVENT);
    if(rv != RV_OK)
    {
        AppExitOnError("subscription init failed.");
    }
	sprintf(strLocalContact, "sip:%s@%s", PUB_ID, g_pClientIP);
	rv = RvSipSubsDialogInitStr(hSubs, NULL, NULL, strLocalContact, NULL);
	if(rv != RV_OK)
    {
        AppExitOnError("subscription init failed.");
    }

	/*----------------------------------------------------
      Set security-agreement object to the subscription
      ---------------------------------------------------- */
    rv = RvSipSubsGetDialogObj(hSubs,&hDialog);
	if(rv != RV_OK)
    {
        AppExitOnError("Failed to get inner dialog from subscription");
    }
	rv = RvSipCallLegSetSecAgree(hDialog, g_ImsUE.g_clientSecAgree);
	if(rv != RV_OK)
    {
        AppExitOnError("Failed to set security-agreement to subscription");
    }

	/*----------------------------------------------------
      Set outbound-proxy to the subscription (id needed)
      ---------------------------------------------------- */
    if (strlen(OUTBOUND_PROXY_IP) > 0)
	{
		rv = RvSipCallLegSetForceOutboundAddrFlag(hDialog, RV_TRUE);
		if (rv != RV_OK)
		{
			AppExitOnError("Failed to set outbound-proxy to call-leg");
		}
	}
	
	/*----------------------------------------------------
      Insert preloaded route list to the outbound message
      ---------------------------------------------------- */
    /* Get the outbound message of the subscription in order to insert preloaded route information*/
    rv = RvSipSubsGetOutboundMsg(hSubs,&hOutboundMsg);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to get new Outbound Mesaage in AppSubscribe()");
    }

	/* Insert preloaded route information obtained by Service-Route into the outbound message */
	if (AppRouteHopListInsertToMsg(hOutboundMsg) == RV_TRUE)
	{
	    rv = RvSipCallLegUseFirstRouteForInitialRequest(hDialog);
        if(rv != RV_OK)
        {
            AppExitOnError("Failed to set send to first route indication in the call-leg");
        }
	}

	/*-------------------------
      Subscribe to the server
      ------------------------- */
    OSPrintf("\nsending SUBSCRIBE: \n\t%s -> %s\n\n",strFrom,strTo);
    rv = RvSipSubsSubscribe(hSubs);
    if(rv != RV_OK)
    {
        AppExitOnError("subscribing failed.");
    }

	g_ImsUE.g_subs = hSubs;
}

/***************************************************************************
 * AppSubsTerminate
 * ------------------------------------------------------------------------
 * General: Terminate the subscription object
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 ***************************************************************************/
void AppSubsTerminate(void)
{
	RvStatus  rv;
	
	if (g_ImsUE.g_subs == NULL)
	{
		return;
	}

    OSPrintf("\nTerminating subscription: %p\n",g_ImsUE.g_subs);
    rv = RvSipSubsTerminate(g_ImsUE.g_subs);
    if (RV_OK != rv)
	{
	    AppExitOnError("Failed to terminate the subscription");
	}
}


/*-----------------------------------------------------------------------*/
/*                       SUBSCRIPTION CALLBACKS				 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppSubsMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsMsgReceivedEvHandler(
                                        IN  RvSipSubsHandle      hSubs,
                                        IN  RvSipAppSubsHandle   hAppSubs,
                                        IN  RvSipNotifyHandle    hNotify,
                                        IN  RvSipAppNotifyHandle hAppNotify,
                                        IN  RvSipMsgHandle       hMsg)
{
    OSPrintf("<-- Message Received (subscription %p)\n",hSubs);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(hAppNotify);
    RV_UNUSED_ARG(hNotify);
    return RV_OK;
}

/***************************************************************************
 * AppSubsMsgToSendEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we set Ims headers to the outgoing message.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsMsgToSendEvHandler(
                                          IN    RvSipSubsHandle      hSubs,
                                          IN    RvSipAppSubsHandle   hAppSubs,
                                          IN    RvSipNotifyHandle    hNotify,
                                          IN    RvSipAppNotifyHandle hAppNotify,
                                          IN    RvSipMsgHandle       hMsg)
{
    /* Insert Port-S and comp=sigcomp to the Contact header of the outgoing message */
	AppMsgToSendUpdateContact(hMsg);

	/* Insert P-Access-Netwrok-Info to the outgoing message */
	AppMsgToSendSetPAccessNetworkInfo(hMsg);
	
	/* Insert P-Preferred-Identity to the outgoing message */
	AppMsgToSendSetPPreferredIdentity(hMsg);

	/* Insert Accept: application/reginfo+xml to the outgoing message */
	AppMsgToSendSetAcceptRegInfo(hMsg);
	
	OSPrintf("--> Message Sent (subscription %p)\n",hSubs);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(hAppNotify);
    RV_UNUSED_ARG(hNotify);
    return RV_OK;
}

/***************************************************************************
 * AppSubsFinalDestResolvedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the dest resolved event handler.
  *         Here we add comp=sigcomp to the Via header if needed
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hSubs          - The sip stack subscription handle
 *            hAppSubs       - The application handle for this subscription.
 *            hNotify        - The notify object handle (relevant only for notify request or response)
 *            hAppNotify     - The application notify object handle (relevant only for notify request or response)
 *            hTransc        - The transaction handle
 *            hMsgToSend     - The handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsFinalDestResolvedEvHandler(
                      IN  RvSipSubsHandle           hSubs,
                      IN  RvSipAppSubsHandle        hAppSubs,
                      IN  RvSipNotifyHandle         hNotify,
                      IN  RvSipAppNotifyHandle      hAppNotify,
                      IN  RvSipTranscHandle         hTransc,
                      IN  RvSipMsgHandle            hMsgToSend)
{
	/* Add comp=sigcomp to Via header for 3GPP TS 24229 */
	if (IS_SIGCOMP_GM_INTERFACE)
    {
		AppMsgToSendAddCompParam(hMsgToSend);
	}

    RV_UNUSED_ARG(hSubs);
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(hNotify);
    RV_UNUSED_ARG(hAppNotify);
    RV_UNUSED_ARG(hTransc);

	return RV_OK;
}

/***************************************************************************
 * AppSubsStateChangedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application of a subscription state change.
 *          For all states indicating a new incoming requests (subs_rcvd,
 *          refresh_rcvd, ubsubscribe_rcvd) - accept the request, and send
 *          a notify request immediately.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          eState -      The new subscription state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
void RVCALLCONV AppSubsStateChangedEvHandler(
                                    IN  RvSipSubsHandle            hSubs,
                                    IN  RvSipAppSubsHandle         hAppSubs,
                                    IN  RvSipSubsState             eState,
                                    IN  RvSipSubsStateChangeReason eReason)
{
    /*print the new state on screen*/
    OSPrintf("\nsubscription %p - State changed to %s\n\n",
             hSubs,AppGetSubsStateName(eState));

	RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(eReason);
}

/***************************************************************************
 * AppSubsNotifyEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the SubsNotifyEv event handler.
 *          If the new status is request_rcvd - accept the notify request
 *          with RvSipNotifyAccept().
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs         - The sip stack subscription handle
 *          hAppSubs      - The application handle for this subscription.
 *          hNotification - The new created notification object handle.
 *          hAppNotification - The application handle for this notification.
 *          eNotifyStatus - Status of the notification object.
 *          eNotifyReason - Reason to the indicated status.
 *          hNotifyMsg    - The received notify msg.
 ***************************************************************************/
void RVCALLCONV AppSubsNotifyEvHandler(
                                     IN  RvSipSubsHandle        hSubs,
                                     IN  RvSipAppSubsHandle     hAppSubs,
                                     IN  RvSipNotifyHandle      hNotification,
                                     IN  RvSipAppNotifyHandle   hAppNotification,
                                     IN  RvSipSubsNotifyStatus  eNotifyStatus,
                                     IN  RvSipSubsNotifyReason  eNotifyReason,
                                     IN  RvSipMsgHandle         hNotifyMsg)
{
    RvStatus rv;
    static RvBool bRegTerminated = RV_FALSE; /* Keeps the state of the registration */ 

    switch (eNotifyStatus)
    {
        case RVSIP_SUBS_NOTIFY_STATUS_REQUEST_RCVD:
        /*----------------------
          Accept notify request.
          ----------------------*/
            OSPrintf("\n\n\nNotify received - Accepting the notify request\n\n");
            rv = RvSipNotifyAccept(hNotification);
            if(rv != RV_OK)
            {
                AppExitOnError("Failed to accept the notify\n");
            }
		/* ------------------------------------------------------------------
		   Process the received NOTIFY to react to the status of registration
		   ------------------------------------------------------------------ */
			AppProcessNotify(hNotifyMsg,&bRegTerminated);
            break;
        case RVSIP_SUBS_NOTIFY_STATUS_FINAL_RESPONSE_SENT:
            if (bRegTerminated == RV_TRUE)
            {
                OSPrintf("\n\n\nNotify sent - Registration is terminated, close security connections\n\n");
                /* According to paragraph 5.1.1.7 and L.3 the security association or TLS  
                  connection should become terminated without de-REGISTER due to the network 
                  de-registaration */ 
                rv = RvSipRegClientTerminate(g_ImsUE.g_regClient); 
                if (rv != RV_OK)
                {
                    AppExitOnError("Failed to terminate Reg-Client");
                }
            }
            break; 
        default:
            break;
    }
    RV_UNUSED_ARG(hSubs);
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(hAppNotification);
    RV_UNUSED_ARG(eNotifyReason);
    RV_UNUSED_ARG(hNotifyMsg);
}


#ifdef RV_SIGCOMP_ON
/***************************************************************************
 * AppSubsSigCompMsgNotRespondedEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the SigComp message not responded
 *          event handler. Here we decide if a retransmission will take
 *          place and if so, whether the next sent message is compressed
 *
 * Return Value: RV_OK 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hSubs         - The sip stack subscription handle
 *            hAppSubs      - The application handle for this subscription.
 *            hNotify       - The notify object handle (relevant only for notify request or response)
 *            hAppNotify    - The application notify object handle (relevant only for notify request or response)
 *            hTransc       - The transaction handle.
 *            retransNo     - The number of retransmissions of the request
 *                            until now.
 *            ePrevMsgComp  - The type of the previous not responded request
 * Output:    peNextMsgComp - The type of the next request to retransmit (
 *                            RVSIP_TRANSMITTER_MSG_COMP_TYPE_UNDEFINED means that the
 *                            application wishes to stop sending requests).
 ***************************************************************************/
RvStatus RVCALLCONV AppSubsSigCompMsgNotRespondedEv(
                     IN  RvSipSubsHandle              hSubs,
                     IN  RvSipAppSubsHandle           hAppSubs,
                     IN  RvSipNotifyHandle            hNotify,
                     IN  RvSipAppNotifyHandle         hAppNotify,
                     IN  RvSipTranscHandle            hTransc,
                     IN  RvInt32                      retransNo,
                     IN  RvSipTransmitterMsgCompType  ePrevMsgComp,
                     OUT RvSipTransmitterMsgCompType *peNextMsgComp)
{
	if (retransNo < MAX_RETRANS_NO)
    {
        /* Continue re-sending SigComp message (with no bytecode) */
        *peNextMsgComp = RVSIP_TRANSMITTER_MSG_COMP_TYPE_SIGCOMP_COMPRESSED;
    }
    else
    {
        /* Return to the default retransmissions mechanism */
        *peNextMsgComp = RVSIP_TRANSMITTER_MSG_COMP_TYPE_UNCOMPRESSED;
    }
    OSPrintf("\nSigComp msg not responded (subscription: %p). retransNo=%d, prev msg=%s, next msg=%s\n",
             hSubs,
             retransNo,
             AppGetMsgCompTypeName(ePrevMsgComp),
             AppGetMsgCompTypeName(*peNextMsgComp));

    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(hNotify);
    RV_UNUSED_ARG(hAppNotify);
	RV_UNUSED_ARG(hTransc);
    
    return RV_OK;
}
#endif /* RV_SIGCOMP_ON */

/*-----------------------------------------------------------------------*/
/*                          STATIC FUNCTIONS				 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppProcessNotify
 * ------------------------------------------------------------------------
 * General: Process a received NOTIFY. Check the state of registration as 
 *          appears in the XML body. If the registration is terminated, 
 *          de-register from the server.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg          - The received NOTIFY message
 *          pbRegTerminated - Indication if the registration state is 
 *                            terminated.
 ***************************************************************************/
static void  AppProcessNotify (IN  RvSipMsgHandle         hMsg,
                               OUT RvBool                *pbRegTerminated)
{
#define XML_LENGTH     512
	RvChar    strXmlBody[XML_LENGTH];
	RvUint    len;
	RvStatus  rv;

    /* Initialize OUT parameter */ 
    *pbRegTerminated = RV_FALSE; 

	/* Retrieve the state of registration from the XML body.
	   Since parsing the XML body is out of scope from this sample
	   application, we retrieve the state by direct access assuming
	   the position of this field is constant (found at offset 
	   STATE_LOCATION) */

	if (RvSipMsgGetStringLength(hMsg, RVSIP_MSG_BODY) == 0)
	{
		return;
	}

	rv = RvSipMsgGetBody(hMsg, strXmlBody, XML_LENGTH, &len);
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to get XML body from NOTIFY message");
	}
		
	if (strstr(strXmlBody, "state=\"active\"") != NULL)
	{
		/* The user is registered at the server, it is time to make a call */
		OSPrintf("Registration state in NOTIFY message 0x%p is active\n", hMsg);
		AppClientConnectCall();
	}
	else if (strstr(strXmlBody, "state=\"terminated\"") != NULL)
	{
		/* The registration is about to terminate at the server. */
		OSPrintf("Registration state in NOTIFY message 0x%p is terminated -> terminate secured connection\n\n", hMsg);
        *pbRegTerminated = RV_TRUE;
	}
}

/***************************************************************************
 * AppGetSubsStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetSubsStateName (
                          IN  RvSipSubsState  eState)
{

    switch(eState)
    {
    case RVSIP_SUBS_STATE_IDLE:
        return "Idle";
    case RVSIP_SUBS_STATE_SUBS_SENT:
        return "Subs Sent";
    case RVSIP_SUBS_STATE_REDIRECTED:
        return "Redirected";
    case RVSIP_SUBS_STATE_UNAUTHENTICATED:
        return "Unauthenticated";
    case RVSIP_SUBS_STATE_NOTIFY_BEFORE_2XX_RCVD:
        return "Notify Before 2xx Rcvd";
    case RVSIP_SUBS_STATE_2XX_RCVD:
        return "2xx Rcvd";
    case RVSIP_SUBS_STATE_REFRESHING:
        return "Refreshing";
    case RVSIP_SUBS_STATE_REFRESH_RCVD:
        return "Refresh Rcvd";
    case RVSIP_SUBS_STATE_UNSUBSCRIBING:
        return "Unsubscribing";
    case RVSIP_SUBS_STATE_UNSUBSCRIBE_RCVD:
        return "Unsubscribe Rcvd";
    case RVSIP_SUBS_STATE_UNSUBSCRIBE_2XX_RCVD:
        return "Unsubscribe 2xx Rcvd";
    case RVSIP_SUBS_STATE_SUBS_RCVD:
        return "Subs Rcvd";
    case RVSIP_SUBS_STATE_ACTIVATED:
        return "Subs Activated";
    case RVSIP_SUBS_STATE_TERMINATING:
        return "Subs Terminating";
    case RVSIP_SUBS_STATE_PENDING:
        return "Subs Pending";
    case RVSIP_SUBS_STATE_ACTIVE:
        return "Subs Active";
    case RVSIP_SUBS_STATE_TERMINATED:
        return "Subs Terminated";
    default:
        return "Undefined";
    }
}

#endif /* #ifdef RV_SIP_SUBS_ON */
#endif /* RV_SIP_IMS_ON */
