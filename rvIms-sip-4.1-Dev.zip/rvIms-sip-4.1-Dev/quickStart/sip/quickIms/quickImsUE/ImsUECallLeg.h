/*********************************************************************************
 *                              <ImsUECallLeg.h>
 * 
 *   This file defines call-leg functionality for connecting a dialog and
 *   reacting on call-leg events. 
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifndef IMSUE_CALL_LEG_H
#define IMSUE_CALL_LEG_H

#ifdef RV_SIP_IMS_ON
#include "RvSipCallLeg.h"

/*-----------------------------------------------------------------------*/
/*                       CALL LEG CONTROL				 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppClientConnectCall
 * ------------------------------------------------------------------------
 * General: Connects a call. 
 *          The function is called when the sec-agree object informed of 
 *          state active. 
 *          The function sets the already created sec-agree object, 
 *          and its related ip-sec connection to the new call-leg.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   (-)
 ***************************************************************************/
void AppClientConnectCall();

/*-----------------------------------------------------------------------*/
/*                       CALL LEG CALLBACK                               */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppCallLegStateChangedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application of a call-leg state change.
 *          In this sample we just print the new state to screen.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          eState -      The new call-leg state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
void RVCALLCONV AppCallLegStateChangedEvHandler(IN  RvSipCallLegHandle            hCallLeg,
                                                IN  RvSipAppCallLegHandle         hAppCallLeg,
                                                IN  RvSipCallLegState             eState,
                                                IN  RvSipCallLegStateChangeReason eReason);

/***************************************************************************
 * AppCallLegMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppCallLegMsgReceivedEvHandler(IN  RvSipCallLegHandle            hCallLeg,
                                                   IN  RvSipAppCallLegHandle         hAppCallLeg,
                                                   IN  RvSipMsgHandle                hMsg);

/***************************************************************************
 * AppCallLegMsgToSendEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppCallLegMsgToSendEvHandler(IN  RvSipCallLegHandle            hCallLeg,
                                                 IN  RvSipAppCallLegHandle         hAppCallLeg,
                                                 IN  RvSipMsgHandle                hMsg);

/***************************************************************************
 * AppCallLegFinalDestResolvedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the dest resolved event handler.
 *          Here we add comp=sigcomp to the Via header if needed
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hCallLeg       - The SIP Stack call-leg handle.
 *            hAppCallLeg    - The application handle for this call-leg.
 *            hTransc        - The transaction handle.
 *            hAppTransc     - The application handle for this transaction.
 *                             For INVITE/BYE the hAppTransc is NULL.
 *            hMsgToSend     - The handle to the outgoing message.
 ***************************************************************************/
RvStatus RVCALLCONV AppCallLegFinalDestResolvedEvHandler(
                      IN  RvSipCallLegHandle     hCallLeg,
                      IN  RvSipAppCallLegHandle  hAppCallLeg,
                      IN  RvSipTranscHandle      hTransc,
                      IN  RvSipAppTranscHandle   hAppTransc,
                      IN  RvSipMsgHandle         hMsgToSend);

/***************************************************************************
 * AppCallLegSigCompMsgNotRespondedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the SigComp message not responded
 *          event handler. Here we decide if a retransmission will take
 *          place and if so, whether the next sent message is compressed
 *
 * Return Value: RV_OK.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hCallLeg       - The sip stack call-leg handle
 *            hAppCallLeg    - The application handle for this call-leg.
 *            hTransc        - The transaction handle.
 *            hAppTransc     - The transaction application handle.
 *            retransNo      - The number of retransmissions of the request
 *                             until now.
 *            ePrevMsgComp   - The type of the previous not responded request
 * Output:    peNextMsgComp  - The type of the next request to retransmit (
 *                             RVSIP_TRANSC_MSG_TYPE_UNDEFINED means that the
 *                             application wishes to stop sending requests).
 ***************************************************************************/
RvStatus RVCALLCONV AppCallLegSigCompMsgNotRespondedEvHandler(
						             IN  RvSipCallLegHandle           hCallLeg,
								     IN  RvSipAppCallLegHandle        hAppCallLeg,
								     IN  RvSipTranscHandle            hTransc,
							         IN  RvSipAppTranscHandle         hAppTransc,
								     IN  RvInt32                      retransNo,
							     	 IN  RvSipTransmitterMsgCompType  ePrevMsgComp,
								     OUT RvSipTransmitterMsgCompType *peNextMsgComp);


#endif /* #ifdef RV_SIP_IMS_ON */

#endif /* #ifndef IMSUE_CALL_LEG_H */
