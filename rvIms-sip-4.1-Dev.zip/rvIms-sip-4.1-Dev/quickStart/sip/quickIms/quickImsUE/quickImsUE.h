/*********************************************************************************
 *                              <quickImsUE.h>
 *   Type definitions for the quick Ims UE sample application
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Ofra Wachsman                  June 2006
 *    Tamarb Barzuza                 Sep 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "RV_SIP_DEF.h"

#ifndef QUICK_IMSUE_H
#define QUICK_IMSUE_H

#ifdef RV_SIP_IMS_ON
#include "RvSipCallLeg.h"
#include "RvSipSecAgree.h"
#include "RvSipSubscription.h"
#include "RvSipRegClient.h"
#include "IMSCOM_AKA_Auc.h"
#include "ImsUEServiceRoute.h"
#include "ImsComDefs.h"

/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

/* ImsUE
   ----------------------------------------------------------------
   A global struct containing the entire Ims UE application data 
   ---------------------------------------------------------------- */
typedef struct
{
	/* g_clientSecAgree holds the handle of security-agreement */
	RvSipSecAgreeHandle			g_clientSecAgree;

	/* g_regClient holds the handle of register-client */
	RvSipRegClientHandle		g_regClient;

	/* g_subs holds the handle of subscription */
	RvSipSubsHandle				g_subs;

	/* g_subs holds the handle of call-leg */
	RvSipCallLegHandle			g_CallLeg;

	/* g_clientExpires holds the value of the last Expires header sent to the 
	   server within a REGISTER request */
	RvInt32						g_clientExpires;

	/* g_portS hold the local protected port-s */
	RvInt32						g_portS;

	/* g_ClientAkaAV holds the Authentication-Vector information of the client.
	   It is generated when receiving the first 401 response, using the nonce
	   value of the authentication header */
	AKA_Av						g_ClientAkaAV;

	/* g_RouteListData hold the routeList data,the pool & page uses
	   to build the routeList,and a counter that keeps the updated number of
	   route headers in the list*/
	RouteListData				g_RouteListData;
	
	/* g_eCompType holds the indication to compress with sigcomp */
	RvSipCompType               g_eCompType;

} ImsUE;

#endif /* #ifdef RV_SIP_IMS_ON */

#endif /* #ifndef QUICK_IMSUE_H */

