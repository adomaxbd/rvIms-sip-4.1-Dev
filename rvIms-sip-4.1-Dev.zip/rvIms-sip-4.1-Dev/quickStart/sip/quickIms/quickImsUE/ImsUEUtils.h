/*********************************************************************************
 *                              <ImsUEUtils.h>
 * 
 *   This file defines general utility functions for the Ims UE application
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifndef IMSUE_UTILS_H
#define IMSUE_UTILS_H

#ifdef RV_SIP_IMS_ON

/*-----------------------------------------------------------------------*/
/*                       UTILITY FUNCTIONS                               */
/*-----------------------------------------------------------------------*/
/***************************************************************************
 * AppMsgToSendUpdateContact
 * ------------------------------------------------------------------------
 * General: Sets the local port-s to the Contact header of the message
 *          Set comp=sigcomp when needed
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 ***************************************************************************/
void AppMsgToSendUpdateContact(IN  RvSipMsgHandle      hMsg);

/***************************************************************************
 * AppMsgToSendAddCompParam
 * ------------------------------------------------------------------------
 * General: Sets sigcomp-id to the Via header of the message
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 *
 ***************************************************************************/
void AppMsgToSendAddCompParam(IN  RvSipMsgHandle      hMsg);

/***************************************************************************
 * AppMsgToSendUpdateReqUri
 * ------------------------------------------------------------------------
 * General: Sets comp=sigcomp to the Request-Uri of the message
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 *         eCompType - The compression type
 ***************************************************************************/
void AppMsgToSendUpdateReqUri(IN  RvSipMsgHandle      hMsg,
							  IN  RvSipCompType       eCompType);

/***************************************************************************
 * AppMsgToSendSetPAccessNetworkInfo
 * ------------------------------------------------------------------------
 * General: Sets the P-Access-Network-Info header into the given message
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 ***************************************************************************/
void AppMsgToSendSetPAccessNetworkInfo(IN  RvSipMsgHandle      hMsg);

/***************************************************************************
 * AppMsgToSendSetPPreferredIdentity
 * ------------------------------------------------------------------------
 * General: Sets the P-Preferred-Identity header into the given message
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 ***************************************************************************/
void AppMsgToSendSetPPreferredIdentity(IN  RvSipMsgHandle      hMsg);

/***************************************************************************
 * AppMsgToSendSetAcceptRegInfo
 * ------------------------------------------------------------------------
 * General: Sets the Accept: application/reginfo+xml header into the given message
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg      - The message being sent 
 ***************************************************************************/
void AppMsgToSendSetAcceptRegInfo(IN  RvSipMsgHandle      hMsg);

#endif /* #ifdef RV_SIP_IMS_ON */

#endif /* #ifndef IMSUE_UTILS_H */

