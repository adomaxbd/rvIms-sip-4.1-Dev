/*********************************************************************************
 *                              <ImsUEServiceRoute.c>
 *
 *   This file implements utility functions for Service-Route processing.
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifdef RV_SIP_IMS_ON
#include "ImsUEServiceRoute.h"
#include "ImsComUtils.h"
#include "quickImsUE.h"

/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/

/* Handle to the global Ims UE object */
extern ImsUE                 g_ImsUE;

/*Handle to the application memory pool */
extern HRPOOL                g_appPool;

/*Handle to the message manager */
extern RvSipMsgMgrHandle     g_hMsgMgr;

/*-----------------------------------------------------------------------*/
/*                        STATIC FUNCTIONS PROTOTYPES                    */
/*-----------------------------------------------------------------------*/
static void  AppCopyOneServiceRouteHeader(IN  RvSipMsgHandle               hMsg,
                                          IN  RvSipRouteHopHeaderHandle    hSrcServiceRouteHeaderHandle,
                                          IN  RvInt                        IndexOfSRouteHeaderInMessage);

static void AppInsertOneRouteHeaderIntoMessage(IN  RvSipMsgHandle       hOutBoundMsg,
                                               IN  RvInt                index);

/*-----------------------------------------------------------------------*/
/*                         SERVICE ROUTE FUNCTIONS						 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppResetRouteHopHeaderList
 * ------------------------------------------------------------------------
 * General: Reset the global structure of service route information
 * Return Value:
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  (-)
 ***************************************************************************/
void AppResetRouteHopHeaderList(void)
{
    RvInt index = 0;

    for(index=0; index<MAX_NUM_OF_ROUTE_HEADER_LIST; index++)
    {
        g_ImsUE.g_RouteListData.routeHopHeaderList[index] = NULL;
    }
    g_ImsUE.g_RouteListData.numOfRouteHopHeadersInList = 0;
	if(g_ImsUE.g_RouteListData.serviceRouteListPage != NULL_PAGE)
	{
		RPOOL_FreePage(g_appPool,g_ImsUE.g_RouteListData.serviceRouteListPage);
	}
	g_ImsUE.g_RouteListData.serviceRouteListPage = NULL;

}

/***************************************************************************
 * AppRouteHopListInsertToMsg
 * ------------------------------------------------------------------------
 * General: Inserts the list of route hop headers into the given message
 * Return Value: A boolean indication to whether Route header were actually
 *               inserted to the message
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  (-)
 ***************************************************************************/
RvBool AppRouteHopListInsertToMsg(IN RvSipMsgHandle  hOutboundMsg)
{
	/*----------------------------------------------------------------
      Insert the route header list (if exist) to the outbound message
    ------------------------------------------------------------------*/
    if (g_ImsUE.g_RouteListData.numOfRouteHopHeadersInList >0)
    {
        RvInt32 i = 0;
		for (i=0; i<g_ImsUE.g_RouteListData.numOfRouteHopHeadersInList;i++)
        {
            AppInsertOneRouteHeaderIntoMessage(hOutboundMsg,i);
        }
        return RV_TRUE;
    }

	return RV_FALSE;
}

/***************************************************************************
 * AppServiceRouteListStore
 * ------------------------------------------------------------------------
 * General: Copy the service-route list received in the given message
 *          to the global list of route hop header. The stored list will be
 *          preloaded to outgoing request messages
 *
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg - The message from which to copy the Service-Route list
 *
 ***************************************************************************/
void  AppServiceRouteListStore(IN  RvSipMsgHandle   hMsg)
{

    RvSipHeaderListElemHandle headerListElem   = NULL;
    RvSipRouteHopHeaderHandle hRouteHopHeader  = NULL;
    RvSipRouteHopHeaderType   routeHopType;
    RvInt                     indexOfSRouteHeaderInList = 0;

    /*delete all the global route list handles when a new message arrives from registrar*/
    AppResetRouteHopHeaderList();

    /*retrieve all the service-route headers from the message.NULL is returned
    if there is no list*/
    hRouteHopHeader = (RvSipRouteHopHeaderHandle)RvSipMsgGetHeaderByTypeExt(
                                          hMsg,
                                          RVSIP_HEADERTYPE_ROUTE_HOP,
                                          RVSIP_FIRST_HEADER,
                                          RVSIP_MSG_HEADERS_OPTION_ALL,/*get also badSyntax headers*/
                                          &headerListElem);

    /*save the service-route header list in a global var :g_RouteListData.routeHopHeaderList*/
    while((hRouteHopHeader != NULL) &&
          (indexOfSRouteHeaderInList < MAX_NUM_OF_ROUTE_HEADER_LIST))
    {

        routeHopType = RvSipRouteHopHeaderGetHeaderType(hRouteHopHeader);
        /*if the route hop is a record route, add its address spec to the
        route address list*/
        if(routeHopType == RVSIP_ROUTE_HOP_SERVICE_ROUTE_HEADER)
        {
			AppCopyOneServiceRouteHeader(hMsg,hRouteHopHeader,indexOfSRouteHeaderInList);
			indexOfSRouteHeaderInList ++;
		}

		hRouteHopHeader = (RvSipRouteHopHeaderHandle)RvSipMsgGetHeaderByType(
											hMsg,
											RVSIP_HEADERTYPE_ROUTE_HOP,
											RVSIP_NEXT_HEADER,
											&headerListElem);

    }
}

/*-----------------------------------------------------------------------*/
/*                             STATIC FUNCTIONS                          */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppInsertOneRouteHeaderIntoMessage
 * ------------------------------------------------------------------------
 * General: copy the Route header from the global page to the given message.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hOutboundMsg  - The message to insert a Route-Hop header to
 *         index         - The index of the header to be inserted
 ***************************************************************************/
static void AppInsertOneRouteHeaderIntoMessage(IN  RvSipMsgHandle   hOutBoundMsg,
                                               IN  RvInt            index)

{
    RvSipRouteHopHeaderHandle    hNewRouteHeaderHandle = NULL;
    RvStatus                     rv;

    rv = RvSipRouteHopHeaderConstructInMsg(hOutBoundMsg,
                                           RV_FALSE, /*pushHead*/
                                           &hNewRouteHeaderHandle);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to construct Route-Hop header in message");
    }

    rv = RvSipRouteHopHeaderCopy(hNewRouteHeaderHandle,
								 g_ImsUE.g_RouteListData.routeHopHeaderList[index]);
	if(rv != RV_OK)
    {
        AppExitOnError("Failed to copy Route-Hop header");
    }
}

/***************************************************************************
 * AppCopyOneServiceRouteHeader
 * ------------------------------------------------------------------------
 * General: copy only ONE service-route header handle at a time into the global app
 *          variable: g_RouteListData.routeHopHeaderList.save it as ROUTE header type.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg                         - The handle of the received msg.
 *          hSrcServiceRouteHeaderHandle - The handle to the service-route header in the received message.
 *          IndexOfSRouteHeaderInMessage - The num of the current service-route header in the.
 *                                         service-route list in the message.
 *
 ***************************************************************************/
static void AppCopyOneServiceRouteHeader(
                                  IN  RvSipMsgHandle            hMsg,
                                  IN  RvSipRouteHopHeaderHandle hSrcServiceRouteHeaderHandle,
                                  IN  RvInt                     IndexOfSRouteHeaderInMessage)
{
    RvStatus                  rv                    = RV_OK;
    RvSipRouteHopHeaderHandle hDestRouteHeaderHandle = NULL;

    if(g_ImsUE.g_RouteListData.serviceRouteListPage == NULL) /*first call*/
	{
		rv = RPOOL_GetPage(g_appPool,0,&(g_ImsUE.g_RouteListData.serviceRouteListPage));
		if(rv != RV_OK)
		{
			AppExitOnError("Failed to allocate new memory page");
		}
	}
	/* construct one service-route header on the application page in order to copy the
       service-route header list from the ,received message*/
    rv = RvSipRouteHopHeaderConstruct(g_hMsgMgr,
                                      g_appPool,
                                      g_ImsUE.g_RouteListData.serviceRouteListPage,
                                      &hDestRouteHeaderHandle);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to construct new Route-Hop header");
    }

    /*copy the original service-route header to the application page*/
    rv = RvSipRouteHopHeaderCopy(hDestRouteHeaderHandle,hSrcServiceRouteHeaderHandle);
    if (rv != RV_OK)
    {
        AppExitOnError("Failed to copy Route-Hop header");
    }

    /*change the list from SERVICE_ROUTE type to ROUTE type*/
    rv = RvSipRouteHopHeaderSetHeaderType(hDestRouteHeaderHandle,RVSIP_ROUTE_HOP_ROUTE_HEADER);
	if (rv != RV_OK)
    {
        AppExitOnError("Failed to set Route-Hop header type");
    }

    g_ImsUE.g_RouteListData.routeHopHeaderList[IndexOfSRouteHeaderInMessage] = hDestRouteHeaderHandle;
    g_ImsUE.g_RouteListData.numOfRouteHopHeadersInList++;

    RV_UNUSED_ARG(hMsg)
}


#endif /* RV_SIP_IMS_ON */
