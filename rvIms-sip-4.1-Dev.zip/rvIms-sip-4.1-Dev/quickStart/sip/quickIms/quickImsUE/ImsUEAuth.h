/*********************************************************************************
 *                              <ImsUEAuth.h>
 * 
 *   This file defines functionality for performing Aka authentication to the server,
 *   and reacting to authentication events.  
 *
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Tamarb Barzuza                 Dec 2007
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/

#include "RV_SIP_DEF.h"

#ifndef IMSUE_AUTH_H
#define IMSUE_AUTH_H

#ifdef RV_SIP_IMS_ON
#include "RvSipAuthenticator.h"

/*-----------------------------------------------------------------------*/
/*                          AUTH CONTROL								 */
/*-----------------------------------------------------------------------*/

/***************************************************************************************
* AppClientGenerateClientAV
* -------------------------------------------------------------------------------------
* General:  This function generates the Authentication Vector for the client side.
*           1. Get the Authentication header from the given authentication object.
*           2. Extract the RAND and AUTN values from the nonce value in the Authentication
*              header.
*           3. Generate the Authentication Vector, using RAND and the shared secret USER_PW.
* Return Value: RvStatus.
* -------------------------------------------------------------------------------------
* Arguments:
* Input:  hAuthObj - Handle to the authentication object.
**************************************************************************************/
RvStatus AppClientGenerateClientAV( IN RvSipAuthObjHandle hAuthObj);

/***************************************************************************
 * AppClientGetRandAndAutnFromHeader
 * ------------------------------------------------------------------------
 * General:  Gets the nonce value from authentication header.
 *           Decode it base 64, and break it into AUTN and RAND strings.
 * Return Value: RV_OK - if successful. error code o/w
 * ------------------------------------------------------------------------
 * Arguments:
 * input   : hAuthHeader - The Authentication header.
 * output  : pRAND - pointer to the RAND buffer.
 *           pAUTN - pointer to the AUTN buffer.
 ***************************************************************************/
RvStatus AppClientGetRandAndAutnFromHeader(IN  RvSipAuthenticationHeaderHandle   hAuthHeader,
                                           OUT RvUint8							*pRAND,
                                           OUT RvUint8							*pAUTN);

/*-----------------------------------------------------------------------*/
/*                          AUTH CALLBACKS								 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * AppClientAuthenticationGetSharedSecretEv
 * ------------------------------------------------------------------------
 * General: This callback function is called when the stack builds the 
 *          Authorization header, using the received WWW-Authenticate header.
 *          The client should supply the user-name and password.
 *          If the server required AKA authentication, the client should 
 *          supply the RES parameter from the Authentication-Vector, and not 
 *          its plain password.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hAuthenticator    - Handle to the authenticator object.
 *          hAppAuthenticator - Handle to the application authenticator handle.
 *          hObject           - handle to the Object, that is served
 *                              by the Authenticator (e.g. CallLeg, RegClient)
 *          peObjectType      - pointer to the variable, that stores type of
 *                              the Object. Use following code to get the type:
 *                              RvSipCommonStackObjectType eObjType = *peObjectType;
 *          pRpoolRealm       - the realm string in RPool_ptr format
 * Output:  pRpoolUserName    - the user-name string in RPool_ptr format
 *          pRpoolPassword    - the password string in RPool_ptr format
 ***************************************************************************/
void RVCALLCONV AppAuthenticationMD5Ev(IN  RvSipAuthenticatorHandle       hAuthenticator,
                                       IN  RvSipAppAuthenticatorHandle    hAppAuthenticator,
                                       IN  RPOOL_Ptr                     *pRpoolMD5Input,
                                       IN  RvUint32                       length,
                                       OUT RPOOL_Ptr                     *pRpoolMD5Output);

/***************************************************************************
 * AppAuthenticationMD5Ev
 * ------------------------------------------------------------------------
 * General:  Notifies that there is a need to use the MD5 algorithm.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pRpoolMD5Input  - Rpool pointer to the MD5 input
 *          length          - the length of the string inside the page
 * Output:  pRpoolMD5Output - Rpool pointer to the MD5 output
 ***************************************************************************/
void RVCALLCONV AppClientAuthenticationGetSharedSecretEv(
                                   IN  RvSipAuthenticatorHandle       hAuthenticator,
                                   IN  RvSipAppAuthenticatorHandle    hAppAuthenticator,
                                   IN  void*                          hObject,
                                   IN  void*                          peObjectType,
                                   IN  RPOOL_Ptr                     *pRpoolRealm,
                                   INOUT RPOOL_Ptr                   *pRpoolUserName,
                                   OUT RPOOL_Ptr                     *pRpoolPassword);

#endif /* #ifdef RV_SIP_IMS_ON */

#endif /* #ifndef IMSUE_AUTH_H */

