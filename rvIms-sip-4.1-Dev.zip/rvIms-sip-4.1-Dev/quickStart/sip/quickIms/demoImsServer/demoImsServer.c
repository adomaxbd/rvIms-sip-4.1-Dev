

/*********************************************************************************
 *                              <quickImsUE.c>
 *   This file gives an example of the UE side in a Gm Interface flow.
 *   The UE can be configured to support either 3GPP TS-24.229, TISPAN ES-283.003
 *   or PKT-SP-24.229 by setting the relevant value to GM_INTERFACE_STANDARD in ImsComDefs.h.
 *   The 3GPP/TISPAN/PACKET_CABLE modes will affect message headers, message compression,
 *   security mechanisms, etc.
 *   The Gm Interface sample application includes:
 *   Initiate the RADVISION SIP stack.
 *   Register application callbacks.
 *   Implement application callbacks.
 *
 *   Here is further description of each of the Gm interface modes:
 *
 *   I. 3GPP/TISPAN Interface
 *   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *   In this mode the UE initiates a security-agreement with ipsec-3gpp security
 *   using REGISTER request.
 *   UE and server maintain lifetime timer for the ipsec-3gpp security-associations
 *   according to the status of the registration flow.
 *   UE subscribes to registration-state info via reg event, using the security agreement and
 *   the established ipsec-3gpp connection.
 *   UE connects a call to UE2 via the server using the security agreement and the established
 *   ipsec-3gpp connection. Disconnect the call from UE2 side is simulated at the server.
 *   Upon server invoking notification on the upcoming termination of the UE registration,
 *   the UE de-registers to the server.
 *   Once the de-registration is complete the UE and server terminate the security-associations
 *   and the subscription objects.
 *
 *   The Gm Interface sample message flow is the following:
 *   =============================================================================
 *     UE                                                     SERVER
 *      |                                                       |
 *   create sec-agree                                           |
 *   with local security ip-sec                                 |
 *      |    ------------- REGISTER ----------------->          |
 *      |                                               create sec-agree with local
 *      |                                               security ip-sec.
 *      |                                               create AV (AKA Authentication Vector)
 *      |                                               for the user.
 *      |                                               fill the sec-agree with AV params.
 *      |                                               set the sec-agree to the transaction.
 *      |    <------------ 401 -----------------------          |
 *      |                                               sec-agree is active.
 *      |                                               security-association status is temporary
 *      |                                               start lifetime timer to reg-await-auth interval
 *   create AV using AKA                                        |
 *   params from Authentication                                 |
 *   header.                                                    |
 *   fill the sec-agree with AV params.                         |
 *   sec agree is active                                        |
 *   security-association status is temporary                   |
 *   start lifetime timer to reg-await-auth interval            |
 *	    |														|
 *      |    ------------- REGISTER ----------------->          |
 *      |    <------------ 200 -----------------------          |
 *      |                                               security-association status is established
 *      |                                               start  lifetime timer to registration interval
 *      |                                               plus 30 seconds
 *      |                                               Start timer for the registration period minus 5 seconds
 *      |														|
 *      |                                                       |
 *   security-association status is established                 |
 *   start lifetime timer to registration interval              |
 *   plus 30 seconds                                            |
 *      |                                                       |
 *      |                                                       |
 *   subscribe to reg event                                     |
 *   using the active sec-agree                                 |
 *      |    ------------- SUBSCRIBE ----------------->         |
 *      |    <------------ 200 -----------------------          |
 *      |                                               Notify the UE on the registration-state
 *      |                                               which is currently active
 *      |                                               The registration-state info is indicated
 *      |                                               in the XML body of the NOTIFY request
 *      |                                               The NOTIFY is sent using the active sec-agree
 *      |    <------------ NOTIFY --------------------          |
 *      |    ------------ 200 ----------------------->          |
 *      |                                                       |
 *      |                                                       |
 *   connect a call to UE2 via the                              |
 *   server, using the active sec-agree                         |
 *      |    ------------- INVITE   ----------------->          |
 *      |                                               set the sec-agree to the
 *      |                                               new call-leg
 *      |                                               Invoke 200 response (simulating a response
 *                                                      that was originated by UE2 and forwarded by the server)
 *      |    <------------ 200 -----------------------          |
 *      |    ------------- ACK      ----------------->          |
 *      |                                               disconnect the call, using
 *      |                                               the active sec-agree (simulating a BYE request
 *                                                      that was originated by UE2 and forwarded by the server)
 *      |    <------------ BYE -----------------------          |
 *      |    ------------- 200      ----------------->          |
 *      |														|
 *      |														|
 *      |                                               Upon registration timer fires,
 *      |                                               Notify the UE on the registration-state
 *      |                                               which is currently terminated
 *      |                                               The registration-state info is indicated
 *      |                                               in the XML body of the NOTIFY request
 *      |                                               The NOTIFY is sent using the active sec-agree
 *      |    <------------ NOTIFY --------------------          |
 *      |    ------------ 200 ----------------------->          |
 *   Observe that the registration-state                        |
 *   is terminated. There's no need to de-register.             |
 *      |														|
 *   terminate sec-agree                                terminate sec-agree
 *   terminate subscription object                      terminate subscription object
 *      |                                                       |
 *   ==============================================================================
 *
 *   II. PACKET CABLE Interface
 *   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *   In this mode the UE initiates a security-agreement with TLS security
 *   using REGISTER request.
 *   UE and server maintain lifetime timer for the TLS session according to the status
 *   of the registration flow.
 *   UE subscribes to registration-state info via reg event, using the security agreement and
 *   the established TLS connection.
 *   UE connects a call to UE2 via the server using the security agreement and the established
 *   TLS connection. Disconnect the call from UE2 side is simulated at the server.
 *   Upon server invoking notification on the upcoming termination of the UE registration,
 *   the UE de-registers to the server.
 *   Once the de-registration is complete the UE and server terminate the TLS session
 *   and the subscription objects.
 *
 *   The Gm Interface sample message flow is the following:
 *   =============================================================================
 *     UE                                                     SERVER
 *      |                                                       |
 *   create sec-agree                                           |
 *   with local security TLS                                    |
 *      |    ------------- REGISTER ----------------->          |
 *      |                                               create sec-agree with local
 *      |                                               security TLS.
 *      |                                               fill the sec-agree with digest params.
 *      |                                               set the sec-agree to the transaction.
 *      |    <------------ 401 -----------------------          |
 *      |                                               sec-agree is active.
 *      |                                                       |
 *   calculate SIP digest-response                              |
 *   parameters as indicated in                                 |
 *   RFC 2617 from Authentication                               |
 *   header.                                                    |
 *   fill the sec-agree with these params.                      |
 *   sec agree is active                                        |
 *	    |														|
 *      |    ------------- REGISTER ----------------->          |
 *      |    <------------ 200 -----------------------          |
 *      |                                                       |
 *      |<-------------TLS connection is established----------->|
 *      |														|
 *      |                                                       |
 *      |                                                       |
 *      |                                                       |
 *   subscribe to reg event                                     |
 *   using the active sec-agree                                 |
 *      |    ------------- SUBSCRIBE ----------------->         |
 *      |    <------------ 200 -----------------------          |
 *      |                                               Notify the UE on the registration-state
 *      |                                               which is currently active
 *      |                                               The registration-state info is indicated
 *      |                                               in the XML body of the NOTIFY request
 *      |                                               The NOTIFY is sent using the active sec-agree
 *      |    <------------ NOTIFY --------------------          |
 *      |    ------------ 200 ----------------------->          |
 *      |                                                       |
 *      |                                                       |
 *   connect a call to UE2 via the                              |
 *   server, using the active sec-agree                         |
 *      |    ------------- INVITE   ----------------->          |
 *      |                                               set the sec-agree to the
 *      |                                               new call-leg
 *      |                                               Invoke 200 response (simulating a response
 *                                                      that was originated by UE2 and forwarded by the server)
 *      |    <------------ 200 -----------------------          |
 *      |    ------------- ACK      ----------------->          |
 *      |                                               disconnect the call, using
 *      |                                               the active sec-agree (simulating a BYE request
 *                                                      that was originated by UE2 and forwarded by the server)
 *      |    <------------ BYE -----------------------          |
 *      |    ------------- 200      ----------------->          |
 *      |														|
 *      |														|
 *      |                                               Upon registration timer fires,
 *      |                                               Notify the UE on the registration-state
 *      |                                               which is currently terminated
 *      |                                               The registration-state info is indicated
 *      |                                               in the XML body of the NOTIFY request
 *      |                                               The NOTIFY is sent using the active sec-agree
 *      |    <------------ NOTIFY --------------------          |
 *      |    ------------ 200 ----------------------->          |
 *   Observe that the registration-state                        |
 *   is terminated. There's no need to de-register.             |
 *      |														|
 *   terminate sec-agree                                terminate sec-agree
 *   terminate subscription object                      terminate subscription object
 *      |                                                       |
 *   ==============================================================================
 *
 *   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *   You can run this application as is: An instance of quickImsUE (UE) versus an instance of
 *   demoImsServer (Server).
 *   Notice that the application exits on errors.
 * ------------------------------------------------------------------
 * Note:
 *       A. In order to run this sample you must compile the stack with IMS:
 *       you must set RV_SIP_IMS_ON in RvSipUserConfig.h
 *
 *       B. When configured in 3GPP/TISPAN modes this sample is
 *       designed to demonstrate ipsec usage, therefore
 *       it is recommended to run this sample on an OS that supports ipsec.
 *       To use ipsec you must compile with RV_IMS_IPSEC_ENABLED set to RV_YES
 *       in rvuserconfig.h. However, if you wish to run this sample without
 *       ipsec support, you must compile with RV_IMS_IPSEC_ENABLED set to RV_NO
 *       in rvuserconfig.h and set RV_SIP_IPSEC_NEG_ONLY in RvSipUserConfig.h.
 *       Before running the sample you must also set the correct addresses in
 *       file ImsComDefs.h
 *
 *       C. When configured in PACKET CABLE mode this sample is designed
 *          to demonstrate TLS+Digest usage. Therefore it is recommended
 *          to:
 *          I. Compile this sample (as well as the stack beneath)
 *          with RV_TLS_ON (or RV_CFLAG_TLS). For more infomration about
 *          this compilation flag, please apply the SIP Stack Prog Guide.
 *          II. Link this sample with ssl libraries. For instance, in case
 *          of compiling this sample over windows, you'll have to add
 *          the libraries libeay32.lib and ssleay32.lib to the list of
 *          linker's input libraries.
 *
 *
 *       D. When running this sample with IPv6 addresses, you should
 *          compile this sample (as well as the stack beneath) with
 *          RV_NET_IPV6 (or RV_CFLAG_IPV6). For more infomration about
 *          this compilation flag, please apply the SIP Stack Prog Guide.
 *
 *       Under windows you must first compile the stack from the rvsip.dsw
 *       workspace with the following configurations:
 *       - Win32 Debug configuration for Debug execution
 *       - Win32 Release configuration for Release execution.
 * --------------------------------------------------------------------
 *    Author                         Date
 *    ------                        ------
 *    Ofra Wachsman                  June 2006
 *    Tamarb Barzuza                 Sep  2007
 *    Dikla Dror Behr                July 2008
 *********************************************************************************/

/*-----------------------------------------------------------------------*/
/*                        INCLUDE HEADER FILES                           */
/*-----------------------------------------------------------------------*/
#include "RV_SIP_DEF.h"


#include <stdio.h>
#include <stdarg.h>
#if (RV_OS_TYPE == RV_OS_TYPE_INTEGRITY)
#include <unistd.h>
#endif

#if (RV_OS_TYPE == RV_OS_TYPE_WINCE) || (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
#include "simpleOSUtils.h"
#endif

#ifdef RV_SIP_IMS_ON
#include "RvSipStackTypes.h"
#include "RvSipStack.h"
#include "RvSipCallLegTypes.h"
#include "RvSipCallLeg.h"
#include "RvSipTransaction.h"
#include "RvSipTransactionTypes.h"
#include "RvSipSecAgreeTypes.h"
#include "RvSipSecAgree.h"
#include "RvSipMid.h"
#include "RvSipSecurityHeader.h"
#include "RvSipSecurity.h"
#include "RvSipAuthenticationHeader.h"
#include "RvSipAuthorizationHeader.h"
#include "RvSipSecurity.h"
#include "RvSipViaHeader.h"
#include "RvSipExpiresHeader.h"
#include "RvSipCSeqHeader.h"
#include "RvSipSubscription.h"
#include "RvSipSubscriptionStateHeader.h"
#include "RvSipOtherHeader.h"
#include "RvSipRouteHopHeader.h"
#include "RvSipPUriHeader.h"

#include "ImsComDefs.h"
#include "ImsComTlsUtils.h"
#include "ImsCom_md5c.h"
#include "ImsComSigComp.h"

#if (RV_OS_TYPE == RV_OS_TYPE_VXWORKS)
#include <vxWorks.h>
#include <taskLib.h>
#include <time.h>
#if (RV_IMS_IPSEC_ENABLED==RV_YES) && (RV_OS_VERSION == RV_OS_VXWORKS_3_1)
#include <wrn/ipsec/ipsec.h>
#endif
#endif

#if (RV_OS_TYPE == RV_OS_TYPE_WINCE) || (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
#include "simpleOSUtils.h"
#endif

/*internal usage only*/
#ifdef USE_INTERNAL_SAMPLE_DEFS
#include "samplesInternalDefs.h"
#endif
/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/

#define REG_AWAIT_AUTH       240
#define SIGCOMP_PARAMETERS   ((IS_SIGCOMP_GM_INTERFACE) ? ";comp=sigcomp;sigcomp-id=ims-quick-srv-sigcomp-id" : "")
#define SRV_SIGCOMP_ID_STR   "ims-quick-srv-sigcomp-id"

/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/

/*Handle to the stack manager. This parameter is returned when calling
  RvSipStackConstruct. You should supply this handle when using the stack
  manager API functions.*/
RvSipStackHandle  g_hStackMgr    = NULL;

/* Handle to the stack transport manager. You can get this handle by calling
   RvSipStackGetTransportMgrHandle. This handle should be used when calling some
   of the connection function and TLS engine functions */
RvSipTransportMgrHandle g_hTransportMgr = NULL;

/*Handle to the security-agreement manager. This value is returned when calling
  RvSipStackGetSecAgreeMgrHandle after constructing the stack. You should
  supply this handle when using the sec-agree manager API functions.*/
static RvSipSecAgreeMgrHandle  g_hSecAgreeMgr = NULL;

/*Handle to the transaction manager. This value is returned when calling
  RvSipStackGetTransactionMgrHandle after constructing the stack. You should
  supply this handle when using the transaction manager API functions.*/
static RvSipTranscMgrHandle  g_hTranscMgr = NULL;

/*Handle to the call-leg manager. You can get this handle by calling
  RvSipStackGetCallLegMgrHandle. You should supply this handle when
  using the call-leg manager API functions.*/
static RvSipCallLegMgrHandle g_hCallLegMgr  = NULL;

/*Handle to the subscription manager. You can get this handle by calling
  RvSipStackGetSubsMgrHandle. You should supply this handle when
  using the subscription manager API functions.*/
static RvSipSubsMgrHandle g_hSubsMgr  = NULL;

/*Handle to the Authenticator manager. This value is returned when calling
  RvSipStackGetAuthenticationHandle. You should supply this handle when using the
  Authenticator manager API functions.*/
static RvSipAuthenticatorHandle g_hAuthenticatorMgr  = NULL;

/*Handle to the Mid manager. This Mid manager is constructed when calling
  RvSipMidConstruct() and is used for timer services. You should supply this
  handle when using the Mid manager API functions.*/
static RvSipMidMgrHandle g_hMidMgr  = NULL;

/*Handle to the log-module. You can get this handle by calling
  RvSipStackGetLogHandle. You need this value in order to construct the application
  memory pool.*/
RV_LOG_Handle         g_hLog         = NULL;

/*Handle to the application memory pool. The application should construct its own
  memory using rpool API. The pool is needed for encoding messages or message
  parts. (See AppPrintMessage() )*/
HRPOOL                g_appPool      = NULL;

/* =======================================
     The authentication users database.
     Used for authenticating clients.
   ======================================= */
/* Each user record contains the following parameters:
   user name and password - the password is the shared secret of the user.
   sqn - the sequence number that was used to generate the authentication-vector.
   av  - the authentication-vector.
   nonce - the nonce value to use when responding with 401 for this user.
           the nonce value is the concatenation of RAND and AUTN, encoded base 64. */
typedef struct
{
    RvChar username[USER_NAME_LEN];
    RvChar password[USER_KEY_LEN];  /* user private key */
    RvUint8 sqn[AKA_SQN_LEN];       /* SQN generated for this user */
    AKA_Av av;                      /* Authentication vector of this user */
    RvChar nonce[45];               /* 44 for the encoded base 64 string + 1 for null termination.*/

}AuthUserRecord;

/* g_serverAuthUser is the actual users table.
   In this sample we assume that we have only one user in the table. */
static AuthUserRecord g_serverAuthUser;

/* g_strGmAddrScehme is a pointer to a constant string which can be "sip" or "sips"
   This string should be initialized through application initialization */
static RvChar *g_strGmAddrScheme = NULL;

/*The following variable saves the port to be used,
  that was given as input to the program */
static RvUint16 g_serverPort    = SERVER_PORT;
static RvUint16 g_serverPortTls = SERVER_TLS_PORT;
static RvUint16 g_clientPortTls = CLIENT_TLS_PORT;

/*The following variables save the command line parameters
  that were given as input to the program */
static RvChar g_pServerIP[MAX_STRING_SIZE] = SERVER_IP;

#endif /*#ifdef RV_SIP_IMS_ON*/

/*-----------------------------------------------------------------------*/
/*                        STATIC FUNCTIONS PROTOTYPES                    */
/*-----------------------------------------------------------------------*/
static int mainFunc(int argc, char *argv[]);

#ifdef RV_SIP_IMS_ON

#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
static void mainFuncForSymbian(void);
#endif

static void AppStackInitialize(void);

static void AppSetCallBackFunctions(void);

static void AppGenerateSQN(OUT RvUint8* sqn);

static void AppServerGenerateNonceValue(IN AKA_Av* av,
                                        OUT RvChar* nonce);

static void RVCALLCONV AppServerInitSecAgree(IN  RvSipSecAgreeHandle hSecAgree);

static RvStatus RVCALLCONV AppServerCreateSecAgreeObject(
                                       IN  RvSipSecAgreeMgrHandle	hSecAgreeMgr,
                                       OUT RvSipSecAgreeHandle*	    phNewSecAgree);

static int AppAnalyzeCommandLineArguments(int argc, char *argv[]);

/*---- E V E N T    H A N D L E R S   I M P L M E N T A T I O N ----------*/
/* SEC AGREE EVENTS */
static void RVCALLCONV AppServerSecAgreeStateChangedEvHandler(
                                        IN  RvSipSecAgreeHandle       hSecAgree,
                                        IN  RvSipAppSecAgreeHandle     hAppSecAgree,
                                        IN  RvSipSecAgreeState         eState,
                                        IN  RvSipSecAgreeReason        eReason);

static void RVCALLCONV AppServerSecAgreeStatusEvHandler(
                                   IN  RvSipSecAgreeHandle        hSecAgree,
                                   IN  RvSipAppSecAgreeHandle     hAppSecAgree,
                                   IN  RvSipSecAgreeStatus        eStatus,
								   IN  void*					  pInfo);

static RvStatus RVCALLCONV AppServerSecAgreeMgrSecAgreeRequiredEvHandler(
                                       IN  RvSipSecAgreeMgrHandle	hSecAgreeMgr,
                                       IN  RvSipSecAgreeOwner*	    pOwner,
                                       IN  RvSipMsgHandle           hMsg,
                                       IN  RvSipSecAgreeHandle	    hCurrSecAgree,
                                       IN  RvSipSecAgreeRole	    eRole,
                                       OUT RvSipSecAgreeHandle*	    phNewSecAgree);

static void RVCALLCONV AppSecAgreeGetPorts(IN  RvSipSecAgreeHandle       hSecAgree,
										   OUT RvInt32                  *pLocalPortS,
										   OUT RvInt32                  *pRemotePortS);


static RvSipSubsHandle RVCALLCONV AppSecAgreeGetSubsOwner(
											IN  RvSipSecAgreeHandle   hSecAgree);
/* TRANSACTION EVENTS */
static void RVCALLCONV AppServerTranscCreatedEvHandler(
                           IN  RvSipTranscHandle            hTransc,
                           IN  void                         *context,
                           OUT RvSipTranscOwnerHandle       *phAppTransc,
                           OUT RvBool                      *b_handleTransc);

static void RVCALLCONV AppServerTranscStateChangedEvHandler(
                                   IN  RvSipTranscHandle                 hTransc,
                                   IN  RvSipTranscOwnerHandle            hAppTransc,
                                   IN  RvSipTransactionState             eState,
                                   IN  RvSipTransactionStateChangeReason eReason);

static RvStatus RVCALLCONV AppServerTranscMsgReceivedEvHandler(
                                    IN  RvSipTranscHandle            hTransc,
                                    IN  RvSipTranscOwnerHandle       hAppTransc,
                                    IN  RvSipMsgHandle               hMsg);

static RvStatus RVCALLCONV AppServerTranscMsgToSendEvHandler(
                                    IN  RvSipTranscHandle            hTransc,
                                    IN  RvSipTranscOwnerHandle       hAppTransc,
                                    IN  RvSipMsgHandle               hMsg);

/* CALL-LEG EVENTS */
static void RVCALLCONV AppCallLegCreatedEvHandler(
                                                  IN  RvSipCallLegHandle            hCallLeg,
                                                  OUT RvSipAppCallLegHandle         *phAppCallLeg);

static void RVCALLCONV AppCallLegStateChangedEvHandler(
                                                       IN  RvSipCallLegHandle            hCallLeg,
                                                       IN  RvSipAppCallLegHandle         hAppCallLeg,
                                                       IN  RvSipCallLegState             eState,
                                                       IN  RvSipCallLegStateChangeReason eReason);

static RvStatus RVCALLCONV AppCallLegMsgReceivedEvHandler(
                                                          IN  RvSipCallLegHandle            hCallLeg,
                                                          IN  RvSipAppCallLegHandle         hAppCallLeg,
                                                          IN  RvSipMsgHandle                hMsg);

static RvStatus RVCALLCONV AppCallLegMsgToSendEvHandler(
                                                        IN  RvSipCallLegHandle            hCallLeg,
                                                        IN  RvSipAppCallLegHandle         hAppCallLeg,
                                                        IN  RvSipMsgHandle                hMsg);

/* AUTHENTICATOR EVENTS */
static void RVCALLCONV AppAuthenticationMD5Ev(IN  RvSipAuthenticatorHandle       hAuthenticator,
                                              IN  RvSipAppAuthenticatorHandle    hAppAuthenticator,
                                              IN  RPOOL_Ptr                     *pRpoolMD5Input,
                                              IN  RvUint32                     length,
                                              OUT RPOOL_Ptr                     *pRpoolMD5Output);

static void RVCALLCONV AppServerTranscAuthCredentialsFoundEv(
                      IN    RvSipTranscHandle               hTransc,
                      IN    RvSipTranscOwnerHandle          hAppTransc,
                      IN    RvSipAuthorizationHeaderHandle  hAuthorization,
                      IN    RvBool                         bCredentialsSupported);

static void RVCALLCONV AppServerTranscAuthCompletedEv(IN    RvSipTranscHandle        hTransc,
                                                      IN    RvSipTranscOwnerHandle   hAppTransc,
                                                      IN    RvBool                   bAuthSucceed);

/* SUBSCRIPTION EVENTS */
static void RVCALLCONV AppSubsCreatedEvHandler(
                                               IN  RvSipSubsHandle    hSubs,
                                               IN  RvSipCallLegHandle hCallLeg,
                                               IN  RvSipAppCallLegHandle hAppCallLeg,
                                               OUT RvSipAppSubsHandle *phAppSubs);

static void RVCALLCONV AppSubsStateChangedEvHandler(
                                    IN  RvSipSubsHandle            hSubs,
                                    IN  RvSipAppSubsHandle         hAppSubs,
                                    IN  RvSipSubsState             eState,
                                    IN  RvSipSubsStateChangeReason eReason);

static RvStatus RVCALLCONV AppSubsMsgToSendEvHandler(
                                          IN    RvSipSubsHandle      hSubs,
                                          IN    RvSipAppSubsHandle   hAppSubs,
                                          IN    RvSipNotifyHandle    hNotify,
                                          IN    RvSipAppNotifyHandle hAppNotify,
                                          IN    RvSipMsgHandle       hMsg);

static RvStatus RVCALLCONV AppSubsMsgReceivedEvHandler(
                                        IN  RvSipSubsHandle      hSubs,
                                        IN  RvSipAppSubsHandle   hAppSubs,
                                        IN  RvSipNotifyHandle    hNotify,
                                        IN  RvSipAppNotifyHandle hAppNotify,
                                        IN  RvSipMsgHandle       hMsg);

static void AppNotifySetBody(IN  RvSipSecAgreeHandle hSecAgree,
						     IN  RvSipMsgHandle      hMsg,
						     IN  RvBool              bIsActive);

static void AppNotifySend(IN  RvSipSubsHandle           hSubs,
						  IN  RvSipSecAgreeHandle       hSecAgree,
                          IN  RvSipSubscriptionSubstate eSubstate,
						  IN  RvBool					bIsRegActive);

static const RvChar*  AppGetSubsStateName (
                          IN  RvSipSubsState  eState);

/* TIMER EVENTS */
void RVCALLCONV AppServerTimerExpEv(IN void* context);

/*--------------------U T I L I T Y   F U N C T I O N S -------------------*/

static void AppServerInitiateServerAppInfo(void);

static void AppPrintMessage(IN RvSipMsgHandle hMsg);

static const RvChar*  AppGetCallLegStateName (
                                              IN  RvSipCallLegState  eState);

static const RvChar*  AppGetDirectionName(
                                          IN RvSipCallLegDirection eDirection);

static const RvChar*  AppGetTranscStateName (
                          IN  RvSipTransactionState  eState);

static const RvChar*  AppGetSecAgreeStateName(IN  RvSipSecAgreeState  eState);

static void AppServerInsertImsHeaders(IN RvSipMsgHandle       hMsg,
									  IN RvSipSecAgreeHandle  hSecAgree);

static void AppServerGetSecAgreeObject(IN  RvSipSecAgreeMgrHandle	hSecAgreeMgr,
                                       IN  RvSipSecAgreeOwner*	    pOwner,
                                       IN  RvSipMsgHandle           hMsg,
                                       OUT RvSipSecAgreeHandle*	    phNewSecAgree);

static void AppServerGetIPsecSecAgreeObject(
                                IN  RvSipSecAgreeMgrHandle	     hSecAgreeMgr,
                                IN  RvSipSecAgreeMsgRcvdInfo    *pMsgRcvdInfo,
                                OUT RvSipSecAgreeHandle*	     phNewSecAgree);

static void AppServerGetTlsSecAgreeObject(
                          IN  RvSipSecAgreeMgrHandle	  hSecAgreeMgr,
                          IN  RvSipMsgHandle              hMsg,
                          IN  RvSipSecAgreeMsgRcvdInfo   *pMsgRcvdInfo,
                          OUT RvSipSecAgreeHandle*	      phNewSecAgree);

static void AppServerVerifyIMPIMatching(IN RvSipMsgHandle hMsg);

static RvStatus RVCALLCONV AppCallLegFinalDestResolvedEvHandler(
                                       IN  RvSipCallLegHandle     hCallLeg,
                                       IN  RvSipAppCallLegHandle  hAppCallLeg,
                                       IN  RvSipTranscHandle      hTransc,
                                       IN  RvSipAppTranscHandle   hAppTransc,
                                       IN  RvSipMsgHandle         hMsgToSend);

static RvStatus RVCALLCONV AppSubsFinalDestResolvedEvHandler(
                                       IN  RvSipSubsHandle           hSubs,
                                       IN  RvSipAppSubsHandle        hAppSubs,
                                       IN  RvSipNotifyHandle         hNotify,
                                       IN  RvSipAppNotifyHandle      hAppNotify,
                                       IN  RvSipTranscHandle         hTransc,
                                       IN  RvSipMsgHandle            hMsgToSend);

static void AppMsgToSendAddSigCompIdParam(IN  RvSipMsgHandle  hMsg);

static void AppSetExpires(IN  RvSipTranscHandle  hTransc,
						  OUT RvUintPtr         *pExpires);

static void AppSetContact(IN  RvSipTranscHandle  hTransc);

static void AppExitOnError(RvChar* str);

#endif /*#ifdef RV_SIP_IMS_ON*/

static int  OSPrintf(IN const char *format,... );


/*-----------------------------------------------------------------------*/
/*                      I M P L E M E N T A T I O N                      */
/*-----------------------------------------------------------------------*/
/***************************************************************************
 * main
 * ------------------------------------------------------------------------
 * General: In the main function we perform the following:
 *          1. Initialize the RADVISION SIP stack.
 *          2. Set the callback functions in the call-leg manager.
 *          3. Initiate the server authentication users database
 *          4. Activates the RvSipStackProcessEvents() function that
 *             command the stack to process the event queue.
 ***************************************************************************/
static int mainFunc(int argc, char *argv[])
{
#ifdef RV_SIP_IMS_ON
    int rc;

    OSPrintf("Executing demoImsServer\n");

    /* Analyze command line arguments */
    rc = AppAnalyzeCommandLineArguments(argc, argv);
    if (rc != 0)
        return rc;

    /*1. Initialize the RADVISION SIP stack.*/
    AppStackInitialize();
    /*2. Initializing the TLS engines only in non-ipsec mode */
    if (!IS_IPSEC_GM_INTERFACE)
    {
        AppInitTlsSecurity();
    }
    /*3. Set the callback functions in the call-leg manager.*/
    AppSetCallBackFunctions();
    /*4. Initiate the server authentication users information */
    AppServerInitiateServerAppInfo();
    /*5. Activates the RvSipStackProcessEvents() function that
         commands the stack to process the event queue.*/
    RvSipStackProcessEvents();
    return 0;
#else /* #ifdef RV_SIP_IMS_ON */
	OSPrintf("\nThis Sample requires that flag RV_SIP_IMS_ON defined.\nAborting.\n");
	return 1;
#endif /* #ifdef RV_SIP_IMS_ON */
}
#if (RV_OS_TYPE == RV_OS_TYPE_NUCLEUS) /* embedded start function */
int mainForEmbedded()
{
    mainFunc(0, NULL);
    return 0;
}
#elif (RV_OS_TYPE == RV_OS_TYPE_VXWORKS) /* vxworks start function */
void startVx()
{
#if (RV_IMS_IPSEC_ENABLED==RV_YES)
    ipsecAttachIf(SERVER_IP);
#endif
    taskSpawn("mainFunc", 100, 0, 0x30000, (FUNCPTR)mainFunc, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
}
#elif (RV_OS_TYPE == RV_OS_TYPE_PSOS) /* pSOS start function */
/* pSOS Shell entry point */
#include <psos.h>
#include <prepc.h>
void mainForEmbedded(int argc, char **argv, char **env, void *exit_param, const char *console_dev)
{
    mainFunc(argc, argv);
    psh_exit(exit_param);
}
#elif (RV_OS_TYPE == RV_OS_TYPE_WINCE) /* WinCE start function */
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPWSTR lpCmdLine,
                   int nCmdShow)
{
    OSSetMainFuncCB(mainFunc);
    OSWinCEMain(hInstance,hPrevInstance,lpCmdLine,nCmdShow);
}
#else /* not embedded start function */
int main(int argc, char *argv[])
{
#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
    mainFuncForSymbian();
    return 0;
#else
    return mainFunc(argc, argv);
#endif
}
#endif

#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
/***************************************************************************
 * mainFuncForSymbian
 * ------------------------------------------------------------------------
 * General: Called from main(). Creates heap and initiates thread. Starts
 *          the SIP sample.
 ***************************************************************************/
static void mainFuncForSymbian(void)
{
   /* Symbian stack and heap should be enlarged so we are */
    /* Construction SIP on new thread                      */
    SymbianCreateThread((void *)mainFunc);
    while(1)
    {
      SymbianSleep(1000);
    }
}
#endif

#ifdef RV_SIP_IMS_ON
/***************************************************************************
 * AppStackInitialize
 * ------------------------------------------------------------------------
 * General: Initializing the stack and allocating the application memory pool.
 *          When initializing we first set the configuration struct to the
 *          default values and then change some of the configuration parameters.
 *          We then use RvSipStackConstruct to initialize the stack.
 ***************************************************************************/
static void AppStackInitialize(void)
{
    RvStatus		rv;
    RvSipStackCfg	stackCfg;
	RvSipMidCfg		midCfg;

    /* Define TLS variables */
    RvChar         *tlsAddr;
    RvUint16        tlsPort;


    RvSipMidInit();

    /*Initialize the configuration structure with default values*/
    RvSipStackInitCfg(sizeof(stackCfg),&stackCfg);

    /*change some of the default values*/
    stackCfg.maxCallLegs = 6;
    stackCfg.maxTransactions = 16;
    stackCfg.tcpEnabled = RV_TRUE;
    stackCfg.maxSecAgrees = 2;
    stackCfg.maxSecurityObjects = 2;
	stackCfg.maxSubscriptions = 2;
    stackCfg.enableServerAuth = RV_TRUE;

    /*setting the sec-agree extension in the supported list*/
    stackCfg.supportedExtensionList = "sec-agree";

    stackCfg.localUdpPort = g_serverPort;
    stackCfg.localTcpPort = g_serverPort;
    tlsPort               = g_serverPortTls;

    RvSipMidInit();  /* In order to enable memory allocation */
    if (IS_IPV6_GM_INTERFACE(g_pServerIP))
    {
        sprintf(stackCfg.localUdpAddress,"%s%%%d",g_pServerIP,SERVER_IPV6_SCOPE);
        sprintf(stackCfg.localTcpAddress,"%s%%%d",g_pServerIP,SERVER_IPV6_SCOPE);
        tlsAddr = RvSipMidMemAlloc(sizeof(g_pServerIP)+sizeof(SERVER_IPV6_SCOPE)+2 /* 1 for the % and 1 for the '\0' */);
        sprintf(tlsAddr,"%s%%%d",g_pServerIP,SERVER_IPV6_SCOPE);
    }
    else
    {
        strcpy(stackCfg.localUdpAddress, g_pServerIP);
        strcpy(stackCfg.localTcpAddress,g_pServerIP);
        tlsAddr = RvSipMidMemAlloc(sizeof(g_pServerIP)+1 /* 1 the '\0' */);
        strcpy(tlsAddr,g_pServerIP);
    }

    if (!(IS_IPSEC_GM_INTERFACE))
    {
        /* Set resources specific to Packet Cable requirements (non ipsec mode)*/
        stackCfg.numOfTlsAddresses = 1;
        stackCfg.localTlsAddresses = &tlsAddr;
        stackCfg.localTlsPorts     = &tlsPort;
        stackCfg.numOfTlsEngines = 2;
    }

#if (RV_OS_TYPE == RV_OS_TYPE_NUCLEUS) || (RV_OS_TYPE == RV_OS_TYPE_VXWORKS) || \
    (RV_OS_TYPE == RV_OS_TYPE_PSOS) || (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
    /* Disable most of log */
    stackCfg.defaultLogFilters = RVSIP_LOG_ERROR_FILTER|RVSIP_LOG_EXCEP_FILTER;
#endif

    /*Call the stack initialization function*/
    rv = RvSipStackConstruct(sizeof(stackCfg),&stackCfg,&g_hStackMgr);
    if(rv != RV_OK)
    {
        AppExitOnError("Application failed to construct the stack\n");
    }

    /* Free the allocated memory, required for the stack construction */
    RvSipMidMemFree(tlsAddr);

    /*getting handles for the internal modules*/
    RvSipStackGetTransportMgrHandle(g_hStackMgr,&g_hTransportMgr);
    RvSipStackGetSecAgreeMgrHandle(g_hStackMgr, &g_hSecAgreeMgr);
    RvSipStackGetTransactionMgrHandle(g_hStackMgr,&g_hTranscMgr);
    RvSipStackGetCallLegMgrHandle(g_hStackMgr,&g_hCallLegMgr);
	RvSipStackGetSubsMgrHandle(g_hStackMgr, &g_hSubsMgr);
    RvSipStackGetAuthenticatorHandle(g_hStackMgr, &g_hAuthenticatorMgr);
    RvSipStackGetLogHandle(g_hStackMgr,&g_hLog);

    OSPrintf("\nThe RADVISION SIP stack was constructed successfully. Version - %s\n",
                RvSipStackGetVersion());

    /*Construct a pool of memory for the application*/
    g_appPool = RPOOL_Construct(1024,10,g_hLog,RV_FALSE,"ApplicationPool");

#ifdef RV_SIGCOMP_ON
	if (IS_SIGCOMP_GM_INTERFACE)
	{
		/* Initialize the SigComp module if applying 3GPP TS 24.229 */
		rv = AppInitSigComp();
		if(rv != RV_OK)
		{
			AppExitOnError("Application failed to construct the SigComp module\n");
		}
	} /* IS_SIGCOMP_GM_INTERFACE */
#endif /* #ifdef RV_SIGCOMP_ON */

	/* Construct Mid layer to obtain timer services */
	memset(&midCfg, 0, sizeof(RvSipMidCfg));
	midCfg.maxUserTimers = 3;
	midCfg.hLog			 = g_hLog;
	rv = RvSipMidConstruct(sizeof(RvSipMidCfg), &midCfg, &g_hMidMgr);
	if (RV_OK != rv)
	{
		AppExitOnError("Failed to construct Mid layer");
	}

    RvSipMidEnd();
}

/***************************************************************************
 * AppSetCallBackFunctions
 * ------------------------------------------------------------------------
 * General: Set application call back functions in the call-leg manager.
 ***************************************************************************/
static void AppSetCallBackFunctions(void)
{
    RvStatus					 rv;
    RvSipCallLegEvHandlers       appCallEvHandlers;
    RvSipTransactionEvHandlers   appTranscEvHandlers;
    RvSipSecAgreeMgrEvHandlers   appSecAgreeMgrEvHandlers;
	RvSipSecAgreeEvHandlers      appSecAgreeEvHandlers;
    RvSipAuthenticatorEvHandlers authEvHandlers;
	RvSipSubsEvHandlers          appSubsEvHandlers;

    /*Reset the appEvHandlers since not all callbacks are set by this sample*/
    memset(&appCallEvHandlers,0,sizeof(RvSipCallLegEvHandlers));
    memset(&appTranscEvHandlers,0,sizeof(RvSipTransactionEvHandlers));
    memset(&appSecAgreeMgrEvHandlers, 0, sizeof(RvSipSecAgreeMgrEvHandlers));
    memset(&authEvHandlers,0,sizeof(RvSipAuthenticatorEvHandlers));
	memset(&appSecAgreeEvHandlers,0,sizeof(RvSipSecAgreeEvHandlers));
	memset(&appSubsEvHandlers,0,sizeof(RvSipSubsEvHandlers));

    /*Set application callbacks in the structure*/
    appCallEvHandlers.pfnCallLegCreatedEvHandler    = AppCallLegCreatedEvHandler;
    appCallEvHandlers.pfnStateChangedEvHandler      = AppCallLegStateChangedEvHandler;
    appCallEvHandlers.pfnMsgReceivedEvHandler       = AppCallLegMsgReceivedEvHandler;
    appCallEvHandlers.pfnMsgToSendEvHandler         = AppCallLegMsgToSendEvHandler;
    appCallEvHandlers.pfnFinalDestResolvedEvHandler = AppCallLegFinalDestResolvedEvHandler;

    /*Set the structure in the call-leg manager*/
    rv = RvSipCallLegMgrSetEvHandlers(g_hCallLegMgr,
                                      &appCallEvHandlers,
                                      sizeof(RvSipCallLegEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks");
    }

    /*Set application callbacks in the structure*/
    appSubsEvHandlers.pfnSubsCreatedEvHandler       = AppSubsCreatedEvHandler;
    appSubsEvHandlers.pfnStateChangedEvHandler      = AppSubsStateChangedEvHandler;
    appSubsEvHandlers.pfnMsgReceivedEvHandler       = AppSubsMsgReceivedEvHandler;
    appSubsEvHandlers.pfnMsgToSendEvHandler         = AppSubsMsgToSendEvHandler;
    appSubsEvHandlers.pfnFinalDestResolvedEvHandler = AppSubsFinalDestResolvedEvHandler;

    /*Set the structure in the subscription manager*/
    rv = RvSipSubsMgrSetEvHandlers(g_hSubsMgr,
                                   &appSubsEvHandlers,
                                   sizeof(RvSipSubsEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks");
    }

    /*Set application callbacks in the structure*/
    appTranscEvHandlers.pfnEvTransactionCreated   = AppServerTranscCreatedEvHandler;
    appTranscEvHandlers.pfnEvMsgReceived          = AppServerTranscMsgReceivedEvHandler;
    appTranscEvHandlers.pfnEvMsgToSend            = AppServerTranscMsgToSendEvHandler;
    appTranscEvHandlers.pfnEvStateChanged         = AppServerTranscStateChangedEvHandler;
    appTranscEvHandlers.pfnEvAuthCompleted        = AppServerTranscAuthCompletedEv;
    appTranscEvHandlers.pfnEvAuthCredentialsFound = AppServerTranscAuthCredentialsFoundEv;

    /*Set the structure in the transaction manager*/
    rv = RvSipTransactionMgrSetEvHandlers(g_hTranscMgr,
                                        NULL,
                                        &appTranscEvHandlers,
                                        sizeof(RvSipTransactionEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks");
    }

    appSecAgreeMgrEvHandlers.pfnSecAgreeMgrSecAgreeRequiredEvHandler = AppServerSecAgreeMgrSecAgreeRequiredEvHandler;
    rv = RvSipSecAgreeMgrSetSecAgreeMgrEvHandlers(g_hSecAgreeMgr,
                                                  &appSecAgreeMgrEvHandlers,
                                                  sizeof(RvSipSecAgreeMgrEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks");
    }

	appSecAgreeEvHandlers.pfnSecAgreeStateChangedEvHandler = AppServerSecAgreeStateChangedEvHandler;
	appSecAgreeEvHandlers.pfnSecAgreeStatusEvHandler       = AppServerSecAgreeStatusEvHandler;
	rv = RvSipSecAgreeMgrSetSecAgreeEvHandlers(g_hSecAgreeMgr,
                                               &appSecAgreeEvHandlers,
                                               sizeof(RvSipSecAgreeEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks");
    }

    authEvHandlers.pfnMD5AuthenticationExHandler = AppAuthenticationMD5Ev;

    /*Set the structure in the call-leg manager*/
    rv = RvSipAuthenticatorSetEvHandlers(g_hAuthenticatorMgr,
                                         &authEvHandlers,
                                         sizeof(RvSipAuthenticatorEvHandlers));
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to set application callbacks for authentication");
    }

    /* Set TLS callbacks only in non-ipsec mode */
    if (!IS_IPSEC_GM_INTERFACE)
    {
        RvSipTransportMgrEvHandlers     TransportMgrEvHandlers;

        /*Reset the appEvHandlers since not all callbacks are set by this sample*/
        memset(&TransportMgrEvHandlers,0,sizeof(RvSipTransportMgrEvHandlers));
        TransportMgrEvHandlers.pfnEvTlsStateChanged = AppTransportConnectionTlsStateChanged;
#if (RV_OS_TYPE == RV_OS_TYPE_SYMBIAN)
        TransportMgrEvHandlers.pfnEvTlsPostConnectionAssertion   = AppTransportConnectionTlsPostConnectionAssertion;
#endif
        /*Set the structure in the transport manager*/
        rv = RvSipTransportMgrSetEvHandlers(
            g_hTransportMgr,NULL,&TransportMgrEvHandlers,sizeof(RvSipTransportMgrEvHandlers));
        if(rv != RV_OK)
        {
            AppExitOnError("Failed to set application callbacks for transport (TLS)");
        }
    }
}

/* SEC AGREE EVENTS */
/***************************************************************************
 * AppSecAgreeMgrSecAgreeRequiredEvHandler
 * ----------------------------------
 * General: Notifies the application that a security-agreement was requests by
 *          the remote party.
 *          In this function we do the following actions:
 *          1. Search for an existing security-agreement object:
 *             Find the security-agreement object that owns the security-associations
 *             on which the message is received, otherwise create a new object.
 *          2. Set the security-agreement object to its owner.
 *
 * Return Value: RV_OK (the returned status is ignored in the current stack version)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgreeMgr       - The sip stack handle to the security-agreement manager
 *         pOwner             - The sip object receiving the message that caused the
 *                              invoking of this event. If this event was invoked due to calling
 *                              RvSipSecAgreeHandleMsgRcvd(), pOwner will be NULL.
 *         hMsg               - The received message requesting for a security-agreement.
 *         pCurrSecAgree      - The current security-agreement object of this owner. This
 *                              security-agreement assumes a state that cannot handle negotiation
 *                              (INVALID, TERMINATED, etc), hence a new security-agreement object
 *                              is required. NULL if there is no security-agreement object to
 *                              this owner.
 *         eRole              - The role of the required security-agreement object (client
 *                              or server).
 * Output: ppSecAgree         - The new security-agreement object to use.
 **************************************************************************/
static RvStatus RVCALLCONV AppServerSecAgreeMgrSecAgreeRequiredEvHandler(
                                       IN  RvSipSecAgreeMgrHandle	hSecAgreeMgr,
                                       IN  RvSipSecAgreeOwner*	    pOwner,
                                       IN  RvSipMsgHandle           hMsg,
                                       IN  RvSipSecAgreeHandle	    hCurrSecAgree,
                                       IN  RvSipSecAgreeRole	    eRole,
                                       OUT RvSipSecAgreeHandle*	    phNewSecAgree)
{
    RvSipSecAgreeHandle       hSecAgree = NULL;      /* handle to the server security-agreement*/
	RvStatus                  rv        = RV_OK;

    /* This implementation is for servers only */
    if (eRole != RVSIP_SEC_AGREE_ROLE_SERVER)
    {
        return RV_OK;
    }

	/* ===================================================
    1. Get a security-agreement object to supply.
       =================================================== */
    AppServerGetSecAgreeObject(hSecAgreeMgr, pOwner, hMsg, &hSecAgree);

    /* ===================================================
    2. Set the security-agreement object to its owner.
       =================================================== */
    switch(pOwner->eOwnerType)
    {
    case RVSIP_COMMON_STACK_OBJECT_TYPE_TRANSACTION:
        rv = RvSipTransactionSetSecAgree((RvSipTranscHandle)pOwner->pOwner, hSecAgree);
        break;
    case RVSIP_COMMON_STACK_OBJECT_TYPE_CALL_LEG:
        rv = RvSipCallLegSetSecAgree((RvSipCallLegHandle)pOwner->pOwner, hSecAgree);
        break;
    case RVSIP_COMMON_STACK_OBJECT_TYPE_SUBSCRIPTION:
		{
			RvSipCallLegHandle  hCallLeg;
			rv = RvSipSubsGetDialogObj((RvSipSubsHandle)pOwner->pOwner, &hCallLeg);
			if (RV_OK == rv)
			{
				rv = RvSipCallLegSetSecAgree(hCallLeg, hSecAgree);
			}
		}
        break;
    default:
        AppExitOnError("\nUnknown object type in AppServerSecAgreeMgrSecAgreeRequiredEvHandler\n");
    }
    if (rv != RV_OK)
    {
        AppExitOnError("\nFailed to set server security-agreement to owner object");
    }

    /* Return the security-agreement handle */
    *phNewSecAgree = hSecAgree;

    RV_UNUSED_ARG(hCurrSecAgree)

    return RV_OK;
}

/***************************************************************************
 * AppServerSecAgreeStateChangedEvHandler
 * ----------------------------------
 * General: Server handling of the SecAgreeStateChangedEvHandler.
 *          In this sample code, we print the new state of the security-agreement.
 *          If the state is Invalid due to Security-Object expiration, we terminate
 *          the security-agreement
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree	- A handle to the security-agreement object.
 *         hAppSecAgree - The application handle for this security-agreement.
 *         eState		- The new security-agreement state.
 *         eReason		- The reason for the state change (if informative).
 **************************************************************************/
static void RVCALLCONV AppServerSecAgreeStateChangedEvHandler(
                                                        IN  RvSipSecAgreeHandle       hSecAgree,
                                                        IN  RvSipAppSecAgreeHandle     hAppSecAgree,
                                                        IN  RvSipSecAgreeState         eState,
                                                        IN  RvSipSecAgreeReason        eReason)
{
    RvSipSecAgreeRole eRole;
	RvBool            bPrinted = RV_FALSE;
	RvStatus          rv;

    RvSipSecAgreeGetRole(hSecAgree, &eRole);

	switch (eState)
	{
	case RVSIP_SEC_AGREE_STATE_INVALID:
		if (RVSIP_SEC_AGREE_REASON_SECURITY_OBJ_EXPIRED == eReason)
		{
			/* ----------------------------------------------------------
		       The security-agreement is invalidated due to connection
		       closing at the client. Terminate the security-agreement.
		       ---------------------------------------------------------- */
			OSPrintf("\nServer sec-agree %p - State changed to Invalid due to Client closing the ipsec connection -> Terminate the security-agreement\n\n",
					 hSecAgree);
			bPrinted = RV_TRUE;
			rv = RvSipSecAgreeTerminate(hSecAgree);
			if (RV_OK != rv)
			{
				AppExitOnError("\nFailed to terminate security-agreement");
			}
		}
		break;
	case RVSIP_SEC_AGREE_STATE_TERMINATED:
		{
			/* The server shall treat the subscription for registration-info as terminated once the user
			   is de-registered and the security-association is deleted.
			   The security-agreement changing state to terminated indicates the deletion of security-associations.
			   At this point, the user already de-registered from the server.
			   We terminate the subscription object */
			RvSipSubsHandle hSubs;

			hSubs = AppSecAgreeGetSubsOwner(hSecAgree);
			if (hSubs != NULL)
			{
				rv = RvSipSubsTerminate(hSubs);
				if (RV_OK != rv)
				{
					AppExitOnError("\nFailed to terminate subscription object");
				}
			}
		}
	default:
		break;
	}

	if (bPrinted == RV_FALSE)
	{
		/*print the new state on screen*/
		OSPrintf("\nServer sec-agree %p - State changed to %s\n\n",
		         hSecAgree,AppGetSecAgreeStateName(eState));
	}

	RV_UNUSED_ARG(hAppSecAgree)
}

/***************************************************************************
 * AppServerSecAgreeStatusEvHandler
 * ----------------------------------
 * General: Notifies the application of security-agreement statuses.
 *          Here we set the lifetime timer according to the security-association
 *          status
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree	- A handle to the security-agreement object.
 *         hAppSecAgree - The application handle for this security-agreement.
 *         eStatus      - The reported status of the security-agreement.
 *         pInfo        - Auxiliary information. Not in use.
 **************************************************************************/
static void RVCALLCONV AppServerSecAgreeStatusEvHandler(
                                   IN  RvSipSecAgreeHandle        hSecAgree,
                                   IN  RvSipAppSecAgreeHandle     hAppSecAgree,
                                   IN  RvSipSecAgreeStatus        eStatus,
								   IN  void*					  pInfo)
{
	RvStatus		   rv;
	RvUint32           expires;

	switch (eStatus)
	{
	case RVSIP_SEC_AGREE_STATUS_IPSEC_TEMPORARY_ASSOCIATION:
		OSPrintf("\nServer sec-agree %p - Security Association status is Temporary\n\n", hSecAgree);
		/* ===================================================
		   Start lifetime timer to reg-await-auth interval
		   =================================================== */
		OSPrintf("Server sec-agree %p - Starting lifetime timer to interval %d\n\n", hSecAgree, REG_AWAIT_AUTH);
		rv = RvSipSecAgreeStartIpsecLifetimeTimer(hSecAgree, REG_AWAIT_AUTH);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to start lifetime timer");
		}
		break;
	case RVSIP_SEC_AGREE_STATUS_IPSEC_ESTABLISHED_ASSOCIATION:
		OSPrintf("\nServer sec-agree %p - Security Association status is Established\n\n", hSecAgree);
		/* =============================================================
		   Start lifetime timer to registration interval plus 30 seconds
		   1. Get the expires value the application stored in the
		      security-agreement
		   2. Start lifetime timer at the sec-agree to the registration
		      interval plus 30
		   ============================================================= */
		/* The expiration value is stored in the application handle of the sec-agree */
		rv = RvSipSecAgreeGetAppHandle(hSecAgree, (RvSipAppSecAgreeHandle*)&expires);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to get expiration value stored in sec-agree");
		}
		if (expires != 0)
		{
			/* Start lifetime timer to the expiration value plus 30 seconds */
			OSPrintf("Server sec-agree %p - Starting lifetime timer to interval %d\n\n", hSecAgree, expires+30);
			rv = RvSipSecAgreeStartIpsecLifetimeTimer(hSecAgree, expires+30);
			if (RV_OK != rv)
			{
				AppExitOnError("\nFailed to start lifetime timer");
			}
		}
		break;
	case RVSIP_SEC_AGREE_STATUS_IPSEC_LIFETIME_EXPIRED:
		/* Handle lifetime expiration. This is out of scope of this sample application. */
		break;
	default:
		break;
	}

	RV_UNUSED_ARG(hAppSecAgree)
	RV_UNUSED_ARG(pInfo)
}


/* TRANSACTION EVENTS */
/***************************************************************************
 * AppTranscCreatedEvHandler
 * ------------------------------------------------------------------------
 * General:  Notifies that a new transaction was created.
 *           This application does not exchange handles with the transaction.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc - The new sip stack transaction handle
 *          context - The application context given in the
 *                    RvSipTransactionMgrSetEvHandlers function. (In this
 *                    example it is null but applications can use this
 *                    parameters as reference to their database.
 * Output:  phAppTransc - The application handle for this call-leg.
 *          b_handleTransc - Indicates whether the application wishes to handle
 *                           this transaction. I False the transaction will
 *                           be a stand alone transaction.
 ***************************************************************************/
static void RVCALLCONV AppServerTranscCreatedEvHandler(
                           IN  RvSipTranscHandle            hTransc,
                           IN  void                         *context,
                           OUT RvSipTranscOwnerHandle       *phAppTransc,
                           OUT RvBool                      *b_handleTransc)
{
	/* Set the owner of the transaction to NULL */
	*phAppTransc = NULL;
	/*the application wishes to handle the transaction*/
    *b_handleTransc = RV_TRUE;
    RV_UNUSED_ARG(hTransc)
    RV_UNUSED_ARG(context)
}

/***************************************************************************
 * AppTranscStateChangedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application of a transaction state changed.
 *          If the new state is GENERAL_REQUEST_RCVD and the method is REGISTER,
 *          authenticate the request with RvSipTransactionAuthBegin().
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc -     The sip stack transaction handle
 *          hAppTransc - The application handle for this transaction
 *          eState -      The new transaction state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
static void RVCALLCONV AppServerTranscStateChangedEvHandler(
                                   IN  RvSipTranscHandle                 hTransc,
                                   IN  RvSipTranscOwnerHandle            hAppTransc,
                                   IN  RvSipTransactionState             eState,
                                   IN  RvSipTransactionStateChangeReason eReason)
{
	RvStatus                  rv;

    /*print the new state on screen*/
    OSPrintf("\nTransc %p - State changed to %s\n\n", hTransc,AppGetTranscStateName(eState));

    switch(eState)
    {
    case RVSIP_TRANSC_STATE_SERVER_GEN_REQUEST_RCVD:
        {
            RvChar methodStr[20] = {0};

            RvSipTransactionGetMethodStr(hTransc,20,methodStr);

            if(strcmp(methodStr,"REGISTER")==0)
            {
				/* Authenticate the REGISTER request */
                OSPrintf("\nBegin authentication process \n");

                rv = RvSipTransactionAuthBegin(hTransc);
                if(rv != RV_OK)
                {
                    AppExitOnError("\nFailed to begin to the authentication");
                }
            }
        }
        break;
    default:
        break;
    }
    RV_UNUSED_ARG(hAppTransc);
    RV_UNUSED_ARG(eReason);
}

/***************************************************************************
 * AppTranscMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc -    The sip stack transaction handle
 *          hAppTransc - The application handle for this transaction.
 *          hMsg -        Handle to the incoming message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppServerTranscMsgReceivedEvHandler(
                                    IN  RvSipTranscHandle            hTransc,
                                    IN  RvSipTranscOwnerHandle       hAppTransc,
                                    IN  RvSipMsgHandle               hMsg)
{
    OSPrintf("\n<-- Message Received (transaction %p)\n",hTransc);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppTransc);
    return RV_OK;
}

/***************************************************************************
 * RvSipTranscMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc -    The sip stack transaction handle
 *          hAppTransc - The application handle for this transaction.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppServerTranscMsgToSendEvHandler(
                                    IN  RvSipTranscHandle            hTransc,
                                    IN  RvSipTranscOwnerHandle       hAppTransc,
                                    IN  RvSipMsgHandle               hMsg)
{
	RvSipSecAgreeHandle  hSecAgree;
	RvStatus             rv;

    OSPrintf("--> Message Sent (Transc %p)\n",hTransc);

	rv = RvSipTransactionGetSecAgree(hTransc, &hSecAgree);
	if (RV_OK != rv || hSecAgree == NULL)
	{
		AppExitOnError("\nFailed to get security-agreement from transaction");
	}

	/* Insert Ims headers to message */
	AppServerInsertImsHeaders(hMsg, hSecAgree);

    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppTransc);
    return RV_OK;
}

/*-------------------- T I M E R   C A L L B A C K S -------------------*/
/************************************************************************
 * AppServerTimerExpEv
 * General: An implementation of timer expiration. This is the timer indicating
 *          the expiration of client registration. We send an appropriate
 *          NOTIFY to the client
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   context - The security-agreement of the user whose registration
 *                    expires
 ************************************************************************/
void RVCALLCONV AppServerTimerExpEv(IN void* context)
{
	RvSipSecAgreeHandle  hSecAgree = (RvSipSecAgreeHandle)context;
	RvSipSubsHandle      hSubs     = NULL;

	/* ========================================================
	   Handle client registration expiration
	   1. Find the subscription for the registration-info event
	   2. Send NOTIFY with XML body indicating the expiration
	      of the registration
	   ======================================================== */

	/* Find subscription object */
	hSubs = AppSecAgreeGetSubsOwner(hSecAgree);
	if (hSubs == NULL)
	{
		AppExitOnError("\nFailed to get subscription from security-agreement");
	}

	/* Prepare for sending a NOTIFY request with subscription-state active and
	   registration-state terminated*/
	AppNotifySend(hSubs, hSecAgree, RVSIP_SUBSCRIPTION_SUBSTATE_ACTIVE, RV_FALSE);
}


/*-------------------- S U B S C R I P T I O N  F U N C T I O N S -------------------*/
/***************************************************************************
 * AppSubsCreatedEvHandler
 * ------------------------------------------------------------------------
 * General:  Notifies that a new subscription was created.
 *           This application does not exchange handles with the subscription.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs - The new sip stack subscription handle
 * Output:  phAppSubs - The application handle for this subscription.
 ***************************************************************************/
static void RVCALLCONV AppSubsCreatedEvHandler(
                                               IN  RvSipSubsHandle        hSubs,
                                               IN  RvSipCallLegHandle     hCallLeg,
                                               IN  RvSipAppCallLegHandle  hAppCallLeg,
                                               OUT RvSipAppSubsHandle    *phAppSubs)
{
	RvSipCallLegHandle			hDialog;
	RvStatus					rv;

    OSPrintf("\nNotifier subscription %p was created\n\n",hSubs);

	/* The application handle for the dialog object of the subscription is the
	   subscription itself. The subscription will be retrieved from the dialog when
	   the owner subscription of the security-agreement is required */
	rv = RvSipSubsGetDialogObj(hSubs, &hDialog);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to get dialog object from subscription");
	}

	rv = RvSipCallLegSetAppHandle(hDialog, (RvSipAppCallLegHandle)hSubs);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to set application handle to hidden call-leg");
	}
	/* The application handle to a subscription is set to NULL*/
    *phAppSubs = NULL;
    RV_UNUSED_ARG(hCallLeg);
    RV_UNUSED_ARG(hAppCallLeg);
}

/***************************************************************************
 * AppSubsMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppSubsMsgReceivedEvHandler(
                                        IN  RvSipSubsHandle      hSubs,
                                        IN  RvSipAppSubsHandle   hAppSubs,
                                        IN  RvSipNotifyHandle    hNotify,
                                        IN  RvSipAppNotifyHandle hAppNotify,
                                        IN  RvSipMsgHandle       hMsg)
{
    OSPrintf("\n<-- Message Received (subscription %p)\n",hSubs);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(hAppNotify);
    RV_UNUSED_ARG(hNotify);
    return RV_OK;
}

/***************************************************************************
 * AppSubsMsgToSendEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppSubsMsgToSendEvHandler(
                                          IN    RvSipSubsHandle      hSubs,
                                          IN    RvSipAppSubsHandle   hAppSubs,
                                          IN    RvSipNotifyHandle    hNotify,
                                          IN    RvSipAppNotifyHandle hAppNotify,
                                          IN    RvSipMsgHandle       hMsg)
{
	RvSipCallLegHandle   hDialog;
	RvSipSecAgreeHandle  hSecAgree;
	RvStatus             rv;

	OSPrintf("--> Message Sent (subscription %p)\n",hSubs);

	rv = RvSipSubsGetDialogObj(hSubs, &hDialog);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to get dialog object from subscription");
	}

	rv = RvSipCallLegGetSecAgree(hDialog, &hSecAgree);
    if (RV_OK != rv || hSecAgree == NULL)
	{
		AppExitOnError("\nFailed to get security-agreement from subscription");
	}

	/* Insert Ims headers to message */
	AppServerInsertImsHeaders(hMsg, hSecAgree);

	AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(hAppNotify);
    RV_UNUSED_ARG(hNotify);
    return RV_OK;
}

/***************************************************************************
 * AppSubsStateChangedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application of a subscription state change.
 *          For all states indicating a new incoming requests (subs_rcvd,
 *          refresh_rcvd, ubsubscribe_rcvd) - accept the request, and send
 *          a notify request immediately.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs -       The sip stack subscription handle
 *          hAppSubs -    The application handle for this subscription.
 *          eState -      The new subscription state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
static void RVCALLCONV AppSubsStateChangedEvHandler(
                                    IN  RvSipSubsHandle            hSubs,
                                    IN  RvSipAppSubsHandle         hAppSubs,
                                    IN  RvSipSubsState             eState,
                                    IN  RvSipSubsStateChangeReason eReason)
{
    RvStatus             rv;

    /*print the new state on screen*/
    OSPrintf("\nsubscription %p - State changed to %s\n\n",
             hSubs,AppGetSubsStateName(eState));

    switch(eState)
    {
    /*-------------------------------------------------------------------
      Accept incoming subscription and send a notify (active) immediately
      -------------------------------------------------------------------*/
    case RVSIP_SUBS_STATE_SUBS_RCVD:
		{
			RvSipCallLegHandle			hCallLeg;
			RvSipSecAgreeHandle			hSecAgree;
			RvChar						helper[256];
			RvSipAddressHandle          hAddr;
            RvInt32						localPort  = UNDEFINED;
			RvInt32						remotePort = UNDEFINED;


			/* Get the dialog object of this subscription */
			rv = RvSipSubsGetDialogObj(hSubs, &hCallLeg);
			if (RV_OK != rv)
			{
				AppExitOnError("\nFailed to get dialog object from subscription");
			}

			/* Retrieve the security-agreement of this subscription from the dialog object */
			rv = RvSipCallLegGetSecAgree(hCallLeg, &hSecAgree);
			if(rv != RV_OK)
			{
				AppExitOnError("Failed to get security-agreement from call-leg\n");
			}

            if (IS_IPSEC_GM_INTERFACE)
            {
                /* Set local Contact to the subscription. The local contact is the server
                   contact with protected server port */
                AppSecAgreeGetPorts(hSecAgree, &localPort, &remotePort);
            }
            else
            {
                localPort  = g_serverPortTls;
                remotePort = g_clientPortTls;
            }

            sprintf(helper, "%s:%s:%d%s", g_strGmAddrScheme, g_pServerIP, localPort,SIGCOMP_PARAMETERS);

			rv = RvSipCallLegGetNewMsgElementHandle(hCallLeg, RVSIP_HEADERTYPE_UNDEFINED,
													RVSIP_ADDRTYPE_URL, (void**)&hAddr);
			if (RV_OK == rv)
			{
				rv = RvSipAddrParse(hAddr, helper);
				if (RV_OK == rv)
				{
					rv = RvSipCallLegSetLocalContactAddress(hCallLeg, hAddr);
				}
			}
			if (RV_OK != rv)
			{
				AppExitOnError("\nFailed to set local contact to subscription");
			}

			/* Accept the subscription */
			OSPrintf("Accepting the subscription\n\n");
			rv = RvSipSubsRespondAccept(hSubs, UNDEFINED);
			if(rv != RV_OK)
			{
				AppExitOnError("Failed to accept the subscription\n");
			}

			/* Send active notify to the subscription */
			AppNotifySend(hSubs, hSecAgree, RVSIP_SUBSCRIPTION_SUBSTATE_ACTIVE, RV_TRUE);
		}
        break;
    default:
        break;
    }
    RV_UNUSED_ARG(hAppSubs);
    RV_UNUSED_ARG(eReason);
}

/***************************************************************************
 * AppNotifySend
 * ------------------------------------------------------------------------
 * General: Creates and sends Notify requests.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hSubs		 - Handle to the subscription.
 *          hSecAgree    - Handle to the security-agreement.
 *          eSubstate	 - Value to set in subscription-state header of notify
 *                         request.
 *          bIsRegActive - RV_TRUE if the registration is active or RV_FALSE
 *                         if it is terminated
 ***************************************************************************/
static void AppNotifySend(IN  RvSipSubsHandle           hSubs,
						  IN  RvSipSecAgreeHandle       hSecAgree,
                          IN  RvSipSubscriptionSubstate eSubstate,
						  IN  RvBool					bIsRegActive)
{
    RvSipNotifyHandle					hNotify;
    RvSipMsgHandle						hMsg;
    RvSipSubscriptionStateHeaderHandle	hSubsStateHeader;
    RvStatus							rv;

    /*---------------------------
      Create a notify request.
      ---------------------------*/
    rv = RvSipSubsCreateNotify(hSubs, NULL, &hNotify);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to create notification object\n");
        return;
    }
    rv = RvSipNotifyGetOutboundMsg(hNotify, &hMsg);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to got notification outbound message\n");
        return;
    }
    /*-----------------------------------------------
      Set subscription-state header in notify message.
      -----------------------------------------------*/
    rv = RvSipSubscriptionStateHeaderConstructInMsg(hMsg, RV_TRUE, &hSubsStateHeader);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to create Subscription-State header\n");
        return;
    }
    rv = RvSipSubscriptionStateHeaderSetSubstate(hSubsStateHeader, eSubstate, NULL);

	/* ----------------------------------
	   Set XML body to the NOTIFY message
	   ---------------------------------- */
	AppNotifySetBody(hSecAgree, hMsg, bIsRegActive);

    /*---------------------------
      Send the notify request.
      ---------------------------*/
    rv = RvSipNotifySend(hNotify);
    if(rv != RV_OK)
    {
        AppExitOnError("Failed to send Notify request\n");
        return;
    }
    /* after sending the notify request, we must not use the notify message handle again */
    hMsg = NULL;
}

/***************************************************************************
 * AppGetSubsStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetSubsStateName (
                          IN  RvSipSubsState  eState)
{

    switch(eState)
    {
    case RVSIP_SUBS_STATE_IDLE:
        return "Idle";
    case RVSIP_SUBS_STATE_SUBS_SENT:
        return "Subs Sent";
    case RVSIP_SUBS_STATE_REDIRECTED:
        return "Redirected";
    case RVSIP_SUBS_STATE_UNAUTHENTICATED:
        return "Unauthenticated";
    case RVSIP_SUBS_STATE_NOTIFY_BEFORE_2XX_RCVD:
        return "Notify Before 2xx Rcvd";
    case RVSIP_SUBS_STATE_2XX_RCVD:
        return "2xx Rcvd";
    case RVSIP_SUBS_STATE_REFRESHING:
        return "Refreshing";
    case RVSIP_SUBS_STATE_REFRESH_RCVD:
        return "Refresh Rcvd";
    case RVSIP_SUBS_STATE_UNSUBSCRIBING:
        return "Unsubscribing";
    case RVSIP_SUBS_STATE_UNSUBSCRIBE_RCVD:
        return "Unsubscribe Rcvd";
    case RVSIP_SUBS_STATE_UNSUBSCRIBE_2XX_RCVD:
        return "Unsubscribe 2xx Rcvd";
    case RVSIP_SUBS_STATE_SUBS_RCVD:
        return "Subs Rcvd";
    case RVSIP_SUBS_STATE_ACTIVATED:
        return "Subs Activated";
    case RVSIP_SUBS_STATE_TERMINATING:
        return "Subs Terminating";
    case RVSIP_SUBS_STATE_PENDING:
        return "Subs Pending";
    case RVSIP_SUBS_STATE_ACTIVE:
        return "Subs Active";
    case RVSIP_SUBS_STATE_TERMINATED:
        return "Subs Terminated";
    default:
        return "Undefined";
    }
}

/***************************************************************************
 * AppNotifySetBody
 * ----------------------------------
 * General: Sets reginfo XML body to the given NOTIFY message to indicate the
 *          state of the client registration
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree - The security-agreement sending a NOTIFY
 *         hMsg      - The NOTIFY message
 *         bIsActive - RV_TRUE if the registration is active, RV_FALSE if it
 *                     is terminated
 **************************************************************************/
static void AppNotifySetBody(IN  RvSipSecAgreeHandle hSecAgree,
							 IN  RvSipMsgHandle      hMsg,
							 IN  RvBool              bIsActive)
{
	RvChar     strReginfoXml[1024];
	RvChar     strState[16];
	RvChar     strEvent[16];
	RvInt32    localPort;
	RvInt32    remotePort;
	RvStatus   rv;

	if (bIsActive == RV_TRUE)
	{
		/* Registration state active */
		strcpy(strState, "active");
		strcpy(strEvent, "registered");
	}
	else /* Terminated */
	{
		/* Registration state terminated */
		strcpy(strState, "terminated");
		strcpy(strEvent, "expired");
	}

    if (IS_IPSEC_GM_INTERFACE)
    {
        AppSecAgreeGetPorts(hSecAgree, &localPort, &remotePort);
    }
	else
    {
        localPort  = g_serverPortTls;
        remotePort = g_clientPortTls;
    }

	/* Encode version */
	sprintf(strReginfoXml, "%s\n","<?xml version=\"1.0\"?>");
	/* Encode reginfo schema information */
	sprintf(strReginfoXml+strlen(strReginfoXml), "\t%s\n","<reginfo xmlns=\"urn:ietf:params:xml:ns:reginfo\"");
	sprintf(strReginfoXml+strlen(strReginfoXml), "\t\t%s\n","xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
	sprintf(strReginfoXml+strlen(strReginfoXml), "\t\t\t%s\n","version=\"0\" state=\"full\">");
	/* Encode registration information */
	sprintf(strReginfoXml+strlen(strReginfoXml), "\t\t<registration aor=\"sip:%s@%s\" id=\"abcd\"\n", PUB_ID, g_pServerIP);
	sprintf(strReginfoXml+strlen(strReginfoXml), "\t\t\t\tstate=\"%s\">\n", strState);
	/* Encode contact information */
	sprintf(strReginfoXml+strlen(strReginfoXml), "\t\t\t<contact id=\"1234\" state=\"%s\" event=\"%s\">\n", strState, strEvent);
	if (remotePort > UNDEFINED)
	{
        sprintf(strReginfoXml+strlen(strReginfoXml), "\t\t\t\t<uri>%s:%s:%d%s</uri>\n", g_strGmAddrScheme,CLIENT_IP, remotePort,SIGCOMP_PARAMETERS);
	}
	else
	{
		sprintf(strReginfoXml+strlen(strReginfoXml), "\t\t\t\t<uri>%s:%s%s</uri>\n", g_strGmAddrScheme, CLIENT_IP,SIGCOMP_PARAMETERS);
	}
	/* Encode elements closing */
	sprintf(strReginfoXml+strlen(strReginfoXml), "\t\t\t</contact>\n\t\t</registration>\n\t</reginfo>");

	rv = RvSipMsgSetBody(hMsg, strReginfoXml);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to set body to NOTIFY message");
	}

	/* Set Content-Type: application/reginfo+xml to the message */
	rv = RvSipMsgSetContentTypeHeader(hMsg, "application/reginfo+xml");
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to set Content-Type to NOTIFY message");
	}
}

/*--------------------S E C - A G R E E   F U N C T I O N S -------------------*/
/***************************************************************************
 * AppServerCreateSecAgreeObject
 * ----------------------------------
 * General: Creates a new server sec-agree object:
 *          1. Create the sec-agree object using RvSipSecAgreeMgrCreateSecAgree()
 *          2. Set its role (server) and its Security-Server header.
 * Return Value: RvStatus
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgreeMgr - The sip stack handle to the security-agreement manager.
 * Output: ppSecAgree   - The new security-agreement object to use.
 **************************************************************************/
static RvStatus RVCALLCONV AppServerCreateSecAgreeObject(
                                       IN  RvSipSecAgreeMgrHandle	hSecAgreeMgr,
                                       OUT RvSipSecAgreeHandle*	    phNewSecAgree)
{

    RvSipSecAgreeHandle       hSecAgree = NULL;  /* handle to the server security-agreement*/
    RvSipSecurityHeaderHandle hSecurityHeader;   /* handle to the Security-Server header*/
    RvSipCommonListElemHandle hListElem;         /* handle to the Security-Server header list element*/
    RvStatus                  rv;

    /* Create a new security-agreement */
    rv = RvSipSecAgreeMgrCreateSecAgree(hSecAgreeMgr, NULL, &hSecAgree);
    if (rv != RV_OK)
    {
        AppExitOnError("\nFailed to create a new security-agreement");
    }

    /* Set the role of the security-agreement to server */
    rv = RvSipSecAgreeSetRole(hSecAgree, RVSIP_SEC_AGREE_ROLE_SERVER);
    if (rv != RV_OK)
    {
        AppExitOnError("\nFailed to set role to the security-agreement");
    }

	/* Set special standard support to the sec-agree object */
	rv = RvSipSecAgreeSetSpecialStandardFlag(hSecAgree, GM_INTERFACE_STANDARD);
	if (rv != RV_OK)
    {
        AppExitOnError("\nFailed to set special standard support to the security-agreement");
    }

    /* Allocate a new Security header in the sec-agree object */
    rv = RvSipSecAgreeGetNewMsgElementHandle(hSecAgree, RVSIP_HEADERTYPE_SECURITY, RVSIP_ADDRTYPE_UNDEFINED, (void**)&hSecurityHeader);
    if (rv != RV_OK)
    {
        AppExitOnError("\nFailed to allocate a new security header");
    }

    /* Parse Security-Server header */
    {
        RvChar *strSecurityServer = (IS_IPSEC_GM_INTERFACE) ?
                        "Security-Server: ipsec-3gpp;q=1;alg=hmac-md5-96;prot=esp;mod=trans;ealg=aes-cbc" :
                        "Security-Server: tls;q=1";
        rv = RvSipSecurityHeaderParse(hSecurityHeader, strSecurityServer);
    }

    if (rv != RV_OK)
    {
        AppExitOnError("\nFailed to parse Security-Server header");
    }

#if (defined RV_SIP_IPSEC_NEG_ONLY)
    if (IS_IPSEC_GM_INTERFACE)
    {
        /* Ipsec is not supported by the operating system, we shall be using the local
	       client ports */
	    rv = RvSipSecurityHeaderSetPortC(hSecurityHeader, g_serverPort);
	    if (rv != RV_OK)
        {
            AppExitOnError("Failed to set port-c to security header");
        }
	    rv = RvSipSecurityHeaderSetPortS(hSecurityHeader, g_serverPort);
	    if (rv != RV_OK)
        {
            AppExitOnError("Failed to set port-s to security header");
        }
    }
#endif /* RV_SIP_IPSEC_NEG_ONLY */

    /* Push Security-Server header to local security list */
    rv = RvSipSecAgreePushLocalSecurityHeader(hSecAgree, hSecurityHeader,
                                              RVSIP_FIRST_ELEMENT, NULL, &hListElem);
    if (rv != RV_OK)
    {
        AppExitOnError("\nFailed to push Security-Server header to local security list");
    }

    *phNewSecAgree = hSecAgree;

    return RV_OK;
}

/***************************************************************************
 * AppServerInitSecAgree
 * ----------------------------------
 * General: Init the sec-agree with ip-sec parameters.
 *          The function sets the keys values for ip-sec. (the keys were created
 *          while generating the Authentication Vector).
 *          The function then init the security using RvSipSecAgreeInit().
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree	- A handle to the security-agreement object.
 **************************************************************************/
static void RVCALLCONV AppServerInitSecAgree(IN  RvSipSecAgreeHandle       hSecAgree)
{
    RvStatus                 rv;

    if (IS_IPSEC_GM_INTERFACE)
    {
        RvSipSecAgreeIpsecInfo   ipsecInfo; /* structure for ipsec-3gpp extra parameters*/

        /* Reset ipsec info structure */
        memset(&ipsecInfo, 0, sizeof(RvSipSecAgreeIpsecInfo));

        /* Set IK generated in the Authentication Vector to the ipsec info structure */
        memcpy(ipsecInfo.IK, g_serverAuthUser.av.IK, 16);
        ipsecInfo.IKlen = 16*8;

        /* Set CK generated in the Authentication Vector to the ipsec info structure */
        memcpy(ipsecInfo.CK, g_serverAuthUser.av.CK, 16);
        ipsecInfo.CKlen = 16*8;

        /* Set ipsec info to the server security-agreement */
        rv = RvSipSecAgreeSetIpsecInfo (hSecAgree, &ipsecInfo, sizeof(RvSipSecAgreeIpsecInfo));
        if (rv != RV_OK)
        {
            AppExitOnError("\nFailed to set ipsec info to server security-agreement\n");
        }
    } /* IS_IPSEC_GM_INTERFACE */
#ifdef RV_SIGCOMP_ON
    if (IS_SIGCOMP_GM_INTERFACE)
    {
        /* Enable sigcomp compression for 3GPP TS 24229 and Packet Cable 2.0 */
        RvSipSecAgreeSendOptions  sendOptions;

        sendOptions.eMsgCompType = RVSIP_TRANSMITTER_MSG_COMP_TYPE_SIGCOMP_COMPRESSED;
        sendOptions.strSigcompId = SRV_SIGCOMP_ID_STR;
        rv = RvSipSecAgreeSetSendOptions(hSecAgree, &sendOptions, sizeof(RvSipSecAgreeSendOptions));
        if (RV_OK != rv)
        {
            AppExitOnError("\nFailed to set sigcomp to the send options of the security-agreement");
       	}
    }
#endif /* #ifdef RV_SIGCOMP_ON */

    /* Initiate the server security-agreement */
    rv = RvSipSecAgreeInit(hSecAgree);
    if (rv != RV_OK)
    {
        AppExitOnError("\nFailed to initiate server security-agreement\n");
    }

    OSPrintf("\nServer security-agreement was Init.\n");
}


/***************************************************************************
 * AppSecAgreeGetPorts
 * ----------------------------------
 * General: Retrieves the local portS and remote portS from the security-agreement
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree	- A handle to the security-agreement object.
 * Output: pLocalPortS  - The local portS
 *         pRemotePortS - The remote portS
 **************************************************************************/
static void RVCALLCONV AppSecAgreeGetPorts(IN  RvSipSecAgreeHandle       hSecAgree,
										   OUT RvInt32                  *pLocalPortS,
										   OUT RvInt32                  *pRemotePortS)
{
	RvSipSecurityHeaderHandle   hSecurityHeader;
	RvSipCommonListHandle       hList;
	RvSipCommonListElemHandle   hListElem;
	RvInt                       temp;
	RvStatus                    rv;

	rv = RvSipSecAgreeGetLocalSecurityHeader(hSecAgree, RVSIP_FIRST_ELEMENT, NULL, &hSecurityHeader, &hListElem);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to get local security header");
	}
	*pLocalPortS = RvSipSecurityHeaderGetPortS(hSecurityHeader);

	rv = RvSipSecAgreeGetRemoteSecurityList(hSecAgree, &hList);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to get remote security list");
	}
	rv = RvSipCommonListGetElem(hList, RVSIP_FIRST_ELEMENT, NULL, &temp, (void**)&hSecurityHeader, &hListElem);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to get remote security header");
	}
	*pRemotePortS = RvSipSecurityHeaderGetPortS(hSecurityHeader);
}


/***************************************************************************
 * AppSecAgreeGetSubsOwner
 * ----------------------------------
 * General: Retrieves the subscription owner of the security-agreement
 * Return Value: The returned subscription
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgree	- A handle to the security-agreement object.
 **************************************************************************/
static RvSipSubsHandle RVCALLCONV AppSecAgreeGetSubsOwner(
											IN  RvSipSecAgreeHandle   hSecAgree)
{
	RvSipSecAgreeOwner    pList[5];
	RvInt32               size = 5;
	RvSipCallLegHandle    hCallLeg;
	RvSipAppCallLegHandle hAppCallLeg;
	RvInt32               i;
	RvStatus              rv;

	/* The subscription for the registration-info event is retrieved from the security-agreement.
	   The application may store this subscription in the application handle of the security-agreement.
	   Here we are taking it from the security-agreement owners list for brevity */
	rv = RvSipSecAgreeGetOwnersList(hSecAgree, size, sizeof(RvSipSecAgreeOwner), pList, &size);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to get owners list from security-agreement");
	}

	for (i = 0; i < size; i++)
	{
		if (pList[i].eOwnerType == RVSIP_COMMON_STACK_OBJECT_TYPE_CALL_LEG)
		{
			hCallLeg = (RvSipCallLegHandle)pList[i].pOwner;
			rv = RvSipCallLegGetAppHandle(hCallLeg, &hAppCallLeg);
			if (RV_OK != rv)
			{
				AppExitOnError("\nFailed to get app handle from call-leg");
			}
			return (RvSipSubsHandle)hAppCallLeg;
		}
	}

	return NULL;
}


/*--------------------A U T H   F U N C T I O N S -------------------*/
/***************************************************************************
 * AppServerTranscAuthCredentialsFoundEv
 * ------------------------------------------------------------------------
 * General:  This event is called from the RvSipTranscAuthBegin() function,
 *           to give an authorization header to the application.
 *           The application has to take the realm and username parameters from
 *           the header, handle it, and continue the authentication procedure
 *           by calling to RvSipTranscAuthProceed() API.
 *
 *           If it is a supported credentials we do as follows:
 *           1. Verify that this username is in the server authentication users table.
 *           2. Handle an empty Authorization header:
 *              Theoretically we should approach the authentication center here,
 *              to get the Authentication-Vector for the specific user.
 *              In this sample we generate all Authentication-Vectors in advance,
 *              so we may just skip it.
 *           3. Proceed in authentication process with RvSipTranscAuthProceed():
 *               - Give the user's password, which is the RES parameter from the
 *                 Authentication-Vector.
 *               - Skip the given credentials, in case it is empty or not supported, or the
 *                 user is unknown.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc  - The new sip stack transaction handle.
 *          hAppTransc  - Application handle for the transaction.
 *          hAuthorization - Handle to the Authorization header holding the credentials.
 *          bCredentialsSupported - RV_TRUE if supported, RV_FALSE if not.
 ***************************************************************************/
static void RVCALLCONV AppServerTranscAuthCredentialsFoundEv(
                      IN    RvSipTranscHandle               hTransc,
                      IN    RvSipTranscOwnerHandle          hAppTransc,
                      IN    RvSipAuthorizationHeaderHandle  hAuthorization,
                      IN    RvBool                         bCredentialsSupported)
{
    RvStatus rv;
    RvChar strName[USER_NAME_LEN], strRealm[15], strNonce[50];
    RvBool toSkip = RV_FALSE;
    RvUint actualLen;

    OSPrintf("\nAuthentication credentials found \n");

    if(bCredentialsSupported == RV_FALSE)
    {
        OSPrintf("\nCredentials are not supported \n");
        toSkip = RV_TRUE;
    }
    else
    {
        /* =====================================================================
        1. Verify that this username is in the server authentication users table.
           ===================================================================== */
        rv = RvSipAuthorizationHeaderGetCredentialIdentifier(hAuthorization,
                        strRealm, 15, strName, USER_NAME_LEN, strNonce, 50,
                        (RvUint*)&actualLen, (RvUint*)&actualLen, (RvUint*)&actualLen);
        if(rv != RV_OK)
        {
            OSPrintf("\nCouldn't get credential Identifiers from authorization header \n");
        }

        if(strcmp(strName, g_serverAuthUser.username) != 0)
        {
            OSPrintf("\nUnknown username %s. continue with loop \n", strName);
            toSkip = RV_TRUE;
        }

        actualLen = RvSipAuthorizationHeaderGetStringLength(hAuthorization, RVSIP_AUTHORIZATION_RESPONSE);
        if(3 == actualLen) /* response="" */
        {
            /* =====================================
            2. Handle an empty Authorization header
               ===================================== */
            toSkip = RV_TRUE;
        }

    }
    /* ===================================
    3. Proceed in authentication process
    ====================================== */
    if(toSkip == RV_FALSE)
    {
        if (IS_IPSEC_GM_INTERFACE)
        {
            rv = RvSipTransactionAuthProceed(hTransc,RVSIP_TRANSC_AUTH_ACTION_USE_PASSWORD,
                    hAuthorization, (RvChar*)g_serverAuthUser.av.XRES);
        }
        else
        {
            rv = RvSipTransactionAuthProceed(hTransc,RVSIP_TRANSC_AUTH_ACTION_USE_PASSWORD,
                    hAuthorization, (RvChar*)USER1_PW);
        }
    }
    else
    {
        rv = RvSipTransactionAuthProceed(hTransc, RVSIP_TRANSC_AUTH_ACTION_SKIP, NULL, NULL);
    }

    if(rv != RV_OK)
    {
        OSPrintf("\nFailed to proceed in authentication process.\n");
    }
    RV_UNUSED_ARG(hAppTransc);
}
/***************************************************************************
* AppServerTranscAuthCompletedEv
* ------------------------------------------------------------------------
* General:  AppServerTranscAuthCompletedEv() is called when the
*           authentication procedure is completed.
*           1. If it was completed successfully, accept the request,
*           2. Else,
*              - Before first respond, we initiate the security-agreement.
*              - Respond unauthenticated to the request.
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:   hTransc     - The sip stack transaction handle
*          hAppTransc  - Application handle for the transaction
*          bAuthSucceed - RV_TRUE if we found correct authorization header,
 *                        RV_FALSE if we did not.
***************************************************************************/
static void RVCALLCONV AppServerTranscAuthCompletedEv(IN    RvSipTranscHandle        hTransc,
                                                      IN    RvSipTranscOwnerHandle   hAppTransc,
                                                      IN    RvBool                   bAuthSucceed)
{
    RvStatus			rv;
    RvChar*				nonce = NULL;
    RvSipSecAgreeHandle hSecAgree;
	RvUintPtr            expires;

	rv = RvSipTransactionGetSecAgree(hTransc, &hSecAgree);
    if(rv != RV_OK)
    {
        AppExitOnError("No sec-agree in transc \n");
    }

    if(bAuthSucceed == RV_TRUE)
    {
        OSPrintf("\nAuthentication completed successfully (transc %p)\n\n",hTransc);

		AppSetExpires(hTransc, &expires);

        /* If the client was registering it's addr, add a Contact header into the response of the REGISTER request */
        if (expires != 0)
        {
            AppSetContact(hTransc);
        }

		/* Accept the request */
        rv = RvSipTransactionRespond(hTransc, 200, NULL);
        if(rv != RV_OK)
        {
            AppExitOnError("Failed to accept the incoming request\n");
        }

		if (expires == 0 && hSecAgree != NULL)
		{
			/* The de-registeration is approved by the server. At the quickstart application
			   scenario this de-registration indicates that there are no more registrations
			   for the user at the server. The security-associations are terminated via
			   terminating the security-agreement */
			rv = RvSipSecAgreeTerminate(hSecAgree);
			if(rv != RV_OK)
			{
				AppExitOnError("Failed to accept the incoming request\n");
			}
		}
    }
    else
    {
        OSPrintf("\nAuthentication completed with failure! \n\n");

        /* ===================================================
           Before first responding, we must init the sec-agree
           =================================================== */
        AppServerInitSecAgree(hSecAgree);

        /* =======================================
           Respond unauthenticated to the request.
           ======================================= */

        if (IS_IPSEC_GM_INTERFACE)
        {
            /* get the correct nonce value for the 401 response.
           the nonce value holds the RAND and AUTN values related to this
           user's Authentication-Vector. */
            nonce = (RvChar*)g_serverAuthUser.nonce;

            rv = RvSipTransactionRespondUnauthenticatedDigest(
                            hTransc, 401, NULL, REALM,
                            DOMAIN, nonce, LOCAL_OPAQUE, RV_TRUE,
                            RVSIP_AUTH_ALGORITHM_OTHER, "AKAv1-MD5",
                            RVSIP_AUTH_QOP_AUTH_ONLY, NULL);
        }
        else
        {
            rv = RvSipTransactionRespondUnauthenticatedDigest(
                            hTransc, 401, NULL, REALM,
                            DOMAIN, nonce, LOCAL_OPAQUE, RV_TRUE,
                            RVSIP_AUTH_ALGORITHM_MD5, NULL,
                            RVSIP_AUTH_QOP_AUTH_ONLY, NULL);
        }

        if(rv != RV_OK)
        {
            AppExitOnError("RvSipTransactionRespondUnauthenticatedDigest failed\n");
        }
    }

    RV_UNUSED_ARG(hAppTransc);
}
/***************************************************************************
 * AppAuthenticationMD5Ev
 * ------------------------------------------------------------------------
 * General:  Notifies that there is a need to use the MD5 algorithm.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pRpoolMD5Input  - Rpool pointer to the MD5 input
 *          length          - the length of the string inside the page
 * Output:  pRpoolMD5Output - Rpool pointer to the MD5 output
 ***************************************************************************/
static void RVCALLCONV AppAuthenticationMD5Ev(IN  RvSipAuthenticatorHandle       hAuthenticator,
                                              IN  RvSipAppAuthenticatorHandle    hAppAuthenticator,
                                              IN  RPOOL_Ptr                     *pRpoolMD5Input,
                                              IN  RvUint32                      length,
                                              OUT RPOOL_Ptr                     *pRpoolMD5Output)
{
    RvChar strDigest[1024];
    RvChar strResponse[33];
    RvUint8 digest[20];
    MD5_CTX mdc;

    /* The string for the md5 is on a page. first we copy it to
       a consecutive buffer.*/
    RPOOL_CopyToExternal(pRpoolMD5Input->hPool,
                         pRpoolMD5Input->hPage,
                         pRpoolMD5Input->offset,
                         (void*)strDigest,
                         length);

    /* implementation of the MD5 algorithm - we give the string to the MD5*/
    MD5Init(&mdc);
    MD5Update(&mdc, (RvUint8 *)strDigest,(unsigned int)strlen(strDigest));
    MD5Final(digest, &mdc);
    MD5toString(digest, strResponse);

    /*after we have a result we must copy it back to the page*/
    RPOOL_AppendFromExternalToPage(pRpoolMD5Output->hPool,
                                   pRpoolMD5Output->hPage,
                                   (void*)strResponse,
                                   (RvInt)strlen(strResponse) + 1,
                                   &(pRpoolMD5Output->offset));
    RV_UNUSED_ARG(hAuthenticator);
    RV_UNUSED_ARG(hAppAuthenticator);

}

/* CALL-LEG EVENTS */
/***************************************************************************
 * AppCallLegCreatedEvHandler
 * ------------------------------------------------------------------------
 * General:  Notifies that a new call-leg was created.
 *           This application does not exchange handles with the call-leg.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg - The new sip stack call-leg handle
 * Output:  phAppCallLeg - The application handle for this call-leg.
 ***************************************************************************/

static void RVCALLCONV AppCallLegCreatedEvHandler(
                           IN  RvSipCallLegHandle            hCallLeg,
                           OUT RvSipAppCallLegHandle         *phAppCallLeg)
{
    OSPrintf("\nIncoming call-leg %p was created\n\n",hCallLeg);
    *phAppCallLeg = NULL;  /*the application handle is set to NULL*/
}


/***************************************************************************
 * RvSipCallLegStateChangedEv
 * ------------------------------------------------------------------------
 * General: Notifies the application of a call-leg state change.
 *          If the new state is Offering - accept the call.
 *          If an incoming call-leg reached the Connected state, disconnect
 *          the call with RvSipCallLegDisconnect().
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          eState -      The new call-leg state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
static void RVCALLCONV AppCallLegStateChangedEvHandler(
                                   IN  RvSipCallLegHandle            hCallLeg,
                                   IN  RvSipAppCallLegHandle         hAppCallLeg,
                                   IN  RvSipCallLegState             eState,
                                   IN  RvSipCallLegStateChangeReason eReason)
{
    RvStatus             rv;
    RvSipCallLegDirection eDirection;

    RvSipCallLegGetDirection(hCallLeg,&eDirection);

    /*print the new state on screen*/
    OSPrintf("\n%s call-leg %p - State changed to %s\n\n",
             AppGetDirectionName(eDirection),
             hCallLeg,AppGetCallLegStateName(eState));

    switch(eState)
    {
    /*----------------------------------------------
      Accept incoming calls in the offering state
      ---------------------------------------------*/
    case RVSIP_CALL_LEG_STATE_OFFERING:
        OSPrintf("Accepting the call\n\n");
        rv = RvSipCallLegAccept(hCallLeg);
        if(rv != RV_OK)
        {
            AppExitOnError("Failed to accept the call");
        }

        break;
    /*------------------------------------------------
      Disconnect incoming calls in the connected state
      ------------------------------------------------*/
    case RVSIP_CALL_LEG_STATE_CONNECTED:
        if(eDirection == RVSIP_CALL_LEG_DIRECTION_INCOMING)
        {
            OSPrintf("Disconnecting the call\n\n");
            rv = RvSipCallLegDisconnect(hCallLeg);
            if(rv != RV_OK)
            {
                AppExitOnError("Failed to disconnect the call");
            }
        }
        break;
    default:
        break;
    }
    RV_UNUSED_ARG(hAppCallLeg);
    RV_UNUSED_ARG(eReason);
}

/***************************************************************************
 * AppCallLegMsgReceivedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the message received event handler.
 *          Here we only print the message that was received.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppCallLegMsgReceivedEvHandler(
                                    IN  RvSipCallLegHandle            hCallLeg,
                                    IN  RvSipAppCallLegHandle         hAppCallLeg,
                                    IN  RvSipMsgHandle                hMsg)
{
    OSPrintf("\n<-- Message Received (call-leg %p)\n",hCallLeg);
    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppCallLeg);
    return RV_OK;
}

/***************************************************************************
 * RvSipCallLegMsgToSendEv
 * ------------------------------------------------------------------------
 * General: Application implementation to the message to send event handler.
 *          Here we only print the message that is about to be sent.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          hMsg -        Handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppCallLegMsgToSendEvHandler(
                                    IN  RvSipCallLegHandle            hCallLeg,
                                    IN  RvSipAppCallLegHandle         hAppCallLeg,
                                    IN  RvSipMsgHandle                hMsg)
{
    RvSipSecAgreeHandle  hSecAgree;
    RvStatus             rv;

	OSPrintf("--> Message Sent (call-leg %p)\n",hCallLeg);

	rv = RvSipCallLegGetSecAgree(hCallLeg, &hSecAgree);
	if (RV_OK != rv || hSecAgree == NULL)
	{
		AppExitOnError("\nFailed to get security-agreement from call-leg");
	}

	/* Insert Ims headers to message */
	AppServerInsertImsHeaders(hMsg, hSecAgree);

    AppPrintMessage(hMsg);
    RV_UNUSED_ARG(hAppCallLeg);
    return RV_OK;
}
/*--------------------U T I L I T Y   F U N C T I O N S -------------------*/
/***************************************************************************
 * AppServerInitiateServerAppInfo
 * ------------------------------------------------------------------------
 * General: Initializing the server database tables:
 *          1. Authentication users table:
 *             For each user Generate SQN value, Authentication-vector, and the
 *             correct nonce value.
 *             In this sample the table contains a single user.
 *          2. Security agreement objects table.
 ***************************************************************************/
static void AppServerInitiateServerAppInfo(void)
{
    /* 1. Authentication users table */
    strcpy(g_serverAuthUser.username, USER1_NAME);
    strcpy(g_serverAuthUser.password, USER1_PW);

    if (IS_IPSEC_GM_INTERFACE)
    {
    /* Generate the sqn, Authentication-vector and nonce, for each user,
       using its password
       (The generation of the Authentication-vector, is according to
       3GPP TS 33.102.
       The generation of the SQN value which is used in creating the
       authentication vector, is simply a timestamp, 6 bytes length.
       The application may generate the SQN in a different way
        as defined in annex C of 3GPP TS 33.102). */
        AppGenerateSQN(g_serverAuthUser.sqn);
        AkaCreateAVAndRand((RvUint8*)g_serverAuthUser.password,g_serverAuthUser.sqn, (RvUint8*)AMF, &(g_serverAuthUser.av));
        AppServerGenerateNonceValue(&(g_serverAuthUser.av), g_serverAuthUser.nonce);
    }


    /* 2. Initialize the g_strGmAddrScheme */
    g_strGmAddrScheme = (IS_IPSEC_GM_INTERFACE) ? "sip" : "sips";

}

/***************************************************************************
 * AppGenerateSQN
 * ------------------------------------------------------------------------
 * General: Generates sqn value (timestamp, 6 bytes)
 * Return Value: none.
 * ------------------------------------------------------------------------
 * Arguments:
 * output  : sqn - pointer to buffer (RvUint8 sqn[6]).
 ***************************************************************************/
static void AppGenerateSQN(OUT RvUint8* sqn)
{
    RvUint16 timestamp2 = (RvUint16)RvSipMidTimeInSecondsGet();
    RvUint32 timestamp = RvSipMidTimeInMilliGet();

    /* convert timestamp to sqn */
    memset(sqn, 0, AKA_SQN_LEN);
    memcpy(sqn,  (const void*)&timestamp2, 2);
    memcpy(sqn+2,(const void*)&timestamp, 4);

}


/***************************************************************************
 * AppServerGenerateNonceValue
 * ------------------------------------------------------------------------
 * General: Generates the nonce value as defined in RFC 3310:
 *          1. Concatenate RAND and AUTN values.
 *          2. Encode the string base 64.
 ***************************************************************************/
static void AppServerGenerateNonceValue(IN AKA_Av* av,
                                        OUT RvChar* nonce)
{
    RvUint8 nonceDecodeB64[AKA_RAND_LEN+AKA_AUTN_LEN];
    RvInt32 len;

    memset(nonceDecodeB64, 0, AKA_RAND_LEN+AKA_AUTN_LEN);
    memset(nonce, 0, 45);

    /* concatenate RAND and AUTN values */
    memcpy(nonceDecodeB64, av->RAND, AKA_RAND_LEN);
    memcpy(nonceDecodeB64+AKA_RAND_LEN, av->AUTN, AKA_AUTN_LEN);

    /* encode the string base 64 */
    len = RvSipMidEncodeB64(nonceDecodeB64, AKA_RAND_LEN+AKA_AUTN_LEN, (RvUint8*)nonce, 45);
    if(len < 0)
    {
        AppExitOnError("Failed to encodeB64 while generating nonce");
    }
}

/***************************************************************************
 * AppSetExpires
 * ------------------------------------------------------------------------
 * General: Copies the Expires header from the request into the 200 response
 *          Sets the Expires value to the security-agreement to be used for
 *          setting lifetime expiration
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc  - Handle to the transaction
 * Output:  pExpires - The expires value
 ***************************************************************************/
static void AppSetExpires(IN  RvSipTranscHandle  hTransc,
						  OUT RvUintPtr         *pExpires)
{
	RvSipMsgHandle            hRcvdMsg;
	RvSipSecAgreeHandle       hSecAgree;
	RvSipMsgHandle            hOutboundMsg;
	RvStatus                  rv;
	RvSipHeaderListElemHandle hListElem    = NULL;
	RvSipExpiresHeaderHandle  hExpires     = NULL;
	RvSipHeaderListElemHandle hNewListElem = NULL;
	void*                     pNewExpires  = NULL;
	RvSipMidTimerHandle       hMidTimer;

	/* Get the received message from the server transaction */
	rv = RvSipTransactionGetReceivedMsg(hTransc, &hRcvdMsg);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to get received message from transaction");
	}

	/* Get the expires header from the message */
	hExpires = RvSipMsgGetHeaderByType(hRcvdMsg, RVSIP_HEADERTYPE_EXPIRES, RVSIP_FIRST_HEADER, &hListElem);
	if (hExpires != NULL)
	{
		/* Get the outbound message from the transaction */
		rv = RvSipTransactionGetOutboundMsg(hTransc, &hOutboundMsg);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to get outbound message from transaction");
		}

		/*==================================================
		  Set the Expires header to the outbound message
		  ==================================================*/
		rv = RvSipMsgPushHeader(hOutboundMsg, RVSIP_FIRST_HEADER, (void*)hExpires, RVSIP_HEADERTYPE_EXPIRES, &hNewListElem, &pNewExpires);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to set Expires header to outbound message");
		}

		/* Get the security-agreement attached to this transaction */
		rv = RvSipTransactionGetSecAgree(hTransc, &hSecAgree);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to get security agreement from transaction");
		}

		/* Get the expires value from the expires header */
		rv = RvSipExpiresHeaderGetDeltaSeconds(hExpires, (RvUint32*)pExpires);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to get expires value from message");
		}

		/*=====================
		  Set Expiration Timer
		  ===================== */
		if (*pExpires != 0)
		{
			/* Set Timer according to the expiration value less 5 seconds in order to alert the client
			   on registration expiration */
			rv = RvSipMidTimerSet(g_hMidMgr, (RvUint32)((*pExpires-5)*1000), AppServerTimerExpEv, (void*)hSecAgree, &hMidTimer);
			if (RV_OK != rv)
			{
				AppExitOnError("\nFailed to set expiration timer");
			}
		}

		/*==================================================
		  Store the Expires value in the security-agreement
		  application handle. The Expires value will be used
		  later to compute the Lifetime interval.
		  ==================================================*/
		rv = RvSipSecAgreeSetAppHandle(hSecAgree, (RvSipAppSecAgreeHandle)*pExpires);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to set expires value to security-agreement");
		}
	}
}

/***************************************************************************
 * AppSetExpires
 * ------------------------------------------------------------------------
 * General: Copies the Contact header from the request into the 200 response
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransc  - Handle to the transaction
 * Output:  None
 ***************************************************************************/
static void AppSetContact(IN  RvSipTranscHandle  hTransc)
{
	RvSipMsgHandle            hRcvdMsg;
	RvSipMsgHandle            hOutboundMsg;
	RvStatus                  rv;
	RvSipHeaderListElemHandle hListElem    = NULL;
	RvSipContactHeaderHandle  hContact     = NULL;
	RvSipHeaderListElemHandle hNewListElem = NULL;
	void*                     pNewContact  = NULL;

	/* Get the received message from the server transaction */
	rv = RvSipTransactionGetReceivedMsg(hTransc, &hRcvdMsg);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed to get received message from transaction");
	}

	/* Get the expires header from the message */
	hContact = RvSipMsgGetHeaderByType(hRcvdMsg, RVSIP_HEADERTYPE_CONTACT, RVSIP_FIRST_HEADER, &hListElem);
	if (hContact != NULL)
	{
		/* Get the outbound message from the transaction */
		rv = RvSipTransactionGetOutboundMsg(hTransc, &hOutboundMsg);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to get outbound message from transaction");
		}

		/*==================================================
		  Set the Expires header to the outbound message
		  ==================================================*/
		rv = RvSipMsgPushHeader(
                hOutboundMsg, RVSIP_FIRST_HEADER, (void*)hContact, RVSIP_HEADERTYPE_CONTACT, &hNewListElem, &pNewContact);
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to set Contact header to outbound message");
		}
	}
}


/***************************************************************************
 * AppServerInsertImsHeaders
 * ------------------------------------------------------------------------
 * General: Inserts Ims headers to the given message, based on the message type
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg      - Handle to the message.
 *          hSecAgree - The security-agreement sending a message
 ***************************************************************************/
static void AppServerInsertImsHeaders(IN RvSipMsgHandle       hMsg,
									  IN RvSipSecAgreeHandle  hSecAgree)
{
	RvSipMethodType				eMethod      = RVSIP_METHOD_UNDEFINED;
	RvInt32                     localPort    = UNDEFINED;
	RvInt32                     remotePort   = UNDEFINED;
	RvInt16						responseCode = UNDEFINED;
	RvSipOtherHeaderHandle		hOtherHeader;
	RvSipPUriHeaderHandle       hPAssocUri;
	RvSipPUriHeaderHandle       hPAssertId;
	RvSipRouteHopHeaderHandle	hServiceRouteHeader;
	RvChar						helper[256];
	RvStatus					rv;

	if (RvSipMsgGetMsgType(hMsg) == RVSIP_MSG_REQUEST)
	{
		eMethod = RvSipMsgGetRequestMethod(hMsg);
	}
	else
	{
		RvSipCSeqHeaderHandle  hCSeqHeader = RvSipMsgGetCSeqHeader(hMsg);
		eMethod = RvSipCSeqHeaderGetMethodType(hCSeqHeader);
		responseCode = RvSipMsgGetStatusCode(hMsg);
	}

    if (IS_IPSEC_GM_INTERFACE)
    {
        if (hSecAgree != NULL)
        {
            AppSecAgreeGetPorts(hSecAgree, &localPort, &remotePort);
	    }
    }
	else
    {
        localPort  = g_serverPortTls;
        remotePort = g_clientPortTls;
    }

	if (eMethod == RVSIP_METHOD_REGISTER && responseCode == 200)
	{
		/* Add Ims headers for 200 response on a REGISTER request */

		/* Path Header */
		sprintf(helper, "Path: <sip:term@%s%s;lr>", g_pServerIP,SIGCOMP_PARAMETERS);
		/* The user name term indicates that the Path header relates to requests
		   for the UE terminating case */
		rv = RvSipOtherHeaderConstructInMsg(hMsg, RV_FALSE, &hOtherHeader);
		if (RV_OK == rv)
		{
			rv = RvSipOtherHeaderParse(hOtherHeader, helper);
		}
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to add Path header to message");
		}

		/* Require header */
		rv = RvSipOtherHeaderConstructInMsg(hMsg, RV_FALSE, &hOtherHeader);
		if (RV_OK == rv)
		{
			rv = RvSipOtherHeaderParse(hOtherHeader, "Require: path");
		}
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to add Require header to message");
		}

		/* Service-Route header */
		if (localPort > UNDEFINED)
		{
			sprintf(helper, "Service-Route: <%s:orig@%s:%d%s;lr>", g_strGmAddrScheme, g_pServerIP, localPort,SIGCOMP_PARAMETERS);
		}
		else
		{
			sprintf(helper, "Service-Route: <%s:orig@%s;lr>", g_strGmAddrScheme, g_pServerIP);
		}
		/* The user name orig indicates that the Service-Route header relates to requests
		   for the UE originating case */
		rv = RvSipRouteHopHeaderConstructInMsg(hMsg, RV_FALSE, &hServiceRouteHeader);
		if (RV_OK == rv)
		{
			rv = RvSipRouteHopHeaderParse(hServiceRouteHeader, helper);
		}
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to add Service-Route header to message");
		}

		/* Set comp=sigcomp in the Service-Route header if needed */
		if (IS_SIGCOMP_GM_INTERFACE)
		{
		    /* Set comp=sigcomp in the Service-Route header if needed */
			RvSipAddressHandle          hAddr;
			hAddr = RvSipRouteHopHeaderGetAddrSpec(hServiceRouteHeader);
			rv = RvSipAddrUrlSetCompParam(hAddr, RVSIP_COMP_SIGCOMP, NULL);
			if (RV_OK != rv)
			{
				AppExitOnError("\nFailed to add comp=sigcomp to Service-Route header");
			}
            rv = RvSipAddrUrlSetSigCompIdParam(hAddr,SRV_SIGCOMP_ID_STR);
            if (RV_OK != rv)
            {
                AppExitOnError("\nFailed to add sigcomp-id to Service-Route header");
			}
		}

		/* P-Associated-URI header */
		if (remotePort > UNDEFINED)
		{
			sprintf(helper, "P-Associated-URI: <%s:%s@%s:%d>", g_strGmAddrScheme, PUB_ID, CLIENT_IP, remotePort);
		}
		else
		{
			sprintf(helper, "P-Associated-URI: <%s:%s@%s>", g_strGmAddrScheme, PUB_ID, CLIENT_IP);
		}
		rv = RvSipPUriHeaderConstructInMsg(hMsg, RV_FALSE, &hPAssocUri);
		if (RV_OK == rv)
		{
			rv = RvSipPUriHeaderParse(hPAssocUri, helper);
		}
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to add P-Associated-URI header to message");
		}
	}

	if (eMethod == RVSIP_METHOD_SUBSCRIBE && responseCode == 200)
	{
		/* Add Ims headers for 200 response on a SUBSCRIBE request */

		/* P-Asserted-Identity */
		rv = RvSipPUriHeaderConstructInMsg(hMsg, RV_FALSE, &hPAssertId);
		if (RV_OK == rv)
		{
			sprintf(helper, "P-Asserted-Identity: <sip:%s>", g_pServerIP);
			rv = RvSipPUriHeaderParse(hPAssertId, helper);
		}
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to add P-Asserted-Identity header to message");
		}
	}

	if (eMethod == RVSIP_METHOD_INVITE || eMethod == RVSIP_METHOD_BYE)
	{
		/* Add Ims headers for dialog related messages */

		/* P-Asserted-Identity */
		rv = RvSipPUriHeaderConstructInMsg(hMsg, RV_FALSE, &hPAssertId);
		if (RV_OK == rv)
		{
			if (localPort > UNDEFINED)
			{
				sprintf(helper, "P-Asserted-Identity: <%s:%s@%s:%d>", g_strGmAddrScheme, REMOTE_PUB_ID, g_pServerIP, localPort);
			}
			else
			{
				sprintf(helper, "P-Asserted-Identity: <%s:%s@%s>", g_strGmAddrScheme, REMOTE_PUB_ID, g_pServerIP);
			}
			rv = RvSipPUriHeaderParse(hPAssertId, helper);
		}
		if (RV_OK != rv)
		{
			AppExitOnError("\nFailed to add P-Asserted-Identity header to message");
		}
	}
}

/***************************************************************************
 * AppServerGetSecAgreeObject
 * ----------------------------------
 * General: Get a security-agreement object that shall process an incoming message.
 *          The security-agreement object is identified by the following process
 *          a. If the message is received upon a security-association, find the
 *             security-agreement object that owns this security-association.
 *          b. If the message is received unprotected, create a new security-agreement
 *             object
 *          NOTE: The security-agreement object is static in the following
 *                special cases:
 *                1. When this application is compiled with RV_SIP_IPSEC_NEG_ONLY on (i.e.,
 *                   without ipsec).
 *                2. When this application is configured to work in Digest+TLS interface
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgreeMgr       - The sip stack handle to the security-agreement manager
 *         pOwner             - The sip object receiving the message that caused the
 *                              invoking of this event. If this event was invoked due to calling
 *                              RvSipSecAgreeHandleMsgRcvd(), pOwner will be NULL.
 *         hMsg               - The received message requesting for a security-agreement.
 * Output: ppSecAgree         - The new security-agreement object to use.
 **************************************************************************/
static void AppServerGetSecAgreeObject(IN  RvSipSecAgreeMgrHandle	hSecAgreeMgr,
                                       IN  RvSipSecAgreeOwner*	    pOwner,
                                       IN  RvSipMsgHandle           hMsg,
                                       OUT RvSipSecAgreeHandle*	    phNewSecAgree)
{
    RvSipSecAgreeMsgRcvdInfo  msgRcvdInfo;
    RvStatus                  rv;

	if (pOwner->eOwnerType == RVSIP_COMMON_STACK_OBJECT_TYPE_SUBSCRIPTION)
	{
		/* Retrieve the dialog from the subscription. The dialog is the owner required for
		   calling RvSipSecAgreeMgrGetMsgRcvdInfo() */
		rv = RvSipSubsGetDialogObj(pOwner->pOwner, (RvSipCallLegHandle*)&pOwner->pOwner);
		if (RV_OK != rv)
		{
			AppExitOnError("\n\nFailed when calling RvSipSubsGetDialogObj within AppServerSecAgreeMgrSecAgreeRequiredEvHandler\n\n");
		}
		pOwner->eOwnerType = RVSIP_COMMON_STACK_OBJECT_TYPE_CALL_LEG;
	}


	/* Get the message received information from the security-agreement manager */
	rv = RvSipSecAgreeMgrGetMsgRcvdInfo(hSecAgreeMgr, sizeof(RvSipSecAgreeOwner), pOwner, hMsg,
										sizeof(RvSipSecAgreeMsgRcvdInfo), &msgRcvdInfo);
	if (RV_OK != rv)
	{
		AppExitOnError("\nFailed when calling RvSipSecAgreeMgrGetMsgRcvdInfo within AppServerSecAgreeMgrSecAgreeRequiredEvHandler\n\n");
	}


    if (IS_IPSEC_GM_INTERFACE)
    {
        AppServerGetIPsecSecAgreeObject(hSecAgreeMgr,&msgRcvdInfo,phNewSecAgree);
    }
    else
    {
        AppServerGetTlsSecAgreeObject(hSecAgreeMgr,hMsg,&msgRcvdInfo,phNewSecAgree);
    }

}

/***************************************************************************
 * AppServerGetIPsecSecAgreeObject
 * ----------------------------------
 * General: Get a security-agreement object that shall process an IPsec
 *          (or to be IPsec when working in IPsec interface) incoming message.
 *          The security-agreement object is identified by the following process
 *          a. If the message is received upon a security-association, find the
 *             security-agreement object that owns this security-association.
 *          b. If the message is received unprotected, create a new security-agreement
 *             object
 *          NOTE: In the special case of compiling with RV_SIP_IPSEC_NEG_ONLY on (i.e.,
 *                without ipsec), the security-agreement object is static
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgreeMgr       - The sip stack handle to the security-agreement manager
 *         pMsgRcvdInfo       - Information of the message, requesting for a security-agreement.
 * Output: ppSecAgree         - The new security-agreement object to use.
 **************************************************************************/
static void AppServerGetIPsecSecAgreeObject(
                                   IN  RvSipSecAgreeMgrHandle	 hSecAgreeMgr,
                                   IN  RvSipSecAgreeMsgRcvdInfo *pMsgRcvdInfo,
                                   OUT RvSipSecAgreeHandle*	     phNewSecAgree)
{
	RvStatus                  rv;
#ifndef RV_SIP_IPSEC_NEG_ONLY

	RvSipSecAgreeHandle       hSecAgree = NULL;      /* handle to the server security-agreement*/

	/* a. Find the security-agreement object that owns the security-association on which the message is received:
	      i.   Get the message received information from the security-agreement manager (see the calling function)
		  ii.  Get the security-object from the local-address
		  iii. Get the security-agreement from the security-object */

	/* ii. Get the security-agreement object from the local-address */
	rv = RvSipSecAgreeMgrGetSecAgree(hSecAgreeMgr, pMsgRcvdInfo, &hSecAgree);
    if (RV_OK != rv)
    {
        AppExitOnError("\nFailed when calling RvSipSecAgreeMgrGetSecAgree within AppServerSecAgreeMgrSecAgreeRequiredEvHandler\n");
    }

#else /* RV_SIP_IPSEC_NEG_ONLY is defined */

	static RvSipSecAgreeHandle  hSecAgree = NULL;

#endif /* #ifndef RV_SIP_IPSEC_NEG_ONLY */

	if(hSecAgree == NULL) /* did not find a sec-agree */
    {
		/* Note: At this point, the application must identify whether the received message should
		         have been received upon a security-association. If the message should have been
				 received securely it must be discarded here. This is out of the scope of this
		         sample application. */

        /* create new sec-agree object */
        rv = AppServerCreateSecAgreeObject(hSecAgreeMgr, &hSecAgree);
        if (rv != RV_OK)
        {
            AppExitOnError("\n\nFailed to create a new security-agreement\n\n");
        }

        /* Return the newly created server security-agreement */
        OSPrintf("\n\nIPsec Server sec-agree %p was created\n\n", hSecAgree);
    }
    else
    {
        OSPrintf("\n\nUse existing ipsec server sec-agree %p \n\n", hSecAgree);
    }

	/* Return the security-agreement handle */
    *phNewSecAgree = hSecAgree;
}

/***************************************************************************
 * AppServerGetTlsSecAgreeObject
 * ----------------------------------
 * General: Get a security-agreement object that shall process a TLS (or
 *          to be TLS when working in Digest+TLS interface) incoming message.
 *          The security-agreement object is identified by the following process
 *          a. If the message is received upon a security-association, find the
 *             security-agreement object that owns this security-association.
 *          b. If the message is received unprotected, create a new security-agreement
 *             object
 *
 *          According to the standard, the Security Agreement should be matched
 *          to an IMPI (IP Multimedia Private Identity). In this implementation a
 *          static reference is kept for a security-agreement object that matches
 *          the configured USER1_NAME (which functions as an IMPI).
 *
 *          NOTE: Due to this specific static reference, if the function
 *                encounters an unknown IMPI over unsecured connection,
 *                it considers the message as invalid and exits the application.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hSecAgreeMgr       - The sip stack handle to the security-agreement manager
 *         hMsg               - The received message requesting for a security-agreement.
 *         pMsgRcvdInfo       - Information of the message,
 *                              requesting for a security-agreement.
 * Output: ppSecAgree         - The new security-agreement object to use.
 **************************************************************************/
static void AppServerGetTlsSecAgreeObject(
                                    IN  RvSipSecAgreeMgrHandle	  hSecAgreeMgr,
                                    IN  RvSipMsgHandle            hMsg,
                                    IN  RvSipSecAgreeMsgRcvdInfo *pMsgRcvdInfo,
                                    OUT RvSipSecAgreeHandle*	  phNewSecAgree)
{
#define USER1_NAME_LEN (sizeof(USER1_NAME)+2) /* The '2' is for the 2 additional " enclosing chars */
    static RvSipSecAgreeHandle      hSecAgree = NULL;
    RvStatus                        rv;

    if (pMsgRcvdInfo->rcvdFromAddr.eTransportType != RVSIP_TRANSPORT_TLS)
    {
        /* 1.1 If the message is unsecured, verify that the received IMPI equals USER1_NAME */
        AppServerVerifyIMPIMatching(hMsg);
    }

    /* 2. Create a new Security Agreement if none is created */
    if(hSecAgree == NULL) /* sec-agree was not created yet */
    {
		/* Note: At this point, the application must identify whether the received message should
		         have been received upon a security-association. If the message should have been
				 received securely it must be discarded here. This is out of the scope of this
		         sample application. */

        /* create new sec-agree object */
        rv = AppServerCreateSecAgreeObject(hSecAgreeMgr, &hSecAgree);
        if (rv != RV_OK)
        {
            AppExitOnError("\nFailed to create a new security-agreement\n");
        }

        /* Return the newly created server security-agreement */
        OSPrintf("\nTLS Server sec-agree %p was created\n\n", hSecAgree);
    }
    else
    {
        OSPrintf("\nUse existing TLS server sec-agree %p \n\n", hSecAgree);
    }

	/* Return the security-agreement handle */
    *phNewSecAgree = hSecAgree;
}

/***************************************************************************
 * AppServerVerifyIMPIMatching
 * ----------------------------------
 * General: Verifies that the given incoming message includes an IMPI that
 *          exactly matches USER1_NAME.
 *
 *
 *          NOTE: If the function encounters an unknown IMPI, it considers
 *                the message as invalid and exits the application.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:  hMsg               - The received message requesting for a security-agreement.
 * Output:
 **************************************************************************/
static void AppServerVerifyIMPIMatching(IN RvSipMsgHandle hMsg)
{
    RvSipHeaderListElemHandle       hListElem = NULL;
    RvSipAuthorizationHeaderHandle  hAuth;
    RvChar                          strMsgIMPI[USER1_NAME_LEN];
    RvUint                          msgIMPILen;
    RvStatus                        rv;

    hAuth = RvSipMsgGetHeaderByType(
        hMsg,RVSIP_HEADERTYPE_AUTHORIZATION,RVSIP_FIRST_HEADER,&hListElem);
    if (hAuth == NULL)
    {
        AppExitOnError("\n\nFailed to retrieve Authorization header from incoming message (in Digest+TLS mode)\n\n");
    }
    rv = RvSipAuthorizationHeaderGetUserName(hAuth,strMsgIMPI,USER1_NAME_LEN,&msgIMPILen);
    if (rv != RV_OK)
    {
        AppExitOnError("\n\nFailed to retrieve username from Authorization header\n\n");
    }
    if (msgIMPILen != USER1_NAME_LEN || strstr(strMsgIMPI,USER1_NAME) == NULL)
    {
        AppExitOnError("\n\nThe received username within the Authorization header is different than USER1_NAME\n\n");
    }
}


/***************************************************************************
 * AppCallLegFinalDestResolvedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the dest resolved event handler.
 *          Here we add sigcomp-id to the Via header if needed
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hCallLeg       - The SIP Stack call-leg handle.
 *            hAppCallLeg    - The application handle for this call-leg.
 *            hTransc        - The transaction handle.
 *            hAppTransc     - The application handle for this transaction.
 *                             For INVITE/BYE the hAppTransc is NULL.
 *            hMsgToSend     - The handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppCallLegFinalDestResolvedEvHandler(
                      IN  RvSipCallLegHandle     hCallLeg,
                      IN  RvSipAppCallLegHandle  hAppCallLeg,
                      IN  RvSipTranscHandle      hTransc,
                      IN  RvSipAppTranscHandle   hAppTransc,
                      IN  RvSipMsgHandle         hMsgToSend)
{
	/* Add comp=sigcomp to Via header for 3GPP TS 24229 or Packet Cable 2.0 */
	if (IS_SIGCOMP_GM_INTERFACE)
    {
		AppMsgToSendAddSigCompIdParam(hMsgToSend);
	}

    RV_UNUSED_ARG(hCallLeg);
    RV_UNUSED_ARG(hAppCallLeg);
    RV_UNUSED_ARG(hTransc);
    RV_UNUSED_ARG(hAppTransc);

	return RV_OK;
}

/***************************************************************************
 * AppSubsFinalDestResolvedEvHandler
 * ------------------------------------------------------------------------
 * General: Application implementation to the dest resolved event handler.
  *         Here we add sigcomp-id to the Via header if needed
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hSubs          - The sip stack subscription handle
 *            hAppSubs       - The application handle for this subscription.
 *            hNotify        - The notify object handle (relevant only for notify request or response)
 *            hAppNotify     - The application notify object handle (relevant only for notify request or response)
 *            hTransc        - The transaction handle
 *            hMsgToSend     - The handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppSubsFinalDestResolvedEvHandler(
                      IN  RvSipSubsHandle           hSubs,
                      IN  RvSipAppSubsHandle        hAppSubs,
                      IN  RvSipNotifyHandle         hNotify,
                      IN  RvSipAppNotifyHandle      hAppNotify,
                      IN  RvSipTranscHandle         hTransc,
                      IN  RvSipMsgHandle            hMsgToSend)
{
	/* Add comp=sigcomp to Via header for 3GPP TS 24229 */
	if (IS_SIGCOMP_GM_INTERFACE)
    {
		AppMsgToSendAddSigCompIdParam(hMsgToSend);
	}

	RV_UNUSED_ARG(hSubs);
	RV_UNUSED_ARG(hAppSubs);
	RV_UNUSED_ARG(hNotify);
	RV_UNUSED_ARG(hAppNotify);
	RV_UNUSED_ARG(hTransc);

	return RV_OK;
}

/***************************************************************************
* AppMsgToSendAddSigCompIdParam
* ------------------------------------------------------------------------
* General: Sets sigcomp-id to the Via header of the message
* Return Value:
* ------------------------------------------------------------------------
* Arguments:
* Input:  hMsg      - The message being sent
*
***************************************************************************/
static void AppMsgToSendAddSigCompIdParam(IN  RvSipMsgHandle  hMsg)
{
    RvSipHeaderListElemHandle  hListElem;
    RvSipViaHeaderHandle       hViaHeader;
    RvStatus                   rv;

    hViaHeader = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_VIA, RVSIP_FIRST_HEADER, &hListElem);
    if (hViaHeader == NULL)
    {
        AppExitOnError("\nMissing Via header");
    }

    rv = RvSipViaHeaderSetSigCompIdParam(hViaHeader,SRV_SIGCOMP_ID_STR);
    if (RV_OK != rv)
    {
        AppExitOnError("\nFailed to set sigcomp-id parameter to Via header");
    }
}

/***************************************************************************
 * AppPrintMessage
 * ------------------------------------------------------------------------
 * General: Prints a message on the screen. For doing this we need to
 *          encode the message and then copy the result to a consecutive
 *          buffer.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg -  Handle to the message.
 ***************************************************************************/
void AppPrintMessage(IN RvSipMsgHandle hMsg)
{
    RvStatus   rv;
    HPAGE       hPage;
    RvChar     *msgBuf;
    RvUint32   msgSize;

    /* getting the encoded message on an rpool page.*/
    rv = RvSipMsgEncode(hMsg, g_appPool, &hPage, &msgSize);
    if (rv != RV_OK)
    {
        OSPrintf("Message encoding failed");
        exit(1);
    }
    /*allocate a consecutive buffer - use UTILS since malloc doesn't work on all OS's */
    msgBuf = (RvChar *)RvSipMidMemAlloc(msgSize+1);

    /* copy the encoded message to an external consecutive buffer*/
    rv = RPOOL_CopyToExternal(g_appPool,
                              hPage,
                              0,
                              (void*)msgBuf,
                              msgSize);
    /*terminate the buffer with null*/
    msgBuf[msgSize] = '\0';
    if(rv != RV_OK)
    {
        OSPrintf("Message encoding failed");
        /*free the page the encode function allocated*/
        RPOOL_FreePage(g_appPool, hPage);
        RvSipMidMemFree(msgBuf);
        exit(1);
    }
    OSPrintf("%s\n",msgBuf);
    /*free the page the encode function allocated*/
    RPOOL_FreePage(g_appPool, hPage);
    RvSipMidMemFree(msgBuf);
}
/***************************************************************************
 * AppExitOnError
 * ------------------------------------------------------------------------
 * General: prints an error message and exits.
  ***************************************************************************/
void AppExitOnError(RvChar* str)
{
    OSPrintf("%s\n",str);
    exit(1);
}

/***************************************************************************
 * AppGetTranscStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetTranscStateName (
                          IN  RvSipTransactionState  eState)
{

    switch(eState)
    {
    case RVSIP_TRANSC_STATE_UNDEFINED:
        return "Undefined";
    case RVSIP_TRANSC_STATE_IDLE:
        return "Idle";
    case RVSIP_TRANSC_STATE_SERVER_GEN_REQUEST_RCVD:
        return "General Request Received";
    case RVSIP_TRANSC_STATE_SERVER_GEN_FINAL_RESPONSE_SENT:
        return "General Final Response Sent";
    case RVSIP_TRANSC_STATE_SERVER_INVITE_REQUEST_RCVD:
        return "Invite Request Received";
    case RVSIP_TRANSC_STATE_SERVER_INVITE_FINAL_RESPONSE_SENT:
        return "Invite Final Response Sent";
    case RVSIP_TRANSC_STATE_CLIENT_GEN_REQUEST_SENT:
        return "General Request Sent";
    case RVSIP_TRANSC_STATE_CLIENT_GEN_PROCEEDING:
        return "General Proceeding";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_CALLING:
        return "Invite Calling";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_PROCEEDING:
        return "Invite Proceeding";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_FINAL_RESPONSE_RCVD:
        return "Invite Final Response Received";
    case RVSIP_TRANSC_STATE_CLIENT_INVITE_ACK_SENT:
        return "Invite Ack Sent";
    case RVSIP_TRANSC_STATE_CLIENT_GEN_FINAL_RESPONSE_RCVD:
        return "General Final Response Received";
    case RVSIP_TRANSC_STATE_TERMINATED:
        return "Terminated";
    default:
        return "";
    }
}

/***************************************************************************
 * AppGetCallLegStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
const RvChar*  AppGetCallLegStateName (
                          IN  RvSipCallLegState  eState)
{

    switch(eState)
    {
    case RVSIP_CALL_LEG_STATE_ACCEPTED:
        return "Accepted";
    case RVSIP_CALL_LEG_STATE_CONNECTED:
        return "Connected";
    case RVSIP_CALL_LEG_STATE_DISCONNECTED:
        return "Disconnected";
    case RVSIP_CALL_LEG_STATE_DISCONNECTING:
        return "Disconnecting";
    case RVSIP_CALL_LEG_STATE_IDLE:
        return "Idle";
    case RVSIP_CALL_LEG_STATE_INVITING:
        return "Inviting";
    case RVSIP_CALL_LEG_STATE_OFFERING:
        return "Offering";
    case RVSIP_CALL_LEG_STATE_REDIRECTED:
        return "Redirected";
    case RVSIP_CALL_LEG_STATE_TERMINATED:
        return "Terminated";
    default:
        return "Undefined";
    }
}

/***************************************************************************
 * AppGetSecAgreeStateName
 * ------------------------------------------------------------------------
 * General: Returns the name of a given state
 * Return Value: The string with the state name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The state as enum
 ***************************************************************************/
static const RvChar*  AppGetSecAgreeStateName (IN  RvSipSecAgreeState  eState)
{
    switch(eState)
    {
        case RVSIP_SEC_AGREE_STATE_IDLE:
            return "Idle";
        case RVSIP_SEC_AGREE_STATE_CLIENT_LOCAL_LIST_READY:
            return "Client Local List Ready";
        case RVSIP_SEC_AGREE_STATE_CLIENT_REMOTE_LIST_READY:
            return "Client Remote List Ready";
        case RVSIP_SEC_AGREE_STATE_CLIENT_HANDLING_INITIAL_MSG:
            return "Client Handling Initial Msg";
        case RVSIP_SEC_AGREE_STATE_CLIENT_LOCAL_LIST_SENT:
            return "Client Local List Sent";
        case RVSIP_SEC_AGREE_STATE_CLIENT_CHOOSE_SECURITY:
            return "Client Choose Security";
        case RVSIP_SEC_AGREE_STATE_SERVER_LOCAL_LIST_READY:
            return "Server Local List Ready";
        case RVSIP_SEC_AGREE_STATE_SERVER_REMOTE_LIST_READY:
            return "Server Remote List Ready";
        case RVSIP_SEC_AGREE_STATE_SERVER_READY:
            return "Server Ready";
        case RVSIP_SEC_AGREE_STATE_ACTIVE:
            return "Active";
        case RVSIP_SEC_AGREE_STATE_NO_AGREEMENT_REQUIRED:
            return "No Agreement Required";
        case RVSIP_SEC_AGREE_STATE_INVALID:
            return "Invalid";
        case RVSIP_SEC_AGREE_STATE_TERMINATED:
            return "Terminated";
        default:
            return "Undefined";

    }
}

/***************************************************************************
 * AppGetDirectionName
 * ------------------------------------------------------------------------
 * General: Returns a call-leg direction as a string.
 * Return Value: The string with the direction name.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   eState - The direction as enum
 ***************************************************************************/
const RvChar*  AppGetDirectionName(
                        IN RvSipCallLegDirection eDirection)
{
    switch(eDirection)
    {
    case RVSIP_CALL_LEG_DIRECTION_INCOMING:
        return "INCOMING";
    case RVSIP_CALL_LEG_DIRECTION_OUTGOING:
        return "OUTGOING";
    default:
        return "Undefined";
    }
}

/***************************************************************************
 * AppAnalyzeCommandLineArguments
 * ------------------------------------------------------------------------
 * General: Analyzes the given Command Line Arguments
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   argc, argv
 ***************************************************************************/
static int AppAnalyzeCommandLineArguments(int argc, char *argv[])
{
    /* Analyze command line arguments and set global variables */
    if (argc < 2)
    {
        OSPrintf("Default Server UDP port %d will be used.\n", g_serverPort);
        OSPrintf("Default Server TLS port %d will be used.\n", g_serverPortTls);
        OSPrintf("Default Client TLS port %d will be used.\n", g_clientPortTls);
    }
    else if (argc == 5)
    {
        g_serverPort    = (RvUint16)atoi(argv[1]);
        g_serverPortTls = (RvUint16)atoi(argv[2]);
        g_clientPortTls = (RvUint16)atoi(argv[3]);
        sprintf(g_pServerIP,    "%s",    argv[4]);

        OSPrintf("Given Server UDP port %d will be used.\n", g_serverPort);
        OSPrintf("Given Server TLS port %d will be used.\n", g_serverPortTls);
        OSPrintf("Given Client TLS port %d will be used.\n", g_clientPortTls);
    }
    else
    {
        OSPrintf("Invalid arguments given!\n");
        OSPrintf("Usage:   demoImsServer <server udp port> <server tls port> <client tls port> <server ip>\n\n");
        OSPrintf("Example: demoImsServer 6060 6061 6071 [fe80::21c:23ff:fe03:1137]\n");

        return 1;
    }

    return 0;
}

#endif /*#ifdef RV_SIP_IMS_ON*/
/***************************************************************************
 * OSPrintf
 * ------------------------------------------------------------------------
 * General: Implementation of printf for different Operating Systems.
 *          (Print formatted output to the standard output stream.)
 * Return Value: The number of characters printed, or a negative value
 *               if an error occurs.
 *-------------------------------------------------------------------------
 * Arguments:
 * Input: format - Format control.
 *        There might be additional parameters according to the format.
 *-------------------------------------------------------------------------
 ***************************************************************************/
int OSPrintf(IN const char *format,... )
{
    int      charsNo;
    va_list  ap;
#if (RV_OS_TYPE == RV_OS_TYPE_WINCE)
    RvChar  cbuf[MAX_PRINT_LEN];

    /*************************************
     Print message to the buffer first
    **************************************/
    va_start(ap,format);
    charsNo = vsprintf (cbuf, format, ap);
    va_end(ap);

    /************************************************
     Using default output window for printing
    *************************************************/
    charsNo = OSWinCEPrintf(NULL,0,cbuf);
#else
    va_start(ap,format);
    charsNo = vprintf(format,ap);
    va_end(ap);

#endif

    return charsNo;
}



