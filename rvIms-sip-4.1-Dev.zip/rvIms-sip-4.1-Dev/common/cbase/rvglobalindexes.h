#ifndef  _rv_global_indexes_h_
#define _rv_global_indexes_h_

#define RV_CCORE_GLOBALS_INDEX          0
#define RV_SDP_GLOBALS_INDEX            1
#define RV_SIP_GLOBALS_INDEX            2
#define RV_SIGCOMP_GLOBALS_INDEX		3


#define RV_MAX_GL_DATA_INDEX            5

#endif

