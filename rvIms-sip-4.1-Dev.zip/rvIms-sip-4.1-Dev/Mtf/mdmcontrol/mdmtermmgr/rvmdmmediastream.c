/******************************************************************************
Filename   : rvmdmmediastream.c
Description: Structures and functions to save digitmap information
******************************************************************************
                Copyright (c) 2001 RADVision Inc.
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision LTD.
No part of this publication may be reproduced in any form whatsoever 
without written prior approval by RADVision LTD..

RADVision LTD. reserves the right to revise this publication and make 
changes without obligation to notify any person of such revisions or 
changes.
******************************************************************************/

#define LOGSRC	LOGSRC_MDMCONTROL
#include "ipp_inc_std.h"
#include "rvmdmtermmgrutil.h"
#include "rvmdm.h"
#include "rvmdmmediastream.h"
#include "rvccterminalmdm.h"
#include "rvmdm.h"
#include "mtfMediaInt.h" 

/*MOVE TO rvterminalmdm.c*/
rvDefineVector(RvMdmMediaStreamInfo)

rvDefineFindIf(RvVectorIter, RvMdmMediaStreamInfo)


void rvMdmMediaStreamInfoConstructA(RvMdmMediaStreamInfo * x/*, const RvMdmStreamDescriptor * descr*/, RvMdmStreamId streamId,RvAlloc * alloc)
{
	rvMdmStreamDescriptorConstructA(&x->streamDescr, streamId, alloc);
/*	x->streamDescr = (RvMdmStreamDescriptor *)descr; */
	x->status = RV_MDMSTREAM_NEW;
	x->userData = NULL;
	x->alloc = alloc;
}

void rvMdmMediaStreamInfoDestruct(RvMdmMediaStreamInfo * x)
{
	rvMdmStreamDescriptorDestruct(&x->streamDescr);
}

/* Required for the vector */
RvMdmMediaStreamInfo* rvMdmMediaStreamInfoConstructCopy(RvMdmMediaStreamInfo* d,const RvMdmMediaStreamInfo * s,RvAlloc* alloc)
{
	rvMdmStreamDescriptorConstructCopy(&d->streamDescr, &s->streamDescr, alloc);
	d->status = s->status;
	d->userData = s->userData;
	d->alloc = s->alloc;
	return d;
}

const RvSdpMsg* rvMdmMediaStreamInfoGetLocalDescriptor(RvMdmMediaStreamInfo* x, RvMdmStreamId streamId)
{
	RvMdmStreamDescriptor*	mediaDescr = rvMdmMediaStreamInfoGetStreamDescriptor(x);
	if (rvMdmStreamDescriptorIsLocalDescriptorSet(&x->streamDescr))
		return (rvMdmStreamDescriptorGetLocalDescriptor(mediaDescr, streamId));

	return NULL;
}

const RvSdpMsg* rvMdmMediaStreamInfoGetRemoteDescriptor(RvMdmMediaStreamInfo* x, RvMdmStreamId streamId)
{
	RvMdmStreamDescriptor*	mediaDescr = rvMdmMediaStreamInfoGetStreamDescriptor(x);
	if (rvMdmStreamDescriptorIsRemoteDescriptorSet(&x->streamDescr))
		return (rvMdmStreamDescriptorGetRemoteDescriptor(mediaDescr, streamId));

	return NULL;

}
/* Compare by id */
RvBool rvMdmMediaStreamInfoEqual(const RvMdmMediaStreamInfo* d,const RvMdmMediaStreamInfo* s) {
	return rvMdmMediaStreamInfoMatchId(d,rvMdmMediaStreamInfoGetId(s));
}


/*Note: Check if mode,parameters,reserve can also be absent,what to do...*/
static void fillMdmInfo(RvMdmMediaStreamInfo * x,RvMdmMediaStreamDescr * descr)
{
	RvSdpMsgList* local=NULL,* remote=NULL;
	
	if(rvMdmStreamDescriptorIsLocalDescriptorSet(&x->streamDescr))
		local = &x->streamDescr.localDescriptors;
    else
        local = NULL;

	if( rvMdmStreamDescriptorIsRemoteDescriptorSet(&x->streamDescr))
		remote = &x->streamDescr.remoteDescriptors;
    else
        remote = NULL;

	rvMdmMediaStreamDescrConstruct_(descr,
		rvMdmStreamDescriptorGetMode(&x->streamDescr),
		local,remote);
}

RVAPI RvUint32 rvMdmMediaStreamInfoGetId(const RvMdmMediaStreamInfo * x) {
	if(x==NULL)
		return 0;
	return rvMdmStreamDescriptorGetId(&x->streamDescr);
}

void rvMdmMediaStreamInfoSetId(RvMdmMediaStreamInfo * x, RvUint32 id) {

	RvMdmStreamDescriptor*  streamDescr = &x->streamDescr;

	rvMdmStreamDescriptorSetId(streamDescr, id);
}

RvBool rvMdmMediaStreamInfoMatchId(const RvMdmMediaStreamInfo * x,unsigned int streamId) {
	if(x==NULL) 
		return (streamId==0);
	else
		return streamId==rvMdmStreamDescriptorGetId(&x->streamDescr);
}


/* How to build a response:
   Create the difference lists in place
   Copy the new media stuff - Because it is saved in the termination
  	
  Note: in general (modify) needs to give to the application only the modified parameters,
  those are also the ones coming back...
  This must be copied but only once...
*/

static void buildRsp(RvMdmMediaStreamInfo * x, RvMdmMediaStreamDescr * mdmMediaInfo, /*const RvMdmStreamDescriptor * cmdStream,*/RvMdmMediaDescriptor * rspMedia,RvAlloc * alloc) {

	RvMdmStreamDescriptor tmpStream;
	RvMdmStreamDescriptor * rspStreamDescr;
/*	RvMdmParameterList * rspList;
	const RvMdmParameterList * inList;*/

	rvMdmStreamDescriptorConstructA(&tmpStream,rvMdmMediaStreamInfoGetId(x),alloc);
	rvMdmMediaDescriptorAddStream(rspMedia,&tmpStream);

	rspStreamDescr = (RvMdmStreamDescriptor *)rvMdmMediaDescriptorGetStream(rspMedia,
														   rvMdmMediaDescriptorGetNumStreams(rspMedia)-1);


	if (rvMdmMediaStreamDescrIsReportLocal_(mdmMediaInfo) && rvMdmMediaStreamDescrGetLocalDescr(mdmMediaInfo))
    {
		rvMdmStreamDescriptorAddEmptyLocalDescriptor(rspStreamDescr);
		rvSdpMsgListCopy(&rspStreamDescr->localDescriptors,rvMdmMediaStreamDescrGetLocalDescr(mdmMediaInfo));
	}		


	if (rvMdmMediaStreamDescrIsReportRemote_(mdmMediaInfo) && rvMdmMediaStreamDescrGetRemoteDescr(mdmMediaInfo))
    {
		rvMdmStreamDescriptorAddEmptyRemoteDescriptor(rspStreamDescr);
		rvSdpMsgListCopy(&rspStreamDescr->remoteDescriptors,rvMdmMediaStreamDescrGetRemoteDescr(mdmMediaInfo));
	}
	
	rvMdmStreamDescriptorDestruct(&tmpStream);
}


RvBool rvMdmMediaStreamInfoCreateMdmMedia(RvMdmMediaStreamInfo * x, 
                                          RvCCTerminalMdm * term, 
                                          RvMdmMediaDescriptor * rspMedia) {
	RvMdmMediaStreamDescr mdmMediaInfo;
	RvMdmError mdmError;
	RvMdmTerm * mdmTerm = &term->mdmTerm;
    RvMdmMediaStream*       mediaObsolete = NULL;
    RvMdmMediaParam   *param = &mdmMediaInfo.param;

	/* Fill the mdm object with the media information */
	fillMdmInfo(x, &mdmMediaInfo);
		
	/* Call application callback to create a new media stream and set parameters */
    param->cmd = RVMDM_CMD_CREATE;
    if(mdmMediaInfo.localDescr)
        param->normal.localSdp = rvSdpMsgListGetElement( mdmMediaInfo.localDescr, 0);
    else
        param->normal.localSdp = NULL;

    if(mdmMediaInfo.remoteDescr)
        param->normal.remoteSdp = rvSdpMsgListGetElement( mdmMediaInfo.remoteDescr, 0); 
    else
        param->normal.remoteSdp = NULL;

    param->normal.localCapsSdp = NULL; /*we put it NULL because nobody uses it afterward. It may be extracted from mdmTerm->termClass->mediaCaps */

    if( !rvMdmTermCreateMediaStream_( mdmTerm, mediaObsolete, &mdmMediaInfo, &mdmError))
    {
		return RV_FALSE;
	}

	if (rspMedia)
	buildRsp(x,&mdmMediaInfo, rspMedia,term->alloc);
	return RV_TRUE;
}


RvBool rvMdmMediaStreamInfoModifyMediaDone(void* conn,
										  RvMdmMediaStreamInfo * x, 
                                          RvCCTerminalMdm * term, 
										  RvBool status,
                                          RvMdmMediaDescriptor * rspMedia,
										  RvMdmTermReasonModifyMedia reason)
{
	RvMdmTerm * mdmTerm = &term->mdmTerm;
	RvMdmMediaStreamDescr mdmMediaInfo;

	/* Fill the mdm object with the media information */
	fillMdmInfo(x, &mdmMediaInfo);
		
	/* Call application callback to create a new media stream and set parameters */
	rvModifyMediaCompletedIntCB(conn, mdmTerm, status, x, &mdmMediaInfo, reason);
		
	/* Build response */
	if (rspMedia)
		buildRsp(x,&mdmMediaInfo,/*cmdStream,*/rspMedia,term->alloc);
	return RV_TRUE;
}

void rvMdmMediaStreamInfoReleaseMdmMedia(RvMdmMediaStreamInfo * x,RvCCTerminalMdm * term) {
	RvMdmError error;

	if(!rvMdmTermDestroyMediaStream_(&term->mdmTerm,x,&error)) {
		/*ERROR*/
	}
}

RVAPI RvBool rvMdmMediaStreamInfoIsLocalDescriptorSet(RvMdmMediaStreamInfo* x)
{
	const RvMdmStreamDescriptor* descr = rvMdmMediaStreamInfoGetStreamDescriptor(x);
	return rvMdmStreamDescriptorIsLocalDescriptorSet(descr);
}

RVAPI RvBool rvMdmMediaStreamInfoIsRemoteDescriptorSet(RvMdmMediaStreamInfo* x)
{
	const RvMdmStreamDescriptor* descr = rvMdmMediaStreamInfoGetStreamDescriptor(x);
	return rvMdmStreamDescriptorIsRemoteDescriptorSet(descr);
}
void rvMdmMediaStreamInfoAddLocalDescriptor(RvMdmMediaStreamInfo* x, RvSdpMsg *msg)
{
    if (x != NULL)
	rvMdmStreamDescriptorAddLocalDescriptor(&x->streamDescr, msg);
}
void rvMdmMediaStreamInfoAddRemoteDescriptor(RvMdmMediaStreamInfo* x, RvSdpMsg *msg)
{
	rvMdmStreamDescriptorAddRemoteDescriptor(&x->streamDescr, msg);
}

void rvMdmMediaStreamInfoClearLocal(RvMdmMediaStreamInfo* x)
{
	rvMdmStreamDescriptorClearLocalDescriptors(&x->streamDescr);
}

void rvMdmMediaStreamInfoClearRemote(RvMdmMediaStreamInfo* x)
{
	rvMdmStreamDescriptorClearRemoteDescriptors(&x->streamDescr);
}

RvBool RvMdmMediaStreamInfoDoesMediaTypeExist(RvMdmMediaStreamInfo* x, 
											  RvSdpMediaType		mediaType)
{
	const RvMdmStreamDescriptor* streamDescr = NULL;
	const RvSdpMsg* msg = NULL;
	RvSdpMediaDescr* media = NULL;
	unsigned int i;

	if (x == NULL)
		return RV_FALSE;
	
	if ((streamDescr = rvMdmMediaStreamInfoGetStreamDescriptor(x)) == NULL)
		return RV_FALSE;

	/*TODO:CHECK REMOTE???????*/
	if (rvMdmStreamDescriptorIsLocalDescriptorSet(streamDescr) == RV_FALSE)
		return RV_FALSE;

	if ((msg = rvMdmStreamDescriptorGetLocalDescriptor(streamDescr, 0)) == NULL)
		return RV_FALSE;

	for(i=0; i < rvSdpMsgGetNumOfMediaDescr(msg); ++i)
	{
		if ((media = rvSdpMsgGetMediaDescr(msg, i)) != NULL)
		{
			if (rvSdpMediaDescrGetMediaType(media) == mediaType)
				return RV_TRUE;
		}
	}

	return RV_FALSE;

}

