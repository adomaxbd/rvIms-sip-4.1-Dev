/******************************************************************************
Filename:    rvmdmtermspecialdm.h
Description: 
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever 
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#ifndef RV_MDMTERMSPECIALDM_H
#define RV_MDMTERMSPECIALDM_H

#include "rvtimer.h"
#include "rvansi.h"

#include "rvmdmobjects.h"
#include "rvmdmtermmgrutil.h"
#include "rvmdm.h"

#define RV_MDMDIGITMAP_MAX_DIGIT_LEN 32



typedef struct
{
	RvInt32     digitLen;
	RvUint32    digitMap[RV_MDMDIGITMAP_MAX_DIGIT_LEN];	
} RvMdmSpecialDM;

rvDeclareList(RvMdmSpecialDM)

RvMdmSpecialDM* RvMdmSpecialDMConstructCopy(RvMdmSpecialDM* d,const RvMdmSpecialDM* s,RvAlloc* a);
RvBool RvMdmSpecialDMEqual(const RvMdmSpecialDM* x,const RvMdmSpecialDM* y);
#define RvMdmSpecialDMDestruct       rvMdmSpecialDMDestruct


#endif /* RV_MDMTERMSPECIALDM_H */
