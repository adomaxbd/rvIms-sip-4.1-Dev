/******************************************************************************
Filename:    rvmdmtermmgrutil.h
Description:
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

#define LOGSRC	LOGSRC_MDMCONTROL
#include "ipp_inc_std.h"
#include "rvtypes.h"

#include "rvmdmtermmgrutil.h"
#include "rvmdm.h"

/*--------------------------------------------------------------------------------------*/
/*   Timers                                                                             */
/*--------------------------------------------------------------------------------------*/
/* TODO: Allocate them from their own pool so they don't depend on term memory
   Needs a special allocator in the termination or the term mgr
*/

#define RV_MDMTERMTIMER_MAXTIME 30000

/* Call only from inside the timeout callback!*/
static void timerRelease(RvMdmTermTimer* t) {
	if(t!=NULL) {
		IppTimerDestruct(&t->timer);
		rvMtfAllocatorDealloc(t, sizeof(RvMdmTermTimer));
	}
}

/* Note: Make the function return some value to reset the timer
   (for example return 500 to reset to 500 msecs .
   The term state mutex can be used as the timer mutex
   Then the function will check the state.
   If is processing, will just reset the timer.
   If not, will lock the term mutex and do the work.
*/
static RvBool processTimer( void* data)
{
	RvMdmTermTimer* t = (RvMdmTermTimer*)data;

	/* Check valid twice: one for the case that the timer was canceled
	   before expiration and the mutex data may be false */
	/*if(t->valid!=RV_TRUE) {
		timerRelease(t);	
		return;
	}*//*move to rvMdmTermTimerCancel*/

	RvMutexLock(t->mutex,IppLogMgr());
	/* This is for the case that the timer was just canceled concurrently
	   with expiration, the mutex will insure serially, i.e., the full
	   cancel must be done before the process or the other way around */
	if(t->valid==RV_TRUE)
	{
		if(t->loopCnt)
		{
			t->loopCnt--;
			IppTimerStart(&t->timer,IPP_TIMER_DONT_CHECK_IF_STARTED, 0);
			RvMutexUnlock(t->mutex,IppLogMgr());
		    return RV_TRUE;
		}
		/* Call callback function */
		t->func(data);
	}
	RvMutexUnlock(t->mutex,IppLogMgr());
	timerRelease(t);

	return RV_TRUE;
}

RvMdmTermTimer* rvMdmTermTimerCreate(RvAlloc* alloc,RvMilliseconds ms,
										  rvMdmTermTimerCB func, void* data,
										  RvMutex* mutex)
{
	RvMdmTermTimer* t = NULL;
	rvMtfAllocatorAlloc(sizeof(RvMdmTermTimer), (void**)&t);

	t->valid = RV_TRUE;
	t->data = data;
	t->alloc = alloc;
	t->func = func;
	t->mutex = mutex;
	t->loopCnt = 0;
	/* Total sleep time will be split, so the timer never sleeps more
	   than max. This is allow the timer to release itself quickly if
	   is canceled and avoid timers hanging around forever. */
	if(ms > RV_MDMTERMTIMER_MAXTIME)
    {
		t->loopCnt = ms/RV_MDMTERMTIMER_MAXTIME;
		ms = ms - t->loopCnt*RV_MDMTERMTIMER_MAXTIME;
	}
	IppTimerConstruct(&t->timer,ms,processTimer,t);
	IppTimerStart(&t->timer, IPP_TIMER_RESTART_IF_STARTED, 0);
	return t;
}

void rvMdmTermTimerCancel(RvMdmTermTimer* t)
{
	if(t!=NULL) {
        RvMutexLock(t->mutex,IppLogMgr());
        t->valid = rvFalse;
	    RvMutexUnlock(t->mutex,IppLogMgr());
		timerRelease(t);
    }
}

