/******************************************************************************
Filename:    rvmdmtermspecaildm.c
Description:
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#define LOGSRC	LOGSRC_MDMCONTROL
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ipp_inc_std.h"
#include "rvmdmtermspecialdm.h"
#include "rvccterminalmdm.h"
#include "rvmdmobjects.h"


typedef RvListRevIter(RvMdmSpecialDM) RvMdmSpecialDMIter;

rvDefineList(RvMdmSpecialDM)
rvDefineListAllocBack(RvMdmSpecialDM)
#define rvMdmDigitPositionBitValue(c) (isdigit(c) ? (1 << (c - '0')) : ((1 << 9) << (c & 15)))

void rvMdmDigitPositionAdd(RvInt32* digitMap, int c1, int c2) 
{
	
	int b1 = rvMdmDigitPositionBitValue(c1);
    int b2 = rvMdmDigitPositionBitValue(c2);

    *digitMap |= (b2 - b1) | b2;
};

static void rvMdmSpecialDMConstruct(RvMdmSpecialDM* specialMap, RvChar* token, RvChar* pbxPrefix)
{

    RvChar * currDigit = NULL;
    RvChar*  tmp = NULL;

    memset(specialMap, 0 ,sizeof(RvMdmSpecialDM));
    if (RvMemoryAlloc(NULL, (RvSize_t)strlen(token)+2, NULL, (void**)&currDigit) != RV_OK)
        return;

    memset(currDigit, 0, strlen(token)+2);
    tmp = currDigit;
    if(pbxPrefix != NULL)
        strncpy(currDigit, pbxPrefix, 1);
	strcat(currDigit, token);
	
	printf("@@@ currDigit == %s\n",currDigit);
	
	while( *currDigit )
	{
		/* Handle X */
		if( *currDigit == 'x' || *currDigit == 'X' )
		{
			rvMdmDigitPositionAdd(&(specialMap->digitMap[specialMap->digitLen]), (char) '0', (char) '9');	
			specialMap->digitLen++;		
		}

		/* Handle digits */
		/* ------------- */
		else if (*currDigit >= '0' && *currDigit <= '9')
		{
		       printf("@@@ rvMdmDigitPositionAdd\n");
			rvMdmDigitPositionAdd(&(specialMap->digitMap[specialMap->digitLen]),(char)(*currDigit), (char)(*currDigit));	
			specialMap->digitLen++;
		}

		/* Handle '*' */
		else if (*currDigit == '*' || *currDigit == 'e' || *currDigit == 'E')
		{
			rvMdmDigitPositionAdd(&(specialMap->digitMap[specialMap->digitLen]),(char) 'e', (char) 'e');	
			specialMap->digitLen++;
		}

		/* Handle '#' */
		else if (*currDigit == '#'|| *currDigit == 'f' || *currDigit == 'F')
		{
			rvMdmDigitPositionAdd(&(specialMap->digitMap[specialMap->digitLen]),(char) 'f', (char) 'f');	
			specialMap->digitLen++;
		}
		
		/* Handle [] */
		else if( ( *currDigit ) == '[' )
		{
			int ii = 0;
			
			currDigit++;
			
			while(*currDigit != ']' && ii < 20)
			{
			    ii ++;
			    
			    if(*(currDigit+1) != '-')
			    {
			        if(*currDigit >= '0' && *currDigit <= '9')
			        {
			            rvMdmDigitPositionAdd(&(specialMap->digitMap[specialMap->digitLen]),(char)(*currDigit), (char)(*currDigit));
			        }
			        else if (*currDigit == '*' || *currDigit == 'e' || *currDigit == 'E')
			        {
			            rvMdmDigitPositionAdd(&(specialMap->digitMap[specialMap->digitLen]),(char) 'e', (char) 'e');	
			        }
			        else if (*currDigit == '#' || *currDigit == 'f' || *currDigit == 'F')
			        {
			            rvMdmDigitPositionAdd(&(specialMap->digitMap[specialMap->digitLen]),(char) 'f', (char) 'f');	
			        }
			        currDigit++;
			    }
			    else
			    {			    	
			        rvMdmDigitPositionAdd(&(specialMap->digitMap[specialMap->digitLen]),(char)(*currDigit),(char)(*(currDigit+2)));
			        currDigit = currDigit + 3;	
			    }
			    
			}
			specialMap->digitLen++;	
		}

		currDigit++;
	}
	RvMemoryFree((void*)tmp, NULL);
	return;
}




void PSip_SpecialDM_Add(RvIppTerminalHandle ippTerm , RvChar* pattern, RvChar* pbxPrefix)
{
	RvMdmSpecialDM * cur = NULL;
       RvCCTerminal* t = (RvCCTerminal*)ippTerm;
       RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
	RvChar* token = NULL;
	RvChar* saveptr = NULL;
	RvChar delim[2] = "|";
	RvChar* map = NULL;
	RvChar* tmp = NULL;
    
    if (RvMemoryAlloc(NULL, (RvSize_t)strlen(pattern)+1, NULL, (void**)&map) != RV_OK)
        return;
       memset(map, 0, strlen(pattern)+1);
	tmp = map;
	strcpy(map, pattern);
	for(; ;map = NULL)
	{		
            token = strtok_r(map, delim, &saveptr);			
            if(token == NULL)
                break;	
    	     cur = rvListAllocBack(RvMdmSpecialDM)(&term->specialDM);
    	     rvMdmSpecialDMConstruct(cur, token, pbxPrefix);
		
	}	
	RvMemoryFree((void*)tmp, NULL);
	
    
}

RvMdmDigitMapMatchType PSip_SpecialDM_Match(struct RvCCTerminalMdm_* x, RvChar*dialString)
{

	RvMdmSpecialDMIter i, next;
	RvMdmSpecialDM * cur = NULL;
	RvInt32 len = strlen(dialString);
	RvInt32 digitmap = 0;
	RvInt32 index = 0;
    
	for (i=rvListBegin(&x->specialDM);i!=rvListEnd(&x->specialDM);i=next)
    {
		next=rvListIterNext(i);
	    cur = rvListIterData(i);
    	if(len > cur->digitLen)
            continue;
		
		for(index = 0; index < len; index++)
		{
			if(!(rvMdmDigitPositionBitValue(dialString[index]) & cur->digitMap[index]))			
				break;				
		}
		
		
		if(index == len)
		{	
			/* if all digit match and the lenght is same, match it! */
			if(len == cur->digitLen)
				return RV_MDMDIGITMAP_UNAMBIGUOUSMATCH;
			else if(len < cur->digitLen) 
				return 	RV_MDMDIGITMAP_PARTIALMATCH;	
		}	
        
    }

    
    return 	RV_MDMDIGITMAP_NOMATCH;
}


void rvMdmSpecialDMDestruct(RvMdmSpecialDM* x)
{
}

/* This will be an empty function to allow unconstructed objects to be inserted */
RvMdmSpecialDM* RvMdmSpecialDMConstructCopy(RvMdmSpecialDM* d,const RvMdmSpecialDM* s,RvAlloc* a)
{
	return d;
}


RvBool RvMdmSpecialDMEqual(const RvMdmSpecialDM* x,const RvMdmSpecialDM* y)
{
	return rvTrue;
}
