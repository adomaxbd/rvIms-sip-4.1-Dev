/******************************************************************************
Filename:    rvmdmtermevent.c
Description:
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#define LOGSRC	LOGSRC_MDMCONTROL
#include "ipp_inc_std.h"
#include "ippevexchange.h"
#include "rvmutex.h"
#include "rvstr.h"
#include "rvlist.h"

#include "rvmdm.h"
#include "rvmdmtermevent.h"
#include "rvmdmtermdigitmap.h"
#include "rvmdmtermsignal.h"
#include "rvccterminalmdm.h"
#include "basephone.h"


#define RvMdmEventConstructCopy rvMdmEventConstructCopy
#define RvMdmEventDestruct rvMdmEventDestruct
#define RvMdmEventEqual rvNeverEqual

rvDefineList(RvMdmEvent)
rvDefineListAllocBack(RvMdmEvent)

extern unsigned int  g_dwDigitMatchType;

extern void Psip_MdmTermQueueObsEventTimesPlus();

extern void Psip_MdmTermProcessObsEventTimesPlus();

static void  queueBlockedObsEvent(RvCCTerminalMdm * x, RvMdmPackageItem* name,
							   RvMdmMediaStream * media, const RvMdmParameterList * args);




static void buildObservedEvent2(RvMdmEvent * obsEvent,
								const RvMdmPackageItem *name,
								const RvMdmParameterList * args,RvAlloc * alloc)
{
	/* If processing a buffered event,use the original time */
	rvMdmEventConstructA(obsEvent,name,alloc);

	if (args != NULL)
    {
		rvMdmParameterListCopy((RvMdmParameterList*)rvMdmEventGetParameterList(obsEvent), args);
	}
}


static void buildObservedEvent(RvCCTerminalMdm * x,RvMdmEvent * obsEvent,
							   const RvMdmPackageItem *name,RvMdmMediaStream * media,
							   const RvMdmParameterList * args)
{
	/* Store media data in terminal*/
	if (media != NULL)
		rvCCTerminalMdmSetMediaEventData(x, (RvMdmMediaStreamInfo*)media);

/*	RvMutexLock(&x->mutex,IppLogMgr());*/
	buildObservedEvent2(obsEvent,name,args,x->alloc);
/*	RvMutexUnlock(&x->mutex,IppLogMgr());*/
}


/*Generate an event completion for digitmaps for the dd package */
void  rvMdmDigitMapBuildDDEvComplete(RvMdmParameterList *parameters,
										const char * digitString,
										RvMdmDigitMapMatchType matchType,
										void* userData)
{
	RvAlloc * alloc = (RvAlloc*)userData;

	/* If the digitString is empty, don't encode the parameter.
	   In the package, encoding an empty string is required,
	   but the syntax doesn't support it */
	if (digitString[0])
    {
		RvMdmParameterValue value;

		/* Build the parameter value (digit string) */
		rvMdmParameterValueConstructA(&value, digitString, alloc);

		/* Add to digit string parameter list */
		rvMdmParameterListSet2(parameters, "ds", &value);

		rvMdmParameterValueDestruct(&value);
	}

	/* Add Termination method */
	if (matchType != RV_MDMDIGITMAP_NOMATCH)
	{
		RvMdmParameterValue value;
        const RvChar* paramValue[] = {"PM", "FM", "UM"};

        rvMdmParameterValueConstructA(&value, paramValue[(int)matchType-1], alloc);

		/* Add termination method to parameter list */
		rvMdmParameterListSet2(parameters, "Meth", &value);

		/* Destruct local objects */
		rvMdmParameterValueDestruct(&value);
	}
}

/* Return mapped character or RV_MDMEVENT_NOTFOUND if failed to translate */
unsigned char rvMdmDigitMapTranslateDDEvent(const char * eventName, const RvMdmParameterList* args) {
/*
+------+--------------+
| DTMF | Event Symbol |
+------+--------------+
| d0   | "0"          |
| d1   | "1"          |
| d2   | "2"          |
| d3   | "3"          |
| d4   | "4"          |
| d5   | "5"          |
| d6   | "6"          |
| d7   | "7"          |
| d8   | "8"          |
| d9   | "9"          |
| da   | "A" or "a"   |
| db   | "B" or "b"   |
| dc   | "C" or "c"   |
| dd   | "D" or "d"   |
| ds   | "E" or "e"   |
| do   | "F" or "f"   |
+------+--------------+
*/
	RV_UNUSED_ARG(args);

    if ((eventName[0] != 'd') || (eventName[2] != '\0'))
    {
        /* The event name is always 2 characters, where the first is always 'd' */
		return RV_MDMEVENT_NOTFOUND;
    }

	if(eventName[1]>='0' && eventName[1]<='9')
		return (unsigned char)eventName[1];
	if(eventName[1]>='a' && eventName[1]<='d')
		return (unsigned char)eventName[1];
	if(eventName[1]=='s')
		return (unsigned char)'e';
	if(eventName[1]=='o')
		return (unsigned char)'f';

	return RV_MDMEVENT_NOTFOUND;
}

static RvBool isInDigitMapPkg(const RvMdmPackageItem *name)
{
	return ((!rvStrIcmp("kp", rvMdmPackageItemGetPackage(name))) ||
            (!rvStrIcmp("dd", rvMdmPackageItemGetPackage(name))));
}

static void generateDMEventCompletion(RvCCTerminalMdm * x,RvMdmMediaStream * media)
{
	RvMdmParameterList parameters;

	/* Disable digitmap and timer */
	rvMdmTermDeactivateDigitMap(x);

	/* Build the digitmap parameters */
	rvMdmParameterListConstructA(&parameters,x->alloc);
	x->digitMapEC->evCompleteF(&parameters, rvStringGetData(&x->dialString),
        x->digitMapStat, x->digitMapEC->userData);

	rvMdmTermQueueObsEvent(rvCCTerminalMdmGetMdmTerm(x), rvCCTerminalMdmGetCompEventPkg(x), "ce", media, &parameters);

	/* Destruct local objects */
	rvMdmParameterListDestruct(&parameters);
}

static void processDigitMapUnmatch(RvCCTerminalMdm * x,const RvMdmPackageItem *name,
								 RvMdmMediaStream * media,const RvMdmParameterList * args) 
{
	RV_UNUSED_ARG(args);

    /* Don't generate completion event twice! */
	/* if receiving a "ce", don't produce a new "ce" */
	if(!strcmp("ce",rvMdmPackageItemGetItem(name)))
    {
		/* Disable digitmap and timer */
		rvMdmTermDeactivateDigitMap(x);
    }
	else
    {
    	generateDMEventCompletion(x,media);
    }
}

/*
Order of processing:
If an event causes
the digitmap to stop (no possible match).
1. First report the digitmap completion (fail status)
2. Then report the event

If is in the package and matches but reporting is explicitly required
(i.e. if using wildcard in the package)
2. First report the event
1. Then report the digitmap event completion (if is done).

Timer events are never reported!
*/
static RvBool processDigitMapEvent(RvCCTerminalMdm * x,const RvMdmPackageItem *name,
								   RvMdmMediaStream * media,const RvMdmParameterList * args)
{
	unsigned char newDigit;
	RvMdmDigitMapMatchType lastStat = x->digitMapStat;

    /* Search in analog function first (this eliminates the need for TranslateF callback in rvMdmDigitMapDataConstruct())*/
    newDigit = rvMdmDigitMapTranslateDDEvent(rvMdmPackageItemGetItem(name), args);
    if (newDigit == RV_MDMEVENT_NOTFOUND)
    {
        /* If not found, check in IPP function */
        newDigit = rvMdmKpDigitMapTranslateKeypadEv(rvMdmPackageItemGetItem(name), args);
    }
	
	/* Treat this as a non-match event */
	if (newDigit == RV_MDMEVENT_NOTFOUND)
    {
		/* The reported match state is the last match */
		x->digitMapStat=lastStat;
		processDigitMapUnmatch(x,name,media,args);
	}
	else if (newDigit != RV_MDMEVENT_IGNORE)
    {
	    RvUint timerDuration;

		rvStringPushBack(&x->dialString, (char)newDigit);
		x->digitMapStat = rvMdmTermMatchDialString_(&x->mdmTerm,
            rvStringGetData(&x->dialString), &timerDuration);

		/* Stop signals for the first digit even if it is not an acceptable dial digit */
		/* e.g. sometimes '*' or '#' are not valid for dialing. We want to stop signals
		   anyway */
		if (rvStringGetSize(&x->dialString)==1)
			rvMdmTermEventStopSignals(x);

        switch (x->digitMapStat)
        {
        case RV_MDMDIGITMAP_NOMATCH:
			/* Subtract last event and generate a digit-map completion event */
			rvStringResize(&x->dialString,rvStringGetSize(&x->dialString)-1);

			/* The reported match state is the last match */
			x->digitMapStat = lastStat;
			processDigitMapUnmatch(x, name, media, args);
			return RV_FALSE;

        case RV_MDMDIGITMAP_PARTIALMATCH:
        case RV_MDMDIGITMAP_FULLMATCH:
			x->digitMapMedia = media; /* Save for later processing */

			/* 0 is used to disable the inter-digit time */
			if (timerDuration != 0 )
			{
			    if(g_dwDigitMatchType == 1 && timerDuration > 2 && rvStringGetSize(&x->dialString) >= 8)
			    {
			        timerDuration = 2;
			    }
				rvMdmTermDigitMapTimerRestart(x, timerDuration*1000);
	        }

			/* If event is explicitly required, send a notify */
			return RV_FALSE;
		
        case RV_MDMDIGITMAP_UNAMBIGUOUSMATCH:
			generateDMEventCompletion(x, media);
		}
	}

	return RV_TRUE;
}

/*
In case that the digit map is not active, just push the dtmf event into
the dialstring so it can be access by the call control.
*/
static void accumulateDigitMapEvent(RvCCTerminalMdm * x,const RvMdmPackageItem *name,
								    RvMdmMediaStream * media,const RvMdmParameterList * args)
{
	unsigned char newDigit;

	RV_UNUSED_ARG(media);

	/* Digit Map not installed */
	if(x->digitMapEC==NULL)
		return;

    /* Search in analog function first*/
    newDigit = rvMdmDigitMapTranslateDDEvent(rvMdmPackageItemGetItem(name), args);
    if (newDigit == RV_MDMEVENT_NOTFOUND)
    {
        /* If not found, check in IPP function */
        newDigit = rvMdmKpDigitMapTranslateKeypadEv(rvMdmPackageItemGetItem(name), args);
    }

	/* MDM expects 'ds' (*) to be mapped to 'e' for digitmap matching */
	/* We map it back to '*' for DTMF relay */
	if(newDigit=='e')
		newDigit='*';
	/* MDM expects 'do' (#) to be mapped to 'f' for digitmap matching */
	/* We map it back to '#' for DTMF relay */
	if(newDigit=='f')
		newDigit='#';

	if ((newDigit != RV_MDMEVENT_IGNORE) && (newDigit != RV_MDMEVENT_NOTFOUND))
		rvStringPushBack(&x->dialString, (char)newDigit);

	return;
}


/* Function to be called if digitmap timer expires
   If status was RV_MDMDIGITMAP_PARTIALMATCH, send notify with dd/Meth=PM.
   If status was RV_MDMDIGITMAP_FULLMATCH send notify with dd/Meth=FM
   We will be passing the user data along for the sheer fun of it.
*/
void rvMdmTermDigitMapTimerProcess(RvCCTerminalMdm * x)
{
	generateDMEventCompletion(x,x->digitMapMedia);

/*	sendNotify(x);
	processEmbFields(x,x->digitMapReqEvent);*/
}



static RvBool rvMdmTermPostEvent(void* data)
{
	RvCCTerminal* x = (RvCCTerminal*)data;
	RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);

	/* Don't send events if unregister term event was already sent for this termination */
	if (rvCCTerminalMdmBlockedEventIsUnregOn(term) == RV_TRUE)
    	return RV_TRUE;

    sendEventToMsgSocket(x);

	return RV_TRUE;
}

/* Register physical term events are queued to avoid deadlock if the event is process
   in the context of the user application.*/
RvBool rvMdmTermQueueRegisterTermEvent(RvMdmTerm* mdmTerm)
{
	RvCCTerminal* t = (RvCCTerminal *)rvMdmTermGetXTerm_(mdmTerm);
	RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);

	RvMutexLock(&term->blockedEventMutex,IppLogMgr());

	rvMdmTermPostEvent(t);

	rvCCTerminalMdmBlockedEventSetReg(term, RV_TRUE);

	RvMutexUnlock(&term->blockedEventMutex,IppLogMgr());

    return RV_TRUE;
}

/* Unregister physical term events are queued to avoid deadlock if the event is process
   in the context of the user application.*/
RvBool rvMdmTermQueueUnregTermEvent(RvMdmTerm* mdmTerm)
{
	RvCCTerminal* t = (RvCCTerminal *)rvMdmTermGetXTerm_(mdmTerm);
	RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);

	if(term->inactive)
        return RV_TRUE;

//	RvMutexLock(&term->blockedEventMutex,IppLogMgr());

    rvCCTerminalMdmBlockedEventSetUnreg(term, RV_TRUE);

	rvMdmTermPostEvent(t);

/*	RvMutexUnlock(&term->blockedEventMutex,IppLogMgr());*/

    return RV_TRUE;
}
/* All events are queued to avoid deadlock if the event is process
   in the context of the user application.*/
RvBool rvMdmTermQueueObsEvent(RvMdmTerm* mdmTerm,const char* pkg,const char* id,
						  RvMdmMediaStream* media,RvMdmParameterList * args)
{
	RvCCTerminal* t = (RvCCTerminal *)rvMdmTermGetXTerm_(mdmTerm);
	RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
	RvMdmPackageItem item;
    RvBool retval = RV_TRUE;
    
    //Psip_MdmTermQueueObsEventTimesPlus();

	if(term->inactive)
		return retval;

	rvMdmPackageItemConstructA(&item,pkg,id,term->alloc);

	RvMutexLock(&term->blockedEventMutex, IppLogMgr());

	queueBlockedObsEvent(term, &item, media, args);

	rvMdmTermPostEvent(t);

	RvMutexUnlock(&term->blockedEventMutex, IppLogMgr());

	/* Destruct local objects */
	rvMdmPackageItemDestruct(&item);
	return retval;
}


/* Process the events coming from timer manager or dedicated thread */
RvBool rvMdmTermProcessObsEvent(RvMdmTerm* mdmTerm,const char* pkg,const char* id,
						  RvMdmMediaStream* media,RvMdmParameterList * args)
{
	RvCCTerminal* t = (RvCCTerminal *)rvMdmTermGetXTerm_(mdmTerm);
	RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
	RvMdmPackageItem item;
    RvBool retval = RV_FALSE;

    //Psip_MdmTermProcessObsEventTimesPlus();
    
	if(term->inactive)
        return RV_TRUE;

	rvMdmPackageItemConstructA(&item,pkg,id,term->alloc);

	RvMutexLock(&term->mutex,IppLogMgr());

	if(isInDigitMapPkg(&item) )
    {
		if(term->digitMapActive )
			retval = processDigitMapEvent(term,&item,media,args);
		else
			accumulateDigitMapEvent(term,&item,media,args);
	}

	RvMutexUnlock(&term->mutex,IppLogMgr());
	rvCCTerminalMdmProcessEvent(t, pkg, id, media, args);

	/* Destruct local objects */
	rvMdmPackageItemDestruct(&item);
	return retval;
}


/*---------------------------------------------------------------------------------*/
/* Functions used to process new events descriptor                                 */
/*---------------------------------------------------------------------------------*/
static RvBool validateRequestedEvent(RvCCTerminalMdm * x,
									 const RvMdmRequestedEvent* reqEvent)
{
	const RvMdmPackageItem* name;

	name = rvMdmRequestedEventGetName(reqEvent);
	return rvMdmTermIsPkgSupported_(rvCCTerminalMdmGetMdmTerm(x), rvMdmPackageItemGetPackage(name));
}

static void processBlockedEventRegisterTerm(RvCCTerminal* x)
{
	RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);


	/* Install digit map so the mapping function is available
	   Note: DigitMap is not actually active at this point */
    rvCCTerminalMdmInstallDigitMap(x, RV_FALSE);

/*  x->inactive = RV_FALSE;*/

	rvCCTerminalMdmBlockedEventSetReg(term, RV_FALSE);

	RvMutexUnlock(&term->mutex,IppLogMgr());
	RvMutexUnlock(&term->blockedEventMutex,IppLogMgr());

	rvMdmTermRegisterPhysTermDone_(&term->mdmTerm);

	RvMutexLock(&term->blockedEventMutex,IppLogMgr());
	RvMutexLock(&term->mutex,IppLogMgr());

}

static void processBlockedEventUnregisterTerm(RvCCTerminal* x)
{
	RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
	RvCCProvider* p = rvCCTerminalMdmGetProvider(term);
	RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);

	rvMdmTermMgrUnregisterTermination(provider->mdmTermMgr, &term->mdmTerm, NULL);
}

static void processBlockedEventObserved(RvCCTerminal* x)
{
	RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
	const char* id,* pkg;
	RvMdmMediaStream * media;
	RvMdmEvent* event;
	RvMdmParameterList* args;

	while (rvListSize(&term->blockedEventBuffer))
    {
		/* Retrieve a blocked event from the buffer */
		event = rvListFront(&term->blockedEventBuffer);
		/* Get the event data */
		media=  (RvMdmMediaStream*) rvCCTerminalMdmGetMediaEventData(term);
		pkg = rvMdmPackageItemGetPackage(rvMdmEventGetName(event));
		id  = rvMdmPackageItemGetItem(rvMdmEventGetName(event));
		args = (RvMdmParameterList*)rvMdmEventGetParameterList(event);
		if( rvMdmParameterListIsEmpty(args) )
			args = NULL;
		/* Process the event (unlock first)*/
		RvMutexUnlock(&term->mutex,IppLogMgr());
		RvMutexUnlock(&term->blockedEventMutex,IppLogMgr());
		rvMdmTermProcessObsEvent(rvCCTerminalMdmGetMdmTerm(term),pkg,id,media,args);
		RvMutexLock(&term->blockedEventMutex,IppLogMgr());
		RvMutexLock(&term->mutex,IppLogMgr());

		rvListPopFront(RvMdmEvent)(&term->blockedEventBuffer);
	}

}

/* Called from event process thread, process all pending events.
   Check the event type first, can be: 1.Observed event 2.Register termination
   3.Unregister termination.*/
void rvMdmTermProcessBlockedEvent(RvCCTerminal* x)
{

	RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);

	RvMutexLock(&term->blockedEventMutex,IppLogMgr());

	RvMutexLock(&term->mutex,IppLogMgr());
	/*Process all observed event */
	if (rvCCTerminalMdmBlockedEventIsObsOn(term))
		processBlockedEventObserved(x);

	/*We assume to have only one Register event for every
	  termination*/
    if (rvCCTerminalMdmBlockedEventIsRegOn(term))
	    processBlockedEventRegisterTerm(x);

	/*Process always the unregister event last, since no events should be
	processed after a termination is unregistered anyway. */
	if (rvCCTerminalMdmBlockedEventIsUnregOn(term))
	{
		processBlockedEventUnregisterTerm(x);
                /* Mutexes should be destructed by now*/
    	return;
	}

	RvMutexUnlock(&term->mutex,IppLogMgr());
	RvMutexUnlock(&term->blockedEventMutex,IppLogMgr());
}


static void  queueBlockedObsEvent(RvCCTerminalMdm * x,RvMdmPackageItem* name,
							       RvMdmMediaStream * media,const RvMdmParameterList * args)
{
	/* Construct observed event and add to linked list */
	RvMdmEvent * event = rvListAllocBack(RvMdmEvent)(&x->blockedEventBuffer);
	/* Don't bother to get the time because the event can be discarded
	   and the delay should be small */
    buildObservedEvent(x,event,name,media,args);
}

/* Processing of the requested events descriptor
   Note: DigitMap descriptor should be processed before this one
0. Stop digitmap timer
1. Copy the requested event descriptor, initialize new observed events
2. Validate the requested events. If there are not supported,send an error reply.
3. For any auditable event, call the audit function and verify that the state is
   acceptable. If not, send error reply
4. For any event with digitmap parameters, find the pkg info,install new digitmap,
   start digitmap timer
5. If bufferActive is set:
   Take one event from buffer and process
*/
void rvMdmTermProcessEvents(RvCCTerminalMdm * x,
								const RvMdmEventsDescriptor * eventsDescr)
{
	size_t i;
	const RvMdmRequestedEvent* reqEvent;

	if (!rvMdmEventsDescriptorIsSet(eventsDescr))
		return;

	/*1. Stop digitmap timer */
	rvMdmTermDeactivateDigitMap(x);

	for (i=0;i<rvMdmEventsDescriptorGetNumEvents(&x->eventsDescr);i++)
    {
		reqEvent = rvMdmEventsDescriptorGetEvent(&x->eventsDescr,i);
		/* 2. Validate the requested events. If they are not supported,send an error reply.*/
		/* Note: should the embedded event get validated as well? */
		if (validateRequestedEvent(x, reqEvent) == RV_FALSE)
			return;

		/* 3. For any event with digitmap parameters, find the pkg info,install new digitmap,*/
		/*    start digitmap timer */
		if (!rvMdmTermProcessDigitMapParameter(x, reqEvent, RV_TRUE))
			return;
	}
}

