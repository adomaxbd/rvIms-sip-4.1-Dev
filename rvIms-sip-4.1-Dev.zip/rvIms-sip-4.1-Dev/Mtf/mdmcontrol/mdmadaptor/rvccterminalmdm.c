/******************************************************************************
Filename   : rvccterminalmdm.c
Description: Implements Mdm Terminal Object
******************************************************************************
                Copyright (c) 2001 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_MDMCONTROL
#include "ipp_inc_std.h"
#include "ippmisc.h"
#include "ippthread.h"
#include "rvlist.h"
#include "rvtypes.h"
#include "rvlog.h"
#include "rvclock.h"
#include "rvstr.h"
#include "rvccprovidermdm.h"
#include "rvccterminalmdm.h"
#include "rvmdmtermevent.h"
#include "rvcctext.h"
#include "rvccCfwMgr.h"
#include "mtfBaseInt.h"
#include "rvccconnsip.h"

#define RV_CCTERMINALMDM_DIGITMAP_LENGTH    4

RvInt32   g_dwBusyToneTime    = 40;
RvInt32   g_dwWarningToneTime = 60;
RvChar  g_conferenceUri[MAX_LINE_NUMBER][50];

RvInt32 PSip_GetBusyToneTime(void)
{
    return g_dwBusyToneTime;
}

RvInt32 PSip_GetWaringToneTime(void)
{
    return g_dwWarningToneTime;
}


void PSip_SetBusyToneTime(RvInt32 dwBusyToneTime)
{
    g_dwBusyToneTime = dwBusyToneTime;
}

void PSip_SetWarningToneTime(RvInt32 dwWarningToneTime)
{
    g_dwWarningToneTime = dwWarningToneTime;
}
void Psip_SetConferenceUri( RvChar* conUri,RvInt32 dwLineIndex)
 {
    if(conUri ==NULL || strlen(conUri)==0 ||strlen(conUri)>=50)
    {
        printf("Psip_SetConferenceUri: uri is not legal\n");
        return;
    }
    if(dwLineIndex<0 || dwLineIndex>=MAX_LINE_NUMBER)
    {
        printf("dwLineIndex is not legal\n");
        return;
    }
    char tmpUri[50] ={0};
    char* tmp;
    strcpy((char*)tmpUri,conUri);
    tmp=strtok((char*)tmpUri,"@"); 
    strcpy((char*)(g_conferenceUri[dwLineIndex]),tmp);
 }
extern int PSip_getLineIndex(void* ptTermDc);
extern RvBool g_dwmaliciouscall[MAX_LINE_NUMBER] ;


/*zhangcg: 20110507*/
RvBool PSip_rvCCTerminalMdmBusyToneTimeOut( void* data);
RvBool PSip_rvCCTerminalMdmWarningToneTimeOut( void* data);
RvBool PSip_rvCCTerminalMdmMaliciousCallTimeOut( void* data);

/*extern RvCCProvider* g_sipProvider;*/

typedef RvVectorIter(RvMdmMediaStreamInfo) RvMdmMediaStreamInfoVectorIter;

rvDeclareFindIf(RvVectorIter, RvMdmMediaStreamInfo)

static char RvCCTerminalDefaultLine[] = "l001";

/*===============================================================================*/
/*===================    P R I V A T E    F U N C T I O N S    ==================*/
/*===============================================================================*/



/*===============================================================================*/
/*============= F U N C T I O N S       I M P L E M E N T A T I O N S ===========*/
/*===============================================================================*/
const RvChar* rvCCTerminalMdmGetTermId(IN RvCCTerminal* term)
{
    RvCCTerminalMdm* x = rvCCTerminalMdmGetImpl(term);
	return (x->terminalId);
}

void rvCCTerminalMdmTerminateAllCalls(RvCCTerminal* t)
{
    RvInt maxConnections = rvCCTerminalGetNumberOfLines(t);
    int i;
	
    for(i=0; i<maxConnections; i++)
    {
        RvCCConnection* c = t->connections[i];
        RvBool callStillAlive = RV_FALSE;
		RvCCTermConnState state = rvCCConnectionGetTermState(c);
        
		/* First unhold held connections otherwise onhook won't be allowed.                      */
		/* Shutting down the toolkit while calls are on hold sometimes results in a memory leak. */
		/* Unholding the calls is the first step to release resources but since the BYE messages */
		/* that are sent after onhook may not be replied before shut down, the SIP connections   */
		/* may not be released and a leak is created                                             */
		if ((state == RV_CCTERMCONSTATE_HELD) || (state == RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD))
		{
			rvCCConnMdmProcessEvent(c, RV_CCTERMEVENT_UNHOLD, &callStillAlive, RV_CCCAUSE_NORMAL); 
		}
        
        if ( (rvCCConnectionGetState(c) != RV_CCCONNSTATE_IDLE) && (rvCCConnectionGetType(c) == RV_CCCONNTYPE_MDM))
        {
            rvCCConnMdmProcessEvent(c, RV_CCTERMEVENT_ONHOOK, &callStillAlive, RV_CCCAUSE_NORMAL);
        }
    }   
}

RvBool rvCCTerminalMdmIsAudioTerminationExist(
    IN RvCCTerminal*            t,
    IN RvCCTerminalAudioType    audio)
{
    RvCCTerminalMdm* x = rvCCTerminalMdmGetImpl(t);

    if (x->termType == RV_CCTERMINALTYPE_ANALOG)
    {
        /* Analog terminations always have audio... */
        return RV_TRUE;
    }

    switch(audio)
    {
        case RV_CCTERMAUDIO_HANDSET:
            return (x->handsetAudioTerm != NULL);

        case RV_CCTERMAUDIO_HANDSFREE:
            return (x->handsfreeAudioTerm != NULL);

        case RV_CCTERMAUDIO_HEADSET:
            return (x->headsetAudioTerm != NULL);

        case RV_CCTERMAUDIO_NONE:
        default :
            return RV_FALSE;
    }
}


/* Switch the audio to the desired output */
/* Note: default audio is handset */
void rvCCTerminalMdmSetActiveAudio(
    IN RvCCTerminal*            t,
    IN RvCCTerminalAudioType    audio)
{
    RvCCTerminalMdm* x = rvCCTerminalMdmGetImpl(t);

    if (x->termType == RV_CCTERMINALTYPE_ANALOG)
    {
        /* Analog gets a special treatment */
    	x->activeAudioTerm = t;
    }
    else
    {
        switch(audio)
        {
        case RV_CCTERMAUDIO_NONE:       x->activeAudioTerm = NULL;
            break;
        case RV_CCTERMAUDIO_HANDSET:    x->activeAudioTerm = x->handsetAudioTerm;
            break;
        case RV_CCTERMAUDIO_HANDSFREE:  x->activeAudioTerm = x->handsfreeAudioTerm;
            break;
        case RV_CCTERMAUDIO_HEADSET:    x->activeAudioTerm = x->headsetAudioTerm;
            break;
        default : break;
    }
}
}

RvCCTerminalAudioType rvCCTerminalMdmGetActiveAudio(IN RvCCTerminal* t)
{
    RvCCTerminalMdm* x;
    
    if (t != NULL)
    {
        x = rvCCTerminalMdmGetImpl(t);

    if (x->termType == RV_CCTERMINALTYPE_ANALOG)
    {
        /* Analog gets a special treatment */
    	return RV_CCTERMAUDIO_NONE;
    }

    if(x->activeAudioTerm == NULL)
        return RV_CCTERMAUDIO_NONE;
    if (x->activeAudioTerm == x->handsetAudioTerm)
        return RV_CCTERMAUDIO_HANDSET;
    if(x->activeAudioTerm == x->handsfreeAudioTerm)
        return RV_CCTERMAUDIO_HANDSFREE;
    if (x->activeAudioTerm == x->headsetAudioTerm)
        return RV_CCTERMAUDIO_HEADSET;
    }

        return RV_CCTERMAUDIO_NONE;
}

/* Set the active audio termination */
void rvCCTerminalMdmSetActiveAudioTerm(
    IN RvCCTerminal*    t,
    IN RvCCTerminal*    at)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);

    if (term->termType != RV_CCTERMINALTYPE_ANALOG)
        term->activeAudioTerm = at;
}

/* Get the active audio termination */
RvCCTerminal* rvCCTerminalMdmGetActiveAudioTerm(IN RvCCTerminal* t)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);

    if (term->termType == RV_CCTERMINALTYPE_ANALOG)
        return t;
    else
        return term->activeAudioTerm;
}

/* Get the active video termination */
RvCCTerminal* rvCCTerminalMdmGetActiveVideoCamTerm(IN RvCCTerminal* t)
{
    RvCCTerminalMdm* term;

    if (t == NULL)
        return NULL;
    
    term = rvCCTerminalMdmGetImpl(t);
    
    if (term->termType == RV_CCTERMINALTYPE_ANALOG)
        return t;
    else
    return term->activeCameraTerm;
}

/* Get the active video termination */
RvCCTerminal* rvCCTerminalMdmGetActiveVideoScrTerm(IN RvCCTerminal* t)
{
    RvCCTerminalMdm* term;

    if (t == NULL)
        return NULL;

    term = rvCCTerminalMdmGetImpl(t);

    if (term->termType == RV_CCTERMINALTYPE_ANALOG)
        return t;
    else
    return term->activeScreenTerm;
}

/* Set the active video termination */
void rvCCTerminalMdmSetActiveVideoCamTerm(
    IN RvCCTerminal*    t,
    IN RvCCTerminal*    at)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);

    if (term->termType != RV_CCTERMINALTYPE_ANALOG)
    term->activeCameraTerm = at;
}

/* Set the active video termination */
void rvCCTerminalMdmSetActiveVideoScrTerm(
    IN RvCCTerminal*    t,
    IN RvCCTerminal*    at)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);

    if (term->termType != RV_CCTERMINALTYPE_ANALOG)
    term->activeScreenTerm = at;
}

RvBool rvCCTerminalMdmMoveSignals(RvCCTerminal* src,RvCCTerminal* dst)
{
    RvCCTerminalMdm* srcTerm;
    RvCCTerminalMdm* dstTerm;

    if (dst==NULL)
        return RV_FALSE;

    if (src != dst) /*Avoid moving signals when switching to same termination (example: off-hook pressed twice)*/
    {
        srcTerm = rvCCTerminalMdmGetImpl(src);
        dstTerm = rvCCTerminalMdmGetImpl(dst);
        RvMutexLock(&srcTerm->mutex,IppLogMgr());
        RvMutexLock(&dstTerm->mutex,IppLogMgr());

        rvMdmTermEventMoveSignals(srcTerm,dstTerm);

        RvMutexUnlock(&dstTerm->mutex,IppLogMgr());
        RvMutexUnlock(&srcTerm->mutex,IppLogMgr());
    }
    return RV_TRUE;
}

void rvCCTerminalMdmStopSignals(IN RvCCTerminal* x)
{
    RvCCTerminal* at;
    RvCCTerminalMdm* term;

    if (x == NULL)
        return;

    at = rvCCTerminalMdmGetActiveAudioTerm(x);
    if (at == NULL)
      return;

    term = rvCCTerminalMdmGetImpl(at);

    /*zhangcg: 20110507*/
    IppTimerStop(&(term->tBusyToneTimer));
    
    IppTimerStop(&(term->tWarningToneTimer));

    RvMutexLock(&term->mutex,IppLogMgr());
    rvMdmTermEventStopSignals(term);
    RvLogInfo(ippLogSource, (ippLogSource,
        "IPP-->Stop Signals, term(%p),atTerm(%p),termMdm(%p)", x, at, term));
    RvMutexUnlock(&term->mutex,IppLogMgr());
}

static void signalParamsForEach(const RvMdmPackageItem *name, const RvMdmParameterValue *value, void *data)
{
    rvMdmSignalSetParameter((RvMdmSignalEx*)data, rvMdmPackageItemGetItem(name),value);
}

static void buildSignalDescr(
    IN RvCCTerminalMdm*         x,
    IN RvMdmSignalsDescriptor*  signalDesc,
    IN const RvChar*            pkg,
    IN const RvChar*            id,
    IN RvMdmParameterList*      args,
    IN RvMdmSignalType          type)
{
    RvMdmSignalEx signal;
    RvMdmPackageItem  item;
    unsigned int duration;

    rvMdmPackageItemConstruct(&item, pkg, id);
    rvMdmSignalExConstructA(&signal, &item, x->alloc);
    rvMdmSignalExSetType(&signal, type);
    duration = 30000; /* default constant value */
    if (args != NULL)
    {
        const RvMdmParameterValue *pVal;
        const char *strVal;
        pVal = rvMdmParameterListGet2(args, "duration");
        if (pVal)
        {
            strVal = rvMdmParameterValueGetValue(pVal);
            sscanf(strVal,"%d",&duration);
            duration /= 10; /* divide 10 to convert from milliseconds  to  1/100 sec */
        }

    }
    rvMdmSignalExSetDuration(&signal, duration);

    if (args != NULL)
    {
        rvMdmParameterListForEach(args, signalParamsForEach, (void *)&signal);
    }
    rvMdmSignalsDescriptorAddSignal(signalDesc, &signal);
    rvMdmSignalExDestruct(&signal);
    rvMdmPackageItemDestruct(&item);
}

static void addSignalParam(RvMdmParameterList* params,const char* id,const char* val)
{
    RvMdmParameterValue value;

    rvMdmParameterValueConstruct(&value, val);
    rvMdmParameterListSet2(params, id, &value);
    rvMdmParameterValueDestruct(&value);

}

static RvBool startSignal(
    IN RvCCTerminalMdm*     x,
    IN const RvChar*        pkg,
    IN const RvChar*        id,
    IN RvMdmParameterList*  args,
    IN RvMdmSignalType      type)
{
    RvMdmSignalsDescriptor signalDesc;
    RvMdmPackageItem pkgItem;

    rvMdmSignalsDescriptorConstructA(&signalDesc, x->alloc);
    buildSignalDescr(x, &signalDesc, pkg, id, args, type);
    rvMdmPackageItemConstruct(&pkgItem, "", "");

    RvMutexLock(&x->mutex,IppLogMgr());
    rvMdmTermProcessNewSignals(x, &signalDesc);
    RvMutexUnlock(&x->mutex,IppLogMgr());

    rvMdmSignalsDescriptorDestruct(&signalDesc);
    rvMdmPackageItemDestruct(&pkgItem);

    return RV_TRUE;
}

RvBool rvCCTerminalMdmStartDialToneSignal(IN RvCCTerminal* x)
{
    if (x == NULL)
        return RV_FALSE;
    RvLogInfo(ippLogSource,(ippLogSource, "IPP-->Start Signal: DIAL TONE"));
    return rvCCTerminalMdmStartSignalAudio(x, "cg", "dt", NULL);
}

RvBool rvCCTerminalMdmStartRingingSignal(IN RvCCTerminal* x)
{
    RvCCTerminalMdm* term;
    RvBool res;

    if (x == NULL)
	{
        return RV_FALSE;
	}

    term = rvCCTerminalMdmGetImpl(x);

    if (term->termType == RV_CCTERMINALTYPE_ANALOG)
    {
	    res = startSignal(term, "al", "ri", NULL, RV_MDMSIGNAL_TIMEOUT);
    }
    else
    {
		RvMdmParameterList params;
		const RvChar*  ringStr;
		RvCCConnection* conn  = rvCCTerminalGetActiveConnection(x);
		RvCCConnection* party = rvCCConnectionGetConnectParty(conn);

		rvMdmParameterListConstruct(&params);

		if ((rvCCConnectionGetState(conn) != RV_CCCONNSTATE_DISCONNECTED) &&
			(party != NULL))
		{
			if (strcmp((ringStr = rvCCConnectionGetDistinctiveRinging(party)), ""))
			{
				addSignalParam(&params, "distRing", ringStr);
				RvLogInfo(ippLogSource,(ippLogSource,
										"rvCCTerminalMdmStartRingingSignal- applying distinctive ringing %s",
										 ringStr));
			}
		}
		addSignalParam(&params, "state", "on");
		addSignalParam(&params, "Indid", "ir");

		res = rvCCTerminalMdmStartSignalUI(x, "ind", "is", &params);

		rvMdmParameterListDestruct(&params);

    }

    RvLogInfo(ippLogSource,(ippLogSource, "IPP-->Start Signal: RINGING,term(%p),ret(%d)",x, res));

    return res;
}

RvBool rvCCTerminalMdmStopRingingSignal(IN RvCCTerminal* x)
{
    RvCCTerminalMdm* term;
    RvMdmParameterList params;
    RvBool res = RV_TRUE;

    if (x == NULL)
        return RV_FALSE;

    term = rvCCTerminalMdmGetImpl(x);

    if (term->termType != RV_CCTERMINALTYPE_ANALOG)
    {
    rvMdmParameterListConstruct(&params);

    addSignalParam(&params, "state", "off");
    addSignalParam(&params, "Indid", "ir");

    res = rvCCTerminalMdmStartSignalUI(x, "ind", "is", &params);

    rvMdmParameterListDestruct(&params);
    }

    RvLogInfo(ippLogSource, (ippLogSource,
        "IPP-->Stop Signal: RINGING,term(%p),ret(%d)", x, res));

    return res;
}

RvBool rvCCTerminalMdmStartRingbackSignal(IN RvCCTerminal* x)
{
    RvCCTerminalMdm* term;
    RvBool res;

    if (x == NULL)
        return RV_FALSE;

    term = rvCCTerminalMdmGetImpl(x);

    if (term->termType == RV_CCTERMINALTYPE_ANALOG)
    {
    	res = startSignal(term, "cg", "rt", NULL, RV_MDMSIGNAL_TIMEOUT);
    }
    else
    {
    RvMdmParameterList params;
        const RvChar*  ringStr;
    RvCCConnection* conn  = rvCCTerminalGetActiveConnection(x);
    RvCCConnection* party = rvCCConnectionGetConnectParty(conn);

    if (strcmp((ringStr = rvCCConnectionGetDistinctiveRingback(party)), ""))
    {
        /* a distinctive ringback was included in the ringing message Alert-Info header */
        rvMdmParameterListConstruct(&params);
        addSignalParam(&params, "distRing", ringStr);
        res = rvCCTerminalMdmStartSignalAudio(x, "cg", "rt", &params);
        rvMdmParameterListDestruct(&params);
        RvLogInfo(ippLogSource,(ippLogSource,
                                "rvCCTerminalMdmStartRingbackSignal- applying distinctive ringback %s",
                                 ringStr));
    }
    else
        res = rvCCTerminalMdmStartSignalAudio(x, "cg", "rt", NULL);
    }

    RvLogInfo(ippLogSource,(ippLogSource, "IPP-->Start Signal: RINGBACK"));

    return res;
}

RvBool rvCCTerminalMdmStartCallWaitingSignal(IN RvCCTerminal* x)
{
    if (x == NULL)
        return RV_FALSE;

    RvLogInfo(ippLogSource,(ippLogSource, "IPP-->Start Signal: CALL WAITING"));
    return rvCCTerminalMdmStartSignalAudio(x, "cg", "cw", NULL);
}

RvBool rvCCTerminalMdmStartCallWaitingCallerSignal(IN RvCCTerminal* x)
{
    if (x == NULL)
        return RV_FALSE;
    RvLogInfo(ippLogSource,(ippLogSource, "IPP-->Start Signal: CALLER CALL WAITING"));
    return rvCCTerminalMdmStartSignalAudio(x, "cg", "cr", NULL);
}

RvBool rvCCTerminalMdmStartBusySignal(IN RvCCTerminal* x)
{
    if (x == NULL)
        return RV_FALSE;
    RvLogInfo(ippLogSource,(ippLogSource, "IPP-->Start Signal: BUSY TONE"));

    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
    if(term == NULL)
    {
        return RV_FALSE;
    }
    
    IppTimerStart(&(term->tBusyToneTimer), IPP_TIMER_RESTART_IF_STARTED, (term->dwBusyToneTime)*1000);
    
    return rvCCTerminalMdmStartSignalAudio(x, "cg", "bt", NULL);
}

RvBool rvCCTerminalMdmStartWarningSignal(IN RvCCTerminal* x)
{
    if (x == NULL)
        return RV_FALSE;
    RvLogInfo(ippLogSource,(ippLogSource, "IPP-->Start Signal: BUSY TONE"));
    
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
    if(term == NULL)
    {
        return RV_FALSE;
    }
    
    IppTimerStart(&(term->tBusyToneTimer), IPP_TIMER_RESTART_IF_STARTED, (term->dwBusyToneTime)*1000);
    
    return rvCCTerminalMdmStartSignalAudio(x, "cg", "bt", NULL);
}

RvBool rvCCTerminalMdmStartWarningExSignal(IN RvCCTerminal* x)
{
    if (x == NULL)
        return RV_FALSE;
    RvLogInfo(ippLogSource,(ippLogSource, "IPP-->Start Signal: WARNING TONE EX"));
    
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
    if(term == NULL)
    {
        return RV_FALSE;
    }
    
    IppTimerStart(&(term->tWarningToneTimer), IPP_TIMER_RESTART_IF_STARTED, (term->dwWarningToneTime)*1000);
    
    return rvCCTerminalMdmStartSignalAudio(x, "cg", "wt", NULL);
}

void rvDtmfAddParam(RvMdmParameterList* list, char* paramName, char* paramValue)
{
    RvMdmPackageItem pkgItem;

    rvMdmPackageItemConstruct(&pkgItem, "", paramName);
    rvMdmParameterListOr(list, &pkgItem, paramValue);
    rvMdmPackageItemDestruct(&pkgItem);
}

RvBool rvCCTerminalMdmStartDTMFTone(
    IN RvCCTerminal*        x,
	IN RvInt32              lineId,
    IN RvDtmfParameters*    dtmfParam)
{
    RvBool rc;
    RvChar val[12];
    RvChar id[3];
    RvChar digit = dtmfParam->digit;
	RvMdmParameterList paramsList;

    if (x == NULL)
        return RV_FALSE;

    if (digit=='e' || digit=='E' || digit=='*')
        strcpy(id, "ds");
    else if (digit=='f' || digit=='F' || digit=='#')
        strcpy(id, "do");
    else
        RvSprintf(id, "d%c", digit);

    rvMdmParameterListConstruct(&paramsList);
    RvSprintf(val, "%d", dtmfParam->duration);
    rvDtmfAddParam(&paramsList, "duration", val);
	RvSnprintf(val, sizeof(val), "l%03d", lineId);
	rvDtmfAddParam(&paramsList, "lineId", val);
    rc = rvCCTerminalMdmStartSignalAudio(x, "dg", id, &paramsList);
    rvMdmParameterListDestruct(&paramsList);

    return rc;
}

RvBool rvCCTerminalMdmStopDTMFTone(IN RvCCTerminal* x)
{
    RvCCTerminalMdm* term;
    
    if (x == NULL)
        return RV_FALSE;
    
    term = rvCCTerminalMdmGetImpl(x);

    if (term->termType != RV_CCTERMINALTYPE_ANALOG)
        rvCCTerminalMdmStopSignals(x);

    return RV_TRUE;
}

RvBool rvCCTerminalMdmSetHoldInd(RvCCTerminal* x, RvBool on)
{
    RvMdmParameterList params;
    RvBool res;

    if (x == NULL)
        return RV_FALSE;

    rvMdmParameterListConstruct(&params);

    addSignalParam(&params, "Indid", "il");
    addSignalParam(&params, "state", on ? "on" : "off");

    res = rvCCTerminalMdmStartSignalUI(x, "ind", "is", &params);

    rvMdmParameterListDestruct(&params);

    return res;
}

RvBool rvCCTerminalMdmSetMuteInd(RvCCTerminal* x, RvBool on)
{
    RvMdmParameterList params;
    RvBool res;

    rvMdmParameterListConstruct(&params);

    addSignalParam(&params, "Indid", "mu");
    addSignalParam(&params, "state", on ? "on" : "off");

    res = rvCCTerminalMdmStartSignalUI(x, "ind", "is", &params);

    rvMdmParameterListDestruct(&params);

    return res;
}

RvBool rvCCTerminalMdmSetAudioInd(
    RvCCTerminal*               x,
                                  char*                     id,
    RvCCTerminalIndState        state)
{
    RvMdmParameterList params;
    RvBool res;

    if (x == NULL)
        return RV_FALSE;

    rvMdmParameterListConstruct(&params);

    /*Ignore requests for Handset, since there are no indicators for Hook Switch*/
    if ((!strcmp(id, "hs")) || (!strcmp(id, "")))
    {
        return RV_TRUE;
    }

    addSignalParam(&params, "Indid", id);

    switch (state)
    {
        case RV_INDSTATE_ON:
            addSignalParam(&params, "state", "on");
            break;
        case RV_INDSTATE_OFF:
            addSignalParam(&params, "state", "off");
            break;

        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    res = rvCCTerminalMdmStartSignalUI(x, "ind", "is", &params);

    rvMdmParameterListDestruct(&params);

    return res;

}

RvBool rvCCTerminalMdmSetLineInd(RvCCTerminal* x, int lineId, RvCCTerminalIndState state)
{
    RvMdmParameterList params;
    char strLineId[12];
    RvBool res;

    if (x == NULL)
        return RV_FALSE;

    rvMdmParameterListConstruct(&params);

    RvSnprintf(strLineId, sizeof(strLineId), "l%03d", lineId);
    addSignalParam(&params, "Indid", strLineId);

    switch (state)
    {
        case RV_INDSTATE_ON:
            addSignalParam(&params, "state", "on");
            break;
        case RV_INDSTATE_OFF:
            addSignalParam(&params, "state", "off");
            break;
        case RV_INDSTATE_BLINK:
        case RV_INDSTATE_FAST_BLINK:
            addSignalParam(&params, "state", "blink");
            break;
        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    res = rvCCTerminalMdmStartSignalUI(x, "ind", "is", &params);

    rvMdmParameterListDestruct(&params);

    return res;

}

/* Special signal to send to inform when the line is active
   (Needed for the application to control handsfree) */
/* Define 2 special signals: la (line active) and li (line inactive) */
RvBool rvCCTerminalMdmSendLineActive(RvCCTerminal* x, int lineId, RvBool active)
{
    RvMdmParameterList params;
    char strLineId[12];
    RvBool res;
    char* signal = "";

    if (x == NULL)
        return RV_FALSE;

    rvMdmParameterListConstruct(&params);

    RvSnprintf(strLineId, sizeof(strLineId), "l%03d", lineId);
    addSignalParam(&params, "LineId", strLineId);

    switch (active)
    {
        case RV_TRUE:
            signal = "la";
            break;
        case RV_FALSE:
            signal = "li";
            break;
        default:
            break;
    }

    res = rvCCTerminalMdmStartSignalUI(x, "rvcc", signal, &params);

    rvMdmParameterListDestruct(&params);
    return res;
}

/*
Use our own package to send all the caller id information
Send all the caller id info so the application  can build the signal
*/
RvBool rvCCTerminalMdmSendCallerId(
    IN RvCCTerminal*    x,
    IN const RvChar*    callerName,
    IN const RvChar*    callerNumber,
    IN const RvChar*    callerAddress,
    IN const RvChar*    callerId)
{
    RvMdmParameterList params;
    RvBool res;

    if (x == NULL)
        return RV_FALSE;

    rvMdmParameterListConstruct(&params);

    addSignalParam(&params, "name", callerName ? callerName : "");
    addSignalParam(&params, "number", callerNumber ? callerNumber : "");
    addSignalParam(&params, "address", callerAddress ? callerAddress : "");
    addSignalParam(&params, "id", callerId ? callerId : "");

    res = rvCCTerminalMdmStartSignalUI(x, "rvcc", "callerid", &params);

    rvMdmParameterListDestruct(&params);

    return res;
}


RvBool rvCCTerminalMdmSetDisplay(
    IN RvCCTerminal*    x,
    IN const RvChar*    text,
    IN RvInt32          row,
    IN RvInt32          column)
{
    RvMdmParameterList  params;
    RvBool              res;
    RvSize_t            strLen;
    RvChar              tmpStr[11];

    if (x == NULL)
        return RV_FALSE;

    strLen = strlen(text);

    rvMdmParameterListConstruct(&params);

    /*Set Row*/
    RvSnprintf(tmpStr, sizeof(tmpStr), "%d", row);
    addSignalParam(&params, "r", tmpStr);

    /*Set Column*/
    RvSnprintf(tmpStr, sizeof(tmpStr), "%d", column);
    addSignalParam(&params, "c", tmpStr);

    /*Set Text*/
    if ((text[0] != '\0') && (text[1] == '\0'))
    {
        /* Single character text. "Replace" 'e' & 'f' with '*' & '#' */
        if (text[0] == 'e')
            addSignalParam(&params, "str", "*");
        else if (text[0] == 'f')
            addSignalParam(&params, "str", "#");
        else
            addSignalParam(&params, "str", text);
    }
    else
    {
        addSignalParam(&params, "str", text);
    }

    res = rvCCTerminalMdmStartSignalUI(x, "dis", "di", &params);

    rvMdmParameterListDestruct(&params);

    /* Update internal row, column */
    x->displayColumn = column + (int)strLen;
    x->displayRow = row;

    RvLogInfo(ippLogSource, (ippLogSource, "IPP-->SET DISPLAY: %s", text));
    return res;
}

RvBool rvCCTerminalMdmClearDisplay(IN RvCCTerminal* x)
{
    if (x == NULL)
        return RV_FALSE;

    /* Update internal row, column */
    x->displayColumn = 0;
    x->displayRow = 0;

    return rvCCTerminalMdmStartSignalUI(x, "dis", "cld", NULL);
}

static void buildReqEventCE(RvCCTerminalMdm* x, RvMdmDigitMapDescriptor* dmDescr,
                            RvBool activateDigitMap)
{
    RvMdmRequestedEvent reqEvent;
    RvMdmPackageItem pkgItem;

    rvMdmPackageItemConstruct(&pkgItem, "kp", "ce");
    rvMdmRequestedEventConstruct(&reqEvent, &pkgItem);
    rvMdmDigitMapDescriptorCopy(&reqEvent.digitMap, dmDescr);

    RvMutexLock(&x->mutex,IppLogMgr());
    rvMdmTermProcessDigitMapParameter(x, &reqEvent,activateDigitMap);
    RvMutexUnlock(&x->mutex,IppLogMgr());

    rvMdmRequestedEventDestruct(&reqEvent);
    rvMdmPackageItemDestruct(&pkgItem);
}

void rvCCTerminalMdmInstallDigitMap(
    IN RvCCTerminal*        x,
    IN RvBool               activateDigitMap)
{
    RvCCTerminalMdm* term;
    RvMdmDigitMapDescriptor     dmDescr;
    const RvMdmDigitMap* dm;
    RvString name;

    if (x == NULL)
        return;
    term = rvCCTerminalMdmGetImpl(x);

    rvStringConstruct(&name, "dialplan0", term->alloc);
    dm = rvMdmTermGetDigitMap(term, &name);
    rvMdmDigitMapDescriptorConstruct(&dmDescr, "dialplan0", dm);

    RvMutexLock(&term->mutex,IppLogMgr());
    buildReqEventCE(term, &dmDescr,activateDigitMap);
    rvMdmTermProcessDigitMap(term, &dmDescr);
    RvMutexUnlock(&term->mutex,IppLogMgr());

    rvMdmDigitMapDescriptorDestruct(&dmDescr);
    rvStringDestruct(&name);

}

void rvCCTerminalMdmSetWaitForDigits(RvCCTerminal* x)
{
    if (x != NULL)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
    rvMdmTermActivateDigitMap(term);
}
}


/* Map events for the ui termination */
RvCCTerminalEvent rvCCTerminalMdmMapEvent(RvCCTerminal*     x,
                                          const char*       pkg,
                                          const char*       id,
                                          RvMdmParameterList* args,
                                          char*             key)
{
    RvCCTerminalEvent event = RV_CCTERMEVENT_UNKNOWN;

    if (!rvStrIcmp(pkg, "al"))
    {
        if (!rvStrIcmp(id, "of"))
        {
            return RV_CCTERMEVENT_OFFHOOK;
        }
        else if (!rvStrIcmp(id, "on"))
        {
            return RV_CCTERMEVENT_ONHOOK;
        }
    }
    else if (!rvStrIcmp(pkg, "dd"))
    {
        if (!rvStrIcmp(id, "ce"))
        {
            return RV_CCTERMEVENT_DIALCOMPLETED;
        }
        else if (rvMdmDigitMapTranslateDDEvent(id, NULL) != RV_MDMEVENT_NOTFOUND)
        {
            return RV_CCTERMEVENT_DIGITS;
        }
    }
    else if (!rvStrIcmp(pkg, "dd-end"))
    {
        if (rvMdmDigitMapTranslateDDEvent(id, NULL) != RV_MDMEVENT_NOTFOUND)
        {
            return RV_CCTERMEVENT_DIGIT_END;
        }
    }

    else if (!rvStrIcmp(pkg,"kf"))
    {
        const RvMdmParameterValue * param = NULL;
        const char* keyId = "";

        if (args != NULL)
        {
            param = rvMdmParameterListGet2((RvMdmParameterList*)args, "keyid");
        
            if (param != NULL)
            {
                keyId = rvMdmParameterValueGetValue(param);    
            }
        }
        
        if(!rvStrIcmp(id,"ku"))
        {
            if(!rvStrIcmp(keyId,"kh"))
                event = RV_CCTERMEVENT_ONHOOK;
            else if(!rvStrIcmp(keyId,"kl"))
                event = RV_CCTERMEVENT_HOLDKEY;
            else if(!rvStrIcmp(keyId,"kc"))
                event = RV_CCTERMEVENT_CONFERENCE;
            else if(!rvStrIcmp(keyId,"kt"))
                event = RV_CCTERMEVENT_TRANSFER;
            else if(!rvStrIcmp(keyId,"kbt"))
                event = RV_CCTERMEVENT_BLIND_TRANSFER;
            else if(!rvStrIcmp(keyId,"mu"))
                event = RV_CCTERMEVENT_MUTE;
            else if(!rvStrIcmp(keyId,"hf") )
                event = RV_CCTERMEVENT_HANDSFREE;
            else if(!rvStrIcmp(keyId,"ht"))
                event = RV_CCTERMEVENT_HEADSET;
            else if(!rvStrIcmp(keyId,"redial"))
                event = RV_CCTERMEVENT_REDIAL;

            else if((rvStrIcmp(keyId,"cfwu") == 0) || (rvStrIcmp(keyId,"cfwb") == 0) || (rvStrIcmp(keyId,"cfnr") == 0))
            {
                    event = RV_CCTERMEVENT_CFW;
            }
            /*Note: make case insensitive*/
            else if(!strncmp(keyId,"l",1))
            {
                strcpy(key,keyId);
                event = RV_CCTERMEVENT_LINE;
            }
        }
        else if(!rvStrIcmp(id,"kd"))
        {
            if(!rvStrIcmp(keyId,"kh"))
			{
                event = RV_CCTERMEVENT_OFFHOOK;
			}
        }
    }
    else if(!rvStrIcmp(pkg,"kp"))
    {
        if(!rvStrIcmp(id,"ce"))
        {
            event = RV_CCTERMEVENT_DIALCOMPLETED;
        }
        else if(!rvStrIcmp(id,"kd"))
		{
            event = RV_CCTERMEVENT_DIGITS;
		}
        /* Use later to control stop playing DTMF tone
           when dialing digits*/
        else if(!rvStrIcmp(id,"ku"))
		{
            event = RV_CCTERMEVENT_DIGIT_END;
		}
    }

    /*Radvision Internal package - Gateway active event*/
    else if(!rvStrIcmp(pkg,"rvcc"))
    {
        if(!rvStrIcmp(id,"ga"))
            event = RV_CCTERMEVENT_GW_ACTIVE;
        else if(!rvStrIcmp(id,"reject"))
        {
            const RvMdmParameterValue * param;
            const char* keyId = RvCCTerminalDefaultLine ; /* default key */

            if (args != NULL)
            {
                param = rvMdmParameterListGet2((RvMdmParameterList*)args, "keyid");
                if (param != NULL)
                    keyId = rvMdmParameterValueGetValue(param);
            }
            strcpy(key,keyId);

            event = RV_CCTERMEVENT_REJECT_KEY;
        }
    }

    /*Radvision Internal package - Modify media*/
    else if(!rvStrIcmp(pkg,"media"))
    {
        if(!rvStrIcmp(id,"modify"))
		{
            event = RV_CCTERMEVENT_MODIFYMEDIA;
		}
		else
			if (!rvStrIcmp(id,"update"))
			{
				event = RV_CCTERMEVENT_MODIFYMEDIA_BY_UPDATE;
			}

    }

    else if (!rvStrIcmp(pkg,"makecall"))
    {
        RvCCTerminalMdm*    term = rvCCTerminalMdmGetImpl(x);
 
        rvStringAssign(&(term)->dialString, id);

        /* This will send DIALCOMPLETED event to state machine*/
        term->digitMapStat = RV_MDMDIGITMAP_UNAMBIGUOUSMATCH;
        rvMdmTermDigitMapTimerProcess(term);

        /* Stop dial tone timer that was started after going off hook*/
        IppTimerStop(rvCCTerminalMdmGetDialToneTimer(x));
        rvCCTerminalMdmStopSignals(x);

        event = RV_CCTERMEVENT_NONE;
    }
	/* User event, unknown to MTF, will be processed by application. */
	else if (!rvStrIcmp(pkg,"user"))
    {
		if(!rvStrIcmp(id,"user"))
		{
			const RvMdmParameterValue * param = NULL;
			const char* keyId = "";

			param = rvMdmParameterListGet2((RvMdmParameterList*)args, "keyid");
			
            if (param != NULL)
            {
                keyId = rvMdmParameterValueGetValue(param); 
				event = atoi(keyId);
            }            
		}
	}
  
    return event;
}


char* rvCCTerminalMdmGetDialString(RvCCTerminal* x)
{
    RvCCTerminalMdm* term;

    if (x == NULL)
        return NULL;
    
    term = rvCCTerminalMdmGetImpl(x);
    return  (char*)rvStringGetData(&(term)->dialString);
}

void rvCCTerminalMdmResetDialString(RvCCTerminal* x)
{
    if (x != NULL)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
    rvStringAssign(&(term)->dialString,"");
}
}



/******************************************************************************
*  rvCCTerminalMdmIsOutOfBandDtmfEnabled
*  ----------------------------
*  General :        get the status of OOD according the configuration file
*
*  Return Value:    RV_TRUE(supported),RV_FALSE(not supported).
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x            terminal object.
*       .
*
*
*
*
*  Output          None.
*
******************************************************************************/
RvBool rvCCTerminalMdmIsOutOfBandDtmfEnabled(RvCCTerminal* x)
{
    RvCCTerminalMdm* term;

    if (x == NULL)
        return RV_FALSE;
    
    term = rvCCTerminalMdmGetImpl(x);

    return term->outOfBandDtmfRelayEnabled;
}

const char* rvCCTerminalMdmGetPhoneNumber(RvCCTerminal* x)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
    RvMdmTermPhoneNumbers* phoneNumbers = rvCCTerminalMdmGetPhoneNumbers(term);

    /* return the first element*/
    if (rvMdmTermPhoneNumbersGetSize(phoneNumbers)<1)
        return NULL;
    else
        return rvMdmTermPhoneNumbersGetByIndex(phoneNumbers, 0);
}

RvBool rvCCTerminalMdmIsDtmfPlayEnabled(RvCCTerminal* x)
{
    RvCCTerminalMdm* term;

    if (x == NULL)
        return RV_FALSE;

    term = rvCCTerminalMdmGetImpl(x);

    return term->playDtmfEnabled;
}


/*
static void sendOnHookEvent(RvCCTerminal* x)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
    RvMdmTerm* mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
    RvMdmParameterList params;
    RvMdmPackageItem item;

    rvMdmParameterListConstruct(&params);
    rvMdmPackageItemConstruct(&item, "", "keyid");
    rvMdmParameterListOr(&params, &item, "kh");

    rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &params);

    rvMdmPackageItemDestruct(&item);
    rvMdmParameterListDestruct(&params);
}
*/
RvBool rvCCTerminalMdmDialToneTimerExpired( void* data)
{
    RvCCTerminal* t = (RvCCTerminal*) data;
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
    RvCCConnection* conn;

    RvLogInfo(ippLogSource, (ippLogSource,
        "Dial Tone Timer Expired for Termination: %s (%p)", rvCCTerminalGetId(t), t));

    /*Sending On-Hook event will disconnect the connection and stop dial tone.*/
/*  sendOnHookEvent(t);*/

    /*Bring to idle state so no dialing will be accepted */
    conn = rvCCTerminalGetActiveConnection(t);
    rvMdmTermDeactivateDigitMap(term);
    rvCCConnectionSetState(conn, RV_CCCONNSTATE_DISCONNECTED);
    rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_IDLE);

    rvCCTerminalMdmStartWarningSignal(t);

    return RV_TRUE;
}

RvBool rvCCTerminalMdmRegisterCompleteTimerExpired( void* data)
{
	RvCCTerminal* t = (RvCCTerminal*) data;

	RvLogInfo(ippLogSource, (ippLogSource,
		"Register complete Timer Expired for Termination: %s (%p)", rvCCTerminalGetId(t), t));

	rvMtfRegisterTermReportStatus( t, RV_TRUE);

	return RV_TRUE;
}

/*===============================================================================*/
/*============= C A L L B A C K     I M P L E M E N T A T I O N S ===============*/
/*===============================================================================*/

RvMdmDigitMapMatchType terminalMdmMatchDigitMap(
    IN RvMdmXTerm*      xTerm,
    IN const RvChar*    dialString,
    IN unsigned int*    timeDuration)
{
    RvCCTerminal* t = (RvCCTerminal*)xTerm;
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
    RvMdmDigitMapMatchType match;
    match = PSip_SpecialDM_Match(term, dialString);
    
    if(match == RV_MDMDIGITMAP_NOMATCH)
        return rvMdmDigitMapMatch(&term->digitMap, dialString, timeDuration);
    if(match == RV_MDMDIGITMAP_UNAMBIGUOUSMATCH)
    {
        *timeDuration = 0;
    }
    else if(match == RV_MDMDIGITMAP_PARTIALMATCH)
    {
        *timeDuration = term->digitMap.shortTimeout;        
    }
    return match;
    
}

RvMdmTermType terminalMdmGetTermType(IN RvMdmXTerm* xTerm)
{
    RvCCTerminal* t = (RvCCTerminal*)xTerm;
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
    return (term->type);

}

RvStatus terminalMdmSetPhoneNumber(
    IN RvMdmTerm*       x,
    IN const RvChar*    number)
{
    RvStatus status;
    RvCCTerminal* t = (RvCCTerminal *)rvMdmTermGetXTerm_(x);
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
    RvMdmTermPhoneNumbers* phoneNumbers = rvCCTerminalMdmGetPhoneNumbers(term);

    if (IppUtilIsNumberValid(number) == RV_FALSE)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"IPP-->Failed to Set Phone Number: %s - Number is invalid", number));
        return RV_ERROR_BADPARAM;
    }

    status = rvMdmTermPhoneNumbersAdd(phoneNumbers, number);

    RvLogInfo(ippLogSource,(ippLogSource,"IPP-->Set Phone Number(%s)=%d", number, status));

    return status;
}

RvBool terminalMdmModifyMedia(
    IN      RvMdmTerm*  x,
    INOUT   RvSdpMsg*   sdpMsg,
	IN      RvChar*     id )
{
    RvMdmMediaStreamInfo    newMedia;
    RvMdmStreamDescriptor* newStreamDescr = NULL;

    RvLogEnter(ippLogSource,(ippLogSource,
        "terminalMdmModifyMedia(x=%p, sdpMsg=%p)",x, sdpMsg));

    rvMdmMediaStreamInfoConstructA(&newMedia, 0, prvDefaultAlloc);

    /* Store new media in the terminal*/
    newStreamDescr = rvMdmMediaStreamInfoGetStreamDescriptor(&newMedia);

    rvMdmStreamDescriptorAddLocalDescriptor(newStreamDescr, sdpMsg);
    rvMdmStreamDescriptorSetMode(newStreamDescr, RV_MDMSTREAMMODE_SENDRECV);

    rvMdmTermProcessEvent(x, "media", id , (RvMdmMediaStreamInfo*)&newMedia, NULL);

    rvMdmMediaStreamInfoDestruct(&newMedia);

    RvLogLeave(ippLogSource,(ippLogSource, "terminalMdmModifyMedia()=1"));
     return RV_TRUE;
}


/*===============================================================================*/
/*======================= T E R M I N A L   A P I ===============================*/
/*===============================================================================*/
RvCCTerminal* rvCCTerminalMdmSelectRtpTerm(RvCCTerminalMdm* term, RvCCConnection* c)
{
    RvCCProvider* p = rvCCTerminalMdmGetProvider(term);
    RvMdmTermMgr* mgr = rvCCTerminalMdmGetTermMgr(term);
    RvCCTerminal* tempT;
    RvCCTerminalMdm* ephTerm;
    RvMdmTerm* mdmEphTerm;
    RvMdmTerm* mdmTerm;
    void* userData;
    RvMdmTerm* rtpTerm;
    RvCCTerminal* ephT;
    RvMdmTermDefaultProperties termPropertiesTmp;
    char termName[128];
    static int termNum = 1;

    /*create temporary term*/
    rvMdmTermDefaultPropertiesConstruct(&termPropertiesTmp);
    /*as  termPropertiesTmp is empty, as no digit map will be built in terminal*/
    tempT = rvCCProviderMdmCreateTerminal(p, RV_CCTERMINALTYPE_EPHEMERAL, "rtp", 0, &termPropertiesTmp);/*create temp term*/
    rvMdmTermDefaultPropertiesDestruct (&termPropertiesTmp);

    ephTerm = rvCCTerminalMdmGetImpl(tempT);
    mdmEphTerm = rvCCTerminalMdmGetMdmTerm(ephTerm);
    mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
    userData = rvMdmTermGetUserData(mdmTerm);

    RvMutexLock(&term->mutex,IppLogMgr());
    rvMdmTermConstruct_(mdmEphTerm, NULL, tempT);
    rvCCTerminalMdmSetType(ephTerm, RV_MDMTERMTYPE_UNKNOWN);

    /*Set user data of line termination in the temporary ephemeral
      termination, so in this callback the user will have an access to his data*/
    rvMdmTermSetUserData(mdmEphTerm, userData);

	/* Try the deprecated callback first... */
	if (mgr->selectF != NULL)
	{
		if ((rtpTerm = rvMdmTermMgrSelectTermination_(mgr, mdmEphTerm)) == NULL)
		{
			RvLogInfo(ippLogSource, (ippLogSource,
				"Select Termination is NULL:%s, Line:%d (%p)",
				rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(c), c));
			RvMutexUnlock(&term->mutex,IppLogMgr());
			return NULL;
		}
	}
	/* Deprecated callback is not registered... */
	else
	{
		RvMtfBaseMgr* mtfMgr = rvGetMtfMgrByMdmTerm(mdmTerm);

		sprintf(termName, "rtp/%d", termNum++);
		rtpTerm = rvMdmTermMgrRegisterEphemeralTermination(mgr, mtfMgr->rtpClass, termName, NULL);
		if (rtpTerm == NULL)
		{
			RvLogInfo(ippLogSource, (ippLogSource,
				"Select Termination is NULL:%s, Line:%d (%p)",
				rvCCTerminalMdmGetId(ephTerm), rvCCConnectionGetLineId(c), c));
			return NULL;
		}
	}
    rvMdmTermSetUserData(rtpTerm, userData);


    /*remove temp terminal*/
    rvCCProviderMdmRemoveTerminal(p, tempT);
	rvCCProviderMdmReleaseTerminal(tempT);

    rvCCConnMdmSetEphTerm(c, rtpTerm);
    ephT = rvCCConnMdmGetEphXTerm(c);

    rvCCTerminalSetEphemeralActiveConnection(ephT, c);

    RvMutexUnlock(&term->mutex,IppLogMgr());
    return ephT;


}

static void buildPhoneNumberDigitmap(RvMdmDigitString* digitString, int digitNum)
{
    RvMdmDigitPosition  digitPosition;
    int i;

    rvMdmDigitPositionConstruct(&digitPosition);
    rvMdmDigitPositionAddEvents(&digitPosition, (char) '0', (char) '9');
    for (i=0; i<digitNum ; ++i)
        rvMdmDigitStringAddElement(digitString, &digitPosition);

    rvMdmDigitPositionDestruct(&digitPosition);
}

/* IP Address Digitmap of the form: 001*000*000*000* (dot is replaced by star) */
static void buildIpAddressDigitmap(RvMdmDigitString* digitString)
{
    RvMdmDigitPosition  digitPosition, digitPosition2;
    int i, j;

    rvMdmDigitPositionConstruct(&digitPosition);
    rvMdmDigitPositionConstruct(&digitPosition2);
    rvMdmDigitPositionAddEvents(&digitPosition, (char) '0', (char) '9');
    rvMdmDigitPositionAddEvents(&digitPosition2, (char) 'e', (char) 'e');
    for (i=0; i<4 ; ++i) {
        for (j=0 ; j<3 ; j++) {
            rvMdmDigitStringAddElement(digitString, &digitPosition);
        }
        rvMdmDigitStringAddElement(digitString, &digitPosition2);
    }

    rvMdmDigitPositionDestruct(&digitPosition);
    rvMdmDigitPositionDestruct(&digitPosition2);
}

void rvCCTerminalMdmSetHoldingConnEx(RvCCTerminal* t, RvCCConnection* c)
{
    (rvCCTerminalMdmGetImpl(t))->holdingConnection=c;

}
/***************************************************************************
 * rvCCTerminalMdmCreateDefaultDigitMap
 * ------------------------------------------------------------------------
 * General:  Creates a default digit map which represents "XXXX" pattern 
 *           and IP dial pattern
 *           This digit map is created since the user has not supplied 
 *           one. 
 *           The digitMap should be constructed prior to this function
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   digitMap    - A pointer to a digit map structure
 ***************************************************************************/
void rvCCTerminalMdmCreateDefaultDigitMap(RvMdmDigitMap* digitMap)
{
	RvMdmDigitString    digitString;

	rvMdmDigitStringConstruct(&digitString);
	/* add a phone number digitmap */
    buildPhoneNumberDigitmap(&digitString, RV_CCTERMINALMDM_DIGITMAP_LENGTH);
    rvMdmDigitMapAddPattern(digitMap, &digitString);
	
    rvMdmDigitStringClear(&digitString);
	
    /* add an ip address digitmap */
    buildIpAddressDigitmap(&digitString);
    rvMdmDigitMapAddPattern(digitMap, &digitString);

	rvMdmDigitStringDestruct(&digitString);

	RvLogInfo(ippLogSource, (ippLogSource,
		         "rvCCTerminalMdmCreateDefaultDigitMap: created a digit map with patterns XXXX|XXX*XXX*XXX*XXX"));
}

void setTermDigitMap(RvCCTerminalMdm* x, RvCCProvider* p)
{

    RvString            digitmapName;
	RvMdmDigitMap*      digitMapPtr;


	digitMapPtr = rvCCProviderMdmGetDigitMapPtr(p);
    rvStringConstruct(&digitmapName, "dialplan0", x->alloc);
    rvMdmTermAddDigitMap(x, digitMapPtr, &digitmapName);
    rvStringDestruct(&digitmapName);   
}

static void constructDynamicFields(RvCCTerminalMdm * x) {

    RvMdmPackageItem pkgItem;

    rvMdmMediaDescriptorConstructA(&x->mediaDescr,x->alloc);

    /* Streams */
    rvVectorConstruct(RvMdmMediaStreamInfo)(&x->streamList,x->alloc);

    /*----------------------------------*/
    /* Event processing state variables */
    /*----------------------------------*/
    rvMdmEventsDescriptorConstructA(&x->eventsDescr,0,x->alloc);
    rvMdmPackageItemConstruct(&pkgItem, "", "");
    rvMdmEventConstructA(&x->lastEvent, &pkgItem, x->alloc);
    rvMdmPackageItemDestruct(&pkgItem);

    x->digitMapActive = RV_FALSE;

    rvMdmDigitMapConstructA(&x->digitMap,x->alloc);
    rvStringConstruct(&x->dialString,"",x->alloc);
    rvStringConstruct(&x->redialString,"",x->alloc);

    x->digitMapEC = NULL;
    /* Current status of the digitmap matching */
    x->digitMapStat = RV_MDMDIGITMAP_NOMATCH;
    /* Requested event for digitmap event */
    x->digitMapReqEvent = NULL;

    /* headset handsfree handset*/
    x->activeAudioTerm      = NULL;
    x->handsetAudioTerm     = NULL;
    x->headsetAudioTerm     = NULL;
    x->handsfreeAudioTerm   = NULL;

    /* Video terminations*/
    x->activeCameraTerm = NULL;
    x->activeScreenTerm = NULL;
    x->cameraVideoTerm  = NULL;
    x->screenVideoTerm  = NULL;

    /* Store previously defined digitmaps */
    rvMdmDigitMapDBConstruct(&x->storedDigitMaps,x->alloc);
    /*----------------------------------*/
    /* Signals variables                */
    /*----------------------------------*/
    rvListConstruct(RvMdmCurSignal)(&x->curSignals,x->alloc);
    rvListConstruct(RvMdmCurSignalList)(&x->curSignalLists,x->alloc);
    rvListConstruct(RvMdmSpecialDM)(&x->specialDM,x->alloc);
    /*-----------------------------------------------*/
    /* Used to queue events when processing commands */
    /*-----------------------------------------------*/
    rvListConstruct(RvMdmEvent)(&x->blockedEventBuffer,x->alloc);
    x->blockedEventTypeMask = RV_BLOCKEDEVENT_NOTIFY;


}

static RvCCConnection* rvAllocConnection(RvCCTerminal* x, RvCCProvider* p)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);
    RvCCConnection* c = NULL;

    rvMtfAllocatorAlloc(sizeof(RvCCConnection), (void**)&c);

    rvCCConnMdmConstruct(c, x, provider, term->alloc);

    /* No need to set state here: it's already set in rvCCConnMdmConstruct
    rvCCConnectionSetState(c, RV_CCCONNSTATE_IDLE);
    */

    return c;
}

void rvCCTerminalMdmConstruct(
    IN RvCCTerminal*                x,
    IN RvCCProvider*                p,
    IN const RvChar*                id,
    IN RvCCTerminalType             type,
    IN RvCCTerminalClbks*           clbks,
    IN RvMdmTermDefaultProperties*  defaultProperties,
    IN RvAlloc*                     a)
{
    RvCCTerminalMdm* term = NULL;
	RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);
	RvInt maxConnections;
	
    rvMtfAllocatorAlloc(sizeof(RvCCTerminalMdm), (void**)&term);

    memset(term,0,sizeof(RvCCTerminalMdm));
    term->provider = p;

    term->alloc = a;
    constructDynamicFields(term);

    RvMutexConstruct(IppLogMgr(), &term->mutex);

    term->termType = type;

    strncpy(term->terminalId, id, sizeof(term->terminalId)-1);
    term->terminalId[sizeof(term->terminalId)-1] = '\0';
    rvMdmTermPhoneNumbersClear(&(term->phoneNumbers));

    term->type = RV_MDMTERMTYPE_UNKNOWN;
    term->inactive = RV_TRUE;
	term->numberOfLines = 2;

    rvMdmTermDefaultPropertiesConstructA(&term->defaultState, a);

    rvCCTerminalInit(x, term, clbks);
	maxConnections = rvCCTerminalGetNumberOfLines(x);
	
#ifdef RV_MTF_N_LINES
	if (defaultProperties != NULL)
	{
		if (defaultProperties->numberOfLines != 0)
		{
			term->numberOfLines =  defaultProperties->numberOfLines;
		}
	}
	else
	{
		term->numberOfLines =  2;
	}
	
	/* Allocate an array of pointers. Number of entries in this array is maxConnections.
	Each pointer will be filled with an allocated pointer to rvCCConnection structure */
	rvMtfAllocatorAlloc(sizeof(RvCCConnection *) * maxConnections, (void**)&x->connections);
	//	x->connections = rvAllocAllocate(a, sizeof(RvCCConnection *) * maxConnections);
	
#else /* RV_MTF_N_LINES */
	term->numberOfLines =  2;
	
#endif /* RV_MTF_N_LINES */

    if ((type==RV_CCTERMINALTYPE_UI) || (type==RV_CCTERMINALTYPE_ANALOG))
    {
        int i;
		
        for (i=0;i<maxConnections;i++)
        {
            x->connections[i] = rvAllocConnection(x, p);
            rvCCConnectionSetLineId(x->connections[i],i+1);
            RvLogInfo(ippLogSource,(ippLogSource,"MDM Connection Allocated(%p), Line:%d\n",
                    x->connections[i], rvCCConnectionGetLineId(x->connections[i])));
        }
    }

    /*Set the right Completion Event Package*/
    if (type == RV_CCTERMINALTYPE_UI)
        term->compEventPkg = "kp";
    else if (type == RV_CCTERMINALTYPE_ANALOG)
        term->compEventPkg = "dd";


    rvMdmTermDigitMapTimerConstruct(term);

    RvMutexConstruct( IppLogMgr(), &term->blockedEventMutex);

    /*
     *  set digit map in terminal
     */
    if(defaultProperties)
    {
        if (*rvMdmDigitMapDescriptorGetName(&defaultProperties->digitMap))
        {
            RvString digitmapName;
            const RvChar *digitmapChars = rvMdmDigitMapDescriptorGetName(&defaultProperties->digitMap);
            rvStringConstruct(&digitmapName, digitmapChars, term->alloc);
            rvMdmTermAddDigitMap(term, rvMdmDigitMapDescriptorGetDigitMap(&defaultProperties->digitMap),
                                        &digitmapName);

            rvStringDestruct(&digitmapName);
        }
        else
            setTermDigitMap(term, p);
    }
    else
    {
        /*
         *  who doesn't care about defaultProperties at all will get the simplest digit map of 4 digitals
         */
        setTermDigitMap(term, p);
    }
    /*If duration==0, dial tone will be infinite*/
    if (rvCCProviderMdmGetDialToneDuration(rvCCTerminalMdmGetProvider(term)) > 0)
        IppTimerConstruct( &term->dialToneTimer,
                           rvCCProviderMdmGetDialToneDuration(p),
                           rvCCTerminalMdmDialToneTimerExpired,
                           x);

	if (provider->registerCompleteTimeout > 0)
		IppTimerConstruct( &term->registerCompleteTimer,
		                   provider->registerCompleteTimeout * 1000,
		                   rvCCTerminalMdmRegisterCompleteTimerExpired,
		                   x);

    /*zhangcg: 20110507*/
    term->dwBusyToneTime   =  PSip_GetBusyToneTime();
    term->dwWarningToneTime = PSip_GetWaringToneTime();
    
    IppTimerConstruct( &term->tBusyToneTimer,
		              (term->dwBusyToneTime) * 1000,/* to do later*/
		              PSip_rvCCTerminalMdmBusyToneTimeOut,
		              x);
		                   
    IppTimerConstruct( &term->tWarningToneTimer,
		               (term->dwWarningToneTime)* 1000, 
		               PSip_rvCCTerminalMdmWarningToneTimeOut,
		               x);

    IppTimerConstruct( &term->tMaliciousCallTimer,
		               1000, 
		               PSip_rvCCTerminalMdmMaliciousCallTimeOut,
		               x);

    term->outOfBandDtmfRelayEnabled = rvCCProviderMdmGetoutOfBandDtmf(rvCCTerminalMdmGetProvider(term));
    term->playDtmfEnabled           = RV_FALSE;
    rvMdmMediaStreamInfoConstructA(&(term->mediaEventData), 0, prvDefaultAlloc);

    /*Presentation Info*/
    rvMdmTermPresentationInfoConstruct(&(term->presentationInfo));

    rvCCCfwDataInitToDefaultValues(&(term->cfwData));

    rvCCTerminalSetState(x, RV_CCTERMINAL_IDLE_STATE);
}

static void destructDynamicFields(RvCCTerminalMdm * x) {
    rvMdmMediaDescriptorDestruct(&x->mediaDescr);
    rvVectorDestruct(RvMdmMediaStreamInfo)(&x->streamList);
    /*----------------------------------*/
    /* Event processing state variables */
    /*----------------------------------*/
    rvMdmEventsDescriptorDestruct(&x->eventsDescr);
    rvMdmEventDestruct(&x->lastEvent);
    rvMdmDigitMapDestruct(&x->digitMap);
    rvStringDestruct(&x->dialString);
    rvStringDestruct(&x->redialString);

    /* Digitmap */
    rvMdmTermDeactivateDigitMap(x);

    /* Store previously defined digitmaps */
    rvMdmDigitMapDBDestruct(&x->storedDigitMaps);
    /*----------------------------------*/
    /* Signals variables                */
    /*----------------------------------*/
    rvListDestruct(RvMdmCurSignal)(&x->curSignals);
    rvListDestruct(RvMdmCurSignalList)(&x->curSignalLists);
    rvListDestruct(RvMdmSpecialDM)(&x->specialDM);

    /*-----------------------------------------------*/
    /* Used to queue events when processing commands */
    /*-----------------------------------------------*/
    rvListDestruct(RvMdmEvent)(&x->blockedEventBuffer);

}


void rvCCTerminalMdmDestruct(RvCCTerminal * x)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
    RvCCTerminalType type = rvCCTerminalMdmGetType(term);

    RvMutexLock(&term->mutex,IppLogMgr());
    destructDynamicFields(term);

	/* Handle UI or Analog */
	/* ------------------- */
    /* Disconnect all active calls. Connections are stored in the UI or Analog terminations only. */
    if ((type == RV_CCTERMINALTYPE_UI) || (type == RV_CCTERMINALTYPE_ANALOG))
	{
		int i;
		RvInt maxConnections;

		/* Disconnect all the active calls (just send BYE) */
		rvCCTerminalMdmTerminateAllCalls(x);

		maxConnections = rvCCTerminalGetNumberOfLines(x);

		/* Release all the objects related to a session: MDM Connections, SIP Connections and Calls. */
		for(i=0; i<maxConnections; i++)
		{
			RvCCConnection* c = x->connections[i];
			RvCCCallMgr*		callMgr =	rvCCBasePhoneGetCallMgr();
			RvCCCall*           call;			
			RvPtrListRevIter    i;
			RvPtrListIter       j;

			/* Release Network (SIP/H323) Connections */
			/* ----------------------- */
			/* There may be some Network connections not released, for example if we didn't receive a final
			   response from remote party yet. The only way we can reach the active Network connections at this point
			   is by checking the list of calls. There is no point of checking the MDM connections since they are
			   already disconnected and their currParty was reset. */

			for (i = rvPtrListBegin(&callMgr->calls); i != rvPtrListEnd(&callMgr->calls); i = rvPtrListIterNext(i))
			{
				call = (RvCCCall *)rvPtrListIterData(i);
				if (rvListSize(&call->connections) > 0)
				{
					for(j = rvListBegin(&call->connections); j != rvListEnd(&call->connections); j = rvListIterNext(j))
					{
						RvCCConnection* conn = (RvCCConnection *)RvPtrListIterData(j);
						if (conn->type == RV_CCCONNTYPE_NETWORK)
						{
							rvCCConnectionRelease(conn);  
						}
					}
				}				
			}

			/* Release Calls */
			/* ------------- */
			/* We remove the call from the list inside the loop, therefore instead of rvPtrListNext we call rvPtrListBegin */
			for (i = rvPtrListBegin(&callMgr->calls); i != rvPtrListEnd(&callMgr->calls); i = rvPtrListBegin(&callMgr->calls))
			{
				call = (RvCCCall *)rvPtrListIterData(i);
				rvCCCallMgrReleaseCall(callMgr, call);
				/* If list is empty now, get out */
				if (rvPtrListSize(&callMgr->calls) == 0)
				{
					break;
				}
			}
			
			/* Release MDM Connections */
			/* ----------------------- */

			rvCCConnMdmDestruct(c);
			rvMtfAllocatorDealloc(c, sizeof(RvCCConnection));
		}  
	}
	/* Handle AT term */
	/* -------------- */
	/*  We go here to disconnect calls when Audio termination (at/hs) unregisters before UI termination does.  
		After Audio termination un-registers we won't be able to disconnect all calls (media line objects are
		released). */ 
	else if (type != RV_CCTERMINALTYPE_EPHEMERAL)
	{
		RvCCProvider*		p = rvCCTerminalMdmGetProvider(term);
		RvCCTerminal*       uiTerm  = rvCCProviderFindTermByType(p, RV_CCTERMINALTYPE_UI);

		if (uiTerm != NULL)
		{			
			rvCCTerminalMdmTerminateAllCalls(uiTerm);
		}
	}

    /*-----------------------------------------------*/
    /* Used to queue events when processing commands */
    /*-----------------------------------------------*/
    /* Try to process all pending events */
    while(!rvListEmpty(&term->blockedEventBuffer) )
        IppThreadSleep(RV_MDMTERM_EVENTTIME*2,0);

    RvMutexDestruct(&term->blockedEventMutex, IppLogMgr());

    /*-----------------------------------------------*/
    /* The digitmap timers                           */
    /*-----------------------------------------------*/
    rvMdmTermDigitMapTimerDestruct(term);

    /*-------------------------------------------------------------------*/
    /* Destruct the default state                                        */
    /*-------------------------------------------------------------------*/
    rvMdmTermDefaultPropertiesDestruct(&term->defaultState);


    /*-------------------------------------------------------------------*/
    /* Destruct the termination mutex                                    */
    /*-------------------------------------------------------------------*/
    RvMutexUnlock(&term->mutex,IppLogMgr());
    RvMutexDestruct(&term->mutex,IppLogMgr());
    /*If dial tone is infinite, no timer was constructed*/
    if (rvCCProviderMdmGetDialToneDuration(rvCCTerminalMdmGetProvider(term)) > 0)
        IppTimerDestruct(&term->dialToneTimer);

    /*zhangcg: 20110507*/
    IppTimerDestruct(&term->tBusyToneTimer);
    IppTimerDestruct(&term->tWarningToneTimer);
    IppTimerDestruct(&term->tMaliciousCallTimer);
    
	IppTimerDestruct(&term->registerCompleteTimer);

    rvMdmMediaStreamInfoDestruct(&(term->mediaEventData));

    rvCCTerminalSetState(x, RV_CCTERMINAL_IDLE_STATE);

    RvMutexDestruct(&x->activeConnMutex, IppLogMgr());

    rvMtfAllocatorDealloc(term, sizeof(RvCCTerminalMdm));
}


struct RvMdmTermMgr_* rvCCTerminalMdmGetTermMgr(RvCCTerminalMdm * x)
{
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(x->provider);
    return provider->mdmTermMgr;
}

static RvBool matchMediaId(RvMdmMediaStreamInfo *m, void * id) {
    RvUint32 id_ = *(RvUint32*)id;
    return rvMdmMediaStreamInfoMatchId(m,id_);
}

const RvSdpMsg* rvCCTerminalMdmGetMediaCaps(RvCCTerminalMdm * x)
{
    RvMdmMediaDescriptor* mediaCaps = x->mediaCaps;
    const RvMdmStreamDescriptor* descr = rvMdmMediaDescriptorGetStream(mediaCaps, 0);

    return rvMdmStreamDescriptorGetLocalDescriptor(descr, 0);
}

static RvMdmMediaStreamInfoVectorIter getMediaStream(RvCCTerminalMdm * x, RvUint32 streamId)
{
    RvMdmMediaStreamInfoVectorIter i = rvFindIf(RvVectorIter,RvMdmMediaStreamInfo)(rvVectorBegin(&x->streamList),rvVectorEnd(&x->streamList),
                                                    matchMediaId,&streamId);
    if(i != rvVectorEnd(&x->streamList))
        return i;
    else
        return NULL;
}

RvMdmMediaStreamInfo* rvCCTerminalMdmGetMediaStream(RvCCTerminalMdm * x, RvUint32 streamId)
{
    RvMdmMediaStreamInfoVectorIter i;
    if ((x != NULL) && (x->streamList.data != NULL))
        i = getMediaStream(x, streamId);
    else
        i = NULL;
    /*if((i=getMediaStream(x, streamId))==0)
        return NULL;*/
    return rvVectorIterData(i);
}

RvMdmStreamId rvCCTerminalMdmAddEmptyMediaStream(RvCCTerminalMdm * x)
{
    RvMdmMediaStreamInfo* mediaStream;
    RvMdmStreamId id=0;
    RvBool found = RV_FALSE;
    RvUint32 i, streamNum = (RvUint32)rvCCTerminalMdmGetNumOfStreams(x);

    RvMutexLock(&x->mutex,IppLogMgr());
    /*Generate stream id - go through the list and find the first empty place*/
    for (i = 1 ; i <= streamNum; ++i)
    {
        RvMdmMediaStreamInfo* media = rvCCTerminalMdmGetMediaStream(x, i);
        if (media == NULL)
        {
            found = RV_TRUE;
            id = i;
            break;
        }
    }

    if (!found)
        id = streamNum+1;

    mediaStream = rvVectorAllocBack(RvMdmMediaStreamInfo)(&x->streamList);
    rvMdmMediaStreamInfoConstructA(mediaStream, id, x->alloc);

    RvMutexUnlock(&x->mutex,IppLogMgr());

    return id;
}

void rvCCTerminalMdmClearMediaStream(RvCCTerminalMdm * x, RvUint32 streamId)
{
    RvMdmMediaStreamInfoVectorIter i = getMediaStream(x, streamId);
    RvMdmMediaStreamInfo* media = (RvMdmMediaStreamInfo*)rvPtrVectorIterData(i);
    rvMdmMediaStreamInfoDestruct(media);
    rvVectorErase(RvMdmMediaStreamInfo)(&x->streamList, i);

}
void rvCCTerminalMdmClearAllMediaStreams(RvCCTerminalMdm * x)
{
    rvVectorClear(RvMdmMediaStreamInfo)(&x->streamList);

}

RvBool rvCCTerminalMdmCreateMedia(RvCCTerminalMdm* term, RvMdmMediaStreamInfo* media, RvMdmMediaDescriptor* rspMedia)
{
    rvMdmStreamDescriptorSetMode(&media->streamDescr, RV_MDMSTREAMMODE_SENDRECV);
    return rvMdmMediaStreamInfoCreateMdmMedia(media, term, rspMedia);
}


static void setLastEvent(RvCCTerminalMdm* x, const char* pkg, const char* id, RvMdmParameterList* args)
{
    RvMdmPackageItem* pkgItem;

    RvMutexLock(&x->mutex,IppLogMgr());

    pkgItem = (RvMdmPackageItem*) rvMdmEventGetName(&x->lastEvent);
    rvStringAssign(&pkgItem->package, pkg);
    rvStringAssign(&pkgItem->item, id);

    if (args != NULL)
    {
        rvMdmEventSetParametersList(&x->lastEvent, args);
    }

    RvMutexUnlock(&x->mutex,IppLogMgr());
}


/*      1. map events for IP PHONE */
/*       2. get the right connection from connections list - for now we choose the active one*/
void rvCCTerminalMdmProcessEvent(RvCCTerminal* x, const char* pkg, const char* id,
                                         RvMdmMediaStream* media, RvMdmParameterList * args)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
    RvCCCallMgr* callMgr = rvCCProviderMdmGetCallMgr(term->provider);
    RvCCTerminalEvent   event;
    char keyId[32];    
    
    event = rvCCTerminalMapEvent(x, pkg, id, args, keyId);

    RvLogInfo(ippLogSource,(ippLogSource,"IPP-->Received Event: %s", rvCCTextEvent(event)));

    /* If event was a completion event containing a digit string, copy it
       to the digit string */
    if (event == RV_CCTERMEVENT_DIALCOMPLETED)
    {
        size_t dsLen;
        const RvMdmParameterValue * param;
        const char* digitString;

        if (args != NULL)
        {      
            param = rvMdmParameterListGet2((RvMdmParameterList*)args, "ds");
            if (param != NULL)
            {
                digitString = rvMdmParameterValueGetValue(param);

                /* Strip quotes if we have to (more for backward compatibility than anything else */
                if (digitString[0]=='"')
                    digitString++;
                dsLen = strlen(digitString);
                if (dsLen && digitString[dsLen-1]=='"')
                    dsLen--;
            }
        }
//add by zhuhaibo 20110401 for tightcoupless of conference or cw
        if ((term->dialString != NULL) && (term->dialString[0] == 0))
        {
            #if 0
            printf("zhuhaibo---------set number = LucentTISPANFlashReques\n");
            dsLen = strlen("LucentTISPANFlashReques");
            rvStringAssignN(&term->dialString, "LucentTISPANFlashReques", dsLen);
            #endif
            dsLen = strlen("nodial");
            rvStringAssignN(&term->dialString, "nodial", dsLen);
            IppTimerStop(rvCCTerminalMdmGetDialToneTimer(x));
            
        }
//add end
    }
    if(event == RV_CCTERMEVENT_USER_CONFERENCE)
    {
        size_t dsLen;
        const RvMdmParameterValue * param;
        const char* digitString;
        RvMdmTerm*          mdmTerm=NULL;
        mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
        int lineIndex = PSip_getLineIndex(mdmTerm->userData);
        if ((term->dialString != NULL) && (term->dialString[0] == 0))
        {
            dsLen = strlen((RvChar*)g_conferenceUri[lineIndex]);
            rvStringAssignN(&term->dialString, (RvChar*)g_conferenceUri[lineIndex], dsLen);
            
            IppTimerStop(rvCCTerminalMdmGetDialToneTimer(x));
           	rvMdmTermEventStopSignals(term);
            
        }
        event = RV_CCTERMEVENT_DIALCOMPLETED;
//add end
    }
    /* store last event for processing by the connection*/
    setLastEvent(term, pkg, id, args);

    rvCCTerminalProcessEventId(x, event, keyId, callMgr, media);
}



RvBool rvCCTerminalMdmIsFirstDigit(RvCCTerminal* x)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);

    if (rvStringGetSize(&term->dialString) == 1)
        return RV_TRUE;

    return RV_FALSE;
}

RvChar rvCCTerminalMdmGetLastDigit(RvCCTerminal* x)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);
    RvSize_t len = rvStringGetSize(&term->dialString);
    const RvChar* str = rvStringGetData(&term->dialString);

    return str[len-1];

}

RvBool rvCCTerminalMdmStartSignalUI(
    IN RvCCTerminal*        x,
    IN const RvChar*        pkg,
    IN const RvChar*        id,
    IN RvMdmParameterList*  args)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(x);

    return startSignal(term, pkg, id, args, RV_MDMSIGNAL_BRIEF);
}

RvBool rvCCTerminalMdmStartSignalAudio(
    IN RvCCTerminal*        x,
    IN const RvChar*        pkg,
    IN const RvChar*        id,
    IN RvMdmParameterList*  params)
{
    RvCCTerminal* at = rvCCTerminalMdmGetActiveAudioTerm(x);
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(at);

    return startSignal(term, pkg, id, params, RV_MDMSIGNAL_TIMEOUT);
}

/*Returns TRUE if there's another connection on Hold except for this one*/
RvBool rvCCTerminalMdmOtherHeldConnExist(RvCCTerminal* t, RvCCConnection* currConn)
{
	RvInt maxConnections = rvCCTerminalGetNumberOfLines(t);
    RvInt i;
	
    if (t !=NULL)
    {
        for (i=0 ; i<maxConnections ; ++i)
        {
            if (rvCCConnectionIsCallOnHold(t->connections[i]) && (t->connections[i] != currConn))
                return RV_TRUE;
        }
    }
	
    return RV_FALSE;
}

/********************************************************************************************
 * rvCCTerminalMdmOtherAlertingConnExist
 * purpose : to find if there is other connection that is in state offerin
 *           or incoming call
 * input   : t          - termination
 *           currConn   - current connection
 *
 * output  : none
 * return  : RV_TRUE if there is another connection in alerting
 *           rvFale if not
 ********************************************************************************************/
RvBool rvCCTerminalMdmOtherAlertingConnExist(RvCCTerminal* t, RvCCConnection* currConn)
{
	RvInt maxConnections = rvCCTerminalGetNumberOfLines(t);
    RvInt i;
	
    for (i=0 ; i<maxConnections ; ++i)
    {
        RvCCTermConnState state = rvCCConnectionGetTermState(t->connections[i]);
        if ((((int)state >0) && ( rvCCConnectionGetState(t->connections[i])==RV_CCCONNSTATE_ALERTING)) &&
            (t->connections[i] != currConn))
        {
            return RV_TRUE;
        }
    }
	
    return RV_FALSE;
}


RvMdmMediaStreamInfo* rvCCTerminalMdmGetMediaEventData(RvCCTerminalMdm* term)
{
    return &(term->mediaEventData);
}

void rvCCTerminalMdmSetMediaEventData(RvCCTerminalMdm* term, RvMdmMediaStreamInfo* media)
{
    /*This will release already allocated memory.*/
    RvMdmMediaStreamInfoDestruct(&(term->mediaEventData));
    RvMdmMediaStreamInfoConstructCopy(&(term->mediaEventData), media, prvDefaultAlloc);
}



/***************************************************************************
 * rvCCTerminalMdmLoadPresentationInfo
 * ------------------------------------------------------------------------
 * General: Loads configuration parameters to Terminal
 *
 ***************************************************************************/
RvBool rvCCTerminalMdmLoadPresentationInfo(RvCCTerminalMdm *            term,
                                            RvMdmTermDefaultProperties* termProperties)
{
    if ((term == NULL) || (termProperties == NULL))
        return RV_FALSE;

    rvMdmTermPresentationInfoCopy(&term->presentationInfo, &termProperties->presentationInfo);

    return RV_TRUE;
}

/***************************************************************************
 * rvCCTerminalMdmGetPresentationInfo
 * ------------------------------------------------------------------------
 * General: Returns presentation name
 *
 ***************************************************************************/
RvMdmTermPresentationInfo* rvCCTerminalMdmGetPresentationInfo(RvCCTerminal *t)
{
    RvCCTerminalMdm* term;

    if (t == NULL)
        return NULL;

    term = rvCCTerminalMdmGetImpl(t);

    return &(term->presentationInfo);

}

RvMdmTermPhoneNumbers* rvCCTerminalMdmGetPhoneNumbers(RvCCTerminalMdm *term)
{
    if (term == NULL)
        return RV_FALSE;

    return (&(term->phoneNumbers));

}



/***************************************************************************
 * rvCCTerminalMdmFillSdpDefaultInfo
 * ------------------------------------------------------------------------
 * General: Fill the session headers in SDP message with default info:
 *          "o=", "v=", "t=" etc.
 *          The info is set according to Offer/Answer (RFC 3264).
 * Return Value: none
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   t       - terminal
 *          sdp     - sdp message to be filled
 *          username - to be used in SDP (in "o" line), this is actually termination id
 ***************************************************************************/
void rvCCTerminalMdmFillSdpDefaultInfo(
    IN RvCCTerminal*    t,
    IN const RvSdpMsg*  sdp,
    IN const RvChar*    username)
{

    RvTime          ltime;
    RvInt32 mixedTime;
    char            session_id[48], version[48];
#if (RV_NET_TYPE & RV_NET_IPV6)
    RvBool          bIsIpV4;
    RvChar          address[RV_IPP_LEN_STRING_IP];
#endif
    RvSdpStatus     sdpStatus;
    const RvChar*   localAddress;

    localAddress = rvCCTerminalMdmGetLocalAddress(t);
    if (localAddress == NULL)
    {
        RvLogError(ippLogSource,(ippLogSource,"fillSdpDefaultInfo:rvCCTerminalMdmGetLocalAddress fail"));
        localAddress = "0.0.0.0";
    }
    RvClockGet(IppLogMgr(), &ltime);
    /* create a unique  session id and version number based on the clock */
    mixedTime = RvTimeGetSecs(&ltime) + (RvTimeGetNsecs(&ltime)/RV_TIME_NSECPERMSEC);
    RvSnprintf(session_id,sizeof(session_id), "%d", mixedTime);
    RvSnprintf(version,sizeof(version), "%d", mixedTime);

#if (RV_NET_TYPE & RV_NET_IPV6)
    bIsIpV4 = IppUtilIsIpV4(localAddress);
    if (bIsIpV4 == RV_FALSE)
    {
        strcpy(address, localAddress);
        IppUtilRemoveBracketsFromIpv6String(address);

        sdpStatus = rvSdpMsgSetOrigin((RvSdpMsg *)sdp, username, session_id, version,
            RV_SDPNETTYPE_IN, RV_SDPADDRTYPE_IP6, address);
    }
    else
#endif /* RV_NET_IPV6 */
    {
        sdpStatus = rvSdpMsgSetOrigin((RvSdpMsg *)sdp, username, session_id, version,
                                RV_SDPNETTYPE_IN, RV_SDPADDRTYPE_IP4, localAddress);
    }

    if (sdpStatus != RV_SDPSTATUS_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"fillSdpDefaultInfo:rvSdpMsgSetOrigin fail error = %d",sdpStatus));
    }

    sdpStatus = rvSdpMsgSetSessionName((RvSdpMsg *)sdp, "-");
    if (sdpStatus != RV_SDPSTATUS_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"fillSdpDefaultInfo:rvSdpMsgSetSessionName fail error = %d",sdpStatus));
    }

    rvSdpMsgClearSessionTime((RvSdpMsg *)sdp);
    if (rvSdpMsgAddSessionTime((RvSdpMsg *)sdp, 0, 0) == NULL)
    {
        RvLogError(ippLogSource,(ippLogSource,"fillSdpDefaultInfo:rvSdpMsgAddSessionTime fail error = %d",sdpStatus));
    }
}

/***************************************************************************
 * rvCCTerminalMdmSetDefaultMedia
 * ------------------------------------------------------------------------
 * General: builds a media descriptor based on local capabilities
 *          that were previously configured by the user.
 *          This media descriptor used as a base to open the local (receive) rtp media.
 * Remarks:
 * Return Value: none
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   t        - active Terminal (either RTP or physical)
 *          straemId - stream Id
 *          username - username to be used in SDP
 ***************************************************************************/
RvMdmMediaStreamInfo* rvCCTerminalMdmSetDefaultMedia(
    IN RvCCTerminal*    t,
    IN int              streamId,
    IN const RvChar*    username)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
    const RvSdpMsg *sdp = rvCCTerminalMdmGetMediaCaps(term);
    RvMdmMediaStreamInfo* media;

    RvMutexLock(&term->mutex,IppLogMgr());

    rvCCTerminalMdmFillSdpDefaultInfo(t, sdp, username);
    media = rvCCTerminalMdmGetMediaStream(term, (RvUint32)streamId);
    rvMdmMediaStreamInfoAddLocalDescriptor(media, (RvSdpMsg*)sdp);

    RvMutexUnlock(&term->mutex,IppLogMgr());

    return media;
}

/***************************************************************************
 * rvCCTerminalMdmCreateLineMedia
 * -------------------------------------------------------------------------
 * General: Create media for a physical termination, if it was not created yet.
 *          The Line Media has only 1 stream (streamId = PHYS_TERM_STREAM_ID),
 *          and is based on the local capabilities.
 *          A physical termination may be either Audio or Video termination.
 *
 * Note:    This is a Connection function, since SDP message of the media will
 *          contain local ip address
 * Return Value: line media stream, which is related to stream id = PHYS_TERM_STREAM_ID
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   t           -   UI termination
 *          activeTerm  - A physical termination (Audio or Video) to create media for.
 ***************************************************************************/
RvMdmMediaStreamInfo* rvCCTerminalMdmCreateLineMedia(RvCCTerminal* t,
                                                     RvCCTerminal* activeTerm)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(activeTerm);
    RvMdmMediaStreamInfo* mediaStream;

    RvMutexLock(&term->mutex, IppLogMgr());

    if (rvCCTerminalMdmGetNumOfStreams(term) == 0)
    {
        int id = (int)rvCCTerminalMdmAddEmptyMediaStream(term);
        RvMdmMediaStreamInfo* media = rvCCTerminalMdmSetDefaultMedia(activeTerm, id, rvCCTerminalMdmGetTermId(t));

        /* this is an ONLY place that we set Line Media (target) mode */
        rvMdmStreamDescriptorSetMode(&media->streamDescr, RV_MDMSTREAMMODE_SENDRECV); /* !!! */
        if (rvCCTerminalMdmCreateMedia(term, media, NULL) == RV_FALSE)
        {
            RvMutexUnlock(&term->mutex, IppLogMgr());
            return NULL;
	    }
    }

    mediaStream = rvCCTerminalMdmGetMediaStream(term, PHYS_TERM_STREAM_ID);
    RvMutexUnlock(&term->mutex, IppLogMgr());


    return mediaStream;
}

/***************************************************************************
 * rvCCTerminalMdmGetLocalAddress
 * -------------------------------------------------------------------------
 * General: Returns local address as was configured by user
 *

 * Return Value: Local address
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   t           -   UI termination
 *
 ***************************************************************************/
const char* rvCCTerminalMdmGetLocalAddress(RvCCTerminal* t)
{
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
    RvCCProvider* p = rvCCTerminalMdmGetProvider(term);
    RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);

    return (provider->localAddress);
}

/*zhangcg: 20110507*/
RvBool PSip_rvCCTerminalMdmBusyToneTimeOut( void* data)
{
    RvCCTerminal* t = (RvCCTerminal*) data;
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
    RvCCConnection* conn;

    RvLogInfo(ippLogSource, (ippLogSource,
        "PSip_rvCCTerminalMdmBusyToneTimeOut for Termination: %s (%p)", rvCCTerminalGetId(t), t));
        
    printf("PSip_rvCCTerminalMdmBusyToneTimeOut\n");

    /*start to play warning tone*/
    rvCCTerminalMdmStartWarningExSignal(t);

    return RV_TRUE;
}

RvBool PSip_rvCCTerminalMdmWarningToneTimeOut( void* data)
{
    RvCCTerminal* t = (RvCCTerminal*) data;
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
    RvCCConnection* conn;

    RvLogInfo(ippLogSource, (ippLogSource,
        "PSip_rvCCTerminalMdmWarningToneTimeOut for Termination: %s (%p)", rvCCTerminalGetId(t), t));
        
    /*stop all the signals*/
    rvCCTerminalMdmStopSignals(t);

    return RV_TRUE;
}


RvBool PSip_rvCCTerminalMdmMaliciousCallTimeOut( void* data)
{
    RvCCTerminal* t = (RvCCTerminal*) data;
    RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
    RvCCConnection* conn = rvCCTerminalGetActiveConnection(t);

    RvStatus rv = RV_OK;
	RvMdmTerm*          mdmTerm=NULL;
    RvSdpMsg*           localSdp=NULL;

    mdmTerm = rvCCTerminalMdmGetMdmTerm(term); 
    if (mdmTerm == NULL)
    {
        RvLogInfo(ippLogSource,(ippLogSource, "PSip_rvCCTerminalMdmMaliciousCallTimeOut() - mdmTerm is NULL, so do nothing."));
        return RV_FALSE;   
    }
    
    localSdp = rvCCConnectionGetMedia(conn); 
    if(localSdp == NULL)
    {       
        RvLogInfo(ippLogSource,(ippLogSource, "PSip_rvCCTerminalMdmMaliciousCallTimeOut() - localSdp is NULL, so do nothing."));
        return RV_FALSE;   
    }
    int lineIndex = PSip_getLineIndex(mdmTerm->userData);
    g_dwmaliciouscall[lineIndex] = RV_FALSE;
           
    rv = rvMdmTermModifyMedia(mdmTerm, localSdp);

    return rv;
}


