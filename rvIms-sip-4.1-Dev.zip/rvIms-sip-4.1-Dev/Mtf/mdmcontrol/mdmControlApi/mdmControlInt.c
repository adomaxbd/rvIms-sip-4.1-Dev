/******************************************************************************
Filename   : rvMdmControlInt.c
Description: MDM Control Internal APIs
******************************************************************************
                Copyright (c) 2004 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_MDMCONTROL
#include "ipp_inc_std.h"
#include "rvccprovidermdm.h"
#include "rvccterminalmdm.h"
#include "rvccconnmdm.h"
#include "mdmControlInt.h"
#include "rvcctext.h"
#include "rvlog.h"
#include "mtfBaseInt.h"

extern		RvMtfBaseMgr*			g_mtfMgr;
static		RvIppMdmExtClbks		mdmExtClbksDeprecated;
extern		RvMtfCallControlClbks	mdmExtClbks;  

/**********************************************************************************
                E X T E N S I O N           A P I s
**********************************************************************************/

RVAPI void RVCALLCONV rvIppMdmRegisterExtClbks(IN RvIppMdmExtClbks* clbks)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvIppMdmRegisterExtClbks(clbks=%p)", clbks));

	if (clbks != NULL)
    {
        mdmExtClbksDeprecated.connectionCreated = clbks->connectionCreated;
		mdmExtClbksDeprecated.connectionDestructed = clbks->connectionDestructed;
		mdmExtClbksDeprecated.display = clbks->display;
		mdmExtClbksDeprecated.displayData = clbks->displayData;
		mdmExtClbksDeprecated.mapUserEvent = clbks->mapUserEvent;
		mdmExtClbksDeprecated.postProcessEvent = clbks->postProcessEvent;
		mdmExtClbksDeprecated.preProcessEvent = clbks->preProcessEvent;
	}

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppMdmRegisterExtClbks()"));
}


RvCCTerminalEvent  rvIppMdmExtPreProcessEventCB(
    IN RvCCConnection*         c,
    IN RvCCTerminalEvent       eventId,
    INOUT RvCCEventCause*       reason)
{
	RvMtfBaseMgr*	    mtfMgr;
	RvCCTerminal*		t;
	RvCCTerminalMdm*	term;
	RvMdmTerm*			mdmTerm;

	t = rvCCConnectionGetTerminal(c);
	term = rvCCTerminalMdmGetImpl(t);
	mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
	mtfMgr = rvGetMtfMgrByMdmTerm(mdmTerm);

	/* Try the deprecated callback first */
    if (mdmExtClbksDeprecated.preProcessEvent != NULL)
    {
        RvCCTerminalEvent newEvent;

        RvLogDebug(ippLogSource,(ippLogSource, "RvIppMdmPreProcessEventCB() - before calling user callback (connHndl=%p,eventId=%s,reason=%s,connState=%s,termConnState=%s)",
                            c, rvCCTextEvent(eventId), rvCCTextCause(*reason),
                            rvCCTextConnState(c->state), rvCCTextTermConnState(c->termState)));

        /* Call user callback */
        newEvent = mdmExtClbksDeprecated.preProcessEvent((RvIppConnectionHandle)c, eventId, reason);

        RvLogDebug(ippLogSource,(ippLogSource, "RvIppMdmPreProcessEventCB() - after calling user callback (reason=%s, new event=%s)",
            rvCCTextCause(*reason), rvCCTextEvent(newEvent)));

        return newEvent;
    }

	/* deprecated callbacks is not registered, try the regular one */
	else if (mdmExtClbks.preProcessEventCB != NULL)
	{
		RvCCTerminalEvent		newEvent = eventId;
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPreProcessEventEv() - before calling user callback (connHndl=%p,eventId=%s,reason=%s,connState=%s,termConnState=%s)",
			c, rvCCTextEvent(eventId), rvCCTextCause(*reason),
			rvCCTextConnState(c->state), rvCCTextTermConnState(c->termState)));
		
		/* Call user callback */
		mdmExtClbks.preProcessEventCB((RvIppConnectionHandle)c, c->userData, c->state, eventId, (RvMtfEvent*)&newEvent, reason);
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPreProcessEventEv() - after calling user callback (reason=%s, new event=%s)",
			rvCCTextCause(*reason), rvCCTextEvent(newEvent)));
		
		return newEvent;
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppMdmExtPreProcessEventCB() - application did not register this callback"));
	}

    return eventId;
}

void rvIppMdmExtPostProcessEventCB(
    IN RvCCConnection*          c,
    IN RvCCTerminalEvent        eventId,
    IN RvCCEventCause           reason)
{
    RvMtfBaseMgr*	    mtfMgr;
	RvCCTerminal*		t;
	RvCCTerminalMdm*	term;
	RvMdmTerm*			mdmTerm;
	
	t = rvCCConnectionGetTerminal(c);
	term = rvCCTerminalMdmGetImpl(t);
	mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
	mtfMgr = rvGetMtfMgrByMdmTerm(mdmTerm);
	
	/* Try the deprecated callback first */
    if (mdmExtClbksDeprecated.postProcessEvent != NULL)
    {

        RvLogDebug(ippLogSource,(ippLogSource, "RvIppMdmPostProcessEventCB() - before calling user callback (connHndl=%p,eventId=%s,reason=%s,connState=%s,termConnState=%s)",
                            c, rvCCTextEvent(eventId), rvCCTextCause(reason),
                            rvCCTextConnState(c->state), rvCCTextTermConnState(c->termState)));

        /*Call user callback*/
        mdmExtClbksDeprecated.postProcessEvent((RvIppConnectionHandle)c, eventId, reason);

        RvLogDebug(ippLogSource,(ippLogSource, "RvIppMdmPostProcessEventCB() - after calling user callback"));
    }
	/* deprecated callbacks is not registered, try the regular one */
	else if (mdmExtClbks.postProcessEventCB!= NULL)
	{	

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPostProcessEventEv() - before calling user callback (connHndl=%p,eventId=%s,reason=%s,connState=%s,termConnState=%s)",
			c, rvCCTextEvent(eventId), rvCCTextCause(reason), rvCCTextConnState(c->state), 
			rvCCTextTermConnState(c->termState)));
		
		/* Call user callback */
		mdmExtClbks.postProcessEventCB((RvIppConnectionHandle)c, c->userData, c->state, eventId, reason);
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPostProcessEventEv() - after calling user callback"));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppMdmExtPostProcessEventCB() - application did not register this callback"));
	}
}

void rvIppMdmExtConnectionCreatedCB(
    IN RvCCConnection* c)
{
    RvMtfBaseMgr*	    mtfMgr;
	RvCCTerminal*		t;
	RvCCTerminalMdm*	term;
	RvMdmTerm*			mdmTerm;
	
	t = rvCCConnectionGetTerminal(c);
	term = rvCCTerminalMdmGetImpl(t);
	mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
	mtfMgr = rvGetMtfMgrByMdmTerm(mdmTerm);
	
    if (mdmExtClbksDeprecated.connectionCreated != NULL)
    {
        RvLogDebug(ippLogSource, (ippLogSource,
            "rvIppMdmExtConnectionCreatedCB() - before calling user callback (connHndl=%p,connState=%s,termConnState=%s)",
                            c, rvCCTextConnState(c->state), rvCCTextTermConnState(c->termState)));

        /*Call user callback*/
        mdmExtClbksDeprecated.connectionCreated((RvIppConnectionHandle)c);

        RvLogDebug(ippLogSource,(ippLogSource, "rvIppMdmExtConnectionCreatedCB() - after calling user callback"));
    }
}

void rvIppMdmExtConnectionDestructedCB(
    IN RvCCConnection*  c)
{
    RvMtfBaseMgr*	    mtfMgr;
	RvCCTerminal*		t;
	RvCCTerminalMdm*	term;
	RvMdmTerm*			mdmTerm;
	
	t = rvCCConnectionGetTerminal(c);
	term = rvCCTerminalMdmGetImpl(t);
	mdmTerm = rvCCTerminalMdmGetMdmTerm(term);
	mtfMgr = rvGetMtfMgrByMdmTerm(mdmTerm);
	
    if (mdmExtClbksDeprecated.connectionDestructed != NULL)
    {
        RvLogDebug(ippLogSource, (ippLogSource,
            "rvIppMdmExtConnectionDestructedCB() - before calling user callback (connHndl=%p,connState=%s,termConnState=%s)",
                            c, rvCCTextConnState(c->state), rvCCTextTermConnState(c->termState)));

        /*Call user callback*/
        mdmExtClbksDeprecated.connectionDestructed((RvIppConnectionHandle)c);

        RvLogDebug(ippLogSource,(ippLogSource, "rvIppMdmExtConnectionDestructedCB() - after calling user callback"));
    }
}

RvCCTerminalEvent rvIppMdmExtMapUserEventCB(
    IN const RvChar*        pkg,
    IN const RvChar*        id,
    IN RvMdmParameterList*  args,
    IN RvChar*              key)
{
	if (g_mtfMgr == NULL)
	{
		return RV_CCTERMEVENT_UNKNOWN;
	}
	
    if (mdmExtClbksDeprecated.mapUserEvent != NULL)
    {
        RvCCTerminalEvent userEvent;

        RvLogDebug(ippLogSource,(ippLogSource, "rvIppMdmExtMapUserEventCB() - before calling user callback (pkg=%s,id=%s,args=%p,key=%s)",
                            pkg, id, args, key));

        /*Call user callback*/
        userEvent = mdmExtClbksDeprecated.mapUserEvent(pkg, id, args, key);

        RvLogDebug(ippLogSource,(ippLogSource, "rvIppMdmExtMapUserEventCB() - after calling user callback (event=%d)", userEvent));

        return userEvent;
    }

    return RV_CCTERMEVENT_UNKNOWN;
}

void rvIppMdmExtDisplayCB(
    IN RvCCConnection*		c,
    IN RvCCTerminal*       term,
    IN RvCCTerminalEvent   event,
    IN RvCCEventCause      cause,
    IN void*               displayData)
{
    RvMtfBaseMgr*	    mtfMgr;
	RvCCTerminalMdm*	t;
	RvMdmTerm*			mdmTerm;
	
	t = rvCCTerminalMdmGetImpl(term);
	mdmTerm = rvCCTerminalMdmGetMdmTerm(t);
	mtfMgr = rvGetMtfMgrByMdmTerm(mdmTerm);
	
	/* Try the deprecated callback first */
    if (mdmExtClbksDeprecated.display != NULL)
    {
        RvLogDebug(ippLogSource,(ippLogSource, "RvIppMdmDisplayCB() - before calling user callback (conn=%p,term=%p,event=%s,cause=%s,data=%p)",
                            c, term, rvCCTextEvent(event), rvCCTextCause(cause), displayData));

        /*Call user callback*/
        mdmExtClbksDeprecated.display((RvIppConnectionHandle)c, (RvIppTerminalHandle)term,
                                event, cause, displayData);

        RvLogDebug(ippLogSource,(ippLogSource, "RvIppMdmDisplayCB() - after calling user callback"));
    }

	/* deprecated callbacks is not registered, try the regular one */
	else
	{
		if (mdmExtClbks.updateTextDisplayCB != NULL)
		{			
			RvLogDebug(ippLogSource,(ippLogSource, "RvMtfUpdateTextDisplayEv() - before calling user callback (hConn=%p,eventId=%s,reason=%s,connState=%s,termConnState=%s)",
				c, rvCCTextEvent(event), rvCCTextCause(cause),
				rvCCTextConnState(c->state), rvCCTextTermConnState(c->termState)));
			
			/* Call user callback */
			mdmExtClbks.updateTextDisplayCB(
						(RvIppConnectionHandle)c, c->userData, c->state, (RvIppTerminalHandle)term, event, cause);
			
			RvLogDebug(ippLogSource,(ippLogSource, "RvMtfUpdateTextDisplayEv() - after calling user callback"));
		}

		/* Use default display function */
		else
		{
			RvLogDebug(ippLogSource,(ippLogSource, "rvIppMdmExtDisplayCB() - application did not register this callback, calling the default one."));
			c->funcs->displayF(c, term, event, cause, displayData);
		}
	}	
}


void rvMtfConnStateChangedCB(
							 IN RvCCConnection*		        c,
							 IN	RvMtfConnectionState	    connState,
							 IN RvMtfCallStateReason	    reason)
{
	if (mdmExtClbks.connStateChangedCB!= NULL)
	{	
		RvLogDebug(ippLogSource,(ippLogSource, 
			"rvMtfConnStateChangedCB() - before calling user callback (connHndl=%p, hConnApp = %p ,connState = %s, reason = %s)",
			c, c->userData, rvCCTextConnState(connState), rvCCTextCallStateReason(reason)));

		/* Call user callback */
		mdmExtClbks.connStateChangedCB((RvIppConnectionHandle)c, (RvMtfConnAppHandle)c->userData, connState, reason);

		RvLogDebug(ippLogSource,(ippLogSource, "rvMtfConnStateChangedCB() - after calling user callback"));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvMtfConnStateChangedCB() - application did not register to this callback."));
	}

}

void rvMtfTermRegistrationStateChangedCB(
							 IN RvCCTerminal*                      t,
							 IN RvMtfRegisterReportType            reportType,
							 IN RvMtfTermRegistrationStatus*       data)
{
	if (mdmExtClbks.termRegistrationStateChangedCB!= NULL)
	{	
		RvCCTerminalMdm*             term = rvCCTerminalMdmGetImpl(t);
		RvMdmTerm*                   mdmTerm = rvCCTerminalMdmGetMdmTerm(term);

		RvLogDebug(ippLogSource,(ippLogSource, 
			"rvMtfTermRegistrationStateChangedCB() - before calling user callback (termHndl=%p, hTermApp = %p ,reportType = %d, data = %p)",
			t, mdmTerm->userData, reportType, data)); 

		/* Call user callback */
		mdmExtClbks.termRegistrationStateChangedCB((RvIppTerminalHandle)t,
		                                           (RvMtfTerminalAppHandle)mdmTerm->userData, 
												    reportType,
									                data);

		RvLogDebug(ippLogSource,(ippLogSource, "rvMtfTermRegistrationStateChangedCB() - after calling user callback"));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvMtfTermRegistrationStateChangedCB() - application did not register to this callback."));
	}

} 



