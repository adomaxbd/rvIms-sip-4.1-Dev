/******************************************************************************
Filename:    rvMdmControlVideoApi.h
Description: MDM Control VideoAPIs
*******************************************************************************
                Copyright (c) 2005 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#ifndef RV_MDMCONTROLVIDEO_API_H
#define RV_MDMCONTROLVIDEO_API_H

#include "rvCallControlApi.h"
#include "rvmdmmediastream.h"

/*@*****************************************************************************
 * Package: RvMtfVideoPkg (root)
 * -----------------------------------------------------------------------------
 * Title: Video
 *
 * General: This section contains functions and type definitions that are used 
 *  		for sending and receiving Fast Update commands.
 ****************************************************************************@*/

/**********************************************************************************
					V I D E O	A P I		D E F I N I T I O N S
**********************************************************************************/

/*@*****************************************************************************
 * RvIppMdmVideoFastUpdatePictureCB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when a Fast Update Picture is received
 *		   from the remote party. It enables the application to pass the
 *         parameters to the decoder.
 *
 * Arguments:
 * Input:	ephemeralTerminalHndl   - Handle to the terminal representing
 *                                    the media stream.
 *			uiTerminalHndl			- Handle to the terminal representing
 *                                    the user interface.
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void ( *RvIppMdmVideoFastUpdatePictureCB)(
									 IN RvIppTerminalHandle	    ephemeralTerminalHndl,
									 IN RvIppTerminalHandle	    uiTerminalHndl);

/*@*****************************************************************************
 * RvIppMdmVideoFastUpdateGobCB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when a Fast Update GOB (Group Of Blocks)
 *		   is received from the remote party. It enables the application to pass
 *         the parameters to the decoder.
 *
 * Arguments:
 *
 * Input:	ephemeralTerminalHndl   - Handle to the terminal representing the
 *                                    media stream.
 *			uiTerminalHndl			- Handle to the terminal representing the
 *                                    user interface.
 *			firstGOB				- The first GOB (Group Of Blocks).
 *          numOfGOB				- The number of GOBs (Group Of Blocks).
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void ( *RvIppMdmVideoFastUpdateGobCB)(
									 IN RvIppTerminalHandle	    ephemeralTerminalHndl,
									 IN RvIppTerminalHandle	    uiTerminalHndl,
									 IN RvUint					firstGOB,
									 IN RvUint					numOfGOB);

/*@*****************************************************************************
 * RvIppMdmVideoFastUpdateMbCB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when a Fast Update MB (Multi Blocks)
 *		   is received from the remote party. It enables the application to pass
 *         the parameters to the decoder.
 *
 * Arguments:
 * Input:	ephemeralTerminalHndl   - Handle to the terminal representing the
 *                                    media stream.
 *			uiTerminalHndl			- Handle to the terminal representing the
 *                                    user interface.
 *			firstGOB				- The first GOB (Group Of Blocks).
 *          firstMV					- The first MB (Multi Blocks).
 *          numOfMBs				- The number of MB (Multi Blocks) to be
 *                                    updated.
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void ( *RvIppMdmVideoFastUpdateMbCB)(
									IN RvIppTerminalHandle	    ephemeralTerminalHndl,
									IN RvIppTerminalHandle		uiTerminalHndl,
									IN RvUint					firstGOB,
									IN RvUint					firstMB,
									IN RvUint					numOfMB);

/*@*****************************************************************************
 * RvIppMdmVideoFastUpdatePictureFreezeCB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when a Fast Update Picture Freeze is received
 *		   from the remote party. It enables the application to pass the
 *         parameters to the decoder.
 *
 * Arguments:
 * Input:  ephemeralTerminalHndl  - Handle to the terminal representing the
 *                                  media stream.
 *         uiTerminalHndl		  - Handle to the terminal representing the
 *                                  user interface.
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void ( *RvIppMdmVideoFastUpdatePictureFreezeCB)(
									 IN RvIppTerminalHandle	    ephemeralTerminalHndl,
									 IN RvIppTerminalHandle	uiTerminalHndl);


/*@*****************************************************************************
 * Type: RvIppMdmVideoExtClbks (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * This structure includes video callbacks for sending and receiving a Fast
 * Update.
 ****************************************************************************@*/
typedef struct RvIppMdmVideoExtClbks_ {
	RvIppMdmVideoFastUpdatePictureCB		fastUpdatePicture;
	RvIppMdmVideoFastUpdateGobCB		    fastUpdateGob;
	RvIppMdmVideoFastUpdateMbCB				fastUpdateMb;
	RvIppMdmVideoFastUpdatePictureFreezeCB	fastUpdatePictureFreeze;
} RvIppMdmVideoExtClbks;

/*@*****************************************************************************
 * rvIppMdmVideoRegisterExtClbks (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Registers video callbacks to the MTF. These callbacks use the terminal 
 *         as the stream specifier. This API should be called after 
 *         rvMtfSipConstruct() is called.
 *
 * Arguments:
 * Input:  clbks     - Pointer to a structure containing video callbacks for
 *                     Fast Update.
 *
 * Return Value: None.
 ****************************************************************************@*/
RVAPI void RVCALLCONV rvIppMdmVideoRegisterExtClbks(
						IN RvIppMdmVideoExtClbks* clbks);


/*===========================================================================*/
/*                            Callbacks by Connection                        */
/*===========================================================================*/

/*@*****************************************************************************
 * RvIppMdmVideoConnFastUpdatePictureCB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when a Fast Update Picture is received
 *		   from the remote party. It enables the application to pass the
 *         parameters to the decoder. 
 *         The media stream is identified by the connection as well as 
 *         by the terminal.
 *
 * Arguments:
 * Input:   connectionHndl          - Handle to the connection representing
 *                                    the media stream.
 *          connAppHndl	        	- Handle to the application data that is
 *								      associated with the connection (the call).
 *			uiTerminalHndl			- Handle to the terminal representing
 *                                    the user interface.
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void ( *RvIppMdmVideoConnFastUpdatePictureCB)(
                                     IN RvIppConnectionHandle   connectionHndl,
									 IN RvMtfConnAppHandle		connAppHndl,
									 IN RvIppTerminalHandle	    uiTerminalHndl);

/*@*****************************************************************************
 * RvIppMdmVideoConnFastUpdateGobCB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when a Fast Update GOB (Group Of Blocks)
 *		   is received from the remote party. It enables the application to pass
 *         the parameters to the decoder.
 *         The media stream is identified by the connection as well as 
 *         by the terminal.
 *
 * Arguments:
 * Input:	connectionHndl          - Handle to the connection representing
 *                                    the media stream.
 *          connAppHndl	        	- Handle to the application data that is
 *								      associated with the connection (the call).
 *			uiTerminalHndl			- Handle to the terminal representing the
 *                                    user interface.
 *			firstGOB				- The first GOB (Group Of Blocks).
 *          numOfGOB				- The number of GOBs (Group Of Blocks).
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void ( *RvIppMdmVideoConnFastUpdateGobCB)(
									IN RvIppConnectionHandle    connectionHndl,
									IN RvMtfConnAppHandle		connAppHndl,
									IN RvIppTerminalHandle	    uiTerminalHndl,
									IN RvUint					firstGOB,
									IN RvUint					numOfGOB);

/*@*****************************************************************************
 * RvIppMdmVideoConnFastUpdateMbCB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when a Fast Update MB (Multi Blocks)
 *		   is received from the remote party. It enables the application to pass
 *         the parameters to the decoder.
 *         The media stream is identified by the connection as well as 
 *         by the terminal.
 *
 * Arguments:
 * Input:	connectionHndl          - Handle to the connection representing
 *                                    the media stream.
 *          connAppHndl	        	- Handle to the application data that is
 *								      associated with the connection (the call).
 *			uiTerminalHndl			- Handle to the terminal representing the
 *                                    user interface.
 *			firstGOB				- The first GOB (Group Of Blocks).
 *          firstMV					- The first MB (Multi Blocks).
 *          numOfMBs				- The number of MB (Multi Blocks) to be
 *                                    updated.
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void ( *RvIppMdmVideoConnFastUpdateMbCB)(
									IN RvIppConnectionHandle    connectionHndl,
									IN RvMtfConnAppHandle		connAppHndl,
									IN RvIppTerminalHandle		uiTerminalHndl,
									IN RvUint					firstGOB,
									IN RvUint					firstMB,
									IN RvUint					numOfMB);

/*@*****************************************************************************
 * RvIppMdmVideoConnFastUpdatePictureFreezeCB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when a Fast Update Picture Freeze is received
 *		   from the remote party. It enables the application to pass the
 *         parameters to the decoder.
 *         The media stream is identified by the connection as well as 
 *         by the terminal.
 *
 * Arguments:
 * Input:  connectionHndl         - Handle to the connection representing
 *                                  the media stream.
 *         connAppHndl	          - Handle to the application data that is
 *								    associated with the connection (the call).
 *         uiTerminalHndl		  - Handle to the terminal representing the
 *                                  user interface.
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void ( *RvIppMdmVideoConnFastUpdatePictureFreezeCB)(
									IN RvIppConnectionHandle    connectionHndl,
									IN RvMtfConnAppHandle		connAppHndl,
									IN RvIppTerminalHandle	    uiTerminalHndl);


/*@*****************************************************************************
 * Type: RvIppMdmVideoConnExtClbks (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * This structure includes video callbacks for sending and receiving a Fast
 * Update with connection identification.
 ****************************************************************************@*/
typedef struct RvIppMdmVideoConnExtClbks_ {
	RvIppMdmVideoConnFastUpdatePictureCB		connFastUpdatePicture;
	RvIppMdmVideoConnFastUpdateGobCB		    connFastUpdateGob;
	RvIppMdmVideoConnFastUpdateMbCB				connFastUpdateMb;
	RvIppMdmVideoConnFastUpdatePictureFreezeCB	connFastUpdatePictureFreeze;
} RvIppMdmVideoConnExtClbks;

/*@*****************************************************************************
 * rvIppMdmVideoRegisterConnExtClbks (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Registers video callbacks to the MTF. These callbacks use the 
 *         connection and the terminal as stream specifiers. 
 *         This API should be called after rvMtfSipConstruct() is called.
 *
 * Arguments:
 * Input:  clbks     - Pointer to a structure containing video callbacks for
 *                     Fast Update.
 *
 * Return Value: None.
 ****************************************************************************@*/
RVAPI void RVCALLCONV rvIppMdmVideoRegisterConnExtClbks(
						IN RvIppMdmVideoConnExtClbks* clbks);

/*===========================================================================*/
/*            Callbacks by Connection and specific Media Stream              */
/*===========================================================================*/

/*@*****************************************************************************
* RvIppMdmVideoStreamConnFastUpdatePictureCB (RvMtfVideoPkg)
* -----------------------------------------------------------------------------
* General:
*         This callback is called when a Fast Update Picture is received
*		  from the remote party. It enables the application to pass the
*         parameters to the decoder. 
*         The media stream is identified by the terminal, the connection, and
*         the stream handle. When streamHndl is NULL, the application should 
*         refer to the main video stream on the specified connection of 
*         the terminal. 
*
* Arguments:
* Input:   connectionHndl   - Handle to the connection.
*          connAppHndl	    - Handle to the application data that is
*							  associated with the connection (the call).
*		   uiTerminalHndl	- Handle to the terminal representing
*                             the user interface.
*		   streamHndl		- Handle to the media stream. When the handle is 
*							  NULL, the Fast Update is for the main video 
*                             stream.
*		   streamAppHndl	- Handle to the application data that is  
*                             associated with the media stream.
*
* Return Value: None.
****************************************************************************@*/
typedef void ( *RvIppMdmVideoStreamConnFastUpdatePictureCB)(
	IN RvIppConnectionHandle     connectionHndl,
	IN RvMtfConnAppHandle		 connAppHndl,
	IN RvIppTerminalHandle	     uiTerminalHndl,
	IN RvMtfMediaStreamHandle    streamHndl,
	IN RvMtfMediaStreamAppHandle streamAppHndl);

/*@*****************************************************************************
* RvIppMdmVideoStreamConnFastUpdateGobCB (RvMtfVideoPkg)
* -----------------------------------------------------------------------------
* General:
*         This callback is called when a Fast Update GOB (Group Of Blocks)
*		  is received from the remote party. It enables the application to pass
*         the parameters to the decoder.
*         The media stream is identified by the terminal, the connection, and
*         the stream handle. When streamHndl is NULL, the application should 
*         refer to the main video stream on the specified connection of the 
*         terminal.
*
* Arguments:
* Input:	connectionHndl    - Handle to the connection representing
*                               the media stream.
*           connAppHndl	      - Handle to the application data that is
*							    associated with the connection (the call).
*			uiTerminalHndl	  - Handle to the terminal representing the
*                               user interface.
*		    streamHndl		  - Handle to the media stream. When the handle is 
*							    NULL, the Fast Update is for the main video stream.
*		    streamAppHndl	  - Handle to the application data that is  
*                               associated with the media stream.
*			firstGOB		  - The first GOB (Group Of Blocks).
*           numOfGOB		  - The number of GOBs (Group Of Blocks).
*
* Return Value: None.
****************************************************************************@*/
typedef void ( *RvIppMdmVideoStreamConnFastUpdateGobCB)(
	IN RvIppConnectionHandle     connectionHndl,
	IN RvMtfConnAppHandle		 connAppHndl,
	IN RvIppTerminalHandle	     uiTerminalHndl,
	IN RvMtfMediaStreamHandle    streamHndl,
	IN RvMtfMediaStreamAppHandle streamAppHndl,
	IN RvUint					 firstGOB,
	IN RvUint					 numOfGOB);

/*@*****************************************************************************
* RvIppMdmVideoStreamConnFastUpdateMbCB (RvMtfVideoPkg)
* -----------------------------------------------------------------------------
* General:
*         This callback is called when a Fast Update MB (Multi Blocks)
*		  is received from the remote party. It enables the application to pass
*         the parameters to the decoder.
*         The media stream is identified by the terminal, the connection, and
*         the stream handle. When streamHndl is NULL, the application should 
*         refer to the main video stream on the specified connection of the 
*         terminal.
*
* Arguments:
* Input:	connectionHndl	- Handle to the connection representing
*                             the media stream.
*           connAppHndl		- Handle to the application data that is
*						      associated with the connection (the call).
*			uiTerminalHndl	- Handle to the terminal representing the
*                             user interface.
*		    streamHndl		- Handle to the media stream. When the handle is 
*							  NULL, the Fast Update is for the main video stream.
*		    streamAppHndl	- Handle to the application data that is  
*                             associated with the media stream.
*			firstGOB		- The first GOB (Group Of Blocks).
*           firstMV			- The first MB (Multi Blocks).
*           numOfMBs		- The number of MB (Multi Blocks) to be
*                             updated.
*
* Return Value: None.
****************************************************************************@*/
typedef void ( *RvIppMdmVideoStreamConnFastUpdateMbCB)(
	IN RvIppConnectionHandle     connectionHndl,
	IN RvMtfConnAppHandle		 connAppHndl,
	IN RvIppTerminalHandle		 uiTerminalHndl,
	IN RvMtfMediaStreamHandle    streamHndl,
	IN RvMtfMediaStreamAppHandle streamAppHndl,
	IN RvUint					 firstGOB,
	IN RvUint					 firstMB,
	IN RvUint					 numOfMB);

/*@*****************************************************************************
* RvIppMdmVideoStreamConnFastUpdatePictureFreezeCB (RvMtfVideoPkg)
* -----------------------------------------------------------------------------
* General:
*         This callback is called when a Fast Update Picture Freeze is received
*		  from the remote party. It enables the application to pass the
*         parameters to the decoder.
*         The media stream is identified by the terminal, the connection, and
*         the stream handle. When streamHndl is NULL, the application should 
*         refer to the main video stream on the specified connection of the 
*         terminal.
*
* Arguments:
* Input:  connectionHndl     - Handle to the connection representing
*                              the media stream.
*         connAppHndl        - Handle to the application data that is
*                              associated with the connection (the call).
*         uiTerminalHndl     - Handle to the terminal representing the
*                              user interface.
*		  streamHndl         - Handle to the media stream. When the handle is 
*                              NULL, the Fast Update is for the main video stream.
*		  streamAppHndl      - Handle to the application data that is  
*                              associated with the media stream.
*
* Return Value: None.
****************************************************************************@*/
typedef void ( *RvIppMdmVideoStreamConnFastUpdatePictureFreezeCB)(
	IN RvIppConnectionHandle     connectionHndl,
	IN RvMtfConnAppHandle		 connAppHndl,
	IN RvIppTerminalHandle	     uiTerminalHndl,
	IN RvMtfMediaStreamHandle    streamHndl,
	IN RvMtfMediaStreamAppHandle streamAppHndl);

/*@*****************************************************************************
* Type: RvIppMdmVideoStreamConnExtClbks (RvMtfVideoPkg)
* -----------------------------------------------------------------------------
* This structure includes video callbacks for sending and receiving a Fast
* Update with connection and media stream identification.
****************************************************************************@*/
typedef struct RvIppMdmVideoStreamConnExtClbks_ {
	RvIppMdmVideoStreamConnFastUpdatePictureCB			streamConnFastUpdatePicture;
	RvIppMdmVideoStreamConnFastUpdateGobCB				streamConnFastUpdateGob;
	RvIppMdmVideoStreamConnFastUpdateMbCB				streamConnFastUpdateMb;
	RvIppMdmVideoStreamConnFastUpdatePictureFreezeCB	streamConnFastUpdatePictureFreeze;
} RvIppMdmVideoStreamConnExtClbks;

/*@*****************************************************************************
* rvIppMdmVideoRegisterStreamConnExtClbks (RvMtfVideoPkg)
* -----------------------------------------------------------------------------
* General:
*         Registers video callbacks to the MTF. These callbacks use the stream,  
*         the connection, and the terminal as stream specifiers. This API should be called  
*         after rvMtfSipConstruct()/rvMtfH323Construct() is called.
*
* Arguments:
* Input:  clbks     - Pointer to a structure containing video callbacks for
*                     Fast Update.
*
* Return Value: None.
****************************************************************************@*/
RVAPI void RVCALLCONV rvIppMdmVideoRegisterStreamConnExtClbks(
	IN RvIppMdmVideoStreamConnExtClbks* clbks);
 

/*@*****************************************************************************
 * rvIppMdmSendFastUpdatePicture (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Sends a FastUpdatePicture command to the remote party.
 *         This API is DEPRECATED!!! Use rvIppMdmSendConnFastUpdatePicture()
 *         instead.
 *
 * Arguments:
 * Input:  uiTerminalHndl     - Handle to the termination.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendFastUpdatePicture(
									IN RvIppTerminalHandle	uiTerminalHndl);

/*@*****************************************************************************
 * rvIppMdmSendConnFastUpdatePicture (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Sends a FastUpdatePicture command to the remote party.
 *         Uses the connection object as media stream specifier.
 *
 * Arguments:
 * Input:  connectionHndl     - Handle to the connection.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendConnFastUpdatePicture(
									IN RvIppConnectionHandle	connectionHndl);

/*@*****************************************************************************
 * rvIppMdmSendFastUpdateGOB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Sends a Fast Update GOB (Group Of Blocks) command to the remote party.
 *         This API is DEPRECATED !!! Use rvIppMdmSendConnFastUpdateGOB()
 *         instead.
 *
 * Arguments:
 * Input:  uiTerminalHndl   -  Handle to the termination.
 *         firstGob			-  The first block number.
 *         numGobs			-  The number of blocks to be updated.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendFastUpdateGOB(
									IN RvIppTerminalHandle		uiTerminalHndl,
									IN RvUint					firstGob,
									IN RvUint					numGobs);

/*@*****************************************************************************
 * rvIppMdmSendConnFastUpdateGOB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Sends a Fast Update GOB (Group Of Blocks) command to the remote party.
 *         Uses the connection object as media stream specifier.
 *
 * Arguments:
 * Input:  connectionHndl   -  Handle to the connection.
 *         firstGob			-  The first block number.
 *         numGobs			-  The number of blocks to be updated.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendConnFastUpdateGOB(
									IN RvIppConnectionHandle	connectionHndl,
									IN RvUint					firstGob,
									IN RvUint					numGobs);
/*@*****************************************************************************
 * rvIppMdmSendFastUpdateMB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Sends a Fast Update Macro Blocks command to the remote party.
 *         This API is DEPRECATED!!! Use rvIppMdmSendConnFastUpdateMB()
 *         instead.
 *
 * Arguments:
 * Input:  uiTerminalHndl   -  Handle to the termination.
 *         firstGob			-  The first block number to be updated.
 *         firstMb			-  The first Multi Block.
 *         numGobs			-  The number of Macro Blocks to be updated.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendFastUpdateMB(
									IN RvIppTerminalHandle		uiTerminalHndl,
									IN RvUint					firstGob,
									IN RvUint					firstMb,
									IN RvUint					numMbs);
/*@*****************************************************************************
 * rvIppMdmSendConnFastUpdateMB (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Sends a Fast Update Macro Blocks command to the remote party.
 *         Uses the connection object as media stream specifier.
 *
 * Arguments:
 * Input:  connectionHndl   -  Handle to the connection.
 *         firstGob			-  The first block number to be updated.
 *         firstMb			-  The first Multi Block.
 *         numGobs			-  The number of Macro Blocks to be updated.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendConnFastUpdateMB(
									IN RvIppConnectionHandle	connectionHndl,
									IN RvUint					firstGob,
									IN RvUint					firstMb,
									IN RvUint					numMbs);

/*@*****************************************************************************
 * rvIppMdmSendFastUpdatePictureFreeze (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Sends a FastUpdatePictureFreeze command to the remote party.
 *         This API is DEPRECATED!!! Use rvIppMdmSendConnFastUpdatePictureFreeze()
 *         instead.
 *
 * Arguments:
 * Input:  uiTerminalHndl   -  Handle to the termination.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendFastUpdatePictureFreeze(
									IN RvIppTerminalHandle	uiTerminalHndl);

/*@*****************************************************************************
 * rvIppMdmSendConnFastUpdatePictureFreeze (RvMtfVideoPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Sends a FastUpdatePictureFreeze command to the remote party.
 *         Uses the connection object as media stream specifier.
 *
 * Arguments:
 * Input:  connectionHndl   -  Handle to the connection.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendConnFastUpdatePictureFreeze(
									IN RvIppConnectionHandle	connectionHndl);

/*@*****************************************************************************
* rvIppMdmSendConnStreamFastUpdatePicture (RvMtfVideoPkg)
* -----------------------------------------------------------------------------
* General:
*         Sends a FastUpdatePicture command of the specific media stream of 
*         the connection to the remote party.
*
* Arguments:
* Input:  connectionHndl     - Handle to the connection.
*         streamHndl        -  Handle to the media stream.
*                              Use NULL for the main video stream (since there is
*                              no stream handle exchange between the MTF and the 
*                              application for the main video stream in the current  
*                              MTF release). Use the streamHndl received from the 
*                              MTF for the second (presentation) video stream.
*
* Return Value: RV_OK if successful, other if not.
****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendConnStreamFastUpdatePicture(
	IN RvIppConnectionHandle	connectionHndl,
	IN RvMtfMediaStreamHandle   streamHndl);

/*@*****************************************************************************
* rvIppMdmSendConnStreamFastUpdateGOB (RvMtfVideoPkg)
* -----------------------------------------------------------------------------
* General:
*         Sends a Fast Update GOB (Group Of Blocks) command to the remote party.
*         Uses the connection and stream object as the media stream specifier.
*
* Arguments:
* Input:  connectionHndl    -  Handle to the connection.
*         streamHndl        -  Handle to the media stream.
*                              Use NULL for the main video stream (since there is 
*                              no stream handle exchange between the MTF and the 
*                              application for the main video stream in the current   
*                              MTF release). Use the streamHndl received from the 
*                              MTF for the second (presentation) video stream.
*         firstGob			-  The first block number.
*         numGobs			-  The number of blocks to be updated.
*
* Return Value: RV_OK if successful, other if not.
****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendConnStreamFastUpdateGOB(
	IN RvIppConnectionHandle	connectionHndl,
	IN RvMtfMediaStreamHandle   streamHndl,
	IN RvUint					firstGob,
	IN RvUint					numGobs);

/*@*****************************************************************************
* rvIppMdmSendConnStreamFastUpdateMB (RvMtfVideoPkg)
* -----------------------------------------------------------------------------
* General:
*         Sends a Fast Update Macro Blocks command to the remote party.
*         Uses the connection and the stream object as the media stream specifier.
*
* Arguments:
* Input:  connectionHndl	-  Handle to the connection.
*         streamHndl        -  Handle to the media stream.
*                              Use NULL for the main video stream (since there is
*                              no stream handle exchange between the MTF and the 
*                              application for the main video stream in the current   
*                              MTF release). Use the streamHndl received from the 
*                              MTF for the second (presentation) video stream.
*         firstGob			-  The first block number to be updated.
*         firstMb			-  The first multi block.
*         numGobs			-  The number of macro blocks to be updated.
*
* Return Value: RV_OK if successful, other if not.
****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendConnStreamFastUpdateMB(
	IN RvIppConnectionHandle	connectionHndl,
	IN RvMtfMediaStreamHandle   streamHndl,
	IN RvUint					firstGob,
	IN RvUint					firstMb,
	IN RvUint					numMbs);

/*@*****************************************************************************
* rvIppMdmSendConnStreamFastUpdatePictureFreeze (RvMtfVideoPkg)
* -----------------------------------------------------------------------------
* General:
*         Sends a FastUpdatePictureFreeze command to the remote party.
*         Uses the connection and the stream object as the media stream specifier.
*
* Arguments:
* Input:  connectionHndl    -  Handle to the connection.
*         streamHndl        -  Handle to the media stream.
*                              Use NULL for the main video stream (since there is
*                              no stream handle exchange between the MTF and the 
*                              application for the main video stream in the current   
*                              MTF release). Use the streamHndl received from the 
*                              MTF for the second (presentation) video stream.
*
* Return Value: RV_OK if successful, other if not.
****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvIppMdmSendConnStreamFastUpdatePictureFreeze(
	IN RvIppConnectionHandle	connectionHndl,
	IN RvMtfMediaStreamHandle   streamHndl);

#endif /*RV_MDMCONTROL_API_H*/
