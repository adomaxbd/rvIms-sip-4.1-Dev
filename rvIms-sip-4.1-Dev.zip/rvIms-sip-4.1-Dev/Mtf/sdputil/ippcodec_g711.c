/******************************************************************************
Filename:    ippcodec_g711.h
Description:
*******************************************************************************/
#include <string.h>
#include "ippcodec.h"
#include "ippcodec_g711.h"

#define LOGSRC	LOGSRC_CODEC

#define    STR_PCMU_PTIME         "ptime"

#ifdef  MTF_SUPPORT_G711_ANNEX2
#define    STR_G711_ANNEX2         "annex2"
#endif
/*******************************************************************************/
/*******************************************************************************/
RVAPI  RvStatus CodecData_g711_Construct( OUT CodecData_g711*	data,
				   IN RvSdpMediaDescr* descr,/*where the codec is located*/
				   IN int			payload
				   )
{
    const char* szValue;

	memset( data,0, sizeof(CodecData_g711));
	
	if(payload <0)
		payload = IppCodecGetFirstPayload( descr);
	/* parse the codec parameters */
    szValue = ippGetAttrByName( STR_PCMU_PTIME, descr);
    if(szValue)
        data->ptime = atoi(szValue);
    else
        data->ptime = 0;

#ifdef  MTF_SUPPORT_G711_ANNEX2
    szValue = ippGetAttrByName( STR_G711_ANNEX2, descr);
    if(szValue && RvStrcasecmp(szValue, "yes")==0)
        data->bAnnex2 = rvTrue;
    else
        data->bAnnex2 = rvFalse;
#endif

	return RV_OK;
}
/*******************************************************************************/
RVAPI void CodecData_g711_Destruct( OUT CodecData_g711*	data)
{
    RV_UNUSED_ARG(data);
}
/*******************************************************************************/
/********************************************************************************/
/*******************************************************************************/
