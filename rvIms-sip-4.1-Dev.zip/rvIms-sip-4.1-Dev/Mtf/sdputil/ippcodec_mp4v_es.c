/******************************************************************************
Filename:    ippcodec_mp4v_es.h
Description:
*******************************************************************************/
#include <string.h>
#include "ippcodec.h"
#include "ippcodec_mp4v_es.h"

#define LOGSRC	LOGSRC_CODEC

/*******************************************************************************/
#define    STR_MP4_PROFILE_LEVEL_ID   "profile-level-id"
#define    STR_MP4_CONFIG             "config"
/*******************************************************************************/
RVAPI RvStatus CodecData_mp4v_es_Construct( OUT CodecData_mp4v_es*	data,
				   IN RvSdpMediaDescr* descr,/*where the codec is located*/
				   IN int			payload
				   )
{
    char    value[32];
    RvInt   index;

	memset( data,0, sizeof(CodecData_mp4v_es));
	
	if(payload <0)
		payload = IppCodecGetFirstPayload( descr);
	/* parse the codec parameters */
	
	/*OPTIONAL parameter*/
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName(
                                                        descr, 
                                                        STR_MP4_PROFILE_LEVEL_ID,
                                                        payload,
                                                        ';',
                                                        value,
                                                        sizeof(value),
                                                        &index
                                                        ))
        data->profileAndLevel = (RvUint8)atoi( value);

    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName(
                                                        descr, 
                                                        STR_MP4_CONFIG,
                                                        payload,
                                                        ';',
                                                        data->config,
                                                        sizeof(data->config),
                                                        &index
                                                        ))
    {
    }
    else
        data->config[0] = '\0'; 


	return RV_OK;
}
/*******************************************************************************/
RVAPI void CodecData_mp4v_es_Destruct( OUT CodecData_mp4v_es*	data)
{
    RV_UNUSED_ARG(data);
}
/*******************************************************************************/
/********************************************************************************/
/*******************************************************************************/
