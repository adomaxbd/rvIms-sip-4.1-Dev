/******************************************************************************
Filename:    ippcodec_g722.h
Description:
*******************************************************************************/
#include <string.h>
#include "ippcodec.h"
#include "ippcodec_g722.h"
#define LOGSRC	LOGSRC_CODEC


#define    STR_PCMU_PTIME         "ptime"
/*******************************************************************************/
/*******************************************************************************/
RVAPI RvStatus CodecData_g722_Construct( OUT CodecData_g722*	data,
				   IN RvSdpMediaDescr* descr,/*where the codec is located*/
				   IN int			payload
				   )
{
    const char* szValue;

	memset( data,0, sizeof(CodecData_g722));
	
	if(payload <0)
		payload = IppCodecGetFirstPayload( descr);
	/* parse the codec parameters */
    szValue = ippGetAttrByName( STR_PCMU_PTIME, descr);
    if(szValue)
        data->ptime = atoi(szValue);
    else
        data->ptime = 0;
	
	return RV_OK;
}
/*******************************************************************************/
RVAPI void CodecData_g722_Destruct( OUT CodecData_g722*	data)
{
    RV_UNUSED_ARG(data);
}
/*******************************************************************************/
/********************************************************************************/
/*******************************************************************************/
