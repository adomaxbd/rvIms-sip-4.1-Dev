/******************************************************************************
Filename:    ippcodec_h263.h
Description:
*******************************************************************************/
#include <string.h>
#include "ippcodec.h"
#include "rvlog.h"
#include "ippcodec_h263.h"


#define LOGSRC	LOGSRC_CODEC

extern RvLogSource         g_logSrc;
/*******************************************************************************/
#define    STR_H263_SQCIF_V        "SQCIF"	/*sqcifMPI	INTEGER (1..32) OPTIONAL,	-- units 1/29.97 Hz*/
#define    STR_H263_QCIF_V         "QCIF"	/*qcifMPI	INTEGER (1..32) OPTIONAL,	-- units 1/29.97 Hz*/
#define    STR_H263_CIF_V          "CIF"	/*cifMPI		INTEGER (1..32) OPTIONAL,	-- units 1/29.97 Hz*/
#define    STR_H263_CIF4_V         "CIF4"	/*cif4MPI	INTEGER (1..32) OPTIONAL,	-- units 1/29.97 Hz*/
#define    STR_H263_CIF16_V        "CIF16"	/*cif16MPI	INTEGER (1..32) OPTIONAL,	-- units 1/29.97 Hz*/
#define    STR_H263_XMAX_V         "XMAX"
#define    STR_H263_YMAX_V         "YMAX"
#define    STR_H263_MPI_V          "MPI"
#define    STR_H263_D_V            "D"
#define    STR_H263_E_V            "E"
#define    STR_H263_F_V            "F"
#define    STR_H263_G_V            "G"
#define    STR_H263_I_V            "I"
#define    STR_H263_J_V            "J"
#define    STR_H263_K_V            "K"
#define    STR_H263_L_V            "L"
#define    STR_H263_M_V            "M"
#define    STR_H263_N_V            "N"
#define    STR_H263_O_V            "O"
#define    STR_H263_P_V            "P"
#define    STR_H263_Q_V            "Q"
#define    STR_H263_R_V            "R"
#define    STR_H263_S_V            "S"
#define    STR_H263_T_V            "T"
#define    STR_H263_PAR_V         "PAR"
#define    STR_H263_CPCF_V         "CPCF"
#define    STR_H263_MAXBR_V        "MAXBR"	/*maxBitRate	INTEGER (1..192400),	-- units 100 bit/s*/
#define    STR_H263_BPP_V          "BPP"	/*bppMaxKb	INTEGER (0..65535) OPTIONAL,	-- units 1024 bits*/
#define    STR_H263_HRD_V          "HRD"	/*hrd-B		INTEGER (0..524287) OPTIONAL,	-- units 128 bits*/
#define    STR_H263_INTERLACED_V   "INTERLACED"
#define    STR_TIAS                 "TIAS"
#define	   STR_AS					"AS"

#define	   DEFAULT_MAXBR			3200
/*******************************************************************************/
#define set_order(order, index, value, order_privilege)   if(order > (RvUint32)index){ order = index; order_privilege = value;}
/*******************************************************************************/
RVAPI RvStatus CodecData_h263_Construct( OUT CodecData_h263*	data,
								  IN RvSdpMediaDescr* descr,/*where the codec is located*/
								  IN int			payload
								  )
{
    char        value[32];
    RvUint32    order = 0xFFFF;
    RvInt       index;
	
	memset( data,0, sizeof(CodecData_h263));
	
	if(payload <0)
		payload = IppCodecGetFirstPayload( descr);
    
	/*  parse the codec parameters
     *  --------------------------
     */
	
	/*OPTIONAL parameter*/
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                        descr, 
                                                        STR_H263_HRD_V,
                                                        payload,
                                                        " ;/",
                                                        value,
                                                        sizeof(value),
                                                        &index
                                                        ))
        data->hrdB = atoi(value);
	
	/*OPTIONAL parameter*/
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                        descr, 
                                                        STR_H263_BPP_V,
                                                        payload,
                                                        " ;/",
                                                        value,
                                                        sizeof(value),
                                                        &index
                                                        ))
        data->bppMaxKb = atoi(value);
	
	/*MUST parameter*/
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                        descr, 
                                                        STR_H263_MAXBR_V,
                                                        payload,
                                                        " ;/", 
                                                        value,
                                                        sizeof(value),
                                                        &index
                                                        ))
        data->maxBitRate = atoi(value);
    else if /*interop MCU*/ (RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                        descr, 
                                                        STR_H263_MAXBR_V,
                                                        payload,
                                                        " ;/",
                                                        value,
                                                        sizeof(value),
                                                        &index
                                                        ))
        data->maxBitRate = atoi(value);
	
    else if /*interop Policom*/ /* from bandwith*/(rvSdpMediaDescrGetNumOfBandwidth( descr) >0)
    {
        RvSdpBandwidth* band = rvSdpMediaDescrGetBandwidth( descr);
        if(RvStrcasecmp(STR_TIAS, band->iBWType) ==0)
            data->maxBitRate = band->iBWValue /100;
		else	if(RvStrcasecmp(STR_AS, band->iBWType) ==0)
			data->maxBitRate = band->iBWValue*10;
		else
		    data->maxBitRate = DEFAULT_MAXBR;
    }

    else
	{
		data->maxBitRate = DEFAULT_MAXBR;
		RvLogError(&g_logSrc, ( &g_logSrc,"sdpToData(): %s is't found in Sdp data. Used default: %d", 
                                STR_H263_MAXBR_V, 
                                data->maxBitRate));
	}
	/*MUST parameter*/
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                        descr, 
                                                        STR_H263_D_V,
                                                        payload,
                                                        " ;/",
                                                        value,
                                                        sizeof(value),
                                                        &index
                                                        )  &&  RvStrcasecmp( value, "2") ==0)
        data->unrestrictedVector = rvTrue;
    else
    	data->unrestrictedVector = rvFalse;
	
	/*MUST parameter*/
    data->arithmeticCoding = (RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                                            descr, 
                                                                            STR_H263_E_V,
                                                                            payload,
                                                                            " ;/",
                                                                            value,
                                                                            sizeof(value),
                                                                            &index
                                                                            ));
	
	/*MUST parameter*/
    data->advancedPrediction = (RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                                            descr, 
                                                                            STR_H263_F_V,
                                                                            payload,
                                                                            " ;/",
                                                                            value,
                                                                            sizeof(value),
                                                                            &index
                                                                            ));
	
	/*MUST parameter*/
    data->pbFrames = (RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                                            descr, 
                                                                            STR_H263_G_V,
                                                                            payload,
                                                                            " ;/", 
                                                                            value,
                                                                            sizeof(value),
                                                                            &index
                                                                            ));	
	/*MUST parameter*/
	/*possibility to change the tradeoff between temporal and spatial resolutions:
	* not clear how it's coded in SDP format. We always put FALSE
	*/
	data->temporalSpatialTradeOffCapability = rvFalse;
	
    /*get resolution options and their order */
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                    descr, 
                                                    STR_H263_SQCIF_V,
                                                    payload,
                                                    " ;/",
                                                    value,
                                                    sizeof(value),
                                                    &index
                                                    ))
    {
        data->sqcifMPI = atoi( value);
        set_order( order, index, MF_RESOLUTION_SQCIF, data->order_privilege);
    }
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                    descr, 
                                                    STR_H263_QCIF_V,
                                                    payload,
                                                    " ;/",
                                                    value,
                                                    sizeof(value),
                                                    &index
                                                    ))
    {
        data->qcifMPI = atoi( value);
        set_order( order, index, MF_RESOLUTION_QCIF, data->order_privilege);
    }
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                    descr, 
                                                    STR_H263_CIF_V,
                                                    payload,
                                                    " ;/",
                                                    value,
                                                    sizeof(value),
                                                    &index
                                                    ))
    {
        data->cifMPI = atoi( value);
        set_order( order, index, MF_RESOLUTION_CIF, data->order_privilege);
    }
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                    descr, 
                                                    STR_H263_CIF4_V,
                                                    payload,
                                                    " ;/",
                                                    value,
                                                    sizeof(value),
                                                    &index
                                                    ))
    {
        data->cif4MPI = atoi( value);
        set_order( order, index, MF_RESOLUTION_4CIF, data->order_privilege);
    }
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName2(
                                                    descr, 
                                                    STR_H263_CIF16_V,
                                                    payload,
                                                    " ;/",
                                                    value,
                                                    sizeof(value),
                                                    &index
                                                    ))
    {
        data->cif16MPI = atoi( value);
        set_order( order, index, MF_RESOLUTION_16CIF, data->order_privilege);
    }

    /*default behavior according RFC 4629*/
    if(order == 0xFFFF)
    {
        data->qcifMPI =2;
        data->framerate = 30/ data->qcifMPI;
        data->order_privilege = MF_RESOLUTION_QCIF;

//        data->cifMPI =2;
//        data->framerate = 30/ data->cifMPI;
//        data->order_privilege = MF_RESOLUTION_CIF;
    }

    /*frame rate*/
    switch(data->order_privilege)
    {
		case MF_RESOLUTION_SQCIF:
			data->framerate = 30/ data->sqcifMPI;
			break;
		case MF_RESOLUTION_QCIF:
			data->framerate = 30/ data->qcifMPI;
			break;
		case MF_RESOLUTION_CIF:
			data->framerate = 30/ data->cifMPI;
			break;
		case MF_RESOLUTION_4CIF:
			data->framerate = 30/ data->cif4MPI;
			break;
		case MF_RESOLUTION_16CIF:
			data->framerate = 30/ data->cif16MPI;
			break;
		default:
    		RvLogError(&g_logSrc, (&g_logSrc,"sdpToData(): Resolution is't found in Sdp data. Used default: QCIF=2"));
			break;
    }
#if 0	
	/*
	*	get encoding name
	*/
	{
		RvSdpRtpMap* rtpMap = NULL;	
		
		if(	IppCodecFindRtpMapInMediaDescr( descr, payload, &rtpMap) && rtpMap)
		{
			data->szEncodingName = rvSdpRtpMapGetEncodingName( rtpMap);			
		}
		else
		{
			if( payload < FIRST_DYNAMIC_PAYLOAD)
			{
				data->szEncodingName = rvSdpCodecNameGetByPayLoad( payload);
			}
			else
				return RV_ERROR_UNKNOWN;
		}
	}
#endif	
	return RV_OK;
}

/******************************************************************************
*  CodecData_h263_to_mediaDsecr
*  --------------------------------
*  General :        Converts data from CodecData_h263 type structure into media
*                   descriptor
*
*
*  Return Value:   RV_OK - all the parameters converted successfully
*                  RV_ERROR_UNKNOWN - otherwise
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          data - ptr to codec data to be converted
*                  descr - media descriptor where the converted values are set
*                          The descriptor may hold values. Theses values will be
*                          overridden.
*                  payload - of the codec.
*				   listOneXcif - notifies whether the media descriptor is limited to 
*                                only one xCIP option (e.g. in an answer to an offer)
*                                or should list all supported xCIFs (e.g. in an offer).
*
*  Output:         none.
******************************************************************************/

RVAPI RvStatus CodecData_h263_to_mediaDsecr( IN CodecData_h263*	data,
								  INOUT RvSdpMediaDescr* descr,/*where the codec is located*/
								  IN int			   payload,
								  IN RV_BOOL           listOneXCif
								  )
{
    char    value[32];
	RvInt   numOfParams, i;
	RV_BOOL addNextXCIF = RV_TRUE;

    
	if(payload <0)
		payload = IppCodecGetFirstPayload( descr);

	/* clear all Fmtp params in descr */
	numOfParams = RvSdpCodecFmtpParamGetNum( descr, payload, ' ');
	
	for (i=0; i < numOfParams; i++)		
	{		
		RvSdpCodecFmtpParamRemoveByIndex(			
			descr,			
			0,			
			RV_FALSE,			
			payload,			
			' ');		
	}

	/* copy params from data to the media descriptor */
	
	/*OPTIONAL parameter*/


	if (data->hrdB != 0)
	{
		IppSdpUtil_itoa(data->hrdB, value);
		RvSdpCodecFmtpParamSet(
			descr,
			STR_H263_HRD_V,
			value,
			rvTrue,
			payload,
			' ',
			NULL);
	}

		
	/*OPTIONAL parameter*/

	if (data->bppMaxKb != 0)
	{
		IppSdpUtil_itoa(data->bppMaxKb, value);
		RvSdpCodecFmtpParamSet(
			descr,
			STR_H263_BPP_V,
			value,
			rvTrue,
			payload,
			' ',
			NULL);
	}



	/*Mandatory parameter*/


	if (data->unrestrictedVector)
	{
		RvSdpCodecFmtpParamSet(
			descr,
			STR_H263_D_V,
			"2",
			rvTrue,
			payload,
			' ',
			NULL);
	}	

	if (data->arithmeticCoding)
	{
		RvSdpCodecFmtpParamSet(
			descr,
			STR_H263_E_V,
			NULL,
			rvTrue,
			payload,
			' ',
			NULL);
	}
	

	if (data->advancedPrediction)
	{
		RvSdpCodecFmtpParamSet(
			descr,
			STR_H263_F_V,
			NULL,
			rvTrue,
			payload,
			' ',
			NULL);
	}
 

	if (data->pbFrames)
	{
		RvSdpCodecFmtpParamSet(
			descr,
			STR_H263_G_V,
			NULL,
			rvTrue,
			payload,
			' ',
			NULL);
	}

	/*  handle xCIF parameters */


	/* Put the preferred xCIF option. If one was not found, put one
	   of the less-preferred xCIF or all of them - depending on the value of listOneXCif.*/
	switch(data->order_privilege)
	{
	case MF_RESOLUTION_SQCIF:
		if (data->sqcifMPI !=0)
		{		
			IppSdpUtil_itoa(data->sqcifMPI, value);
		
			RvSdpCodecFmtpParamSet(
				descr,
				"SQCIF",
				value,
				rvTrue,
				payload,
				' ',
				NULL);
			addNextXCIF = !listOneXCif;
		}
		break;
	
	case MF_RESOLUTION_QCIF:

		if (data->qcifMPI !=0)
		{			
			IppSdpUtil_itoa(data->qcifMPI, value);

			RvSdpCodecFmtpParamSet(
				descr,
				"QCIF",
				value,
				rvTrue,
				payload,
				' ',
				NULL);
			addNextXCIF = !listOneXCif;
		}
		break;
	case MF_RESOLUTION_CIF:

		if (data->cifMPI !=0)
		{			
			IppSdpUtil_itoa(data->cifMPI, value);

			RvSdpCodecFmtpParamSet(
				descr,
				"CIF",
				value,
				rvTrue,
				payload,
				' ',
				NULL);
			addNextXCIF = !listOneXCif;
		}
		break;

	case MF_RESOLUTION_4CIF:

		if (data->cif4MPI !=0)
		{	

			IppSdpUtil_itoa(data->cif4MPI, value);

			RvSdpCodecFmtpParamSet(
				descr,
				"CIF4",
				value,
				rvTrue,
				payload,
				' ',
				NULL);
			addNextXCIF = !listOneXCif;
		}
		break;

	case MF_RESOLUTION_16CIF:

		if (data->cif16MPI !=0)
		{	

			IppSdpUtil_itoa(data->cif16MPI, value);

			RvSdpCodecFmtpParamSet(
				descr,
				"CIF16",
				value,
				rvTrue,
				payload,
				' ',
				NULL);
			addNextXCIF = !listOneXCif;
		}
		break;

	default:
		break;
	}

	/* Add the less preferred xCIF parameters */

	if ((data->sqcifMPI) && (data->order_privilege != MF_RESOLUTION_SQCIF) && addNextXCIF)
	{
		IppSdpUtil_itoa(data->sqcifMPI, value);
		RvSdpCodecFmtpParamSet(
			descr,
			"SQCIF",
			value,
			rvTrue,
			payload,
			' ',
			NULL);
		addNextXCIF = !listOneXCif;
	}


	if ((data->qcifMPI) && (data->order_privilege != MF_RESOLUTION_QCIF) && addNextXCIF)
	{
		IppSdpUtil_itoa(data->qcifMPI, value);
		RvSdpCodecFmtpParamSet(
			descr,
			"QCIF",
			value,
			rvTrue,
			payload,
			' ',
			NULL);
		addNextXCIF = !listOneXCif;
	}


	if ((data->cifMPI) && (data->order_privilege != MF_RESOLUTION_CIF) && addNextXCIF)
	{
		IppSdpUtil_itoa(data->cifMPI, value);
		RvSdpCodecFmtpParamSet(
			descr,
			"CIF",
			value,
			rvTrue,
			payload,
			' ',
			NULL);
		addNextXCIF = !listOneXCif;
	}

	if ((data->cif4MPI) && (data->order_privilege != MF_RESOLUTION_4CIF) && addNextXCIF)
	{
		IppSdpUtil_itoa(data->cif4MPI, value);
		RvSdpCodecFmtpParamSet(
			descr,
			"CIF4",
			value,
			rvTrue,
			payload,
			' ',
			NULL);
		addNextXCIF = !listOneXCif;
	}

	if ((data->cif16MPI) && (data->order_privilege != MF_RESOLUTION_16CIF) && addNextXCIF)
	{
		IppSdpUtil_itoa(data->cif16MPI, value);
		RvSdpCodecFmtpParamSet(
			descr,
			"CIF16",
			value,
			rvTrue,
			payload,
			' ',
			NULL);
		addNextXCIF = !listOneXCif;
	}


	/* Mandatory parameter */
	/* MCU interoperability - Max bit rate must come after xCIF */
    if (data->maxBitRate != 0)
	{
		IppSdpUtil_itoa(data->maxBitRate, value);
		RvSdpCodecFmtpParamSet(
			descr,
			STR_H263_MAXBR_V,		
			value,
			rvTrue,
			payload,
			' ',
			NULL);
	}
	
	else
	{
		RvLogError(&g_logSrc, (&g_logSrc,"CodecData_h263_to_mediaDsecr(): %s is't found in Sdp data", STR_H263_MAXBR_V));
		goto err_exit;
	}
	
   
	return RV_OK;
err_exit:
	return RV_ERROR_UNKNOWN;
}



/*******************************************************************************/
RVAPI void CodecData_h263_Destruct( OUT CodecData_h263*	data)
{
    RV_UNUSED_ARG(data);
}
/*******************************************************************************/
/********************************************************************************/
/*******************************************************************************/
