/******************************************************************************
Filename:    ippcodec_g729.h
Description:
*******************************************************************************/
#include <string.h>
#include "ippcodec.h"
#include "ippcodec_g729.h"

#define LOGSRC	LOGSRC_CODEC

#define	STR_G729_PTIME         "ptime"
#define	STR_G729_ANNEXA        "annexa"
#define	STR_G729_ANNEXB        "annexb"
#define	STR_G729_SILENCE_SUPP	"SilenceSupp"
/*******************************************************************************/
/*******************************************************************************/
RVAPI RvStatus CodecData_g729_Construct( OUT CodecData_g729*	data,
				   IN RvSdpMediaDescr* descr,/*where the codec is located*/
				   IN int			payload
				   )
{
    const char* szValue;
    char    value[32];
    RvInt   index;

	memset( data,0, sizeof(CodecData_g729));
	
	if(payload <0)
		payload = IppCodecGetFirstPayload( descr);
	/* parse the codec parameters */
		
    szValue = ippGetAttrByName( STR_G729_PTIME, descr);
    if(szValue)
        data->ptime = atoi(szValue);
    else
        data->ptime = 0;

    /*annexA is always supported*/
    data->annexa = rvTrue;

    /*annexB*/
    if(RV_SDPSTATUS_OK == RvSdpCodecFmtpParamGetByName(
                                                        descr, 
                                                        STR_G729_ANNEXB,
                                                        payload,
                                                        ' ',
                                                        value,
                                                        sizeof(value),
                                                        &index
                                                        )  &&  RvStrcasecmp( value, "yes") ==0)
        data->annexb = rvTrue;
    else
    	data->annexb = rvFalse;

    return RV_OK;
}
/*******************************************************************************/
RVAPI void CodecData_g729_Destruct( OUT CodecData_g729*	data)
{
    RV_UNUSED_ARG(data);
}
/*******************************************************************************/
/********************************************************************************/
/*******************************************************************************/
