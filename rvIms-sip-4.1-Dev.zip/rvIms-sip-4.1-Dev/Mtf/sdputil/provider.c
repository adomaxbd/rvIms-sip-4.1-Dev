/******************************************************************************
Filename:    provider.c
Description: Ipp wrapper for codec parsing API
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

/***************************************************************************
 * IppUtil_Empty
 * ------------------------------------------------------------------------
 * General: used as empty stub in order to build empty lib file
 * Return Value: 
 * ------------------------------------------------------------------------
 * Arguments:
 ***************************************************************************/
int IppUtil_Empty(void) 
{
    int i;
    for( i=0; i < 1; ++i)
    {
    }
    return i;
}
