/******************************************************************************
Filename:    mtfImsReg.h
*******************************************************************************
				Copyright (c) 2009 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef RV_IMS_REG_H
#define RV_IMS_REG_H
#ifdef RV_SIP_IMS_ON

#include "RvSipStackTypes.h"
#include "RvSipMsgTypes.h"
#include "RvSipRegClientTypes.h"
#include "rvtypes.h"

#if defined(__cplusplus)
extern "C" {
#endif
	
void mtfImsRegClientMsgToSend(IN RvSipRegClientHandle     hRegClient,
							  IN RvSipAppRegClientHandle       hAppRegClient,
							  IN RvSipMsgHandle           hMsg);

void mtfImsRegisterHandleRegStateRegistered(RvSipMsgHandle         hMsg);

void mtfImsRegSetRegClientOutboundPort(INOUT RvSipRegClientHandle hRegClient, 
									   IN	  RvChar* outboundAddress,
							           IN	  RvUint16 outboundPort);

RvStatus mtfImsRegMd5AuthHandleRegClientUnauthState(IN	RvSipRegClientHandle hRegClient,
													IN	RvCCTerminalSip*     term);

void mtfImsRegSetRegClientPortS(IN  RvSipRegClientHandle  hRegClient,
								IN  RvUint32 ipsecPortS);
								

void mtfImsGetPAssociatedUriStr(int* nFlag, char* strUserNameUri, char* strPAssociatedUri);
void PSip_SetPassociatedEnable(RvUint32 dwPassociatedEnable);
#if defined(__cplusplus)
}
#endif

#endif /* RV_SIP_IMS_ON */
#endif /*RV_IMS_REG_H */
