/******************************************************************************
Filename:    mtfImsReg.c
Description: This file includes code for IMS support in the MTF.
*******************************************************************************
				Copyright (c) 2009 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "rvtypes.h"
#ifdef RV_SIP_IMS_ON

#define LOGSRC  LOGSRC_IMS

#include "RvSipSecAgreeTypes.h"
#include "RvSipPAccessNetworkInfoHeader.h"
#include "IppStdInc.h"
#include "ippmisc.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "rvhost.h"
#include "rvstr.h"
#include "sipMgr.h"
#include "mtfImsReg.h"
#include "mtfImsSecAgree.h"
#include "RvSipPUriHeader.h"

extern RvSipControl* g_sipControl;
int g_nPAssociatedUriFlag = 1; /* enable disable PAssociatedUri */
typedef struct NodePAssociated{
    char strPAssociatedUri[64] ;
    char strUserNameInFrom[64];
    struct NodePAssociated* nextNode;
} NodeP;
//NodePAssociated g_NodePassociated={0,{0},{0},0};
NodeP* ptr_gNodePassociated = NULL;

/*===============================================================================*/
/*================      G L O B A L		F U N C T I O N S   =====================*/
/*===============================================================================*/

/***************************************************************************
 * mtfImsRegClientMsgToSend
 * ------------------------------------------------------------------------
 * General: IMS related implementation to the message to send event handler.
 *          Here we take care of the PAccessNetworkInfo field
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient -    The sip stack register-client handle
 *          hAppRegClient - The application handle for this register-client.
 *          hMsg -          Handle to the outgoing message.
 ***************************************************************************/

void mtfImsRegClientMsgToSend( IN RvSipRegClientHandle    hRegClient,
							   IN RvSipAppRegClientHandle hAppRegClient,
							   IN RvSipMsgHandle          hMsg)
{
	RvSipSecAgreeState         eState = RVSIP_SEC_AGREE_STATE_ACTIVE; 
	RvStatus                   rv = RV_OK;
	RvCCTerminal*       xTerm;
    RvCCTerminalSip*    term;
	RvChar pAccessString[RV_SHORT_STR_SZ];
	RvSipPAccessNetworkInfoHeaderHandle hPAccess;

	/* Insert P-Access-Network-Info to the outgoing message, only if the
	   message is secured (i.e., the security-agreement is ACTIVE) */
	if (g_sipControl->imsControl.disableSecAgree == RV_TRUE)
	{
		/* SecAgree is disabled, there is nothing to do */
		return;
	}
    xTerm   = (RvCCTerminal*)hAppRegClient;
    term    = rvCCTerminalSipGetImpl(xTerm);

	rv = RvSipSecAgreeGetState(term->imsTerminalSip.hSecAgree, &eState);
	if (RV_OK != rv)
	{
		RvLogError(ippLogSource,(ippLogSource,"mtfImsRegClientMsgToSend: Failed to get security-agreement state for reg client %p",
				   hRegClient));
	}
	if (eState == RVSIP_SEC_AGREE_STATE_ACTIVE)
	{
		rv = RvSipPAccessNetworkInfoHeaderConstructInMsg(hMsg, RV_FALSE, &hPAccess);
		if (RV_OK != rv)
		{
			RvLogError(ippLogSource, (ippLogSource,"mtfImsRegClientMsgToSend: Failed to construct P-Access-Network-Info header for reg client %p", 
					   hRegClient));
		}
		
		strcpy(pAccessString, "P-Access-Network-Info: ");
		strcat(pAccessString, g_sipControl->imsControl.PAccessNetworkInfo);
		rv = RvSipPAccessNetworkInfoHeaderParse(hPAccess, pAccessString);
		if (rv != RV_OK)
		{
			RvLogError(ippLogSource,(ippLogSource,"mtfImsRegClientMsgToSend: failed to parse P-Access-Network-Info header text for reg client %p", 
					   hRegClient));
		}

	}

	RV_UNUSED_ARG(hRegClient);
}

/***************************************************************************
 * mtfImsRegisterHandleRegStateRegistered
 * ------------------------------------------------------------------------
 * General: This function is called when OK reply was received for Register,
 *          It checks if there is a P-Associated-URI header in the response.
 *          If there is, the first URI of this header is retreived.
 *          
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg       -  Handle to the received message.
 ***************************************************************************/
void mtfImsRegisterHandleRegStateRegistered(RvSipMsgHandle         hMsg)
{
	RvSipHeaderListElemHandle   hElement;
       RvSipHeaderListElemHandle   hElementFrom;
       RvSipPUriHeaderHandle         hHeader = NULL;
       RvSipAddressHandle             hAddress = NULL;      
       RvSipPUriHeaderHandle        hFromHeader = NULL;
       RvSipAddressHandle            hFromAddress = NULL;
       char       userName_Associated[64] ={0};
       char       userName_From[64] ={0};
       int          len = 0;

       NodeP*  pTmpNodePAUri= ptr_gNodePassociated;
       NodeP*  pTmpPreNodePAUri= ptr_gNodePassociated;
	
	/* Check if there is a P-Associated-URI header in the response. If there is, store as the default public user 
	   identity the first URI on the list of URIs present in the header field and bind it to the respective contact
	   address of the UE and the associated set of security associations or TLS session  */

	hFromHeader  = RvSipMsgGetFromHeader(hMsg);
       hFromAddress = RvSipPartyHeaderGetAddrSpec(hFromHeader);
       /* Get user name to userName_From */
       len = RvSipAddrGetStringLength(hFromAddress, RVSIP_ADDRESS_USER);
       RvSipAddrUrlGetUser(hFromAddress, userName_From, len, &len);
       //strncpy(g_strUserNameInFrom,userName_From,sizeof(userName_From));
       printf("@@@from:%s,LineId = %d\n",userName_From);
 
       /* Get P-Associated-URI to userName_Associated */
       hHeader = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_P_URI, RVSIP_FIRST_HEADER,&hElement);

	while(hHeader != NULL)
	{
	        if(RvSipPUriHeaderGetPHeaderType(hHeader) == RVSIP_P_URI_ASSOCIATED_URI_HEADER)
	        {
		    hAddress = RvSipPUriHeaderGetAddrSpec(hHeader);
		    RvSipAddrUrlGetUser(hAddress, userName_Associated, (RvUint)sizeof(userName_Associated), (RvUint*)&len);
		    break;
		}
		hHeader = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_P_URI, RVSIP_NEXT_HEADER, &hElement);
	}
	while(pTmpNodePAUri != NULL && strcmp(pTmpNodePAUri->strUserNameInFrom,userName_From) != 0)
       {
           pTmpPreNodePAUri = pTmpNodePAUri;
           pTmpNodePAUri = pTmpNodePAUri->nextNode;
       }
       if(pTmpNodePAUri != NULL)
       {
             strncpy(pTmpNodePAUri->strPAssociatedUri,userName_Associated,sizeof(userName_Associated)); 
       }
       else
       {
            if(ptr_gNodePassociated == NULL)
            {
                pTmpNodePAUri = (NodeP* )malloc(sizeof(NodeP));
                ptr_gNodePassociated = pTmpNodePAUri;
             }
             else
             {
                pTmpPreNodePAUri->nextNode = (NodeP* )malloc(sizeof(NodeP));
                pTmpNodePAUri = pTmpPreNodePAUri->nextNode;
             }
            memset(pTmpNodePAUri,0,sizeof(NodeP));
            strncpy(pTmpNodePAUri->strUserNameInFrom,userName_From,sizeof(userName_From)); 
            strncpy(pTmpNodePAUri->strPAssociatedUri,userName_Associated,sizeof(userName_Associated)); 
       }
}

/***************************************************************************
* mtfImsRegSetRegClientOutboundPort
* ------------------------------------------------------------------------
* General:  Sets the outbound port of a registration client
*           This is needed when TLS security mechanism is chosen. 
* Return Value: RV_OK - if successful. error code o/w
* ------------------------------------------------------------------------
* Arguments:
* input   : outboundAddress - the outbound address in IP or name format
*			outboundPort    - registrarTlsPort as the new outbound port
*
* output  : hRegClient - Handle to the regClient whose settings are changed. 
***************************************************************************/
void mtfImsRegSetRegClientOutboundPort(INOUT RvSipRegClientHandle hRegClient, 
								IN	  RvChar* outboundAddress,
								IN	  RvUint16 outboundPort)
{

	if (IppUtilIsIpAddress(outboundAddress) == RV_TRUE)
	{
		RvSipRegClientSetOutboundAddress(hRegClient, outboundAddress, outboundPort);
	}
	else
	{
		RvSipRegClientSetOutboundHostName(hRegClient, outboundAddress, outboundPort);
	}
}

/***************************************************************************
* mtfImsRegSetRegClientPortS
* ------------------------------------------------------------------------
* General: Sets port-s to the contact header of the register-client
* Return Value: None
* ------------------------------------------------------------------------
* Arguments:
* Input:   hRegClient - The reg-client object
*		   ipsecPortS - The new value of Port-S
***************************************************************************/
void mtfImsRegSetRegClientPortS(IN  RvSipRegClientHandle  hRegClient,
								   IN  RvUint32 ipsecPortS)
{
	RvSipContactHeaderHandle  *phContact;
	RvSipAddressHandle         hAddr;
	RvStatus                   rv;
	
	phContact = RvSipRegClientGetFirstContactHeader(hRegClient);
	if (*phContact != NULL)
	{
		hAddr = RvSipContactHeaderGetAddrSpec(*phContact);
		if (hAddr != NULL)
		{
			rv = RvSipAddrUrlSetPortNum(hAddr, ipsecPortS);
			if (RV_OK != rv)
			{
				RvLogError(ippLogSource,(ippLogSource,"AppRegClientSetPortS: Failed to set port-s to contact header for reg client %p",
							hRegClient));
			}
		}
	}
}

/***************************************************************************
 * mtfImsRegMd5AuthHandleRegClientUnauthState
 * ------------------------------------------------------------------------
 * General: Perform security agreement actions for a termination when MD5,
 *          not AKA-MD5 authentication is used.
 *          
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hRegClient	-  The sip stack register-client handle
 *          term		-  the terminal for which the actions are performed
 ***************************************************************************/
RvStatus mtfImsRegMd5AuthHandleRegClientUnauthState(IN	RvSipRegClientHandle hRegClient,
													IN	RvCCTerminalSip*     term)
{
	RvStatus  rv;
	RvSipSecurityMechanismType    chosenSecurity;

	rv = rvSecAgreeChooseSecurity(term);
	if (rv != RV_OK)
	{
		rvCallSecAgreeUserCallback(term, rvFalse, RV_MTF_SEC_AGREE_CHOOSE_FAILED, RVSIP_SECURITY_MECHANISM_TYPE_UNDEFINED);
		RvLogError(ippLogSource,(ippLogSource,"mtfImsRegMd5AuthHandleRegClientUnauthState: failed to choose security mechanism for terminal %s",
				   term->terminalId));
		return rv;
	}
	chosenSecurity = term->imsTerminalSip.chosenSecurity;
	rvCallSecAgreeUserCallback(term, RV_TRUE, RV_MTF_SEC_AGREE_SUCCESS, chosenSecurity);
#ifdef RV_CFLAG_TLS
	if (chosenSecurity == RVSIP_SECURITY_MECHANISM_TYPE_TLS)
	{
		/* initiate TLS security from second REGISTER onwards */
		mtfImsRegSetRegClientOutboundPort(hRegClient, term->outboundProxyAddress, 
								 term->registrarTlsPort);
	}
	else
#endif 
	if ((chosenSecurity == RVSIP_SECURITY_MECHANISM_TYPE_IPSEC_IKE) ||
		(chosenSecurity == RVSIP_SECURITY_MECHANISM_TYPE_IPSEC_MAN) ||
		(chosenSecurity == RVSIP_SECURITY_MECHANISM_TYPE_IPSEC_3GPP))		
	{
		/* set PORT-S value of reg client */
		mtfImsRegSetRegClientPortS(hRegClient,term->imsTerminalSip.ipsecPortS);
	}

	return RV_OK;
}
void mtfImsGetPAssociatedUriStr(int* nFlag, char* strUserNameUri, char* strPAssociatedUri)
{
    *nFlag = g_nPAssociatedUriFlag;
    if(g_nPAssociatedUriFlag == 0)
    {
        return;
    }
    if(strPAssociatedUri == NULL)
    {
        return;
    }
    if(ptr_gNodePassociated == NULL)
    {
        strPAssociatedUri[0] = 0;
        return;
    }

    //strncpy(strPAssociatedUri,g_strPAssociatedUri,sizeof(g_strPAssociatedUri)); 
    NodeP* pTmpNode = ptr_gNodePassociated;

    while(pTmpNode != NULL && strcmp(pTmpNode->strUserNameInFrom,strUserNameUri) != 0)
    {
        pTmpNode = pTmpNode->nextNode;
    }
   if(pTmpNode != NULL)
   {
         strncpy(strPAssociatedUri,(char*)pTmpNode->strPAssociatedUri,sizeof(pTmpNode->strPAssociatedUri)); 
   }
   else
   {
        strPAssociatedUri[0] = 0;
   }
}
void PSip_SetPassociatedEnable(RvUint32 dwPassociatedEnable)
{
    g_nPAssociatedUriFlag = dwPassociatedEnable;
}
#endif  /* RV_SIP_IMS_ON */
