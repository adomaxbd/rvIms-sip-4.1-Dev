/******************************************************************************
Filename:    mtfImsSecAgree.h
Description: This file includes code for Security Agreement support in the MTF.
*******************************************************************************
				Copyright (c) 2009 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef MTF_IMS_SEC_AGREE_H
#define MTF_IMS_SEC_AGREE_H

#ifdef RV_SIP_IMS_ON

#if defined(__cplusplus)
extern "C" {
#endif

#include "RvSipStackTypes.h"
#include "rvtypes.h"
#include "sipMgr.h"


/*-----------------------------------------------------------------*/
/*                      FUNCTIONS PROTOTYPES					   */
/*-----------------------------------------------------------------*/

/***************************************************************************
* rvSecAgreeInitiate
* ------------------------------------------------------------------------
* General:  Create a security agreement handle
* Return Value: RV_OK - if successful. error code o/w
* ------------------------------------------------------------------------
* Arguments:
*
* Input:   p -    pointer to X(not implementation) Provider object
*          xTerm - pointer to X terminal.
*
***************************************************************************/
RvStatus rvSecAgreeInitiate (IN  RvCCProvider*           p,
							 IN  RvCCTerminalSip*		 sipTerm);


/***************************************************************************
* AppClientSecAgreeChooseSecurity
* ----------------------------------
* General: Client choose the ip-sec security.
*          The function sets the keys values for ip-sec. (the keys were created
*          while generating the Authentication Vector).
*          The function choose the security using RvSipSecAgreeClientSetChosenSecurity().
* Return Value: RV_OK - if successful. error code o/w
* ------------------------------------------------------------------------
* Arguments:
*
* input	   : term - terminal object to which security agreement handles belong 
*
**************************************************************************/
RvStatus rvSecAgreeChooseSecurity(IN  RvCCTerminalSip *term);

/***************************************************************************
* rvSecAgreeTerminate
* ------------------------------------------------------------------------
* General: Terminate the security-agreement
* Return Value: RV_OK - if successful. error code o/w
* ------------------------------------------------------------------------
* Arguments:
*
* input	   : hSecAgree	- A handle to the security-agreement object.
*
***************************************************************************/
RvStatus rvSecAgreeTerminate (IN  RvSipSecAgreeHandle       hSecAgree);

/***************************************************************************
* rvSecAgreeStatusEvHandler
* ----------------------------------
* General: Notifies the application of security-agreement statuses.
*          Here we set the lifetime timer according to the security-association
*          status
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:  hSecAgree	- A handle to the security-agreement object.
*         hAppSecAgree - The application handle for this security-agreement.
*         eStatus      - The reported status of the security-agreement.
*         pInfo        - Auxiliary information. Not in use.
**************************************************************************/
void RVCALLCONV rvSecAgreeStatusEvHandler(IN  RvSipSecAgreeHandle		hSecAgree,
										  IN  RvSipAppSecAgreeHandle    hAppSecAgree,
										  IN  RvSipSecAgreeStatus       eStatus,
										  IN  void*						pInfo);

/******************************************************************************
*  rvCallSecAgreeUserCallback 
* -----------------------------------------------------------------------------
* General:  Server as in intermediate function in order to pass the correct arguments
*			to callback function RvMtfSecAgreeEv.
*
*  Arguments:
*  Input:			sipTerm			- terminal object to which security agreement handles belong 
*					success			- indication if selection was successful.
*					reason			- reason of outcome.
*					chosenSecurity  - security mechanism chosen.
*
*  Return Value:    None.
*****************************************************************/
void rvCallSecAgreeUserCallback(IN RvCCTerminalSip				*sipTerm,
								IN RvBool						success,
								IN RvMtfSecAgreeReason			reason,
								IN RvSipSecurityMechanismType	chosenSecurity);

#if defined(__cplusplus)
}
#endif

#endif /* RV_SIP_IMS_ON */

#endif /* MTF_IMS_SEC_AGREE_H */
