/******************************************************************************
Filename:    mtfImsSecAgree.c
Description: This file includes code for Security Agreement support in the MTF.
*******************************************************************************
				Copyright (c) 2009 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "rvtypes.h"
#ifdef RV_SIP_IMS_ON

#define LOGSRC  LOGSRC_IMS
#define ESTABLISHED_LIFETIME_INTERVAL_DELAY 30
#define REG_AWIAT_AUTH 240

#include "mtfImsSecAgree.h"
#include "RvSipSecurityHeader.h"
#include "rvccprovidersip.h"
#include "ippmisc.h"
#include "rvccterminalmdm.h"
#include "rvccterminalsip.h"
#include "mtfBaseInt.h"

/*-----------------------------------------------------------------------*/
/*                      STATIC FUNCTIONS PROTOTYPES					     */
/*-----------------------------------------------------------------------*/

static void RvSecPrepareSecAgreeToIpsecChoice(IN RvSipSecAgreeHandle hSecAgree,
											  IN  RvCCTerminalSip *term);

#ifdef RV_CFLAG_TLS
static void AppPrepareSecAgreeToTlsChoice(IN RvSipSecAgreeHandle hSecAgree,
										  IN RvCCTerminalSip *term);
#endif
/***************************************************************************
* rvSecAgreeInitiate
* ------------------------------------------------------------------------
* General:  Initiate a terminal's security agreement handle. When the 
*			function is called, it is yet unknown which security
*           mechanism will be chosen. Therefore, the function performs
*           initialization operations for both IPSec & TLS mechanisms,
*           and adds headers for both of them to the outgoing REGISTER
*           request.
* Return Value: RV_OK - if successful. error code o/w
* ------------------------------------------------------------------------
* Arguments:
*
* Input:   p -    pointer to X(not implementation) Provider object
*          sipTerm - pointer to client terminal.
*
***************************************************************************/

RvStatus rvSecAgreeInitiate (IN  RvCCProvider*           p,
							 IN  RvCCTerminalSip*		 sipTerm)
{

    RvSipControl*			  sipMgr          = rvCCProviderSipGetSipMgr(p);
    RvSipSecurityHeaderHandle hIPSecSecurityHeader; /* handle to the Security-Client header*/
#ifdef RV_CFLAG_TLS
    RvSipSecurityHeaderHandle hTLSSecurityHeader; /* handle to the Security-Client header*/
#endif
    RvSipSecurityHeaderHandle hDigestSecurityHeader; /* handle to the Security-Client header*/
    RvSipCommonListElemHandle hListElem;       /* handle to the Security-Client header list element*/
	RvStatus                  rv;
    RvSipSecAgreeMgrHandle    hSecAgreeMgr;
	RvChar					  strSecurityClient[RV_SHORT_STR_SZ];

    /* =============================================
        Create and init a client sec-agree object
       ============================================= */
	
    RvSipStackGetSecAgreeMgrHandle(sipMgr->stackHndl, &hSecAgreeMgr);

    rv = RvSipSecAgreeMgrCreateSecAgree(hSecAgreeMgr, (RvSipAppSecAgreeHandle)sipTerm, 
										&(sipTerm->imsTerminalSip.hSecAgree));
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to create a new security-agreement for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }

    /* Set the role of the security-agreement to client */
    rv = RvSipSecAgreeSetRole(sipTerm->imsTerminalSip.hSecAgree, RVSIP_SEC_AGREE_ROLE_CLIENT);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to set role to the security-agreement for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }

	/* Set Special Standard support to the security-agreement object (3GPP, TISPAN,...). The value
	   set to the standard flag will not force any change in the application's flow */
	rv = RvSipSecAgreeSetSpecialStandardFlag(sipTerm->imsTerminalSip.hSecAgree, RVSIP_SEC_AGREE_SPECIAL_STANDARD_3GPP_24229);
	if (RV_OK != rv)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to set special standard for the security-agreement of terminal %s to %s",
								 sipTerm->terminalId, sipTerm->imsTerminalSip.PAccessNetworkInfo));
		return rv;
	}

    /* Create a new Security header */
    rv = RvSipSecAgreeGetNewMsgElementHandle(sipTerm->imsTerminalSip.hSecAgree, RVSIP_HEADERTYPE_SECURITY, RVSIP_ADDRTYPE_UNDEFINED, (void**)&hIPSecSecurityHeader);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to create a new security header for IPSec for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }

    /* ==========================================================
	add IPSec security-client header to upcoming REGISTER request 
    =========================================================== */

    /* Parse IPSec Security-Client header if needed */
	strcpy(strSecurityClient, "Security-Client: ipsec-3gpp;alg=hmac-md5-96;prot=esp;mod=trans;ealg=aes-cbc");
	rv = RvSipSecurityHeaderParse(hIPSecSecurityHeader, strSecurityClient);
	if (rv != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to parse IPSec Security-Client header for terminal %s",
								 sipTerm->terminalId));
		return rv;
	}

#if (defined RV_SIP_IPSEC_NEG_ONLY)
    /* Ipsec is not supported by the operating system, we shall be using the local
   client ports */
    rv = RvSipSecurityHeaderSetPortC(hIPSecSecurityHeader, sipTerm->imsTerminalSip.ipsecPortC);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to set port-c to security header for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }
    rv = RvSipSecurityHeaderSetPortS(hIPSecSecurityHeader, sipTerm->imsTerminalSip.ipsecPortS);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to set port-s to security header for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }
#endif /*  (defined RV_SIP_IPSEC_NEG_ONLY) */

    /* Push Security-Client header to local security list */
    rv = RvSipSecAgreePushLocalSecurityHeader(sipTerm->imsTerminalSip.hSecAgree, hIPSecSecurityHeader,
                                                RVSIP_FIRST_ELEMENT, NULL, &hListElem);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to push Security-Client header to local security list for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }

#ifdef RV_CFLAG_TLS
    /* ========================================================
	add TLS security-client header to upcoming REGISTER request 
    ======================================================== */

    /* Parse TLS Security-Client header if TLS is used */

    rv = RvSipSecAgreeGetNewMsgElementHandle(sipTerm->imsTerminalSip.hSecAgree, RVSIP_HEADERTYPE_SECURITY, RVSIP_ADDRTYPE_UNDEFINED, (void**)&hTLSSecurityHeader);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to create a new security header for IPSec for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }


    strcpy(strSecurityClient, "Security-Client: tls");
    rv = RvSipSecurityHeaderParse(hTLSSecurityHeader, strSecurityClient);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to parse TLS Security-Client header for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }

    rv = RvSipSecAgreePushLocalSecurityHeader(sipTerm->imsTerminalSip.hSecAgree, hTLSSecurityHeader,
		RVSIP_LAST_ELEMENT, NULL, &hListElem);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to push Security-Client header to local security list for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }

#endif

    /* ===========================================================
	add digest security-client header to upcoming REGISTER request 
    =========================================================== */

    /* Parse Digest Security-Client header */

    rv = RvSipSecAgreeGetNewMsgElementHandle(sipTerm->imsTerminalSip.hSecAgree, RVSIP_HEADERTYPE_SECURITY, RVSIP_ADDRTYPE_UNDEFINED, (void**)&hDigestSecurityHeader);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to create a new security header for IPSec for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }

    strcpy(strSecurityClient, "Security-Client: digest;d-alg=MD5;d-qop=auth");
    rv = RvSipSecurityHeaderParse(hDigestSecurityHeader, strSecurityClient);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to parse Digest Security-Client header for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }

    rv = RvSipSecAgreePushLocalSecurityHeader(sipTerm->imsTerminalSip.hSecAgree, hDigestSecurityHeader,
		RVSIP_LAST_ELEMENT, NULL, &hListElem);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to push Security-Client header to local security list for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }

    /* Init the client security-agreement */
    rv = RvSipSecAgreeInit(sipTerm->imsTerminalSip.hSecAgree);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Failed to init client security-agreement for terminal %s",
								 sipTerm->terminalId));
		return rv;
    }

	RvLogDebug(ippLogSource,(ippLogSource,"rvCCTerminalSecAgreeInitiate: Client sec-agree %p was created for terminal %s",
							 sipTerm->imsTerminalSip.hSecAgree, sipTerm->terminalId));

	return RV_OK;
}

/***************************************************************************
* rvSecAgreeChooseSecurity
* ----------------------------------
* General: Client choose the ip-sec security.
*          The function sets the keys values for ip-sec. (the keys were created
*          while generating the Authentication Vector).
*          The function choose the security using RvSipSecAgreeClientSetChosenSecurity().
* Return Value: RV_OK - if successful. error code o/w
* ------------------------------------------------------------------------
* Arguments:
*
* input	   : term - terminal object to which security agreement handles belong 
*
**************************************************************************/
RvStatus rvSecAgreeChooseSecurity(IN  RvCCTerminalSip *term)
{
    RvStatus                    rv;
    RvSipSecurityHeaderHandle   hRemoteSecurity;
    RvSipSecurityHeaderHandle	hSecurityHeader;
	RvSipCommonListElemHandle   hListElem;
	/* Declare security mechanism initialized with UNDEFINED */
    /* Declare local security header to hold the local security header matching the chosen security mechanism */
    RvSipSecurityHeaderHandle   hLocalSecurity;
    
	term->imsTerminalSip.chosenSecurity = RVSIP_SECURITY_MECHANISM_TYPE_UNDEFINED;
	
	 /* prepare for both IPSec & TLS (if needed) choices */
	 RvSecPrepareSecAgreeToIpsecChoice(term->imsTerminalSip.hSecAgree, term);
#ifdef RV_CFLAG_TLS
     AppPrepareSecAgreeToTlsChoice(term->imsTerminalSip.hSecAgree, term);
#endif

    /* Initiate the client security-agreement */
    rv = RvSipSecAgreeClientSetChosenSecurity(term->imsTerminalSip.hSecAgree, &(term->imsTerminalSip.chosenSecurity), &hLocalSecurity, &hRemoteSecurity);
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"AppClientSecAgreeChooseSecurity: Failed to choose client security-agreement for terminal %s",
				   term->terminalId));
		return rv;
    }

	RvLogDebug(ippLogSource,(ippLogSource,"AppClientSecAgreeChooseSecurity: Client security was chosen for terminal %s",
				   term->terminalId));
	
	/* Store the local ipsec server port in the local Contact headers  */
	rv = RvSipSecAgreeGetLocalSecurityHeader(term->imsTerminalSip.hSecAgree, RVSIP_FIRST_ELEMENT, NULL, &hSecurityHeader, &hListElem);
	if (rv != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"AppClientSecAgreeChooseSecurity: Failed get Security-Client header from security-agreement for terminal %s",
			   term->terminalId));
		return rv;
	}
	term->imsTerminalSip.ipsecPortS = RvSipSecurityHeaderGetPortS(hSecurityHeader);
	
	RvLogInfo(ippLogSource,(ippLogSource,"rvSecAgreeChooseSecurity: Client security mechanism %d was chosen for terminal %s",
							 term->imsTerminalSip.chosenSecurity, term->terminalId));
	
	return RV_OK;
}

/***************************************************************************
* rvSecAgreeTerminate
* ------------------------------------------------------------------------
* General: Terminate the security-agreement
* Return Value: RV_OK - if successful. error code o/w
* ------------------------------------------------------------------------
* Arguments:
*
* input	   : hSecAgree	- A handle to the security-agreement object.
*
***************************************************************************/
RvStatus rvSecAgreeTerminate (IN  RvSipSecAgreeHandle       hSecAgree)
{
	RvStatus   rv;
	
	RvLogDebug(ippLogSource,(ippLogSource,"rvSecAgreeTerminate: Client sec-agree %p - Terminate the sec-agree",
			   hSecAgree));
	rv = RvSipSecAgreeTerminate(hSecAgree);
	hSecAgree = NULL;
	return rv;
}

/*-----------------------------------------------------------------------*/
/*                       SEC AGREE CALLBACKS							 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
* rvSecAgreeStatusEvHandler
* ----------------------------------
* General: Notifies the application of security-agreement statuses.
*          Here we set the lifetime timer according to the security-association
*          status
* Return Value: (-)
* ------------------------------------------------------------------------
* Arguments:
* Input:  hSecAgree	- A handle to the security-agreement object.
*         hAppSecAgree - The application handle for this security-agreement.
*         eStatus      - The reported status of the security-agreement.
*         pInfo        - Auxiliary information. Not in use.
**************************************************************************/
void RVCALLCONV rvSecAgreeStatusEvHandler(IN  RvSipSecAgreeHandle		hSecAgree,
										  IN  RvSipAppSecAgreeHandle    hAppSecAgree,
										  IN  RvSipSecAgreeStatus       eStatus,
										  IN  void*						pInfo)
{
	RvStatus                 rv;
	RvCCTerminalSip *sipTerm = (RvCCTerminalSip*)hAppSecAgree;

	RV_UNUSED_ARG(pInfo);
	
	switch (eStatus)
	{
	case RVSIP_SEC_AGREE_STATUS_IPSEC_TEMPORARY_ASSOCIATION:
		/* A temporary association is created when an IPSec connection is created after receiving an
		   401 replay, and before a second, successful, REGISTER message is sent */
		RvLogDebug(ippLogSource,(ippLogSource,"rvSecAgreeStatusEvHandler: Client sec-agree %p - Security Association status is Temporary",
			hSecAgree));
		RvLogDebug(ippLogSource,(ippLogSource,"rvSecAgreeStatusEvHandler: Client sec-agree %p - Starting lifetime timer to interval %d",
			hSecAgree, REG_AWIAT_AUTH));

		/* 	Start lifetime timer to constant value */
		rv = RvSipSecAgreeStartIpsecLifetimeTimer(hSecAgree, REG_AWIAT_AUTH);
		if (RV_OK != rv)
		{
			RvLogError(ippLogSource,(ippLogSource,"rvSecAgreeStatusEvHandler: Failed to start lifetime timer for client %p",
					   hSecAgree));
		}
		break;
	case RVSIP_SEC_AGREE_STATUS_IPSEC_ESTABLISHED_ASSOCIATION:
		RvLogDebug(ippLogSource,(ippLogSource,"rvSecAgreeStatusEvHandler: Client sec-agree %p - Security Association status is Established",
			hSecAgree));
		/* An established association is created when an IPSec connection is created after endpoint is 
		   registered successfully to the server over a secure IPSec connection */
		RvLogDebug(ippLogSource,(ippLogSource,"rvSecAgreeStatusEvHandler: Client sec-agree %p - Starting lifetime timer to interval %d",
			hSecAgree, sipTerm->registerExpires + ESTABLISHED_LIFETIME_INTERVAL_DELAY));

		/* 	Start lifetime timer to the expiration timer of registration + constant value */
		rv = RvSipSecAgreeStartIpsecLifetimeTimer(hSecAgree, sipTerm->registerExpires + ESTABLISHED_LIFETIME_INTERVAL_DELAY);
		if (RV_OK != rv)
		{
			RvLogError(ippLogSource,(ippLogSource,"rvSecAgreeStatusEvHandler: Failed to start lifetime timerfor client %p",
					   hSecAgree));
		}
		break;
	case RVSIP_SEC_AGREE_STATUS_IPSEC_LIFETIME_EXPIRED:
		/* Handle lifetime expiration */
		break;
	default:
		break;
	}
}

/******************************************************************************
*  rvCallSecAgreeUserCallback 
* -----------------------------------------------------------------------------
* General:  Server as in intermediate function in order to pass the correct arguments
*			to callback function RvMtfSecAgreeEv.
*
*  Arguments:
*  Input:			sipTerm			- terminal object to which security agreement handles belong 
*					success			- indication if selection was successful.
*					reason			- reason of outcome.
*					chosenSecurity  - security mechanism chosen.
*
*  Return Value:    None.
*****************************************************************/
void rvCallSecAgreeUserCallback(IN RvCCTerminalSip				*sipTerm,
								IN RvBool						success,
								IN RvMtfSecAgreeReason			reason,
								IN RvSipSecurityMechanismType	chosenSecurity)

{
	RvMtfBaseMgr*	mtfMgr;
	RvCCTerminal*   ccTerm;
	RvCCTerminalMdm*    mdmTerminal;
	RvMdmTerm*      mdmTerm;

	ccTerm = rvCCTerminalSipGetMdmTerminal(sipTerm);
	mdmTerminal = rvCCTerminalMdmGetImpl(ccTerm);
	mdmTerm = &mdmTerminal->mdmTerm;
	mtfMgr = rvGetMtfMgrByMdmTerm(mdmTerm);
	
	mtfMgr->imsClbks.secAgreeNegCompletedEv(rvIppMdmTerminalGetHandle(mdmTerm),(RvMtfTerminalAppHandle)mdmTerm->userData,
								success, reason, chosenSecurity);
}

/*-----------------------------------------------------------------------*/
/*                       SEC AGREE STATSIC FUNCTIONS					 */
/*-----------------------------------------------------------------------*/

/***************************************************************************
* AppPrepareSecAgreeToIpsecChoice
* ------------------------------------------------------------------------
* General: Perform initial Security Agreement settings before choosing
*          ipsec as it's security mechanism
* Return Value: -
* ------------------------------------------------------------------------
* Arguments:
* Input:  hSecAgree	- A handle to the security-agreement object to be
*                        prepared before choosing a security mechanism
*         term - terminal object to which security agreement handles belong 
***************************************************************************/
static void RvSecPrepareSecAgreeToIpsecChoice(IN RvSipSecAgreeHandle hSecAgree,
											  IN  RvCCTerminalSip *term)
{
    RvSipSecAgreeIpsecInfo  ipsecInfo; /* structure for ip-sec-3gpp extra parameters*/
    RvStatus                rv;
	
    /* Reset ip-sec info structure */
    memset(&ipsecInfo, 0, sizeof(RvSipSecAgreeIpsecInfo));
	
    /* Set IK to the ip-sec info structure */	
    memcpy(ipsecInfo.IK, term->imsTerminalSip.ClientAkaAV.IK, 16);
    ipsecInfo.IKlen = 16*8;
    
    /* Set CK to the ip-sec info structure */	
    memcpy(ipsecInfo.CK, term->imsTerminalSip.ClientAkaAV.CK, 16);
   	ipsecInfo.CKlen = 16*8;
    
    /* Set ip-sec info to the server security-agreement */
    rv = RvSipSecAgreeSetIpsecInfo (hSecAgree, &ipsecInfo, sizeof(RvSipSecAgreeIpsecInfo));
    if (rv != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"RvSecPrepareSecAgreeToIpsecChoice: Failed to set ip-sec info to client security-agreementfor client %p",
								 hSecAgree));
    }

}

#ifdef RV_CFLAG_TLS
/***************************************************************************
* AppPrepareSecAgreeToTlsChoice
* ------------------------------------------------------------------------
* General: Perform initial Security Agreement settings before choosing
*          TLS as it's security mechanism
* Return Value: -
* ------------------------------------------------------------------------
* Arguments:
* Input:  hSecAgree	- A handle to the security-agreement object to be
*                        prepared before choosing a security mechanism
*         term - terminal object to which security agreement handles belong 
***************************************************************************/
static void AppPrepareSecAgreeToTlsChoice(IN RvSipSecAgreeHandle hSecAgree,
										  IN RvCCTerminalSip *term)
{
    /* Set the local and remote addresses in non-ipsec case */
    RvSipTransportAddr addr;
    RvStatus           rv;

	RvCCProviderSip* p = rvCCProviderSipGetImpl(term->provider);
	
    memset(&addr,0,sizeof(addr));
    addr.eTransportType = RVSIP_TRANSPORT_TLS;
	addr.eAddrType      = IS_IPV6_GM_INTERFACE(p->localAddress) ?
	RVSIP_TRANSPORT_ADDRESS_TYPE_IP6 : RVSIP_TRANSPORT_ADDRESS_TYPE_IP;
	
    /* Initializing the local address structure per the application configuration */
#if (RV_NET_TYPE & RV_NET_IPV6)
	IppUtilGetScopeIdFromIpv6String(p->localAddress, &addr.Ipv6Scope);
#else
	addr.Ipv6Scope      = 0;
#endif
    addr.port           = rvIppTlsGetPort();
	strncpy(addr.strIP,p->localAddress,sizeof(addr.strIP));
	
    rv = RvSipSecAgreeSetLocalAddr(
		hSecAgree,RVSIP_SECURITY_MECHANISM_TYPE_TLS,&addr,sizeof(addr));
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"AppPrepareSecAgreeToTlsChoice: Failed to set TLS local address to client security-agreement for terminal %s",
								 term->terminalId));
    }
	
    /* Initializing the remote address structure per the application configuration */
#if (RV_NET_TYPE & RV_NET_IPV6)
	IppUtilGetScopeIdFromIpv6String(term->registrarAddress, &addr.Ipv6Scope); /* should be extracted from term->registrarAddress */
#endif
	addr.port           = term->registrarTlsPort;
	
    strncpy(addr.strIP,term->registrarAddress,sizeof(addr.strIP));
	
    rv = RvSipSecAgreeSetRemoteAddr(
        hSecAgree,RVSIP_SECURITY_MECHANISM_TYPE_TLS,&addr,sizeof(addr));
    if (rv != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource,"AppPrepareSecAgreeToTlsChoice: Failed to set TLS remote address to client security-agreement for terminal %s",
								 term->terminalId));
    }
}

#endif /* RF_CFLAG_TLS */

#endif  /* RV_SIP_IMS_ON */
