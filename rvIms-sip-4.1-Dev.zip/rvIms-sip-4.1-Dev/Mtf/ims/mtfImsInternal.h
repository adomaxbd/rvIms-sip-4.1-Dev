/******************************************************************************
Filename:    mtfImsInternal.h
*******************************************************************************
				Copyright (c) 2009 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#ifndef MTF_IMS_INTERNAL_H
#define MTF_IMS_INTERNAL_H

#ifdef RV_SIP_IMS_ON

#include "RvSipStackTypes.h"
#include "rvtypes.h"
#include "AKA_Auc.h"

/* IMS fields at application level */
typedef struct {
	RvBool              disableAkaAuthentication; /*  When true and the flag RV_SIP_IMS_ON is set,
	                                                  no Aka authentication will be done, only MD5 */
	RvBool				disableSecAgree;          	/* indication if security agreement feature is disabled. If set to rvTrue,
													   no requests to start security agreement will be sent */

	RvChar              PAccessNetworkInfo[RV_SHORT_STR_SZ];  
												  /* P-Access-Network-Info header text, assumed to be in right syntax. */
	RvUint32			ipsecPortC;				  /* The number of port used as client port for IPSec connection */
	RvUint32			ipsecPortS;				  /* The number of port used as server port for IPSec connection */

} RvImsSipControl;

/* IMS fields at terminal level */
typedef struct {
	RvSipSecAgreeHandle		hSecAgree;			     /* Handle of security-agreement */
	AKA_Av				ClientAkaAV;				 /* The Authentication-Vector information of the client.
														It is generated when receiving the first 401 response, using the nonce
	                                                    value of the authentication header */
	RvBool				SecAgreeInitiated;			 /* indication if security agreement procedures
													    have been started for this terminal */
	RvSipSecurityMechanismType chosenSecurity;		 /* the security mechanism chosen by the terminal */
	RvChar              PAccessNetworkInfo[RV_SHORT_STR_SZ];	 
													 /* P-Access-Network-Info header text, assumed to be in right syntax. */
	RvUint32			ipsecPortC;					 /* The number of port used as client port for IPSec connection */
	RvUint32			ipsecPortS;					 /* The number of port used as server port for IPSec connection */
} RvImsCCTerminalSip;

/* constants */
#define IS_IPV6_GM_INTERFACE(addr)  (strchr(addr,':') != NULL &&\
	strchr(addr,'[') != NULL &&\
strchr(addr,']') != NULL)

#endif /* RV_SIP_IMS_ON */
#endif /* MTF_IMS_INTERNAL_H */
