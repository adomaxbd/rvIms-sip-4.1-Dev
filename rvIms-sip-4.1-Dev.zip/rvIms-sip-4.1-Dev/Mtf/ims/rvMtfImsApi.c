/******************************************************************************
Filename:    rvMtfImsApi.c
Description: This file includes code for IMS APIs.
*******************************************************************************
				Copyright (c) 2009 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#include "rvtypes.h"

#ifdef RV_SIP_IMS_ON
#include "mtfBaseInt.h"
#include "rvMtfHandles.h"
#include "rvMtfImsTypes.h"


#define LOGSRC  LOGSRC_SIPCONTROL

/*===============================================================================*/
/*===================    P R I V A T E	  F U N C T I O N S    ==================*/
/*===============================================================================*/

/*===============================================================================*/
/*================      API		F U N C T I O N S   =====================*/
/*===============================================================================*/

/*@*****************************************************************************
 * rvMtfRegisterImsCallbacks (RvMtfBasePkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Registers IMS callbacks to the MTF. This function should be called
 *         after rvMtfSipConstruct() is called.
 *
 * Arguments:
 *
 * Input:  mtfHandle  - Handle to the MTF.
 *         imsClbks   - Pointer to the structure that contains IMS callbacks.
 *
 * Return Value: None.
 ****************************************************************************@*/
RVAPI void RVCALLCONV rvMtfRegisterImsCallbacks(
                IN RvMtfHandle		    hMtf,
                IN RvMtfImsClbks*		imsClbks)
{
    RvMtfBaseMgr*  mtfMgr = (RvMtfBaseMgr*) hMtf;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfRegisterImsCallbacks(hTerm=%p, imsClbks=%p)", hMtf, imsClbks));

	mtfMgr->imsClbks.secAgreeNegCompletedEv = imsClbks->secAgreeNegCompletedEv;
	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterImsCallbacks()"));
}

#endif /* RV_SIP_IMS_ON */

