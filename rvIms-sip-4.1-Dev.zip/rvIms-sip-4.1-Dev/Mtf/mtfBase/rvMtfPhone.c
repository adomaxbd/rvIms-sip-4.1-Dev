#define LOGSRC  LOGSRC_BASE
#include <basephone.h>
#include "rvccprovidermdm.h"
#include "rvccterminalmdm.h"
#include "rvMtfPhone.h"
#include "mdmControlInt.h"

static char rvCCIpPhoneDisplayLogo[] =  "IP Phone";

static RvMdmXTermMgrClbks xTermMgrClbks[RV_MTF_PROTOCOL_NUM];

void rvCCProviderSipDestruct(RvCCProvider* p);
RvCCConnection* createNewSipConnection(RvCCConnection* c, const char* address,
                                              RvCCEventCause* reason);
RvBool isSipAddress(const char* address);
void mapH323Address(const char* address, char* destAddress);
void mapSipAddress(const char* address, char* destAddress);


void sipPhoneRegisterPhysTermAsyncStep(
	IN RvMdmTerm*					mdmTerm,
	IN RvMdmXTermMgr*				x,
	IN RvMdmTermClass*				c,
	IN const RvChar*				id,
	IN RvMdmTermDefaultProperties*  termProperties,
    IN void*                        userData);

RvBool sipPhoneUnregisterPhysTerm(IN RvMdmXTermMgr* x, IN RvMdmXTerm* xTerm);
#ifdef RV_MTF_H323
void rvCCProviderH323Destruct(RvCCProvider* p);
RvCCConnection* createNewH323Connection(RvCCConnection* c, const char* address,
                                              RvCCEventCause* reason);
void H323PhoneRegisterPhysTermAsyncStep(
	IN RvMdmTerm*					mdmTerm,
	IN RvMdmXTermMgr*				x,
	IN RvMdmTermClass*				c,
	IN const RvChar*				id,
	IN RvMdmTermDefaultProperties*  termProperties,
    IN void*                        userData);
RvBool H323PhoneUnregisterPhysTerm(RvMdmXTermMgr * x,RvMdmXTerm * xTerm);
#endif /* RV_MTF_H323 */






/******************************************************************************
*  getMdmTermMgr
*  ---------------------------------
*  General : helper function to retreive the MDM termination manager
*
*                   .
*
*  Return Value:   pointer to the RvMdmTermMgr
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          None.
*
*  Output:         None.
******************************************************************************/
RvMdmTermMgr* getMdmTermMgr(void)
{
    RvCCProvider* p = rvCCBasePhoneGetMdmProvider();
    return rvCCProviderMdmGetTermMgr(p);
}


void setMdmTermMgr(RvMdmTermMgr* mgr)
{
	RvCCProvider* p = rvCCBasePhoneGetMdmProvider();
	rvCCProviderMdmSetTermMgr(p, mgr);
}

static RvCCConnection* createNewMdmConnection(RvCCConnection* c, const char* address,
											  RvCCEventCause* reason)
{
	RvCCProvider*	p			= rvCCBasePhoneGetMdmProvider();
	RvCCCall*		call		= rvCCConnectionGetCall(c);
	RvCCConnection* newConn		= NULL;

	RvMdmTermMgr* termMgr = getMdmTermMgr();
	char* termId;
	RvCCTerminal* t;
	
	

	if (c->call != NULL)
		rvCCCallLock(c->call);

	if (address != NULL) {
		/* Try to find terminal by id */
		termId = rvMdmTermMgrMapAddressToTermination_(termMgr, address);
		t = rvCCProviderFindTerminalByTermId(p, termId);
		if(t==NULL)
			t = rvCCProviderMdmFindTerminalByNumber(p, address);
	}
	else {
		/* If there is no id, it will find some terminal     */
		/* First look for ui, if not present look for analog */
		t = rvCCProviderMdmFindAnyTerminal(p);
	}

	if (t != NULL) {
		if ((newConn = rvCCProviderMdmCreateConnection(p, t)) != NULL)
			rvCCCallAddParty(call, newConn);
		else
			/* In this case no more free lines are available */
			*reason = RV_CCCAUSE_BUSY;
	}
	else
		/* In this case the termination can not be found */
		*reason = RV_CCCAUSE_NOT_FOUND;

	if (c->call != NULL)
		rvCCCallUnlock(c->call);

	return newConn;
}

RvInt getProviderType(const char* address)
{
	RvMdmTermMgr* termMgr = getMdmTermMgr();
	RvCCIPPhone* mtfPhone=(RvCCIPPhone*)(termMgr->xApp);

	if (isSipAddress(address)) return RV_MTF_PROTOCOL_SIP;
#ifdef RV_MTF_H323
	if (isH323Address(address)) return RV_MTF_PROTOCOL_H323;
#endif /* RV_MTF_H323 */
	return mtfPhone->defaultProtocolType;
}


RvCCConnection*  addressAnalyzeCB(RvCCConnection* x, const char* address,
                                  RvCCEventCause inReason, RvCCEventCause* outReason)
{
	RvCCConnection  *newConn = NULL;
//	RvMdmTermMgr* termMgr = getMdmTermMgr();
//	RvCCIPPhone* mtfPhone=(RvCCIPPhone*)(termMgr->xApp);
	char destAddress[256];
    *outReason = inReason;
	strncpy(destAddress, address,sizeof(destAddress));

    if (inReason == RV_CCCAUSE_OUTGOING_CALL)
    {
		RvCCTerminal* t = rvCCConnectionGetTerminal(x);
		RvCCTerminalMdm* term = rvCCTerminalMdmGetImpl(t);
		RvMdmTerm* mdmTerm = rvCCTerminalMdmGetMdmTerm(term);

//		if (mtfPhone->mapAddresses)
		rvMdmTermMapDialStringToAddress_(mdmTerm, address, destAddress);

		switch(getProviderType(destAddress))
		{
			case RV_MTF_PROTOCOL_SIP:
				newConn = createNewSipConnection(x, destAddress, outReason);
			break;
#ifdef RV_MTF_H323
			case RV_MTF_PROTOCOL_H323:
				newConn = createNewH323Connection(x, destAddress, outReason);
			break;
#endif /* RV_MTF_H323 */
		}

    }
    else if (inReason == RV_CCCAUSE_INCOMING_CALL)
    {
//		if (mtfPhone->mapAddresses)
		switch(x->funcs->getProtocolIdF())
		{
			case RV_MTF_PROTOCOL_SIP:
				mapSipAddress(address, destAddress);
			break;
#ifdef RV_MTF_H323
			case RV_MTF_PROTOCOL_H323:
				mapH323Address(address, destAddress);
			break;
#endif /* RV_MTF_H323 */
		}
		newConn = createNewMdmConnection(x, destAddress, outReason);
    }

    return newConn;

}

void inProcessCB(RvCCConnection* x, RvCCEventCause reason)
{
    RV_UNUSED_ARG(reason);
    rvCCCallConnect(x, x->curParty);

}


static void rvCCIPPhoneConstruct(
    IN RvCCIPPhone*         x,
    IN RvMdmTermMgr*        termMgr,
    IN RvMtfSipPhoneCfg*		cfg)
{
    RvCCProvider* mdmProvider;
	x->a = termMgr->a;
//	x->mapAddresses = cfg->mapAddresses;
	x->defaultProtocolType = cfg->defaultProtocolType;
    RvSdpMgrConstructWithConfig(&cfg->sdpStackCfg, sizeof(RvSdpStackCfg));

    mdmProvider = rvCCBasePhoneGetMdmProvider();

    /*  Create Mdm Provider  */
    /*-----------------------*/
    rvCCProviderMdmConstruct(
						mdmProvider,
						rvCCBasePhoneGetCallMgr(),
						termMgr,
                        cfg,
						termMgr->a);

    rvCCProviderMdmSetDisplayData(mdmProvider,rvCCIpPhoneDisplayLogo);

    /*Register Mdm Connection callbacks*/
    rvCCProviderMdmRegisterAddressAnalyzeCB(mdmProvider, addressAnalyzeCB);
    rvCCProviderMdmRegisterInProcessCB(mdmProvider, inProcessCB);

    /*Register Mdm Termination Mgr callbacks*/
    setMdmTermMgr(termMgr);
    rvMdmTermMgrRegisterMapAddressToTermCB(termMgr, mapAddressToTermination);

}


static void ipPhoneSetMediaCaps(void* mgr_,RvMdmTermClass * rtpClass)
{
	int i;
	for (i=0;i<RV_MTF_PROTOCOL_NUM;i++)
	{
		if (rvCCBasePhoneIsUsed_(i))
			xTermMgrClbks[i].mediaCapsUpdatedF(mgr_,rtpClass);
	}
}


static void ipPhoneStart(IN RvMdmXTermMgr* x)
{
	int i;
	for (i=0;i<RV_MTF_PROTOCOL_NUM;i++)
	{
		if (rvCCBasePhoneIsUsed_(i))
			xTermMgrClbks[i].startF(x);
	}
}

static void ipPhoneStop(IN RvMdmXTermMgr* x)
{
	int i;
	for (i=0;i<RV_MTF_PROTOCOL_NUM;i++)
	{
		if (rvCCBasePhoneIsUsed_(i))
			xTermMgrClbks[i].stopF(x);
	}
}


static void rvCCipPhoneDestruct(RvCCIPPhone* x)
{
	RV_UNUSED_ARG(x);
    rvCCProviderMdmDestruct(rvCCBasePhoneGetMdmProvider());
	if (rvCCBasePhoneIsUsed_(RV_MTF_PROTOCOL_SIP))
		rvCCProviderSipDestruct(rvCCBasePhoneGetNetProvider_(RV_MTF_PROTOCOL_SIP));
#ifdef RV_MTF_H323
    if (rvCCBasePhoneIsUsed_(RV_MTF_PROTOCOL_H323))
		rvCCProviderH323Destruct(rvCCBasePhoneGetNetProvider_(RV_MTF_PROTOCOL_H323));
#endif /* RV_MTF_H323 */
}


static void ipPhoneMgrDestruct(RvMdmTermMgr *  mgr)
{
    rvCCipPhoneDestruct(mgr->xApp);
	rvMtfAllocatorDealloc(mgr->xApp, sizeof(RvCCIPPhone));

    /*rvCCBasePhoneConstruct should be called first when user initiates the toolkit,
      and rvCCBasePhoneDestruct should be called last*/
    rvCCBasePhoneDestruct(rvCCBasePhoneGetBasePhone());
}


static RvMdmTerm* ipPhoneRegisterPhysTerm(
    IN RvMdmXTermMgr*               x,
    IN RvMdmTermClass*              c,
    IN const RvChar*                id,
    IN RvMdmTermDefaultProperties*  termProperties)
{
	xTermMgrClbks[0].registerPhysTermF(x, c, id, termProperties);/*??????????????/*/
	return xTermMgrClbks[1].registerPhysTermF(x, c, id, termProperties);
}

static RvMdmTerm* ipPhoneRegisterPhysTermAsync(
    IN RvMdmXTermMgr*               x,
    IN RvMdmTermClass*              c,
    IN const RvChar*                id,
    IN RvMdmTermDefaultProperties*  termProperties,
    IN void*                        userData)
{
    RvMdmTerm* mdmTerm;

	mdmTerm = rvMdmProviderRegisterPhysTermAsync(x,c,id,termProperties, userData);

    if (mdmTerm != NULL)
    {
		RvCCProvider * p = (RvCCProvider*)x;
		RvCCTerminal * t = rvCCProviderFindTerminalByTermId(p, id);
		RvCCTerminalMdm*  mdmTerminal = rvCCTerminalMdmGetImpl(t);
		RvMtfTerminalType termType = rvCCTerminalMdmGetType(mdmTerminal);

		
#ifdef RV_MTF_H323
		if (rvCCBasePhoneIsUsed_(RV_MTF_PROTOCOL_H323))
			H323PhoneRegisterPhysTermAsyncStep(mdmTerm, x, c, id, termProperties, userData);
#endif /* RV_MTF_H323 */
		
		if (rvCCBasePhoneIsUsed_(RV_MTF_PROTOCOL_SIP))
			sipPhoneRegisterPhysTermAsyncStep(mdmTerm, x, c, id, termProperties, userData);

		if ((termType == RV_CCTERMINALTYPE_ANALOG) || (termType == RV_CCTERMINALTYPE_UI))
		{
			IppTimer* timer = &mdmTerminal->registerCompleteTimer;

			/* Verify that the timer is constructed before it is started */
			if (timer->callback != NULL)
			{
				IppTimerStart(timer,IPP_TIMER_DONT_CHECK_IF_STARTED, 0);
			}
		}
	}
	return mdmTerm;
}


static RvBool ipPhoneUnregisterPhysTerm(IN RvMdmXTermMgr* x, IN RvMdmXTerm* xTerm)
{
	/* H323 unregister must be called before SIP unregister,
	   since SIP unregister performs Mdm Unregister       */
	RvBool           res        = RV_TRUE;

#ifdef RV_MTF_H323
	if (rvCCBasePhoneIsUsed_(RV_MTF_PROTOCOL_H323))
		/* the next function does not invoke rvMdmProviderUnregisterTerm() */
		H323PhoneUnregisterPhysTerm(x, xTerm);
#endif /* RV_MTF_H323 */

	if (rvCCBasePhoneIsUsed_(RV_MTF_PROTOCOL_SIP))
		/* the next function performs Terminal un-registration by calling
		   rvMdmProviderUnregisterTerm() function */
		res = sipPhoneUnregisterPhysTerm(x, xTerm);

	return RV_TRUE;
}


static RvBool ipPhoneRegisterAllTermsToNetwork(RvMdmXTermMgr * xTerm)
{
	int i;
	for (i=0;i<RV_MTF_PROTOCOL_NUM;i++)
	{
		if (rvCCBasePhoneIsUsed_(i))
			xTermMgrClbks[i].registerAllTermsToNetworkF(xTerm);
	}
	return RV_TRUE;
}

static RvBool ipPhoneRegisterTermToNetwork(RvMdmXTermMgr * xTerm, RvMdmTerm* mdmTerm)
{
	int i;
	for (i=0;i<RV_MTF_PROTOCOL_NUM;i++)
	{
		if (rvCCBasePhoneIsUsed_(i))
			xTermMgrClbks[i].registerTermToNetworkF(xTerm, mdmTerm);
	}
	return RV_TRUE;
}

static RvBool ipPhoneUnregisterTermFromNetwork(RvMdmXTermMgr * xTerm, RvMdmTerm* mdmTerm)
{
	int i;
	for (i=0;i<RV_MTF_PROTOCOL_NUM;i++)
	{
		if (rvCCBasePhoneIsUsed_(i))
			xTermMgrClbks[i].unregisterTermFromNetworkF(xTerm, mdmTerm);
	}
	return RV_TRUE;
}

#ifdef RV_MTF_H323
void rvCCH323PhoneGetCallback(
    OUT RvMdmXTermMgrClbks*       xTermMgrClbks);
#endif /* RV_MTF_H323 */
void rvCCSipPhoneGetCallback(
    OUT RvMdmXTermMgrClbks*       xTermMgrClbks);

RvBool rvMtfUnregisterPhysTermDone(IN RvCCTerminal*    mdmt)
{
	
	RvCCTerminalMdm*   mdmTerm = rvCCTerminalMdmGetImpl(mdmt);
	RvCCProvider*      mdmProvider = NULL;

	mdmProvider = mdmTerm->provider;
	rvMdmTermUnregisterTermDone_(&mdmTerm->mdmTerm);
	rvMdmProviderUnregisterTerm(mdmProvider, mdmt);

	return RV_TRUE;
}

void rvMtfRegisterTermReportStatus( RvCCTerminal*       mdmt, 						
								    RvBool              timeOut )
{
	RvCCTerminalMdm*   mdmTerm = rvCCTerminalMdmGetImpl(mdmt);
	RvUint8            i;
	RvUint8            numOfFinalResponses = 0;
	RvBool             notifyUser = RV_TRUE;
	RvMtfRegisterReportType  currentRegType = mdmTerm->registerReportType;

	if (currentRegType == RV_REGISTER_REPORT_TYPE_REG_COMPLETE)
	{
		if (!timeOut)
		{
			/* go over the protocol state array and check if results are reported on all protocols */
			for (i=0; i < RV_MTF_PROTOCOL_NUM; i++)
			{
				if (mdmTerm->protocolRegisterStateReported[i] == RV_TRUE)
				{
					numOfFinalResponses++;
				}
			}
		}
		if ((numOfFinalResponses == RV_MTF_PROTOCOL_NUM) || (timeOut == RV_TRUE))
		{
			/* The following reports will be update reports */
			mdmTerm->registerReportType = RV_REGISTER_REPORT_TYPE_REG_UPDATE;
			
			if (timeOut == RV_FALSE)
			{
				IppTimerStop(&mdmTerm->registerCompleteTimer);
			}
		}
		else
		{
			notifyUser = RV_FALSE;
		}
	}
	
	if (notifyUser == RV_TRUE)
	{
		rvMtfTermRegistrationStateChangedCB(mdmt, currentRegType, &mdmTerm->registrationStatus);
		for (i=0; i < RV_MTF_PROTOCOL_NUM; i++)
		{
			/* Reset the report state */
			mdmTerm->protocolRegisterStateReported[i] = RV_FALSE;		
		}
	}	
}


void rvIPPhoneConstruct(
    OUT RvMdmTermMgr*       mgr,
	IN RvMtfSipPhoneCfg*		cfg)
{
	RvCCIPPhone* ipPhone;
    rvMdmTermMgrConstruct_(mgr, prvDefaultAlloc);

    /* Should construct here the termination manager, etc */
	rvMtfAllocatorAlloc(sizeof(RvCCIPPhone), (void**)&ipPhone);
    rvCCIPPhoneConstruct(ipPhone, mgr, cfg);

    mgr->xApp = ipPhone;
	rvCCSipPhoneGetCallback(&xTermMgrClbks[0]);
#ifdef RV_MTF_H323
	rvCCH323PhoneGetCallback(&xTermMgrClbks[1]);
#endif /* RV_MTF_H323 */
    mgr->xTermMgrClbks->registerPhysTermF = ipPhoneRegisterPhysTerm;
    mgr->xTermMgrClbks->registerPhysTermAsyncF = ipPhoneRegisterPhysTermAsync;
    mgr->xTermMgrClbks->unregisterTermF = ipPhoneUnregisterPhysTerm;

    mgr->xTermMgrClbks->mediaCapsUpdatedF = ipPhoneSetMediaCaps;
    mgr->xTermMgrClbks->registerAllTermsToNetworkF = ipPhoneRegisterAllTermsToNetwork;
    mgr->xTermMgrClbks->registerTermToNetworkF = ipPhoneRegisterTermToNetwork;
    mgr->xTermMgrClbks->unregisterTermFromNetworkF = ipPhoneUnregisterTermFromNetwork;

    mgr->xTermMgrClbks->startF = ipPhoneStart;
    mgr->xTermMgrClbks->stopF  = ipPhoneStop;
    mgr->xTermMgrClbks->destructF = ipPhoneMgrDestruct;
}

