/******************************************************************************
Filename   : rvMtfBase.c
Description: This file includes private and public functions for initialization
			 and termination of MTF.
******************************************************************************
                Copyright (c) 2008 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

#define LOGSRC	LOGSRC_BASE

#include "ipp_inc_std.h"
#include "rvMdmControlApi.h"
#include "rvSipControlApi.h"
#include "rvmdm.h"
#include "mtfBaseInt.h"
#include "rvccapi.h"
#include "rvccterminalmdm.h"
#include "basephone.h"
#include "mtfMediaInt.h"
#include "rvMtfEventsApi.h"
#include "rvMtfExtControlApi.h"
#include "rvcctext.h"
#include "rvclock.h"
#include "ippthread.h"
#include "RvSipStack.h"

#ifdef RV_MTF_STUN
#include "rvSipStunApi.h"
#endif

#ifdef RV_MTF_H323
#include "h323Mgr.h"
#include "h323ControlInt.h"
#endif /* RV_MTF_H323 */


RvMtfSipControlClbks		sipExtClbks;
RvMtfCallControlClbks		mdmExtClbks;
RvMtfBaseMgr*				g_mtfMgr;

/*===============================================================================*/
/*===================    P R I V A T E	  F U N C T I O N S    ==================*/
/*===============================================================================*/

RvMdmTermMgr* rvMtfBaseGetTermMgr(RvMtfHandle		hTerm)
{
	RvMtfBaseMgr* mtfMgr = (RvMtfBaseMgr*)hTerm;

	return &(mtfMgr->termMgr);
}

RvMtfBaseMgr* rvGetMtfMgrByMdmTerm(RvMdmTerm* term)
{
	RvMdmTermMgr* termMgr;
	RvCCTerminal* t;
	RvCCTerminalMdm* terminal;

	t = (RvCCTerminal *)rvMdmTermGetXTerm_(term);

	if (t == NULL)
	{
		return NULL;
	}

	terminal = rvCCTerminalMdmGetImpl(t);
	termMgr = rvCCTerminalMdmGetTermMgr(terminal);

	return ((RvMtfBaseMgr*)rvMdmTermMgrGetUserData(termMgr));

}

RvMtfBaseMgr* rvGetMtfMgrByTermMgr(RvMdmTermMgr* termMgr)
{
	return (RvMtfBaseMgr*)rvMdmTermMgrGetUserData(termMgr);
}

static void setTermProperties(
                       RvMdmTermDefaultProperties*			termProperties,
					   RvMtfTerminationConfig*				termConfig)
{
    RvMdmTermPresentationInfo       presentationInfo;

    strncpy(presentationInfo.presentationName, termConfig->displayName,
                                            sizeof(presentationInfo.presentationName));

    presentationInfo.presentationName[sizeof(presentationInfo.presentationName)-1] = '\0';

	rvMdmTermPropertiesSetPresentationInfo(termProperties, &presentationInfo);

	rvMdmTermDefaultPropertiesSetUsername(termProperties, termConfig->username);
	rvMdmTermDefaultPropertiesSetPassword(termProperties, termConfig->password);

	rvMdmTermDefaultPropertiesSetRegistrarAddress(termProperties, termConfig->registrarAddress);
	rvMdmTermDefaultPropertiesSetRegistrarPort(termProperties, termConfig->registrarPort);
	rvMdmTermDefaultPropertiesSetOutboundProxyAddress(termProperties, termConfig->outboundProxyAddress);
	rvMdmTermDefaultPropertiesSetOutboundProxyPort(termProperties, termConfig->outboundProxyPort);
#ifdef RV_CFLAG_TLS
	rvMdmTermDefaultPropertiesSetRegistrarTlsPort(termProperties, termConfig->registrarTlsPort);
#endif
#ifdef RV_SIP_IMS_ON
	rvMdmTermDefaultPropertiesSetPAccessNetworkInfo(termProperties, termConfig->PAccessNetworkInfo);
	rvMdmTermDefaultPropertiesSetIpSecPortC(termProperties, termConfig->ipsecPortC);
	rvMdmTermDefaultPropertiesSetIpSecPortS(termProperties, termConfig->ipsecPortS);
#endif
	rvMdmTermDefaultPropertiesSetRegisterExpires(termProperties, termConfig->registerExpires);
	rvMdmTermDefaultPropertiesSetTransportType(termProperties, termConfig->transportType);

	if (termConfig->digitMap != NULL)
    {
		rvMdmTermDefaultPropertiesSetDigitMap(termProperties, termConfig->digitMap, "userDigitmap");
	}
#ifdef RV_MTF_N_LINES
	termProperties->numberOfLines = termConfig->numberOfLines;
#endif /* RV_MTF_N_LINES */
}

static void rvGetParam(const RvMdmParameterList* list, RvChar* paramName, RvChar* str)
{
	const RvMdmParameterValue* value;
	const RvChar* data = {""};

	if ((list == NULL) || (paramName == NULL))
	{
		return;
	}

	value = rvMdmParameterListGet2(list, paramName);

	if (value != NULL)
	{
		data = rvMdmParameterValueGetValue(value);
	}

	strcpy(str, data);

}

static RvMtfDigit rvMapIdToDigit(const RvChar* id)
{
	if (!strcmp(id, "d0"))				return RV_MTF_DIGIT_0;
	if (!strcmp(id, "d1"))				return RV_MTF_DIGIT_1;
	if (!strcmp(id, "d2"))				return RV_MTF_DIGIT_2;
	if (!strcmp(id, "d3"))				return RV_MTF_DIGIT_3;
	if (!strcmp(id, "d4"))				return RV_MTF_DIGIT_4;
	if (!strcmp(id, "d5"))				return RV_MTF_DIGIT_5;
	if (!strcmp(id, "d6"))				return RV_MTF_DIGIT_6;
	if (!strcmp(id, "d7"))				return RV_MTF_DIGIT_7;
	if (!strcmp(id, "d8"))				return RV_MTF_DIGIT_8;
	if (!strcmp(id, "d9"))				return RV_MTF_DIGIT_9;
	if (!strcmp(id, "ds"))				return RV_MTF_DIGIT_STAR;
	if (!strcmp(id, "do"))				return RV_MTF_DIGIT_POUND;

	return RV_MTF_DIGIT_NONE;
}

static RvBool rvMapIndicatorState(
                  IN RvChar*            id,
                  IN RvMtfSignalState*  state)
{
	if (!strcmp(id, "on"))
	{
		*state =  RV_MTF_SIGNAL_STATE_ON;
		return RV_TRUE;
	}
	else if (!strcmp(id, "off"))
	{
		*state =  RV_MTF_SIGNAL_STATE_OFF;
		return RV_TRUE;
	}
	else if (!strcmp(id, "blink"))
	{
		*state = RV_MTF_SIGNAL_STATE_BLINK;
		return RV_TRUE;
	}

	else if (!strcmp(id, "fast_blink"))
	{
		*state = RV_MTF_SIGNAL_STATE_FAST_BLINK;
		return RV_TRUE;
	}

	return RV_FALSE;
}

static RvBool rvMapIndicatorType(RvChar* id, RvMtfSignalType* type)
{
	if (strstr(id, "l0"))
	{
		*type =  RV_MTF_SIGNAL_IND_LINE;
		return RV_TRUE;
	}
	if (!strcmp(id, "il"))
	{
		*type =  RV_MTF_SIGNAL_IND_HOLD;
		return RV_TRUE;
	}
	if (!strcmp(id, "mu"))
	{
		*type =  RV_MTF_SIGNAL_IND_MUTE;
		return RV_TRUE;
	}
	if (!strcmp(id, "hs"))
	{
		*type =  RV_MTF_SIGNAL_IND_HANDSFREE;
		return RV_TRUE;
	}
	if (!strcmp(id, "ht"))
	{
		*type =  RV_MTF_SIGNAL_IND_HEADSET;
		return RV_TRUE;
	}

	return RV_FALSE;
}

static RvUint32 parseLineId(const RvChar* line)
{
	RvInt id = (line[1]-'0')*100 + (line[2]-'0')*10 + (line[3]-'0');
	return id;
}


/***************************************************************************
 * addParam
 * ------------------------------------------------------------------------
 * General: Adds parameter to parameters list
 *
 *
 * Return Value: None.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	list		- a pointer to parameters list
 *			paramName	- parameter name
 *			paramValue	- parameter value
 *
 ***************************************************************************/
static void addParam(RvMdmParameterList* list, char* paramName, char* paramValue)
{
	RvMdmPackageItem pkgItem;

	rvMdmPackageItemConstruct(&pkgItem, "", paramName);
	rvMdmParameterListOr(list, &pkgItem, paramValue);
	rvMdmPackageItemDestruct(&pkgItem);
}

static RvStatus mapDigitToEvent(IN RvMtfDigit digit, OUT char* digitEvent)
{
    switch (digit)
    {
        case RV_MTF_DIGIT_0:
            strcpy(digitEvent, "d0");
            break;
        case RV_MTF_DIGIT_1:
            strcpy(digitEvent, "d1");
            break;
        case RV_MTF_DIGIT_2:
            strcpy(digitEvent, "d2");
            break;
        case RV_MTF_DIGIT_3:
            strcpy(digitEvent, "d3");
            break;
        case RV_MTF_DIGIT_4:
            strcpy(digitEvent, "d4");
            break;
        case RV_MTF_DIGIT_5:
            strcpy(digitEvent, "d5");
            break;
        case RV_MTF_DIGIT_6:
            strcpy(digitEvent, "d6");
            break;
        case RV_MTF_DIGIT_7:
            strcpy(digitEvent, "d7");
            break;
        case RV_MTF_DIGIT_8:
            strcpy(digitEvent, "d8");
            break;
        case RV_MTF_DIGIT_9:
            strcpy(digitEvent, "d9");
            break;
        case RV_MTF_DIGIT_STAR:
            strcpy(digitEvent, "ds");
            break;
        case RV_MTF_DIGIT_POUND:
            strcpy(digitEvent, "do");
            break;
        default:
            return RV_ERROR_BADPARAM;
            break;
    }

    return RV_OK;
}


/***************************************************************************
 * registerMdmInternalCallbacks()
 * ------------------------------------------------------------------------
 * General: Registers MDM callbacks
 *
 ***************************************************************************/
static void registerMdmInternalCallbacks(RvMtfBaseMgr* mtfMgr)
{
	RvMdmTermMgr	*termMgr= &mtfMgr->termMgr;

	rvMdmTermMgrRegisterConnectCB(termMgr, NULL);
	rvMdmTermMgrRegisterDisconnectCB(termMgr, NULL);
	rvMdmTermMgrRegisterSelectTermCB(termMgr, NULL); /* This callback is not needed */
	rvMdmTermMgrRegisterDeleteEphTermCB(termMgr, NULL); /* This callback is not needed */
	rvMdmTermMgrRegisterMapAddressToTermCB(termMgr, rvMapAddressToTerminationCB);

}

static void initClassCallbacks(RvMdmTermClass *termClass)
{
	rvMdmTermClassRegisterStartSignalCB(termClass, rvStartSignalIntCB);
	rvMdmTermClassRegisterStopSignalCB(termClass, rvStopSignalIntCB);
	rvMdmTermClassRegisterPlaySignalCB(termClass, rvPlaySignalIntCB);
	rvMdmTermClassRegisterCreateMediaCB(termClass, rvPhysCreateMediaIntCB);
/*	rvMdmTermClassRegisterModifyMediaCB(termClass, rvModifyMediaCB); this callback is never called*/
	rvMdmTermClassRegisterDestroyMediaCB(termClass, rvPhysDestroyMediaIntCB);
	rvMdmTermClassRegisterMapDialStringToAddressCB(termClass, rvMapDialStringToAddressCB);
	rvMdmTermClassRegisterMatchDialStringCB(termClass, rvMatchDialStringToPatternCB);
	rvMdmTermClassRegisterRegisterPhysTermCompletedCB(termClass, rvRegisterTermCompletedCB);
	rvMdmTermClassRegisterUnregisterTermCompletedCB(termClass, rvUnregisterTermCompletedCB);
	rvMdmTermClassRegisterUnregisterTermFromNetworkCompletedCB(termClass, rvUnregisterTermFromNetworkCompletedCB);
}

static void rvInitRtpTermClass(RvMdmTermClass *rtpClass)
{
	rvMdmTermClassRegisterCreateMediaCB(rtpClass, NULL);
	rvMdmTermClassRegisterModifyMediaCB(rtpClass, NULL);
	rvMdmTermClassRegisterDestroyMediaCB(rtpClass, NULL);
	rvMdmTermClassRegisterModifyMediaCompletedCB(rtpClass, NULL);
}

/***************************************************************************
 * initIppClasses()
 * ------------------------------------------------------------------------
 * General: Initializes MTF classes
 *
 ***************************************************************************/
static void rvInitIppClasses(RvMtfBaseMgr* mtfMgr)
{
	mtfMgr->atClass = rvMdmTermMgrCreateTermClass(&mtfMgr->termMgr);
	initClassCallbacks(mtfMgr->atClass);
	mtfMgr->uiClass = rvMdmTermMgrCreateTermClass(&mtfMgr->termMgr);
	initClassCallbacks(mtfMgr->uiClass);
	mtfMgr->phoneClass = rvMdmTermMgrCreateTermClass(&mtfMgr->termMgr);
	initClassCallbacks(mtfMgr->phoneClass);

	rvMdmTermMgrRegisterIPPhoneUiPackages(&mtfMgr->termMgr);

	rvMdmTermClassSetIPPhoneUIPackages(mtfMgr->uiClass);
	rvMdmTermClassSetAudioTransducerPackages(mtfMgr->atClass);
	rvMdmTermClassSetAnalogLinePackages(mtfMgr->phoneClass);
	/* Set all ipp packages to analog termination so that analog will be able to support all features */
	rvMdmTermClassSetIPPhoneUIPackages(mtfMgr->phoneClass);
	rvMdmTermClassSetAudioTransducerPackages(mtfMgr->phoneClass);

}
/*===============================================================================*/
/*==========    O L D   C A L L B A C K	S	I M P L E M E N T A T I O N S  ======*/
/*===============================================================================*/
/***************************************************************************
 * rvMatchDialStringToPatternCB
 * ------------------------------------------------------------------------
 * General: Checks if a dialed string matches a digitmap pattern that was 
 *          configured by the user.
 *          This callback invokes a user proc if such proc exists, otherwise 
 *          a default callback rvMdmTermMatchDialString_ is invoked.
 *
 *
 * Return Value: None.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	term		    - a pointer to mdm term
 *			dialString	    - a dialed string
 *			timerDuration	- a time to wait for the next digit
 *
 ***************************************************************************/
RvMdmDigitMapMatchType rvMatchDialStringToPatternCB(
					RvMdmTerm*		term,
					const RvChar*  	dialString,
					RvUint*	        timerDuration)
{
	RvMtfBaseMgr*			mtfMgr;
	RvIppTerminalHandle		hTerm;
	RvMdmDigitMapMatchType	res = RV_MDMDIGITMAP_NOMATCH;
	
	mtfMgr = rvGetMtfMgrByMdmTerm(term);
	
	if (mtfMgr == NULL)
    {
		RvLogDebug(ippLogSource,(ippLogSource, "rvMatchDialStringToPatternCB() - mtfMgr is NULL, term id=%s, term=0x%p, dialString=%s",
			rvMdmTermGetId(term), term, dialString));
		return res;
    }
	
	hTerm = rvIppMdmTerminalGetHandle(term);
	
	if (hTerm == NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvMatchDialStringToPatternCB() - hTerm is NULL, term id=%s, term=0x%p, dialString=%s",
			rvMdmTermGetId(term), term, dialString));
		return res;
	}
	
	if (mtfMgr->mdmClbks.matchDialStringToPatternCB != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvMatchDialStringToPatternCB() - before user callback, term id=%s, term=0x%p, dialString=%s",
			rvMdmTermGetId(term), term, dialString));
		
		res = mtfMgr->mdmClbks.matchDialStringToPatternCB(hTerm, (RvMtfTerminalAppHandle)rvMdmTermGetUserData(term), (RvChar*)dialString, timerDuration);
		
		RvLogDebug(ippLogSource,(ippLogSource, "rvMatchDialStringToPatternCB() - after user callback (res=%d), term id=%s, term=0x%p, dialString=%s",
			res, rvMdmTermGetId(term), term, dialString));
	}
	else
	{
        res = terminalMdmMatchDigitMap(term->xTerm, dialString, timerDuration);
	}
	
	return res;
	
}


RvBool rvMapDialStringToAddressCB(
				RvMdmTerm*		term,
				const RvChar*	dialString,
				RvChar*			address)
{
	RvMtfBaseMgr*			mtfMgr;
	RvIppTerminalHandle		hTerm;
	RvStatus				res = RV_OK;

	mtfMgr = rvGetMtfMgrByMdmTerm(term);

	if (mtfMgr == NULL)
    {
		RvLogDebug(ippLogSource,(ippLogSource, "rvMapDialStringToAddressCB() - mtfMgr is NULL, term id=%s, term=0x%p, dialString=%s",
			rvMdmTermGetId(term), term, dialString));
		return RV_FALSE;
    }

	hTerm = rvIppMdmTerminalGetHandle(term);

	if (hTerm == NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvMapDialStringToAddressCB() - hTerm is NULL, term id=%s, term=0x%p, dialString=%s",
			rvMdmTermGetId(term), term, dialString));
		return RV_FALSE;
	}

	if (mtfMgr->mdmClbks.mapDialStringToAddressCB != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvMapDialStringToAddressCB() - before user callback, term id=%s, term=0x%p, dialString=%s",
			rvMdmTermGetId(term), term, dialString));

		res = mtfMgr->mdmClbks.mapDialStringToAddressCB(hTerm, (RvMtfTerminalAppHandle)rvMdmTermGetUserData(term), (RvChar*)dialString, address);

		RvLogDebug(ippLogSource,(ippLogSource, "rvMapDialStringToAddressCB() - after user callback (res=%d), term id=%s, term=0x%p, dialString=%s",
			res, rvMdmTermGetId(term), term, dialString));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvMapDialStringToAddressCB() - this callback was not registered by application, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
	}

	if (res == RV_OK)
    {
		return RV_TRUE;
    }

	return RV_FALSE;

}

/* This callback is called when new call arrives, and it is needed to decide which termination receives the call.
   The function checks if user application registered its own implementation, and if not, it will use the default
   implementation. */
RvChar* rvMapAddressToTerminationCB(
								  RvMdmTermMgr*		termMgr,
								  const RvChar*		address)
{
	RvMtfBaseMgr*	mtfMgr;
	RvChar* termId = NULL;
	RvStatus	res = RV_OK;

	mtfMgr = rvGetMtfMgrByTermMgr(termMgr);

	if (mtfMgr == NULL)
    {
		RvLogDebug(ippLogSource,(ippLogSource, "rvMapAddressToTerminationCB() - mtfMgr is NULL, address=%s", address));
		return NULL;
    }

	/* If this callback is registered, then user application will decide which termination will receive the new call */
	if (mtfMgr->mdmClbks.mapAddressToTerminationCB != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvMapAddressToTerminationCB() - before user callback, address%s", address));

		res = mtfMgr->mdmClbks.mapAddressToTerminationCB((RvMtfHandle)mtfMgr, mtfMgr->userData, (RvChar*)address, termId);

		RvLogDebug(ippLogSource,(ippLogSource, "rvMapAddressToTerminationCB() - after user callback (res=%d), destination term id=%s, address=%s",
			res, termId, address));
	}
	/* If this callback is not registered by application, by default MTF will choose the termination by matching the
	   termination id to the username in To header. */
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvMapAddressToTerminationCB() - this callback was not registered by application, calling default callback, address=%s", address));
		termId = mapAddressToTermination(termMgr, address);
	}

	return termId;

}
void rvRegisterTermCompletedCB(
                     IN struct RvMdmTerm_*   term,
                     IN RvMdmError*          mdmError)
{
    RvMtfBaseMgr*		mtfMgr;
    RvIppTerminalHandle hTerm;
	RvCCTerminal*		t;
	RvCCTerminalMdm*	mdmTerminal;
	RvCCTerminalType	termType;
	RvChar*				termId = (RvChar*)rvMdmTermGetId(term);

	RV_UNUSED_ARG(mdmError);

    mtfMgr = rvGetMtfMgrByMdmTerm(term);

    if (mtfMgr == NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvRegisterTermCompletedCB() - mtfMgr is NULL, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
		return;
	}

	hTerm = rvIppMdmTerminalGetHandle(term);

	if (hTerm == NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvRegisterTermCompletedCB() - hTerm is NULL, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
		return;
	}

	t = (RvCCTerminal*)hTerm;
	mdmTerminal = rvCCTerminalMdmGetImpl(t);
	termType = rvCCTerminalMdmGetType(mdmTerminal);

	switch (termType)
	{
		/* ------------------- */
		/* Analog registration */
		/* ------------------- */
		case RV_CCTERMINALTYPE_ANALOG:
			if (mtfMgr->mdmClbks.registerAnalogTermCompletedCB != NULL)
			{
				RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegisterAnalogTermCompletedEv() - before user callback (term id=%s, term=0x%p)",
					termId, term));

				/* Call user callback to indicate Analog registration is done. */
				mtfMgr->mdmClbks.registerAnalogTermCompletedCB(hTerm, (RvMtfTerminalAppHandle)rvMdmTermGetUserData(term));

				RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegisterAnalogTermCompletedEv() - after user callback (term id=%s, term=0x%p)",
					termId, term));
			}
			else
			{
				RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegisterAnalogTermCompletedEv() - this callback was not registered by application, term id=%s, term=0x%p",
					termId, term));
			}
		break;

		/* ------------------- */
		/* IPPhone registration */
		/* -------------------- */
		case RV_CCTERMINALTYPE_UI:
			/* Since we registered UI first, we will wait until AT termination completes before we can call user callback. */
			RvLogDebug(ippLogSource,(ippLogSource, "rvRegisterTermCompletedCB() - called for UI termination, term id=%s, term=0x%p",
				termId, term));
			break;

		case RV_CCTERMINALTYPE_AT:
			/* Since we registered handset termination last, we can call user callback to indicate process is complete. */
			if (!strcmp(termId, "at/hs"))
			{
				RvCCProvider*	p = rvCCBasePhoneGetMdmProvider();
				RvCCTerminal*   uiTerm = rvCCProviderFindTermByType(p, RV_CCTERMINALTYPE_UI);
				RvCCTerminalMdm* uiTermMdm = rvCCTerminalMdmGetImpl(uiTerm);

				if (mtfMgr->mdmClbks.registerIPPhoneTermsCompletedCB != NULL)
				{
					RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegisterIPPhoneTermsCompletedEv() - before user callback (term id=%s, term=0x%p)",
						rvCCTerminalGetId(uiTerm), uiTerm));

					/* Call user callback to indicate IPPhone registration is done.
					   The UI handle is the one we pass to application (uiTerm), not audio (term), since this is the one application holds
					   after calling the API to register. */
					mtfMgr->mdmClbks.registerIPPhoneTermsCompletedCB((RvIppTerminalHandle)uiTerm, (RvMtfTerminalAppHandle)rvMdmTermGetUserData(&uiTermMdm->mdmTerm));

					RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegisterIPPhoneTermsCompletedEv() - after user callback (term id=%s, term=0x%p)",
						rvCCTerminalGetId(uiTerm), uiTerm));
				}
				else
				{
					RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegisterIPPhoneTermsCompletedEv() - this callback was not registered by application, term id=%s, term=0x%p",
						rvCCTerminalGetId(uiTerm), uiTerm));
				}
			}
			/* Other audio termination is done, we wait for handset before calling user callback. */
			else
			{
				RvLogDebug(ippLogSource,(ippLogSource, "rvRegisterTermCompletedCB() - called for AT termination, term id=%s, term=0x%p",
				termId, term));
			}
		break;

#ifdef RV_MTF_VIDEO
		/* ------------------ */
		/* Video registration */
		/* ------------------ */
		case RV_CCTERMINALTYPE_VT:
			/* Since we registered screen termination last, we can call user callback to indicate process is complete. */
			if (!strcmp(termId, "vt/scr"))
			{
				if (mtfMgr->mdmClbks.registerVideoTermsCompletedCB != NULL)
				{
					RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegisterVideoTermsCompletedEv() - before user callback (term id=%s, term=0x%p)",
						termId, term));

					/* Call user callback to indicate Video registration is done.*/
					mtfMgr->mdmClbks.registerVideoTermsCompletedCB(hTerm, (RvMtfTerminalAppHandle)rvMdmTermGetUserData(term));

					RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegisterVideoTermsCompletedEv() - after user callback (term id=%s, term=0x%p)",
						termId, term));
				}
				else
				{
					RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegisterVideoTermsCompletedEv() - this callback was not registered by application, term id=%s, term=0x%p",
						termId, term));
				}
			}
			/* camera termination is done, we wait for screen before calling user callback. */
			else
			{
				RvLogDebug(ippLogSource,(ippLogSource, "rvRegisterTermCompletedCB() - called for camera termination, term id=%s, term=0x%p",
					termId, term));
			}
		break;
#endif /* RV_MTF_VIDEO */

		default:
			RvLogDebug(ippLogSource,(ippLogSource, "rvRegisterTermCompletedCB() - called for %s termination, term=0x%p",
					termId, term));
			break;
	}

}

void rvUnregisterTermCompletedCB(
                   IN struct RvMdmTerm_*   term,
                   IN RvMdmError*          mdmError)
{
    RvMtfBaseMgr*		mtfMgr;
    RvIppTerminalHandle hTerm;
	RvCCTerminal*		t;
	RvCCTerminalMdm*	mdmTerminal;
	RvCCTerminalType	termType;
	RvChar*				termId = (RvChar*)rvMdmTermGetId(term);

	RV_UNUSED_ARG(mdmError);

    mtfMgr = rvGetMtfMgrByMdmTerm(term);

    if (mtfMgr == NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvUnregisterTermCompletedCB() - mtfMgr is NULL, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
		return;
	}

	hTerm = rvIppMdmTerminalGetHandle(term);

	if (hTerm == NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvUnregisterTermCompletedCB() - hTerm is NULL, term id=%s, term=0x%p", rvMdmTermGetId(term), term));
		return;
	}

	t = (RvCCTerminal*)hTerm;
	mdmTerminal = rvCCTerminalMdmGetImpl(t);
	termType = rvCCTerminalMdmGetType(mdmTerminal);

	switch (termType)
	{
		/* ---------------------- */
		/* Analog un-registration */
		/* ---------------------- */
		case RV_CCTERMINALTYPE_ANALOG:
			if (mtfMgr->mdmClbks.unregisterAnalogTermCompletedCB != NULL)
			{
				RvLogDebug(ippLogSource,(ippLogSource, "RvMtfUnregisterAnalogTermCompletedEv() - before user callback (term id=%s, term=0x%p)",
					termId, term));

				/* Call user callback to indicate Analog un-registration is done. */
				mtfMgr->mdmClbks.unregisterAnalogTermCompletedCB(hTerm, (RvMtfTerminalAppHandle)rvMdmTermGetUserData(term));

				RvLogDebug(ippLogSource,(ippLogSource, "RvMtfUnregisterAnalogTermCompletedEv() - after user callback (term id=%s, term=0x%p)",
					termId, term));
			}
			else
			{
				RvLogDebug(ippLogSource,(ippLogSource, "RvMtfUnregisterAnalogTermCompletedEv() - this callback was not registered by application, term id=%s, term=0x%p",
					termId, term));
			}
		break;

		/* ----------------------- */
		/* IPPhone un-registration */
		/* ----------------------- */
		case RV_CCTERMINALTYPE_AT:
			/* Since we un-registered Handset first, we will wait until AT termination completes before we can call user callback. */
			RvLogDebug(ippLogSource,(ippLogSource, "rvUnregisterTermCompletedCB() - called for AT termination, termId=%s, term=0x%p",
				termId, term));
			break;

		case RV_CCTERMINALTYPE_UI:
			/* Since we unregistered UI termination last, we can call user callback to indicate process is complete. */
			if (mtfMgr->mdmClbks.unregisterIPPhoneTermsCompletedCB != NULL)
			{
				RvLogDebug(ippLogSource,(ippLogSource, "RvMtfUnregisterIPPhoneTermsCompletedEv() - before user callback (term id=%s, term=0x%p)",
					termId, hTerm));

				/* Call user callback to indicate un-registration process is done.
				   The UI handle is the one we pass to application, since this is the one application holds
				   after calling the API to register. */
				mtfMgr->mdmClbks.unregisterIPPhoneTermsCompletedCB((RvIppTerminalHandle)hTerm, (RvMtfTerminalAppHandle)rvMdmTermGetUserData(term));

				RvLogDebug(ippLogSource,(ippLogSource, "RvMtfUnregisterIPPhoneTermsCompletedEv() - after user callback (term id=%s, term=0x%p)",
					termId, hTerm));
			}
			else
			{
				RvLogDebug(ippLogSource,(ippLogSource, "RvMtfUnregisterIPPhoneTermsCompletedEv() - this callback was not registered by application, term id=%s, term=0x%p",
					termId, hTerm));
			}
		break;

#ifdef RV_MTF_VIDEO
		/* --------------------- */
		/* Video un-registration */
		/* --------------------- */
		case RV_CCTERMINALTYPE_VT:
			/* Since we registered screen termination last, we can call user callback to indicate process is complete. */
			if (!strcmp(termId, "vt/scr"))
			{
				if (mtfMgr->mdmClbks.unregisterVideoTermsCompletedCB != NULL)
				{
					RvLogDebug(ippLogSource,(ippLogSource, "RvMtfUnregisterVideoTermsTermsCompletedEv() - before user callback (term id=%s, term=0x%p)",
						termId, term));

					/* Call user callback to indicate Video un-registration is done.*/
					mtfMgr->mdmClbks.unregisterVideoTermsCompletedCB(hTerm, (RvMtfTerminalAppHandle)rvMdmTermGetUserData(term));

					RvLogDebug(ippLogSource,(ippLogSource, "RvMtfUnregisterVideoTermsTermsCompletedEv() - after user callback (term id=%s, term=0x%p)",
						termId, term));
				}
				else
				{
					RvLogDebug(ippLogSource,(ippLogSource, "RvMtfUnregisterVideoTermsTermsCompletedEv() - this callback was not registered by application, term id=%s, term=0x%p",
						termId, term));
				}
			}
			/* camera termination is done, we wait for screen before calling user callback. */
			else
			{
				RvLogDebug(ippLogSource,(ippLogSource, "rvUnregisterTermCompletedCB() - called for camera termination, term id=%s, term=0x%p",
					termId, term));
			}
		break;
#endif /* RV_MTF_VIDEO */

		default:
			RvLogDebug(ippLogSource,(ippLogSource, "rvUnregisterTermCompletedCB() - called for %s termination, term=0x%p",
					termId, term));
			break;
	}

}


void rvUnregisterTermFromNetworkCompletedCB(
                   IN struct RvMdmTerm_*   term,
                   IN RvMdmError*          mdmError)
{
    RvMtfBaseMgr*	mtfMgr;
    RvIppTerminalHandle hTerm;

	RV_UNUSED_ARG(mdmError);

    mtfMgr = rvGetMtfMgrByMdmTerm(term);

    if (mtfMgr == NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvUnregisterTermFromNetworkCompletedCB() - mtfMgr is NULL, term id=%s, term=0x%p",
			rvMdmTermGetId(term), term));
		return;
	}

	hTerm = rvIppMdmTerminalGetHandle(term);

	if (hTerm == NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvUnregisterTermFromNetworkCompletedCB() - hTerm is NULL, term id=%s, term=0x%p",
			rvMdmTermGetId(term), term));
		return;
	}

	if (mtfMgr->mdmClbks.unregisterTermFromServerCompletedCB != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvUnregisterTermFromNetworkCompletedCB() - before user callback (term id=%s, term=0x%p)",
			rvMdmTermGetId(term), term));

		mtfMgr->mdmClbks.unregisterTermFromServerCompletedCB(hTerm, (RvMtfTerminalAppHandle)rvMdmTermGetUserData(term));

		RvLogDebug(ippLogSource,(ippLogSource, "rvUnregisterTermFromNetworkCompletedCB() - after user callback (term id=%s, term=0x%p)",
			rvMdmTermGetId(term), term));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvUnregisterTermFromNetworkCompletedCB() - this callback was not registered by application, term id=%s, term=0x%p",
			rvMdmTermGetId(term), term));
	}

    return;

}

/*=======================================================================================*/
/*=====  S I G N A L S	  O L D   C A L L B A C K	  I M P L E M E N T A T I O N S  ====*/
/*=======================================================================================*/

RvBool rvStartSignalIntCB(
                RvMdmTerm*		term,
                RvMdmSignal *	s,
                RvMdmError*     mdmError)
{
	RvMtfBaseMgr*               mtfMgr;
	RvIppTerminalHandle         hTerm;
	const RvChar*			    pkg;
	const RvChar*			    id;
	const RvMdmParameterList*   params;
	RvMtfSignalType				signalType;
	RvMtfSignalState			signalState;
    RvMtfSignalParams			signalParams;
	RvMtfSignalParams*			pSignalParams = NULL;
	char						strPrintParams[256];

    RV_UNUSED_ARG(mdmError);

	if ((term == NULL) || (s == NULL))
    {
		return RV_FALSE;
    }

	mtfMgr = rvGetMtfMgrByMdmTerm(term);
	hTerm = rvIppMdmTerminalGetHandle(term);

	if (hTerm == NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvStartSignalIntCB() - hTerm is NULL, term id=%s, term=0x%p",
			rvMdmTermGetId(term), term));
		return RV_FALSE;
	}

	pkg = rvMdmSignalGetPkg(s);
	id = rvMdmSignalGetId(s);

	strcpy(strPrintParams, "(none)");

	params = rvMdmSignalGetArguments(s);

	/* Signals */
	/* ------- */
	if (!strcmp(pkg, "cg") || !strcmp(pkg, "dg"))
	{
		if (!strcmp(id, "dt"))
		{
			signalType = RV_MTF_SIGNAL_DIALTONE;
            signalState = RV_MTF_SIGNAL_STATE_ON;
		}
		else if (!strcmp(id, "rt"))
		{
			RvChar distTone[128] = {""};

			rvGetParam(params, "distRing", distTone);

			if (strcmp(distTone, ""))
            {
				strncpy((RvChar*)&signalParams.distictiveTone, (RvChar*)&distTone, sizeof(signalParams.distictiveTone));
                signalParams.distictiveTone[sizeof(signalParams.distictiveTone)-1] = '\0';
				RvSprintf(strPrintParams, "distictiveTone=%s", signalParams.distictiveTone);
            }
			else
			{
				strcpy(signalParams.distictiveTone, "");
			}

			pSignalParams = &signalParams;
			signalType = RV_MTF_SIGNAL_RINGBACK;
            signalState = RV_MTF_SIGNAL_STATE_ON;
		}
		else if (!strcmp(id, "cw"))
		{
			signalType = RV_MTF_SIGNAL_CALLWAITING_CALLEE;
            signalState = RV_MTF_SIGNAL_STATE_ON;
		}
		else if (!strcmp(id, "cr"))
		{
			signalType = RV_MTF_SIGNAL_CALLWAITING_CALLER;
            signalState = RV_MTF_SIGNAL_STATE_ON;
		}
		else if (!strcmp(id, "bt"))
		{
			signalType = RV_MTF_SIGNAL_BUSY;
            signalState = RV_MTF_SIGNAL_STATE_ON;
		}
		else if (!strcmp(id, "wt"))
		{
			signalType = RV_MTF_SIGNAL_WARNING;
            signalState = RV_MTF_SIGNAL_STATE_ON;
		}
		else if (!strncmp(id, "d", 1))
		{
            RvMtfSignalParams	signalParams;
			RvChar val1[128] = {""};

			signalParams.digit = rvMapIdToDigit(id);
			
			rvGetParam(params, "lineId", val1);
			signalParams.lineId = parseLineId(val1);

			pSignalParams = &signalParams;

			RvSprintf(strPrintParams, "digit=%d", signalParams.digit);

			signalType = RV_MTF_SIGNAL_DIGIT;
            signalState = RV_MTF_SIGNAL_STATE_ON;
		}
		else
		{
			RvLogDebug(ippLogSource,(ippLogSource, "rvStartSignalIntCB() - unknown id (%s), pkg=%s, term id=%s, term=0x%p",
				id, pkg, rvMdmTermGetId(term), term));
			return RV_FALSE;
		}

		if (mtfMgr->mdmClbks.startSignalCB != NULL)
		{
			RvLogDebug(ippLogSource,(ippLogSource, "rvStartSignalIntCB() - before user callback, signal=%s, state=%s, params:%s, term id=%s, term=0x%p",
				rvMtfTextSignalType(signalType), rvMtfTextSignalState(signalState), strPrintParams, rvMdmTermGetId(term), term));

			mtfMgr->mdmClbks.startSignalCB(hTerm, (RvMtfTerminalAppHandle)rvMdmTermGetUserData(term), signalType, signalState, pSignalParams);

			RvLogDebug(ippLogSource,(ippLogSource, "rvStartSignalIntCB() - after user callback, signal=%s, state=%s, params:%s, term id=%s, term=0x%p",
				rvMtfTextSignalType(signalType), rvMtfTextSignalState(signalState), strPrintParams, rvMdmTermGetId(term), term));

			return RV_TRUE;
		}
		else
		{
			RvLogDebug(ippLogSource,(ippLogSource, "startSignalCB - this callback was not registered by application, term id=%s, term=0x%p",
				rvMdmTermGetId(term), term));
			return RV_TRUE;
		}
	}

	/* Indicators */
	/* ---------- */
	else if (!strcmp(pkg, "ind"))
	{
		if (!strcmp(id, "is"))
		{
			RvMtfSignalState     state = RV_MTF_SIGNAL_STATE_ON;

			RvChar val1[128] = {""};
			RvChar val2[128] = {""};

			rvGetParam(params, "Indid", val1);
			rvGetParam(params, "state", val2);

			if ((val1 == NULL) || (val2 == NULL))
			{
				return RV_FALSE;
			}

			rvMapIndicatorState(val2, &state);

			/* Ringing signal */
			if (strstr(val1, "ir"))
			{
				RvChar val3[128] = {""};
				rvGetParam(params, "distRing", val3);
				if (strcmp(val3, ""))
				{
					strncpy((RvChar*)&signalParams.distictiveTone, (RvChar*)&val3, sizeof(val3));
				}
				else
				{
					strcpy(signalParams.distictiveTone, "");
				}

				if (state == RV_MTF_SIGNAL_STATE_ON)
				{
					mtfMgr->mdmClbks.startSignalCB(
											hTerm,
											(RvMtfTerminalAppHandle)rvMdmTermGetUserData(term),
                                            RV_MTF_SIGNAL_RINGING,
                                            RV_MTF_SIGNAL_STATE_ON,
                                            &signalParams);
				}
				else
				{
					mtfMgr->mdmClbks.stopSignalCB(
											hTerm,
											(RvMtfTerminalAppHandle)rvMdmTermGetUserData(term),
                                            RV_MTF_SIGNAL_RINGING);
				}

			}
			/* Other indicators */
			else
			{
				RvMtfSignalType type = RV_MTF_SIGNAL_DIALTONE;

				rvMapIndicatorType(val1, &type);

				/*Line indicator*/
				if (type == RV_MTF_SIGNAL_IND_LINE)
				{
                    RvMtfSignalParams params;

                    params.lineId = parseLineId(val1);

					mtfMgr->mdmClbks.startSignalCB(
												hTerm,
												(RvMtfTerminalAppHandle)rvMdmTermGetUserData(term),
												RV_MTF_SIGNAL_IND_LINE,
												state, &params);
				}
				/*All other indicators*/
				else
				{
					mtfMgr->mdmClbks.startSignalCB(
									hTerm,
									(RvMtfTerminalAppHandle)rvMdmTermGetUserData(term),
									type,
									state,
									NULL);
				}
			}

		}

	}
	/* Analog signals */
	/* -------------- */
	else if (!strcmp(pkg, "al"))
	{
		if (!strcmp(id, "ri"))
		{
			mtfMgr->mdmClbks.startSignalCB(
								hTerm,
								(RvMtfTerminalAppHandle)rvMdmTermGetUserData(term),
                                RV_MTF_SIGNAL_RINGING,
                                RV_MTF_SIGNAL_STATE_ON,
                                NULL);

		}
		else
		{
			RvLogError(ippLogSource,(ippLogSource, "rvStartSignalIntCB() - unknown id (%s), pkg=%s, term=0x%p", id, pkg, term));
			return RV_FALSE;
		}
	}

	return RV_TRUE;

}

RvBool rvPlaySignalIntCB(
                IN  RvMdmTerm*          term,
                IN  RvMdmSignal*        s,
                IN  RvBool              reportCompletion,
                OUT RvMdmError*         mdmError)
{
    RV_UNUSED_ARG(reportCompletion);

    return rvStartSignalIntCB(term, s, mdmError);

}

RvBool rvStopSignalIntCB(
                RvMdmTerm*      term,
                RvMdmSignal*    s,
                RvMdmError*     mdmError)
{
	RvMtfBaseMgr*			mtfMgr;
	RvIppTerminalHandle		hTerm;
	const RvChar*			pkg;
	const RvChar*			id;
	const RvMdmParameterList* params;
	RvMtfSignalType         signalType = RV_MTF_SIGNAL_DIALTONE; /* This is only to avoid warnings */

    RV_UNUSED_ARG(mdmError);

	if ((term == NULL) || (s == NULL))
    {
		return RV_FALSE;
    }

	mtfMgr = rvGetMtfMgrByMdmTerm(term);
	hTerm = rvIppMdmTerminalGetHandle(term);

	if (hTerm == NULL)
	{
		return RV_FALSE;
	}

	if (mtfMgr->mdmClbks.stopSignalCB == NULL)
	{
		return RV_FALSE;
	}

	pkg = rvMdmSignalGetPkg(s);
	id = rvMdmSignalGetId(s);

	params = rvMdmSignalGetArguments(s);

	if (!strcmp(pkg, "cg"))
	{
		if (!strcmp(id, "dt"))
		{
			signalType = RV_MTF_SIGNAL_DIALTONE;
		}
		else if (!strcmp(id, "rt"))
		{
			signalType = RV_MTF_SIGNAL_RINGBACK;

		}
		else if (!strcmp(id, "cw"))
		{
			signalType = RV_MTF_SIGNAL_CALLWAITING_CALLEE;

		}
		else if (!strcmp(id, "cr"))
		{
			signalType = RV_MTF_SIGNAL_CALLWAITING_CALLER;

		}
		else if (!strcmp(id, "bt"))
		{
			signalType = RV_MTF_SIGNAL_BUSY;

		}
		else if (!strcmp(id, "wt"))
		{
			signalType = RV_MTF_SIGNAL_WARNING;
		}
		else
		{
			RvLogError(ippLogSource,(ippLogSource, "rvStopSignalIntCB() - unknown id (%s), pkg=%s, term=0x%p", id, pkg, term));
			return RV_FALSE;
		}
	}
	else if (!strcmp(pkg, "al"))
	{
		if (!strcmp(id, "ri"))
		{
			signalType = RV_MTF_SIGNAL_RINGING;
		}
		else
		{
			RvLogError(ippLogSource,(ippLogSource, "rvStopSignalIntCB() - unknown id (%s), pkg=%s, term=0x%p", id, pkg, term));
			return RV_FALSE;
		}
	}
	else
	{
		RvLogError(ippLogSource,(ippLogSource, "rvStopSignalIntCB() - unknown pkg (%s), term=0x%p", pkg, term));
		return RV_FALSE;
	}

	mtfMgr->mdmClbks.stopSignalCB(hTerm, (RvMtfTerminalAppHandle)rvMdmTermGetUserData(term), signalType);

	return RV_TRUE;
}


/*===============================================================================*/
/*=====================    A P I	  F U N C T I O N S    ======================*/
/*===============================================================================*/

/****************************************************************************
 * rvMtfSystemInit()
 *****************************************************************************/
RVAPI void RVCALLCONV rvMtfSystemInit(void)
{
	/* NOTE!!!!!!!!!!
    Do not add log here. log is not started yet */
    rvIppSipSystemInit();
}

/****************************************************************************
 * rvMtfSystemEnd()
 *****************************************************************************/
RVAPI void RVCALLCONV rvMtfSystemEnd(void)
{
	rvIppSipSystemEnd();
}

/*****************************************************************************
 * rvMtfInitConfig()
 *****************************************************************************/
RVAPI RV_Status RVCALLCONV rvMtfInitConfig(
    OUT RvIppSipPhoneCfg*    cfg)
{
	RV_Status res;
	RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMtfInitConfig(cfg=%p)", cfg));

    rc = rvIppSipInitConfig(cfg);

	res = ((rc == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfInitConfig()=%d", res));

    return res;
}

/*****************************************************************************
 * rvMtfSipInitConfig()
 *****************************************************************************/
RVAPI RV_Status RVCALLCONV rvMtfSipInitConfig(
     OUT RvMtfSipPhoneCfg*    cfg)
{
	RV_Status res;
	RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMtfSipInitConfig(cfg=%p)", cfg));

    rc = rvIppSipInitConfig(cfg);

	res = ((rc == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfSipInitConfig()=%d", res));

    return res;
}

#ifdef RV_MTF_H323
/*****************************************************************************
 * rvMtfH323InitConfig()
 *****************************************************************************/
RVAPI RV_Status RVCALLCONV rvMtfH323InitConfig(
     OUT RvMtfH323PhoneCfg*    cfg)
{
	RV_Status res;
	RvBool rc;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMtfH323InitConfig(cfg=%p)", cfg));

    rc = rvIppH323InitConfig(cfg);

	res = ((rc == RV_TRUE) ? RV_OK : RV_ERROR_UNKNOWN);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMtfH323InitConfig()=%d", res));

    return res;
}
#endif /* RV_MTF_H323 */


#ifdef RV_MTF_H323
RVAPI RvStatus RVCALLCONV rvMtfAddH323(
						 IN 	RvMtfHandle 			hMtf,
						 IN		RvMtfH323PhoneCfg*		config)
{
	RvMtfBaseMgr*		mtfMgr;
	RvIppMdmExtClbks	deprecatedMdmExtClbks;
	HAPP				hApp;
	HSSEAPP				hSSEApp;
	RvStatus            rv = RV_OK;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfAddH323(hMtf=%p, config=%p)", hMtf, config));

	mtfMgr = (RvMtfBaseMgr*)hMtf;

	mtfMgr->userData = NULL;

	/* Initialize H323 stack*/

	if( rvIppH323StackInitialize(&hApp, &hSSEApp, (HAPPAPP)NULL, config) != rvTrue)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvMtfH323Construct() - Error initializing H323 stack, hMtf=%p", hMtf));
		return RV_ERROR_UNKNOWN;
	}
	/* Set the MTF handle in the H323 stack as application handle */
	rv = cmSetHandle( hApp,(HAPPAPP)hMtf); 
	if(rv !=RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvMtfAddH323(). Failed in cmSetHandle()"));
		return RV_ERROR_UNKNOWN;
	}
	rvCCIPPhoneAddH323(&mtfMgr->termMgr,config, hApp, hSSEApp);

	/* Register internal MDM callbacks */
	registerMdmInternalCallbacks(mtfMgr);

	/* Reset deprecated MDM extensibility callbacks, so these callbacks won't be called.
	   (these callbacks were replaced by RvMtfCallControlClbks). */
	memset(&deprecatedMdmExtClbks, 0, sizeof(RvIppMdmExtClbks));
	rvIppMdmRegisterExtClbks(&deprecatedMdmExtClbks);

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfAddH323()=%d", RV_OK));

	return RV_OK;
}
#endif /* RV_MTF_H323 */
/*****************************************************************************
 * rvMtfSipConstruct()
 *****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfSipConstruct(
						 OUT 	RvMtfHandle*			hMtf,
						 IN		RvMtfSipPhoneCfg*		config)
{
	RvMtfBaseMgr*		mtfMgr;
	RvIppSipExtClbks	deprecatedSipExtClbks;
	RvIppMdmExtClbks	deprecatedMdmExtClbks;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfSipConstruct(hMtf=%p, config=%p)", hMtf, config));

    if (RvMemoryAlloc( NULL, sizeof(RvMtfBaseMgr), IppLogMgr(), (void**)hMtf) != RV_OK)
    {
		RvLogError(ippLogSource,(ippLogSource, "rvMtfSipConstruct() - no resources for allocating mtfMgr, hMtf=%p", hMtf));
		return RV_ERROR_OUTOFRESOURCES;
    }

	mtfMgr = (RvMtfBaseMgr*)*hMtf;

	g_mtfMgr = mtfMgr;

	mtfMgr->userData = NULL;

    rvCCBasePhoneConstruct(rvCCBasePhoneGetBasePhone());
	rvIPPhoneConstruct(&mtfMgr->termMgr, config);
	/* Initialize SIP stack*/
	if( rvIppSipStackInitialize(&(mtfMgr->sipStackHandle), config) != rvTrue)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvMtfSipConstruct() - Error initializing SIP stack, hMtf=%p", hMtf));
		return RV_ERROR_UNKNOWN;
	}

	/* Initialize MTF*/

	rvMdmTermMgrSetUserData(&mtfMgr->termMgr, mtfMgr);

	/* Register internal MDM callbacks */
	registerMdmInternalCallbacks(mtfMgr);

	/* Reset deprecated SIP extensibility callbacks, so these callbacks won't be called.
	   (these callbacks were replaced by RvMtfSipControlClbks). */
	memset(&deprecatedSipExtClbks, 0, sizeof(RvIppSipExtClbks));
	rvIppSipRegisterExtClbks(&deprecatedSipExtClbks);

	/* Reset deprecated MDM extensibility callbacks, so these callbacks won't be called.
	   (these callbacks were replaced by RvMtfCallControlClbks). */
	memset(&deprecatedMdmExtClbks, 0, sizeof(RvIppMdmExtClbks));
	rvIppMdmRegisterExtClbks(&deprecatedMdmExtClbks);

	/* Create and initialize RTP class*/
	mtfMgr->rtpClass = rvMdmTermMgrCreateTermClass(&mtfMgr->termMgr);
	rvInitRtpTermClass(mtfMgr->rtpClass);

	rvInitIppClasses(mtfMgr);


    /*Reset structures of all user callbacks (except for sipExtClbks which should already be registered by now). */
	memset(&mdmExtClbks, 0, sizeof(RvMtfCallControlClbks));
	memset(&mtfMgr->mdmClbks, 0, sizeof(RvMtfMdmClbks));
	memset(&mtfMgr->mediaClbks, 0, sizeof(RvMtfMediaClbks));
	memset(&mtfMgr->connMediaClbks, 0, sizeof(RvMtfConnMediaClbks));
	rvCCIPPhoneAddSIP(&mtfMgr->termMgr,config, mtfMgr->sipStackHandle);
	/* Set MTF handle in SIP stack to have access to MTF objects when SIP stack events are called. */
	RvSipStackSetAppHandle(mtfMgr->sipStackHandle, (RvSipAppStackHandle)*hMtf);

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfSipConstruct()=%d", RV_OK));

	/* initialization for using random numbers */
    RvRandomGeneratorConstruct(&mtfMgr->randomGenerator,(RvUint32)RvClockGet(NULL,NULL));


	return RV_OK;
}

/****************************************************************************
 * rvMtfSipDestruct()
 *****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfSipDestruct(RvMtfHandle		hMtf)
{
	RvMtfBaseMgr* mtfMgr;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfSipDestruct(hMtf=%p)", hMtf));

	mtfMgr = (RvMtfBaseMgr*)hMtf;

	IppThreadSleep(1,0);
	rvMdmTermMgrDestruct(&mtfMgr->termMgr);

	RvMemoryFree(mtfMgr, IppLogMgr ());

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfSipDestruct()=%d", RV_OK));

	return RV_OK;
}

/***************************************************************************
 * rvMtfLoadMediaCapabilities()
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfLoadMediaCapabilities(
                  IN RvMtfHandle		hTerm,
                  IN RvSdpMsg*          mediaCaps)
{
	RvSdpMsgList			sdpList;
	RvSdpMsg                *sdpMsg;
	RvMdmParameterList		params;
    RvMtfBaseMgr*           mtfMgr;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfLoadMediaCapabilities(hTerm=%p, mediaCaps=%p)", hTerm, mediaCaps));

    mtfMgr = (RvMtfBaseMgr*)hTerm;

	rvSdpMsgListConstructA(&sdpList, rvAllocGetDefaultAllocator());
	sdpMsg = rvSdpMsgListAddMsg( &sdpList);

	rvSdpMsgCopy( sdpMsg, mediaCaps);

	rvMdmParameterListConstruct(&params);

	rvMdmTermClassClearMediaCapabilities(mtfMgr->rtpClass);

	rvMdmTermClassAddMediaCapabilities( mtfMgr->rtpClass, &sdpList, &sdpList, &params);

	rvMdmTermClassClearMediaCapabilities(mtfMgr->atClass);
	rvMdmTermClassClearMediaCapabilities(mtfMgr->phoneClass);

	/* Report the capabilities to the MTF. */
	rvMdmTermMgrMediaCapabilitiesUpdated(&mtfMgr->termMgr, mtfMgr->rtpClass);

	rvMdmTermClassAddMediaCapabilities(mtfMgr->atClass, &sdpList, &sdpList, &params);
	rvMdmTermClassAddMediaCapabilities(mtfMgr->phoneClass, &sdpList, &sdpList, &params);

	/* Destruct local objects */
	rvMdmParameterListDestruct(&params);

	rvSdpMsgListDestruct(&sdpList);

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfLoadMediaCapabilities()=%d", RV_OK));

	return RV_OK;
}

/***************************************************************************
 * rvMtfRegisterMediaCallbacks()
 ***************************************************************************/
RVAPI void RVCALLCONV rvMtfRegisterMediaCallbacks(
                IN RvMtfHandle		    hMtf,
                IN RvMtfMediaClbks*     mediaClbks)
{
    RvMtfBaseMgr*  mtfMgr = (RvMtfBaseMgr*) hMtf;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfRegisterMediaCallbacks(hMtf=%p, mediaClbks=%p)", hMtf, mediaClbks));

	mtfMgr->mediaClbks.startPhysicalDeviceCB = mediaClbks->startPhysicalDeviceCB;

	mtfMgr->mediaClbks.createMediaStreamCB = mediaClbks->createMediaStreamCB;

	mtfMgr->mediaClbks.modifyMediaStreamCB = mediaClbks->modifyMediaStreamCB;

	mtfMgr->mediaClbks.stopPhysicalDeviceCB = mediaClbks->stopPhysicalDeviceCB;

	mtfMgr->mediaClbks.destroyMediaStreamCB = mediaClbks->destroyMediaStreamCB;

	mtfMgr->mediaClbks.connectMediaCB = mediaClbks->connectMediaCB;

	mtfMgr->mediaClbks.disconnectMediaCB = mediaClbks->disconnectMediaCB;

	mtfMgr->mediaClbks.modifyMediaCompletedCB = mediaClbks->modifyMediaCompletedCB;

#ifdef RV_MTF_N_LINES
	mtfMgr->mediaClbks.connectMultiStreamsCB = mediaClbks->connectMultiStreamsCB;

	mtfMgr->mediaClbks.disconnectMultiStreamsCB = mediaClbks->disconnectMultiStreamsCB;
#endif

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterMediaCallbacks()"));

}
/***************************************************************************
 * rvMtfRegisterConnMediaCallbacks()
 ***************************************************************************/
RVAPI void RVCALLCONV rvMtfRegisterConnMediaCallbacks(
                IN RvMtfHandle		    hMtf,
                IN RvMtfConnMediaClbks*     connMediaClbks)
{
    RvMtfBaseMgr*  mtfMgr = (RvMtfBaseMgr*) hMtf;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfRegisterConnMediaCallbacks(hMtf=%p, connMediaClbks=%p)", hMtf, connMediaClbks));

	mtfMgr->connMediaClbks.connCreateMediaStreamCB = connMediaClbks->connCreateMediaStreamCB;

	mtfMgr->connMediaClbks.connModifyMediaStreamCB = connMediaClbks->connModifyMediaStreamCB;

#ifdef RV_MTF_SECOND_VIDEO
	mtfMgr->connMediaClbks.connModifySpecificMediaStreamCB = connMediaClbks->connModifySpecificMediaStreamCB;
#endif

	mtfMgr->connMediaClbks.connDestroyMediaStreamCB = connMediaClbks->connDestroyMediaStreamCB;

	mtfMgr->connMediaClbks.connConnectMediaCB = connMediaClbks->connConnectMediaCB;

	mtfMgr->connMediaClbks.connDisconnectMediaCB = connMediaClbks->connDisconnectMediaCB;

	mtfMgr->connMediaClbks.connModifyMediaCompletedCB = connMediaClbks->connModifyMediaCompletedCB;

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterConnMediaCallbacks()"));

}
/***************************************************************************
 * rvMtfRegisterMdmCallbacks()
 ***************************************************************************/
RVAPI void RVCALLCONV rvMtfRegisterMdmCallbacks(
                IN RvMtfHandle		    hTerm,
                IN RvMtfMdmClbks*		mdmClbks)
{
    RvMtfBaseMgr*  mtfMgr = (RvMtfBaseMgr*) hTerm;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfRegisterMdmCallbacks(hTerm=%p, mdmClbks=%p)", hTerm, mdmClbks));

    mtfMgr->mdmClbks.startSignalCB = mdmClbks->startSignalCB;

    mtfMgr->mdmClbks.stopSignalCB = mdmClbks->stopSignalCB;

	mtfMgr->mdmClbks.registerAnalogTermCompletedCB = mdmClbks->registerAnalogTermCompletedCB;

	mtfMgr->mdmClbks.registerIPPhoneTermsCompletedCB = mdmClbks->registerIPPhoneTermsCompletedCB;

	mtfMgr->mdmClbks.registerVideoTermsCompletedCB = mdmClbks->registerVideoTermsCompletedCB;

	mtfMgr->mdmClbks.unregisterAnalogTermCompletedCB = mdmClbks->unregisterAnalogTermCompletedCB;

	mtfMgr->mdmClbks.unregisterIPPhoneTermsCompletedCB = mdmClbks->unregisterIPPhoneTermsCompletedCB;

	mtfMgr->mdmClbks.unregisterVideoTermsCompletedCB = mdmClbks->unregisterVideoTermsCompletedCB;

	mtfMgr->mdmClbks.unregisterTermFromServerCompletedCB = mdmClbks->unregisterTermFromServerCompletedCB;

	mtfMgr->mdmClbks.mapDialStringToAddressCB = mdmClbks->mapDialStringToAddressCB;

	mtfMgr->mdmClbks.matchDialStringToPatternCB = mdmClbks->matchDialStringToPatternCB;

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterMdmCallbacks()"));

}

/***************************************************************************
 * rvMtfStart()
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfStart(IN RvMtfHandle		hMtf)
{
	RV_UNUSED_ARG(hMtf);
	/* Actually there is nothing to do at this stage */
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfStart(hMtf=%p)", hMtf));
	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfStart()=%d", RV_OK));

	return RV_OK;
}

/***************************************************************************
 * rvMtfStop()
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfStop(IN RvMtfHandle		hMtf)
{
	RvMtfBaseMgr* mtfMgr;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfStop(hMtf=%p)", hMtf));

	mtfMgr = (RvMtfBaseMgr*)hMtf;
	rvMdmTermMgrStop(&mtfMgr->termMgr, NULL);

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfStop()=%d", RV_OK));

	return RV_OK;
}

/*****************************************************************************
 * rvMtfSetApplicationHandle()
 *****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfSetApplicationHandle(
                IN RvMtfHandle          hMtf,
                IN RvMtfAppHandle       hAppMtf)
{
	RvMtfBaseMgr* mtfMgr;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfSetApplicationHandle(hMtf=%p, hAppMtf=%p)", hMtf, hAppMtf));

	mtfMgr = (RvMtfBaseMgr*)hMtf;
	mtfMgr->userData = hAppMtf;

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfSetApplicationHandle()=%d", RV_OK));

	return RV_OK;

}

/******************************************************************************
 * rvMtfGetApplicationHandle()
 *****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfGetApplicationHandle(
                IN  RvMtfHandle          hMtf,
                OUT RvMtfAppHandle*      hAppMtf)
{
	RvMtfBaseMgr* mtfMgr;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfGetApplicationHandle(hMtf=%p)", hMtf));

	mtfMgr = (RvMtfBaseMgr*)hMtf;
	*hAppMtf = mtfMgr->userData;

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfGetApplicationHandle(hAppMtf=%p)=%d", hAppMtf, RV_OK));

	return RV_OK;

}

#ifdef RV_MTF_SIMPLE_ON

/******************************************************************************
 * rvMtfSetSimpleClientHandle()
 *****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfSetSimpleClientHandle(
                IN RvMtfHandle				hMtf,
                IN RvSimpleCltPuaHandle		hSimplePua)
{
	RvMtfBaseMgr* mtfMgr;
	
	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfSetSimpleClientHandle(hMtf=0x%p,hSimplePua=0x%p)", hMtf, hSimplePua));
	
	mtfMgr = (RvMtfBaseMgr*)hMtf;
	mtfMgr->hSimplePua = hSimplePua;
	
	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfSetSimpleClientHandle()=%d", RV_OK));
	
	return RV_OK;

}

#endif /* RV_MTF_SIMPLE_ON */

/***************************************************************************
 * rvMtfRegisterIPPhoneTerminations()
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfRegisterIPPhoneTerminations (
				IN RvMtfHandle			        hMtf,
				IN RvChar*				        termId,
				IN RvMtfTerminalAppHandle		hAppTerm,
                OUT RvIppTerminalHandle*	    hTerm)
{
	RvMtfBaseMgr* mtfMgr =      (RvMtfBaseMgr*)hMtf;
    RvMdmTermMgr*	            termMgr;
    RvMdmTerm*		            term;
    RvMdmTermDefaultProperties	termProperties;
	RvStatus					rv = RV_OK;
	RvCCProvider* p;
	RvCCProviderMdm* pm;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfRegisterIPPhoneTerminations(hMtf=%p, termId=%s, hAppTerm=%p)",
			hMtf, termId, hAppTerm));

	termMgr = rvMtfBaseGetTermMgr(hMtf);
	/* configure IP Phone to accept calls for other users */
	p = (RvCCProvider*)termMgr->xTermMgr;
	pm = (RvCCProviderMdm*)p->provider;
	pm->acceptCallWhenUserNotFound = rvTrue;

    rvMdmTermDefaultPropertiesConstruct(&termProperties);

	/* Register UI termination */
	term = rvMdmTermMgrRegisterPhysicalTerminationAsync(
                                        termMgr, mtfMgr->uiClass, termId, &termProperties, (void*)hAppTerm);

	if (term == NULL)
    {
		RvLogError(ippLogSource,(ippLogSource, "rvMtfRegisterIPPhoneTermination() - failed to register UI termination, hMtf=%p, username=%s",
			hMtf, termId));
		rv = RV_ERROR_UNKNOWN;
    }

	else
	{

		/* Register Handset termination */
		mtfMgr->handsetTermination = rvMdmTermMgrRegisterPhysicalTerminationAsync(
			termMgr, mtfMgr->atClass, "at/hs", &termProperties, (void*)hAppTerm);
		if (mtfMgr->handsetTermination == NULL)
		{
			RvLogError(ippLogSource,(ippLogSource, "rvMtfRegisterIPPhoneTermination() - failed to register Handset termination, hMtf=%p",
				hMtf));
			rv = RV_ERROR_UNKNOWN;
		}

		*hTerm = rvIppMdmTerminalGetHandle(term);

	}
	rvMdmTermDefaultPropertiesDestruct(&termProperties);


	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterIPPhoneTerminations(*hTerm=%p)=%d", *hTerm, rv));

    return rv;

}

/***************************************************************************
 * rvMtfUnregisterIPPhoneTerminations()
 ***************************************************************************/
RVAPI RvStatus	RVCALLCONV rvMtfUnregisterIPPhoneTerminations (
                IN RvMtfHandle			    hMtf,
                IN RvIppTerminalHandle		hTerm)
{
	RvMtfBaseMgr*   mtfMgr = (RvMtfBaseMgr*)hMtf;
	RvMdmTermMgr*	termMgr;
	RvChar			termId[RV_NAME_STR_SZ];
	RvBool			res;
	RvStatus		rv = RV_OK;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfUnregisterIPPhoneTerminations(hMtf=%p, hTerm=%p)",
		hMtf, hTerm));

	termMgr = rvMtfBaseGetTermMgr(hMtf);

	/* Un-register handset termination */
	res = rvMdmTermMgrUnregisterTerminationAsync(termMgr,
									mtfMgr->handsetTermination, NULL);

	if (res == RV_FALSE)
    {
		RvLogError(ippLogSource,(ippLogSource, "rvMtfUnregisterIPPhoneTermination() - failed to unregister Handset termination, term=%p",
			hTerm));
		rv = RV_ERROR_UNKNOWN;
    }

	/* Un-register UI termination */
	res = rvMdmTermMgrUnregisterTerminationAsync(termMgr,
		rvIppMdmTerminalGetMdmTerm(hTerm), NULL);

	rvIppMdmTerminalGetId(hTerm, termId, RV_NAME_STR_SZ);

	if (res == RV_FALSE)
    {
		RvLogError(ippLogSource,(ippLogSource, "rvMtfUnregisterIPPhoneTermination() - failed to unregister UI termination, term=%p, termId=%s",
			hTerm, termId));
		rv = RV_ERROR_UNKNOWN;
    }

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfUnregisterIPPhoneTermination()=%d", rv));

	return rv;
}

/***************************************************************************
 * rvMtfRegisterVideoTerminations()
 ***************************************************************************/
#ifdef RV_MTF_VIDEO
RVAPI RvStatus	RVCALLCONV rvMtfRegisterVideoTerminations (
                IN RvMtfHandle			        hMtf,
                IN RvMtfTerminalAppHandle		hAppTerm)
{
	RvMtfBaseMgr* mtfMgr =      (RvMtfBaseMgr*)hMtf;
    RvMdmTermMgr*	            termMgr;
    RvMdmTermDefaultProperties	termProperties;
	RvStatus					rv = RV_OK;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfRegisterVideoTerminations(hMtf=%p, hAppTerm=%p)",
		hMtf, hAppTerm));

	termMgr = rvMtfBaseGetTermMgr(hMtf);

    rvMdmTermDefaultPropertiesConstruct(&termProperties);

	/* Register camera termination */
	mtfMgr->cameraTermination = rvMdmTermMgrRegisterPhysicalTerminationAsync(
										termMgr, mtfMgr->atClass, "vt/cam", &termProperties, (void*)hAppTerm);

	if (mtfMgr->cameraTermination == NULL)
    {
		RvLogError(ippLogSource,(ippLogSource, "rvMtfRegisterVideoTerminations() - failed to register camera termination, hMtf=%p",
			hMtf));
		rv = RV_ERROR_UNKNOWN;
    }

	/* Register screen termination */
	mtfMgr->screenTermination = rvMdmTermMgrRegisterPhysicalTerminationAsync(
										termMgr, mtfMgr->atClass, "vt/scr", &termProperties, (void*)hAppTerm);

	if (mtfMgr->screenTermination == NULL)
    {
		RvLogError(ippLogSource,(ippLogSource, "rvMtfRegisterVideoTerminations() - failed to register screen termination, hMtf=%p",
			hMtf));
		rv = RV_ERROR_UNKNOWN;
    }

	rvMdmTermDefaultPropertiesDestruct(&termProperties);

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterVideoTerminations()=%d", rv));

    return RV_OK;

}

/***************************************************************************
 * rvMtfUnregisterVideoTerminations()
 ***************************************************************************/
RVAPI RvStatus	RVCALLCONV rvMtfUnregisterVideoTerminations (
                IN RvMtfHandle			    hMtf)
{
	RvMtfBaseMgr*   mtfMgr = (RvMtfBaseMgr*)hMtf;
	RvMdmTermMgr*	termMgr;
	RvBool			res;
	RvStatus		rv = RV_OK;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfUnregisterVideoTerminations(hMtf=%p)", hMtf));

	termMgr = rvMtfBaseGetTermMgr(hMtf);

	res = rvMdmTermMgrUnregisterTerminationAsync(termMgr,
									mtfMgr->cameraTermination, NULL);

	if (res == RV_FALSE)
    {
		RvLogError(ippLogSource,(ippLogSource, "rvMdmTermMgrUnregisterTerminationAsync() - failed to unregister camera termination, term=%p",
			mtfMgr->cameraTermination));
		rv = RV_ERROR_UNKNOWN;
    }

	res = rvMdmTermMgrUnregisterTerminationAsync(termMgr,
									mtfMgr->screenTermination, NULL);

	if (res == RV_FALSE)
    {
		RvLogError(ippLogSource,(ippLogSource, "rvMdmTermMgrUnregisterTerminationAsync() - failed to unregister screen termination, term=%p",
			mtfMgr->screenTermination));
		rv = RV_ERROR_UNKNOWN;
    }

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfUnregisterVideoTerminations()=%d", rv));

	return rv;
}

#endif /* RV_MTF_VIDEO */

/***************************************************************************
 * rvMtfRegisterAnalogTermination()
 ***************************************************************************/
RVAPI RvStatus	RVCALLCONV rvMtfRegisterAnalogTermination (
                IN RvMtfHandle			        hMtf,
                IN RvChar*				        termId,
                IN RvMtfTerminationConfig*		termConfig,
                IN RvMtfTerminalAppHandle		hAppTerm,
                OUT RvIppTerminalHandle*	    hTerm)
{
	RvMtfBaseMgr* mtfMgr =      (RvMtfBaseMgr*)hMtf;
    RvMdmTermMgr*	            termMgr;
    RvMdmTerm*		            term;
    RvMdmTermDefaultProperties	termProperties;
	RvStatus					rv = RV_OK;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfRegisterIPPhoneTerminations(hMtf=%p, termId=%s, termConfig=%p, hAppTerm=%p)",
			hMtf, termId, termConfig, hAppTerm));

	termMgr = rvMtfBaseGetTermMgr(hMtf);

    rvMdmTermDefaultPropertiesConstruct(&termProperties);

    setTermProperties(&termProperties, termConfig);

	term = rvMdmTermMgrRegisterPhysicalTerminationAsync(
                                        termMgr, mtfMgr->phoneClass, termId, &termProperties, (void*)hAppTerm);

	if (term == NULL)
    {
		RvLogError(ippLogSource,(ippLogSource, "rvMtfRegisterAnalogTermination() - failed to register analog termination, hMtf=%p, username=%s",
			hMtf, termId));
		rv = RV_ERROR_UNKNOWN;
    }
	else
	{
		rvMdmTermDefaultPropertiesDestruct(&termProperties);

		*hTerm = rvIppMdmTerminalGetHandle(term);
	}

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterAnalogTermination(*hTerm=%p)=%d", hTerm, rv));

    return rv;

}

/***************************************************************************
 * rvMtfUnregisterAnalogTermination()
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfUnregisterAnalogTermination (
                IN RvMtfHandle					hMtf,
				IN RvIppTerminalHandle		    hTerm)
{
	RvMdmTermMgr*	termMgr;
	RvChar			termId[RV_NAME_STR_SZ];
	RvBool			res;
	RvStatus		rv = RV_OK;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfUnregisterAnalogTermination(hMtf=%p, hTerm=%p)",
			hMtf, hTerm));

	termMgr = rvMtfBaseGetTermMgr(hMtf);

	res = rvMdmTermMgrUnregisterTerminationAsync(termMgr,
									rvIppMdmTerminalGetMdmTerm(hTerm), NULL);

	rvIppMdmTerminalGetId(hTerm, termId, RV_NAME_STR_SZ);

	if (res == RV_FALSE)
    {
		RvLogError(ippLogSource,(ippLogSource, "rvMtfUnregisterAnalogTermination() - failed to unregister analog termination, term=%p, termId=%s",
			hTerm, termId));
		rv = RV_ERROR_UNKNOWN;
    }

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterAnalogTermination()=%d", rv));

	return rv;
}

/***************************************************************************
 * rvMtfRegisterTerminationToSipServer()
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfRegisterTerminationToSipServer (
					IN RvMtfHandle			    hMtf,
					IN RvIppTerminalHandle		hTerm)
{
	RvMdmTermMgr*	termMgr;
	RvBool			res;
	RvStatus		rv = RV_OK;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfRegisterTerminationToSipServer(hMtf=%p, hTerm=%p)",
			hMtf, hTerm));

	termMgr = rvMtfBaseGetTermMgr(hMtf);

	res = rvMdmTermMgrRegisterTermToNetwork_(termMgr, rvIppMdmTerminalGetMdmTerm(hTerm));

	if (res == RV_FALSE)
	{
		rv = RV_ERROR_UNKNOWN;
	}

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterTerminationToSipServer()=%d", rv));

	return rv;
}

/***************************************************************************
 * rvMtfRegisterAllTerminationsToSipServer()
 ***************************************************************************/
RVAPI RvStatus	RVCALLCONV rvMtfRegisterAllTerminationsToSipServer (IN RvMtfHandle	hMtf)
{
	RvMdmTermMgr*	termMgr;
	RvBool			res;
	RvStatus		rv = RV_OK;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfRegisterAllTerminationsToSipServer(hMtf=%p)", hMtf));

	termMgr = rvMtfBaseGetTermMgr(hMtf);

	res = rvMdmTermMgrRegisterAllTermsToNetwork_(termMgr);

	if (res == RV_FALSE)
    {
		rv = RV_ERROR_UNKNOWN;
    }

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfRegisterAllTerminationsToSipServer()=%d", rv));

	return rv;
}

/***************************************************************************
 * rvMtfUnregisterTerminationFromSipServer()
 ***************************************************************************/
RVAPI RvStatus	RVCALLCONV rvMtfUnregisterTerminationFromSipServer(
				IN RvMtfHandle			    hMtf,
				IN RvIppTerminalHandle		hTerm)
{
	RvMdmTermMgr*	termMgr;
	RvBool			res;
	RvStatus		rv = RV_OK;

	RvLogEnter(ippLogSource,(ippLogSource, "rvMtfUnregisterTerminationFromSipServer(hMtf=%p, hTerm=%p)", hMtf, hTerm));

	termMgr = rvMtfBaseGetTermMgr(hMtf);

	res = rvMdmTermMgrUnregisterTermFromNetwork_(termMgr, rvIppMdmTerminalGetMdmTerm(hTerm));

	if (res == RV_FALSE)
    {
		rv = RV_ERROR_UNKNOWN;
    }

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfUnregisterTerminationFromSipServer()=%d", rv));

	return rv;
}

/***************************************************************************
 * rvMtfSendKeyEvent()
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfSendKeyEvent(
                            IN RvIppTerminalHandle		hTerm,
                            IN RvMtfEvent				event,
                            IN RvMtfEventInfo*			info)

{
    RvMdmParameterList  paramsList;
    char                strParam[256];
	RvMdmTerm*			mdmTerm;
	RvStatus            rv;

	RvLogEnter(ippLogSource,(ippLogSource,"rvMtfSendKeyEvent(hTerm=%p, event=%s, info=%p)",
							hTerm, rvCCTextEvent(event), info));

	mdmTerm = rvIppMdmTerminalGetMdmTerm(hTerm);

    rvMdmParameterListConstruct(&paramsList);

    switch (event)
    {
        case RV_CCTERMEVENT_ONHOOK:
            addParam(&paramsList, "keyid", "kh");
			rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
        break;

        case RV_CCTERMEVENT_OFFHOOK:
            addParam(&paramsList, "keyid", "kh");
			rvMdmTermProcessEvent(mdmTerm, "kf", "kd", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_HOLD:
            addParam(&paramsList, "keyid", "kl");
			rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_CONFERENCE:
            addParam(&paramsList, "keyid", "kc");
			rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_TRANSFER:
            addParam(&paramsList, "keyid", "kt");
			rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_BLIND_TRANSFER:
            addParam(&paramsList, "keyid", "kbt");
			rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_MUTE:
            addParam(&paramsList, "keyid", "mu");
			rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_HANDSFREE:
            addParam(&paramsList, "keyid", "hf");
			rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_HEADSET:
            addParam(&paramsList, "keyid", "ht");
			rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_REDIAL:
            addParam(&paramsList, "keyid", "redial");
			rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_CFW:
			if (info->cfwActivate == RV_TRUE)
			{
				addParam(&paramsList, "activate", "on");
			}
			else
			{
				addParam(&paramsList, "activate", "off");
			}

			switch (info->cfwType)
			{
				case RV_IPP_CFW_TYPE_BUSY:
					addParam(&paramsList, "keyid", "cfwb");
					rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
				break;
				case RV_IPP_CFW_TYPE_UNCONDITIONAL:
					addParam(&paramsList, "keyid", "cfwu");
					rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
				break;
				case RV_IPP_CFW_TYPE_NO_REPLY:
					addParam(&paramsList, "keyid", "cfnr");
					RvSprintf(strParam, "%d", info->cfwNoReplyTimeout);
					addParam(&paramsList, "timeout", strParam);
					rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
				break;
				default:
				break;
			}
            break;

        case RV_CCTERMEVENT_LINE:
#ifdef RV_MTF_N_LINES
			/* l001 - l009 */
			if (info->lineId <= 9)
			{
				RvSprintf(strParam, "l00%d", info->lineId);
			}
			/* l010 - l099 */
			if ((info->lineId > 9) && (info->lineId < 100))
			{
				RvSprintf(strParam, "l0%d", info->lineId);
			}
			/* l100 - l999 */
			if ((info->lineId > 99) && (info->lineId < 999))
			{
				RvSprintf(strParam, "l%d", info->lineId);
			}
#else
			RvSprintf(strParam, "l00%d", info->lineId);
#endif /* RV_MTF_N_LINES */
            addParam(&paramsList, "keyid", strParam);
			rvMdmTermProcessEvent(mdmTerm, "kf", "ku", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_DIALCOMPLETED:
			rvMdmTermProcessEvent(mdmTerm, "kp", "ce", NULL, NULL);
            break;

        case RV_CCTERMEVENT_DIGITS:
            if ((rv = mapDigitToEvent(info->digit, strParam)) != RV_OK)
            {
                return rv;
            }

            addParam(&paramsList, "keyid", strParam);
			rvMdmTermProcessEvent(mdmTerm, "kp", "kd", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_DIGIT_END:
            if ((rv = mapDigitToEvent(info->digit, strParam)) != RV_OK)
            {
                return rv;
            }

            addParam(&paramsList, "keyid", strParam);
			rvMdmTermProcessEvent(mdmTerm, "kp", "ku", NULL, &paramsList);
            break;

        case RV_CCTERMEVENT_GW_ACTIVE:
			rvMdmTermProcessEvent(mdmTerm, "rvcc", "ga", NULL, NULL);
            break;

	    case RV_CCTERMEVENT_REJECT_KEY:
            RvSprintf(strParam, "l00%d", info->lineId);
            addParam(&paramsList, "keyid", strParam);
			rvMdmTermProcessEvent(mdmTerm, "rvcc", "reject", NULL, &paramsList);
            break;
         case RV_CCTERMEVENT_USER_CONFERENCE:
            RvSprintf(strParam, "%d", event);
            addParam(&paramsList, "keyid", strParam);
			rvMdmTermProcessEvent(mdmTerm, "user", "user", NULL, &paramsList);

            break;
		default:
			RvLogDebug(ippLogSource,(ippLogSource,"rvMtfSendKeyEvent() - unknown event (%d) was sent for Term=%s",
				event, rvCCTerminalMdmGetTermId((RvCCTerminal*)hTerm)));
    }

    rvMdmParameterListDestruct(&paramsList);

    RvLogInfo(ippLogSource,(ippLogSource,"rvMtfSendKeyEvent() - %s event was sent for Term=%s", rvCCTextEvent(event),
        rvCCTerminalMdmGetTermId((RvCCTerminal*)hTerm)));

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfSendKeyEvent()=%d", RV_OK));

    return RV_OK;
}


/***************************************************************************
 * rvMtfSendUserEvent()
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfSendUserEvent(
                          IN RvIppTerminalHandle	hTerm,
						  IN RvUint    				userEvent)
{
	RvMdmParameterList paramsList;
	char eventStr[24];
	RvMdmTerm* mdmTerm;

	RvLogEnter(ippLogSource,(ippLogSource,"rvMtfSendUserEvent(hTerm=%p, userEvent=%d)",
							hTerm, userEvent));

	mdmTerm = rvIppMdmTerminalGetMdmTerm(hTerm);

	rvMdmParameterListConstruct(&paramsList);

	RvSprintf(eventStr, "%d", userEvent);

	addParam(&paramsList, "keyid", eventStr);

	rvMdmTermProcessEvent(mdmTerm, "user", "user", NULL, &paramsList);

	rvMdmParameterListDestruct(&paramsList);

	RvLogInfo(ippLogSource,(ippLogSource,"User event (%d) was sent for TermId=%s",
							userEvent, rvCCTerminalMdmGetTermId((RvCCTerminal*)hTerm)));

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfSendUserEvent()=%d", RV_OK));

	return RV_OK;
}


/******************************************************************************
 * rvMtfSendDialCompletedEvent
 *****************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfSendDialCompletedEvent(
                                  IN RvIppTerminalHandle		term,
								  IN RvChar*					dialString,
                                  IN RvMdmDigitMapMatchType		matchType)
{

	RvMdmParameterList	params;
	RvMdmTerm*			mdmTerm;

	/* Build parameters list. The list is empty and is not used. */
	rvMdmParameterListConstruct(&params);

	/* Build the dial completed event. */
	rvMdmKpDigitMapBuildEvComplete(&params, dialString, matchType, prvDefaultAlloc);

	/*Send a dial completed event to MTF*/
	mdmTerm = rvIppMdmTerminalGetMdmTerm(term);
	rvMdmTermProcessEvent(mdmTerm, "kp", "ce", NULL, &params);

	/*Destruct parameters list. */
	rvMdmParameterListDestruct(&params);

	return RV_OK;

}

/***************************************************************************
 * rvMtfMediaStartModify()
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV rvMtfMediaStartModify(
				IN RvIppTerminalHandle			hTerm,
				IN RvSdpMsg*					sdpMsg,
				IN RvMtfModifyMessage			modifyMessage)
{
	RvCCTerminal*       t;
	RvCCTerminalMdm*    term;
	RvMdmTerm*          mdmTerm;
	RvCCConnection*     c;
    RvBool              res = RV_FALSE;
	RvChar				termId[RV_NAME_STR_SZ];
	RvStatus			rv = RV_OK;

	RvLogEnter(ippLogSource,(ippLogSource,"rvMtfModifyMediaDuringCall(hTerm=%p, sdp=%p, message=%d)",
							hTerm, sdpMsg, modifyMessage));

	t = (RvCCTerminal*)hTerm;

	c = rvCCTerminalGetActiveConnection(t);

	if (rvMtfConnectionGetProtocolId((RvIppConnectionHandle)c) != RV_MTF_PROTOCOL_SIP)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvMtfModifyMediaDuringCall() - Can't modify media in non SIP call, hTerm=%p, conn=%p",
                   hTerm, c));
		return RV_ERROR_NOTSUPPORTED;
	}

	term = rvCCTerminalMdmGetImpl(t);
	mdmTerm = rvCCTerminalMdmGetMdmTerm(term);

	rvMtfTerminationGetId(hTerm, termId, sizeof(termId));

	if (modifyMessage == RV_MTF_MODIFYMEDIA_BY_REINVITE)
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvMtfModifyMediaDuringCall() - modifying media by sending Re-Invite, hTerm=%p, termId=%s",
							hTerm, termId));
		res = rvMdmTermModifyMedia( mdmTerm, sdpMsg);
	}
	else
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvMtfModifyMediaDuringCall() - modifying media by sending Update, hTerm=%p, termId=%s",
							hTerm, termId));
		res = rvMdmTermModifyMediaByUpdate(mdmTerm, sdpMsg);
	}

    if (res == RV_FALSE)
    {
		RvLogError(ippLogSource,(ippLogSource,"rvMtfModifyMediaDuringCall() - failed modifying media, hTerm=%p, termId=%s",
							hTerm, termId));
        rv = RV_ERROR_UNKNOWN;
    }

	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfModifyMediaDuringCall()=%d", rv));

	return rv;
}

RVAPI void RVCALLCONV rvMtfTerminationInitConfig(RvMtfTerminationConfig* termConfig)
{
	RvLogEnter(ippLogSource,(ippLogSource,"rvMtfTerminationInitConfig(termConfig=%p)", termConfig));

	memset(termConfig, 0, sizeof(RvMtfTerminationConfig));

	/* Set default values */
	termConfig->registrarPort = RVSIPCTRL_DEFAULT_PORT;
	termConfig->outboundProxyPort = RVSIPCTRL_DEFAULT_PORT;
	termConfig->transportType = RVSIP_TRANSPORT_UNDEFINED;
#ifdef RV_MTF_N_LINES
	termConfig->numberOfLines = 2;
#endif /* RV_MTF_N_LINES */
#ifdef RV_CFLAG_TLS
	termConfig->registrarTlsPort = RVSIPCTRL_DEFAULT_PORT + 1;
#endif

#ifdef RV_SIP_IMS_ON
	strcpy(termConfig->PAccessNetworkInfo, "");
	termConfig->ipsecPortC = RVSIPCTRL_DEFAULT_PORT + 3;
	termConfig->ipsecPortS = RVSIPCTRL_DEFAULT_PORT + 5;
#endif



	RvLogLeave(ippLogSource,(ippLogSource, "rvMtfTerminationInitConfig()"));
}

/*@****************************************************************************
 * rvMtfMediaGetCurrentMedia (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *       Gets the sdp of the current MTF media i.e. the media which is in effect
 *       right now
 *
 * Arguments:
 *
 * Input:	hTerm			- Handle to the terminal.
 *
 *
 * Return Value: sdpMsg		- Pointer to the SDP message with current media
 **************************************************************************@*/
RVAPI RvSdpMsg* RVCALLCONV rvMtfMediaGetCurrentMedia(
													 IN RvIppTerminalHandle			hTerm)
{
	RvCCTerminal*       t;
	RvCCConnection*     c;
	RvSdpMsg*           sdp = NULL;

	RvLogEnter(ippLogSource,(ippLogSource,"rvMtfMediaGetCurrentMedia(hTerm=%p)", hTerm));

	t = (RvCCTerminal*)hTerm;
	c = rvCCTerminalGetActiveConnection(t);
	sdp = rvCCConnMdmGetMedia(c);

	return sdp;
}


