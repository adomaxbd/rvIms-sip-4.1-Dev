/******************************************************************************
Filename:    rvMtfMediaApi.h
Description: This file includes type definitions and APIs for processing media
			 callbacks and manipulating media in application.
*******************************************************************************
                Copyright (c) 2008 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#ifndef RV_RVMGRMGRMEDIA_H
#define RV_RVMGRMGRMEDIA_H

#include "rvMtfHandles.h"
#include "rvCallControlApi.h"

/*@*****************************************************************************
 * Package: RvMtfMediaPkg (root)
 * -----------------------------------------------------------------------------
 * Title: Media Integration
 *
 * General: This section contains functions and type definitions that are used
 *  		for integrating the media engine of the application with the MTF.
 ****************************************************************************@*/


/*@*****************************************************************************
* Enum: RvMtfMediaStreamDirection (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* Description: This enumerator indicates the direction (send/receive)
* of the stream. Relevant for the RvMtfMediaConnModifySpecificStreamEv callback.
****************************************************************************@*/
typedef enum
{
	RVMTF_MEDIA_STREAM_SEND,
	/* Indicates the send direction of the media stream. The open/close
	action should be performed on the transmitter of the stream.    */
	RVMTF_MEDIA_STREAM_RECEIVE,
	/* Indicates the receive direction of the media stream. The open/close
	action should be performed on the receiver of the stream.        */
	RVMTF_MEDIA_STREAM_UNKNOWN
	/* Indicates that the direction is unknown. */
}RvMtfMediaStreamDirection;

/*@*****************************************************************************
* Enum: RvMtfMediaAction (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* Description: This enumerator indicates what type of action should be
* performed on a media stream that the application has created or modified.
*****************************************************************************@*/
typedef enum
{
    RVMTF_MEDIA_NEW,
		/* Indicates a newly-created media stream. Relevant for the callback
		   RvMtfMediaCreateStreamEv() only. */
    RVMTF_MEDIA_MODIFY_SESSION,
		/* Indicates that the parameters of an existing media stream should be
		   changed (codec, codec attribute, media type. etc.). Relevant for the
		   callback RvMtfMediaModifyStreamEv() only. */
    RVMTF_MEDIA_MUTE,
        /* Indicates that the media stream should be muted. Relevant for the
		   callback RvMtfMediaModifyStreamEv() only. */
    RVMTF_MEDIA_UNMUTE,
		/* Indicates that the media stream should be unmuted. Relevant for the
		   callback RvMtfMediaModifyStreamEv() only. */
    RVMTF_MEDIA_HOLD_LOCAL,
        /* Indicates that the media stream should be put on Hold by the local
		   party. Relevant for the callback RvMtfMediaModifyStreamEv() only. */
    RVMTF_MEDIA_HOLD_REMOTE,
        /* Indicates that the media stream should be put on Hold by the remote
		   party. Relevant for the callback RvMtfMediaModifyStreamEv() only. */
	RVMTF_MEDIA_HOLD_LOCAL_AND_REMOTE,
		/* Indicates that the media stream should be put on Hold by both the
		   local and the remote party. Relevant for the callback
		   RvMtfMediaModifyStreamEv() only.*/
    RVMTF_MEDIA_UNHOLD_LOCAL,
		/* Indicates that the media stream should be unheld by the local party.
		   Relevant for the callback RvMtfMediaModifyStreamEv() only.*/
    RVMTF_MEDIA_UNHOLD_REMOTE,
		/* Indicates that the media stream should be unheld by the remote party.
		   Relevant for the callback RvMtfMediaModifyStreamEv() only.*/
	RVMTF_MEDIA_UNHOLD_INACTIVE_TO_REMOTE,
	    /* Indicates that the media stream should be unheld by the local party,
		   but it is still held by the remote party.
		   Relevant for the callback RvMtfMediaModifyStreamEv() only.*/
	RVMTF_MEDIA_UNHOLD_INACTIVE_TO_LOCAL,
	    /* Indicates that the media stream was unheld by the remote party,
		   but it is still held by the local party.
		   Relevant for the callback RvMtfMediaModifyStreamEv() only.*/
	RVMTF_MEDIA_STREAM_OPEN,
		/* Indicates that the media stream should be opened.
		   Relevant for the callback RvMtfMediaConnModifySpecificStreamEv() only.*/
	RVMTF_MEDIA_STREAM_CLOSE,
		/* Indicates that the media stream should be closed.
		   Relevant for the callback RvMtfMediaConnModifySpecificStreamEv() only.*/
    RVMTF_MEDIA_UNKNOWN
		/* Indicates that the action is unknown. */
}RvMtfMediaAction;

/*@*****************************************************************************
* Type: RvMtfMediaParams (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* Description: This structure contains information about the media stream on
* which the application is required to perform an action. This structure is
* used when the media callbacks RvMtfMediaCreateStreamEv() and
* RvMtfMediaModifyStreamEv() are called.
*****************************************************************************@*/
typedef struct
{
    RvMtfMediaAction		action;
		/* Indicates the action that the application should perform on the media
	       stream. When the callback RvMtfMediaCreateStreamEv() is called, this
	       parameter will always be set to RVMTF_MEDIA_NEW. */
    RvSdpMsg*				localSdp;
		/* Pointer to the SDP message that contains the media parameters of the
	       local party. */
    RvSdpMsg*				remoteSdp;
		/* Pointer to the SDP message that contains the media parameters of the
		   remote party, as received in the incoming SIP message. */
	RvSdpMsg*				localCapsSdp;
		/* Pointer to the SDP message that contains the media capabilities of
		   the local party, which were loaded to the MTF during initialization
	       by calling rvMtfLoadMediaCapabilities(). */

} RvMtfMediaParams;

/*@*****************************************************************************
* Enum: RvMtfMediaType (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* Description: This enumerator indicates the type of the media stream.
*****************************************************************************@*/
typedef enum {
	RVMTF_MEDIATYPE_AUDIO,                /*  Audio. */
	RVMTF_MEDIATYPE_MAIN_VIDEO,           /*  Main video. */
	RVMTF_MEDIATYPE_PRESENTATION_VIDEO,   /*  Presentation video. */
	RVMTF_MEDIATYPE_UNKNOWN
} RvMtfMediaType;

/*@*****************************************************************************
* Type: RvMtfMediaStreamParams (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* Description: This structure contains information about the media stream on
* which the application is required to perform an action. This structure is
* used when the media callback RvMtfMediaConnModifySpecificStreamEv() is called.
*****************************************************************************@*/
typedef struct
{
	RvMtfMediaAction			action;
	/* Indicates the action that the application should perform on the media
	stream. */
	RvSdpMediaDescr*			streamDescriptor;
	/* Pointer to the media stream descriptor that contains the media parameters. */
	RvMtfMediaStreamDirection   streamDirection;
	/* Indicates the direction of the stream. */
	RvMtfMediaType              type;
	/* Indicates the type of the media stream. */
	RvSdpMsg*					sdp;
	/* Pointer to the full SDP message of which the streamDescriptor is a part. */
} RvMtfMediaStreamParams;

/*@*****************************************************************************
* Enum: RvMtfDynamicModifyMediaStatus (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* Description: This enumerator indicates the result of a modifying media process
* during a call.
*****************************************************************************@*/
typedef enum
{
    RV_MTF_MODIFYMEDIA_STATUS_UNKNOWN,
		/* Modify media failed, reason unknown. */
	RV_MTF_MODIFYMEDIA_STATUS_SUCCESS,
		/* Modify media succeeded. */
	RV_MTF_MODIFYMEDIA_STATUS_IN_PROCESS,
		/* Modify media failed because a previous modify media process was not
		   yet completed. */
	RV_MTF_MODIFYMEDIA_STATUS_REMOTE_REJECTED,
		/* Modify media failed because the remote party rejected the request
		   (in case of an outgoing request). */
	RV_MTF_MODIFYMEDIA_STATUS_LOCAL_FAILED
		/* Modify media failed due to a local failure. */
} RvMtfDynamicModifyMediaStatus;

/*===========================================*
 *       MEDIA BY TERMINAL CALLBACKS         *
 *===========================================*/

/*@*****************************************************************************
 * RvMtfMediaStartPhysicalDeviceEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when the application is required to
 *         initialize an audio device (handset, speaker or headset). This callback
 *         is called once, on the first call only.
 *
 * Arguments:
 * Input:	hTerm		- Handle to the terminal.
 *			hAppTerm	- Handle to the application data associated with the
 *                        terminal.
 *			termType	- Type of the terminal, indicating the type of
 *						  application to be initialized: audio or video.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaStartPhysicalDeviceEv)(
                    IN RvIppTerminalHandle				hTerm,
					IN RvMtfTerminalAppHandle			hAppTerm,
					IN RvMtfTerminalType				termType);

/*@*****************************************************************************
 * RvMtfMediaStopPhysicalDeviceEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when the application is required to stop an
 *         audio device (handset, speaker or headset). Currently, this callback
 *         is not called at all. The application should stop all audio
 *         devices after the MTF is shut down.
 *
 * Arguments:
 * Input:	hTerm		- Handle to the terminal.
 *			hAppTerm	- Handle to the application data associated with the
 *                        terminal.
 *			termType	- Type of the terminal, indicating the type of
 *                        application to be stopped: audio or video.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaStopPhysicalDeviceEv)(
                    IN RvIppTerminalHandle				hTerm,
					IN RvMtfTerminalAppHandle			hAppTerm,
					IN RvMtfTerminalType				termType);

/*@*****************************************************************************
 * RvMtfMediaCreateStreamEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when the application is required to create a
 *         new media stream (RTP session) with the specific parameters provided
 *         in this callback (codec, etc.). The application should return the IP
 *         address and port number of the actual new media stream (set in
 *         params->localSdp). This callback is usually called when a new call
 *         is established.
 *
 * Arguments:
 * Input:	hTerm		- Handle to the terminal.
 *			hAppTerm	- Handle to the application data associated with the
 *                        terminal.
 *			params		- Media parameters with which the new media stream
 *                        should be created.
 * Output: params		- Media parameters with which the new media stream was
 *                        created. The localSdp should include the IP address
 *                        and port number of the new media stream. All other
 *						  fields should remain the same.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaCreateStreamEv)(
                    IN		RvIppTerminalHandle				hTerm,
					IN		RvMtfTerminalAppHandle			hAppTerm,
                    INOUT	RvMtfMediaParams*				params);

/*@*****************************************************************************
 * RvMtfMediaModifyStreamEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when the application is required to modify
 *         an existing media stream (RTP session) with the specific parameters
 *         provided in this callback (codec, etc.). The application should return
 *         the IP address and port number of the actual media stream (set in
 *         params->localSdp). This callback is usually called during a
 *         connected call.
 *
 * Arguments:
 * Input:	hTerm		- Handle to the terminal.
 *			hAppTerm	- Handle to the application data associated with the
 *                        terminal.
 *			params		- Media parameters with which the media stream should
 *                        be modified.
 * Output: params		- Media parameters with which the media stream was
 *                        modified. The localSdp should include the IP address
 *                        and port number of the media stream. All other fields
 *                        should remain the same.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaModifyStreamEv)(
                    IN		RvIppTerminalHandle				hTerm,
					IN		RvMtfTerminalAppHandle			hAppTerm,
                    INOUT	RvMtfMediaParams*				params);

/*@*****************************************************************************
 * RvMtfMediaDestroyStreamEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when the application is required to
 *         terminate an existing media stream (RTP session). This callback is
 *         usually called when the call disconnects.
 *
 * Arguments:
 * Input:	hTerm		- Handle to the terminal.
 *			hAppTerm	- Handle to the application data associated with the
 *                        terminal.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaDestroyStreamEv)(
                    IN RvIppTerminalHandle				hTerm,
					IN RvMtfTerminalAppHandle			hAppTerm);

/*@*****************************************************************************
 * RvMtfMediaConnectStreamsEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *			This callback is called when the application is required to connect
 *			one of the following:
 *				1.	An existing media stream (RTP session) with an audio/video
 *					device, to enable media to flow from both parties of the
 *                  call, or
 *				2.	An existing media stream with another existing media stream,
 *					to create mixing of media and enable the establishment of a
 *                  Conference call.
 *			This callback is usually called when a call is being connected
 *			(a remote party or a local user answered the call), or during a
 *          Conference call.
 *
 * Arguments:
 * Input:	hTermSource		- Handle to the source terminal. This may be an RTP
 *                            terminal or an audio/video device.
 *			hAppTermSource	- Handle to the application data associated with
 *                            the source terminal.
 *			hTermTarget		- Handle to the target terminal. This is always an
 *                            RTP terminal.
 *			hAppTermTarget	- Handle to the application data associated with
 *                            the target terminal.
 *			termSourceType	- Type of the source terminal, indicating whether
 *                            the application should connect the RTP session to
 *							  an audio/video device or to another RTP session.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaConnectStreamsEv)(
                    IN RvIppTerminalHandle				hTermSource,
					IN RvMtfTerminalAppHandle			hAppTermSource,
                    IN RvIppTerminalHandle				hTermTarget,
					IN RvMtfTerminalAppHandle			hAppTermTarget,
					IN RvMtfTerminalType				termSourceType);

/*@*****************************************************************************
 * RvMtfMediaDisconnectEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *			This callback is called when the application is required to
 *			disconnect one of the following:
 *				1.	An existing media stream (RTP session) from an audio/video
 *					device, to stop media flowing from both parties of the call,
 *                  or
 *				2.	An existing media stream from another existing media stream,
 *					to stop the mixing of media during a Conference call.
 *			This callback is usually called when a basic call is disconnected
 *			(the remote party or the local user answered the call), or when one
 *          of the participants left the Conference call.
 *
 * Arguments:
 * Input:	hTermSource		- Handle to the source terminal. This may be an RTP
 *                            terminal or an audio/video device.
 *			hAppTermSource	- Handle to the application data associated with
 *                            the source terminal.
 *			hTermTarget		- Handle to the target terminal. This is always an
 *                            RTP terminal.
 *			hAppTermTarget	- Handle to the application data associated with
 *                            the target terminal.
 *			termSourceType	- Type of the source terminal, indicating whether
 *                            the application should disconnect the RTP session
 *							  from the audio/video device or from another RTP
 *                            session.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaDisconnectEv)(
                    IN RvIppTerminalHandle				hTermSource,
					IN RvMtfTerminalAppHandle			hAppTermSource,
                    IN RvIppTerminalHandle				hTermTarget,
					IN RvMtfTerminalAppHandle			hAppTermTarget,
					IN RvMtfTerminalType				termSourceType);

/*@*****************************************************************************
 * RvMtfMediaModifyCompletedEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *			This callback is called when a process of modifying media during a
 *			connected call is completed (dynamic media change). The process may
 *          be initiated by the local party or the remote party.
 *			The callback indicates the result of the process, whether it
 *			succeeded or failed, and the reason for the failure.
 *			During the process of dynamic media change, the application should
 *			keep both the old media stream and the new media stream open (i.e.,
 *          listen on both sockets).
 *			If the process was completed successfully, the application should
 *          close the old media stream and leave the new media stream open.
 *			If the process failed, the application should close the new media
 *			stream and leave the old media stream open.
 *
 * Arguments:
 * Input:	hTerm			- Handle to the terminal on which the media was
 *                            modified.
 *			hAppTermSource	- Handle to the application data associated with
 *                            the terminal.
 *			status			- Status of the process.
 *			sdpMsg			- SDP message containing the new media parameters.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfMediaModifyCompletedEv)(
                    IN RvIppTerminalHandle				hTerm,
					IN RvMtfTerminalAppHandle			hAppTerm,
                    IN RvMtfDynamicModifyMediaStatus	status,
                    IN RvSdpMsg*						sdpMsg);


/*===========================================*
 *     MEDIA BY CONNECTION CALLBACKS         *
 *===========================================*/


/*@*****************************************************************************
 * RvMtfMediaConnCreateStreamEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when the application is required to create a
 *         new media stream (RTP session) with the specific parameters provided
 *         in this callback (codec, etc.). The application should return the IP
 *         address and port number of the actual new media stream (set in
 *         params->localSdp). This callback is usually called when a new call
 *         is established.
 *         This callback is parallel to RvMtfMediaCreateStreamEv. It adds handles 
 *         to the connection in which the media is created. Only ONE of these two
 *         callbacks should be implemented.
 *
 * Arguments:
 * Input:   hConn       - Handle to the connection.
 *			hAppConn	- Handle to the application data associated with the
 *                        connection.
 *          hTerm		- Handle to the terminal.
 *			hAppTerm	- Handle to the application data associated with the
 *                        terminal.
 *			params		- Media parameters with which the new media stream
 *                        should be created.
 * Output: params		- Media parameters with which the new media stream was
 *                        created. The localSdp should include the IP address
 *                        and port number of the new media stream. All other
 *						  fields should remain the same.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaConnCreateStreamEv)(
					IN      RvIppConnectionHandle           hConn,
					IN      RvMtfConnAppHandle              hAppConn,
                    IN		RvIppTerminalHandle				hTerm,				
					IN		RvMtfTerminalAppHandle			hAppTerm,
                    INOUT	RvMtfMediaParams*				params);

/*@*****************************************************************************
 * RvMtfMediaConnModifyStreamEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when the application is required to modify
 *         an existing media stream (RTP session) with the specific parameters
 *         provided in this callback (codec, etc.). The application should return
 *         the IP address and port number of the actual media stream (set in
 *         params->localSdp). This callback is usually called during a
 *         connected call.
 *         This callback is parallel to RvMtfMediaModifyStreamEv. It adds handles 
 *         to the connection in which the media is modified. Only ONE of these two
 *         callbacks should be implemented.
 *
 * Arguments:
 * Input:   hConn       - Handle to the connection.
 *			hAppConn	- Handle to the application data associated with the
 *                        connection.
 *          hTerm		- Handle to the terminal.
 *			hAppTerm	- Handle to the application data associated with the
 *                        terminal.
 *			params		- Media parameters with which the media stream should
 *                        be modified.
 * Output: params		- Media parameters with which the media stream was
 *                        modified. The localSdp should include the IP address
 *                        and port number of the media stream. All other fields
 *                        should remain the same.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaConnModifyStreamEv)(
					IN      RvIppConnectionHandle           hConn,
					IN      RvMtfConnAppHandle              hAppConn,
                    IN		RvIppTerminalHandle				hTerm,		
					IN		RvMtfTerminalAppHandle			hAppTerm,
                    INOUT	RvMtfMediaParams*				params);

#ifdef RV_MTF_SECOND_VIDEO
/*@*****************************************************************************
* RvMtfMediaConnModifySpecificStreamEv (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* General:
*         This callback is called when the application is required to modify a
*         specific media stream.
*         The modification action to be performed is specified in the params.action
*         parameter.
*         The application should update the IP address and port number
*         of the actual media stream in the params structure.
*         Currently, this callback is called for the Presentation Video stream only.
*         The Audio and Main Video streams are handled using the
*         RvMtfMediaConnModifyStreamEv callback.
*
* Arguments:
* Input:    hConn       - Handle to the connection.
*           hAppConn    - Handle to the application data associated with the
*                         connection.
*           hTerm       - Handle to the terminal.
*           hAppTerm    - Handle to the application data associated with the
*                         terminal.
*           hStream     - Handle to the media stream.
*           hAppStream  - Pointer to the handle to the application data associated
*                         with the media stream.
*           mediaStreamParams  - Media parameters of the media stream to be
*                         modified.
* Output:
*           hAppStream  - Pointer to the handle to the application data associated
*                         with the terminal. The application should set the handle
*                         and return it to the MTF for subsequent references to the
*                         media stream.
*			mediaStreamParams - Media parameters with which the media stream was
*                         modified. When mediaStreamParams.streamDirection is
*                         RVMTF_MEDIA_STREAM_RECEIVE, mediaStreamParams.streamDescriptor
*                         should include the IP address and port number of the media stream.
*                         All other fields should remain the same.
*
* Return Value: RV_OK if successful, other if not.
****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaConnModifySpecificStreamEv)(
	IN		RvIppConnectionHandle		hConn,
	IN		RvMtfConnAppHandle			hAppConn,
	IN		RvIppTerminalHandle			hTerm,
	IN		RvMtfTerminalAppHandle		hAppTerm,
	IN      RvMtfMediaStreamHandle		hStream,
	INOUT	RvMtfMediaStreamAppHandle*	hAppStream,
	INOUT   RvMtfMediaStreamParams*		mediaStreamParams);
#endif

/*@*****************************************************************************
 * RvMtfMediaConnDestroyStreamEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when the application is required to
 *         terminate an existing media stream (RTP session). This callback is
 *         usually called when the call disconnects.
 *         This callback is parallel to RvMtfMediaDestroyStreamEv. It adds handles 
 *         to the connection in which the media is modified. Only ONE of these two
 *         callbacks should be implemented.
 *         This callback is parallel to RvMtfMediaDestroyStreamEv. It adds handles 
 *         to the connection in which the media is modified. Only ONE of these two
 *         callbacks should be implemented.
 *
 * Arguments:
 * Input:   hConn       - Handle to the connection.
 *			hAppConn	- Handle to the application data associated with the
 *                        connection.
 *          hTerm		- Handle to the terminal.
 *			hAppTerm	- Handle to the application data associated with the
 *                        terminal.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaConnDestroyStreamEv)(
					IN RvIppConnectionHandle            hConn,
					IN RvMtfConnAppHandle               hAppConn,	
                    IN RvIppTerminalHandle				hTerm,
					IN RvMtfTerminalAppHandle			hAppTerm);

/*@*****************************************************************************
 * RvMtfMediaConnConnectStreamsEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *			This callback is called when the application is required to connect
 *			one of the following:
 *				1.	An existing media stream (RTP session) with an audio/video
 *					device, to enable media to flow from both parties of the
 *                  call, or
 *				2.	An existing media stream with another existing media stream,
 *					to create mixing of media and enable the establishment of a
 *                  Conference call.
 *			This callback is usually called when a call is being connected
 *			(a remote party or a local user answered the call), or during a
 *          Conference call.
 *
 *         This callback is parallel to RvMtfMediaConnectStreamsEv. It adds handles 
 *         to the connection in which the media is modified. Only ONE of these two
 *         callbacks should be implemented.
 *
 * Arguments:
 * Input:   hConn           - Handle to the connection
 *			hAppConn        - Handle to the application data associated with the
 *                            connection.
 *	        hTermSource		- Handle to the source terminal. This may be an RTP
 *                            terminal or an audio/video device.
 *			hAppTermSource	- Handle to the application data associated with
 *                            the source terminal.
 *			hTermTarget		- Handle to the target terminal. This is always an
 *                            RTP terminal.
 *			hAppTermTarget	- Handle to the application data associated with
 *                            the target terminal.
 *			termSourceType	- Type of the source terminal, indicating whether
 *                            the application should connect the RTP session to
 *							  an audio/video device or to another RTP session.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaConnConnectStreamsEv)(
					IN RvIppConnectionHandle            hConn,
					IN RvMtfConnAppHandle               hAppConn,
                    IN RvIppTerminalHandle				hTermSource,
					IN RvMtfTerminalAppHandle			hAppTermSource,
                    IN RvIppTerminalHandle				hTermTarget,
					IN RvMtfTerminalAppHandle			hAppTermTarget,
					IN RvMtfTerminalType				termSourceType);

/*@*****************************************************************************
 * RvMtfMediaConnDisconnectEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *			This callback is called when the application is required to
 *			disconnect one of the following:
 *				1.	An existing media stream (RTP session) from an audio/video
 *					device, to stop media flowing from both parties of the call,
 *                  or
 *				2.	An existing media stream from another existing media stream,
 *					to stop the mixing of media during a Conference call.
 *			This callback is usually called when a basic call is disconnected
 *			(the remote party or the local user answered the call), or when one
 *          of the participants left the Conference call.
 *
 *         This callback is parallel to RvMtfMediaDisconnectEv. It adds handles 
 *         to the connection in which the media is modified. Only ONE of these two
 *         callbacks should be implemented.
 *
 * Arguments:
 * Input:   hConn           - Handle to the connection.
 *			hAppConn        - Handle to the application data associated with the
 *                            connection.
 *          hTermSource		- Handle to the source terminal. This may be an RTP
 *                            terminal or an audio/video device.
 *			hAppTermSource	- Handle to the application data associated with
 *                            the source terminal.
 *			hTermTarget		- Handle to the target terminal. This is always an
 *                            RTP terminal.
 *			hAppTermTarget	- Handle to the application data associated with
 *                            the target terminal.
 *			termSourceType	- Type of the source terminal, indicating whether
 *                            the application should disconnect the RTP session
 *							  from the audio/video device or from another RTP
 *                            session.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaConnDisconnectEv)(
					IN RvIppConnectionHandle            hConn,
					IN RvMtfConnAppHandle               hAppConn,
                    IN RvIppTerminalHandle				hTermSource,
					IN RvMtfTerminalAppHandle			hAppTermSource,
                    IN RvIppTerminalHandle				hTermTarget,
					IN RvMtfTerminalAppHandle			hAppTermTarget,
					IN RvMtfTerminalType				termSourceType);

/*@*****************************************************************************
 * RvMtfMediaConnModifyCompletedEv (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *			This callback is called when a process of modifying media during a
 *			connected call is completed (dynamic media change). The process may
 *          be initiated by the local party or the remote party.
 *			The callback indicates the result of the process, whether it
 *			succeeded or failed, and the reason for the failure.
 *			During the process of dynamic media change, the application should
 *			keep both the old media stream and the new media stream open (i.e.,
 *          listen on both sockets).
 *			If the process was completed successfully, the application should
 *          close the old media stream and leave the new media stream open.
 *			If the process failed, the application should close the new media
 *			stream and leave the old media stream open.
 *
 *         This callback is parallel to RvMtfMediaModifyCompletedEv. It adds handles 
 *         to the connection in which the media is modified. Only ONE of these two
 *         callbacks should be implemented.
 *
 * Arguments:
 * Input:   hConn           - Handle to the connection.
 *			hAppConn        - Handle to the application data associated with the
 *                            connection.
 *       	hTerm			- Handle to the terminal on which the media was
 *                            modified.
 *			hAppTermSource	- Handle to the application data associated with
 *                            the terminal.
 *			status			- Status of the process.
 *			sdpMsg			- SDP message containing the new media parameters.
 *
 * Return Value: RV_OK if successful, other if not.
 ****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfMediaConnModifyCompletedEv)(
					IN RvIppConnectionHandle            hConn,
					IN RvMtfConnAppHandle               hAppConn,
                    IN RvIppTerminalHandle				hTerm,
					IN RvMtfTerminalAppHandle			hAppTerm,
                    IN RvMtfDynamicModifyMediaStatus	status,
                    IN RvSdpMsg*						sdpMsg);


#ifdef RV_MTF_N_LINES
/*@*****************************************************************************
* RvMtfMediaConnectMultiStreamsEv (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* General:
*			This callback is called when the application is required to
*			connect a list of RTP terminations, and create a media mixing.
*			This callback is usually called when a Conference call is connected
*			or when one of the participants joined the Conference call.
*
* Arguments:
* Input:	hTermsList		- List of RTP terminal handles to be disconnected from 
*                             one another to stop the mixing of RTP streams.
*
* Return Value: RV_OK if successful, other if not.
****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaConnectMultiStreamsEv)(
                    IN RvPtrList		hTermsList);


/*@*****************************************************************************
* RvMtfMediaDisconnectMultiStreamsEv (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* General:
*			This callback is called when the application is required to
*			disconnect a list of RTP terminations and stop the media mixing.
*			This callback is usually called when a Conference call is disconnected
*			or when one of the participants left the Conference call.
*
* Arguments:
* Input:	hTermsList		- List of RTP terminal handles to be disconnected from 
*                             one another to stop the mixing of RTP streams.
*
* Return Value: RV_OK if successful, other if not.
****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfMediaDisconnectMultiStreamsEv)(
											IN RvPtrList		hTermsList);

#endif /* RV_MTF_N_LINES */


/*@*****************************************************************************
* Type: RvMtfMediaClbks (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* General: This structure includes pointers to media callbacks that should
* be implemented by the application for implementing media (audio/video)
* during calls.
*****************************************************************************@*/
typedef struct
{
    RvMtfMediaStartPhysicalDeviceEv					startPhysicalDeviceCB;
    RvMtfMediaCreateStreamEv						createMediaStreamCB;
    RvMtfMediaModifyStreamEv						modifyMediaStreamCB;
    RvMtfMediaStopPhysicalDeviceEv					stopPhysicalDeviceCB;
    RvMtfMediaDestroyStreamEv						destroyMediaStreamCB;
    RvMtfMediaConnectStreamsEv						connectMediaCB;
    RvMtfMediaDisconnectEv							disconnectMediaCB;
#ifdef RV_MTF_N_LINES 
	RvMtfMediaConnectMultiStreamsEv					connectMultiStreamsCB;
    RvMtfMediaDisconnectMultiStreamsEv				disconnectMultiStreamsCB;
#endif /* RV_MTF_N_LINES */
	RvMtfMediaModifyCompletedEv						modifyMediaCompletedCB;

} RvMtfMediaClbks;

/*@*****************************************************************************
* Type: RvMtfConnMediaClbks (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* General: This structure includes pointers to media callbacks that the
* application should implement to enable media (audio/video) during calls. 
* These callbacks use the connection object as one of the arguments.
*****************************************************************************@*/
typedef struct
{
    RvMtfMediaConnCreateStreamEv						connCreateMediaStreamCB;
    RvMtfMediaConnModifyStreamEv						connModifyMediaStreamCB;
#ifdef RV_MTF_SECOND_VIDEO
    RvMtfMediaConnModifySpecificStreamEv				connModifySpecificMediaStreamCB;
#endif
    RvMtfMediaConnDestroyStreamEv						connDestroyMediaStreamCB;
    RvMtfMediaConnConnectStreamsEv						connConnectMediaCB;
    RvMtfMediaConnDisconnectEv							connDisconnectMediaCB;
    RvMtfMediaConnModifyCompletedEv						connModifyMediaCompletedCB;

} RvMtfConnMediaClbks;

/*@*****************************************************************************
* Enum: RvMtfModifyMessage (RvMtfMediaPkg)
* -----------------------------------------------------------------------------
* Description: This enumerator indicates which signaling message should be sent
* to notify the remote party about a change of media during a connected call.
*****************************************************************************@*/
typedef enum
{
    RV_MTF_MODIFYMEDIA_BY_REINVITE,
		/* Indicates that media will be changed by sending a Re-Invite message
		   to the remote party. */
	RV_MTF_MODIFYMEDIA_BY_UPDATE
		/* Indicates that media will be changed by sending an Update message to
		   the remote party. */
} RvMtfModifyMessage;


/*@*****************************************************************************
 * rvMtfMediaStartModify (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         Sends a Re-Invite with SDP to the remote party. This function should
 *         be called during a connected call only. After this function is called,
 *         the callback RvMtfModifyMediaCompletedCB() will be called to indicate
 *         the result of the process (for example: a reply from the remote
 *         party, local failure, etc.).
 *
 * Arguments:
 * Input:	hTerm			- Handle to the terminal.
 *			sdpMsg			- Pointer to the SDP message to be sent with
 *                            the Re-Invite.
 *							  The MTF sets the session level parameters:
 *                            "o=", "v=", "t=", etc.
 *							  The application should set the media level
 *                            parameters: "m=", "a=", etc.
 *			modifyMessage	- Indicates which message will be sent out (Update
 *                            or Re-Invite).
 *
 * Return Value: RV_OK upon success.
 ****************************************************************************@*/
RVAPI RvStatus RVCALLCONV rvMtfMediaStartModify(
				IN RvIppTerminalHandle			hTerm,
				IN RvSdpMsg*					sdpMsg,
				IN RvMtfModifyMessage			modifyMessage);

/*@*****************************************************************************
 * rvMtfMediaGetCurrentMedia (RvMtfMediaPkg)
 * -----------------------------------------------------------------------------
 * General:
 *       Gets the SDP of the current MTF media (i.e., the media that is currently 
 *       effective). 
 *
 * Arguments:
 * Input:	hTerm			- Handle to the terminal.
 *
 * Return Value: sdpMsg		- Pointer to the SDP message with the current media.
 ****************************************************************************@*/
RVAPI RvSdpMsg* RVCALLCONV rvMtfMediaGetCurrentMedia(
				IN RvIppTerminalHandle			hTerm);



#endif /*RV_RVMGRMGRMEDIA_H*/

