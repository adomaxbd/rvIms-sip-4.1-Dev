/******************************************************************************
******************************************************************************
Copyright (c) 2008 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/

/*********************************************************************************
 *                              <rvMtfUserConfig.h>
 *
 * The file enables the user to configure the MTF compilation flags.
 * The configuration flags defined here will override any compilation flag
 * supplied in the compilation process.
 *    Author                         Date
 *    ------                        ------
 *    Yochi Moran					July-2009
 *********************************************************************************/

#ifndef _RV_MTF_USER_CONFIG
#define _RV_MTF_USER_CONFIG

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/*--------------------RV_MTF_VIDEO-----------------------*/
/* Enabling the Video add on */
#ifndef RV_MTF_VIDEO
/*
#define RV_MTF_VIDEO
*/
#endif /*RV_MTF_VIDEO*/



/*--------------------RV_MTF_STUN-----------------------*/
/* Enabling the STUN functionality */
#ifndef RV_MTF_STUN
/*
#define RV_MTF_STUN
*/
#endif /*RV_MTF_STUN*/



/*----------RV_MTF_USE_CACHE_ALLOCATOR------------------*/
/* When this flag is on, MTF works with cache Allocator */
#ifndef RV_MTF_USE_CACHE_ALLOCATOR
/*
#define RV_MTF_USE_CACHE_ALLOCATOR
*/
#endif /*RV_MTF_USE_CACHE_ALLOCATOR*/



/*--------------------RV_MTF_SIMPLE_ON------------------*/
/*Enabling the SIMPLE add on integration with MTF */
#ifndef RV_MTF_SIMPLE_ON
/*
#define RV_MTF_SIMPLE_ON
*/
#endif /*RV_MTF_SIMPLE_ON*/
	

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /*#define _RV_MTF_USER_CONFIG*/

