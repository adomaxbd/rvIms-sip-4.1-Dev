/******************************************************************************
Filename:    mtfMediaInt.h
Description: This file includes internal functions for calling deprecated media
			 callbacks.
*******************************************************************************
                Copyright (c) 2008 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#ifndef RV_RVMGRMGRMEDIA_INT_H
#define RV_RVMGRMGRMEDIA_INT_H

#include "rvmdm.h"

void rvModifyMediaCompletedIntCB(
								 void*                      connection,
								 struct RvMdmTerm_*		    term,
								 RvBool					    status,
								 RvMdmMediaStreamInfo *     media,
								 RvMdmMediaStreamDescr*	    streamDescr,
                                 RvMdmTermReasonModifyMedia	reason);

RvBool rvRtpConnectIntCB(
						 RvCCConnection*  conn,
						 RvMdmTermMgr *termMgr,
						 RvMdmTerm *source,
						 RvMdmMediaStreamInfo *m1,
						 RvMdmTerm *target,
						 RvMdmMediaStreamInfo *m2,
	                     RvMdmStreamDirection direction);
 
RvBool rvRtpDisconnectIntCB(
							RvCCConnection*     conn,
							RvMdmTermMgr*		termMgr,
							RvMdmTerm*			source,
                            RvMdmMediaStream*	m1,
                            RvMdmTerm*			target,
                            RvMdmMediaStream*	m2);


RvBool rvRtpCreateMediaIntCB(
			 RvCCConnection*            conn,
			 struct RvMdmTerm_*         term,    
             RvMdmMediaStreamDescr*     streamDescr);

RvBool rvRtpModifyMediaIntCB(
		 RvCCConnection*    conn,
		 struct RvMdmTerm_* term,
         RvMdmMediaStreamDescr* streamDescr);

#ifdef RV_MTF_SECOND_VIDEO
RvBool rvRtpModifySpecificMediaStreamIntCB(
		RvCCConnection*				conn,
		RvMtfMediaStreamHandle		streamHndl,
		struct RvMdmTerm_*			term,
		RvMtfMediaStreamParams*		mediaStreamParams,
		RvMtfMediaStreamAppHandle*  applStreamHndl);
#endif

RvBool rvRtpDestroyMediaIntCB(
	     RvCCConnection*    conn,      
	     RvMdmTerm*         term, 
         RvMdmMediaStream*  media);

RvBool rvPhysCreateMediaIntCB(
          struct RvMdmTerm_* term,
          RvMdmMediaStream* media,
          RvMdmMediaStreamDescr* streamDescr,
          OUT RvMdmError* mdmError);

RvBool rvPhysDestroyMediaIntCB(
           RvMdmTerm*         term,
           RvMdmMediaStream*  media,
           OUT RvMdmError*    mdmError);




#endif /*RV_RVMGRMGRMEDIA_INT_H*/

