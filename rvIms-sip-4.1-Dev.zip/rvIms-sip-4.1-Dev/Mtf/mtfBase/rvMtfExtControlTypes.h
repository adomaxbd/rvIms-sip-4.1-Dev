/******************************************************************************
Filename:    rvMtfExtControlTypes.h
Description: This file includes types definitions for extensibility of MTF.

*******************************************************************************
                Copyright (c) 2008 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#ifndef MTFCONTROL_TYPES_H
#define MTFCONTROL_TYPES_H

#ifdef __cplusplus
extern "C" {
#endif

#include "rvMtfHandles.h"
#include "rvMtfBaseTypes.h"
#include "rvMtfEventsApi.h"
#include "rvSipControlApi.h"

#ifdef RV_CFLAG_TLS
#include "sipTls.h"
#endif

/*@*****************************************************************************
 * Package: RvMtfSipExtPkg (root)
 * -----------------------------------------------------------------------------
 * Title: SIP Control Extensibility
 *
 * General: This section contains functions and type definitions that enable
 *  		limited control of the SIP Stack.
 ****************************************************************************@*/

 /*@*****************************************************************************
  * Package: RvMtfCallControlExtPkg (root)
  * -----------------------------------------------------------------------------
  * Title: Call Control Extensibility
  *
  * General: This section contains functions and type definitions that enable
  *  		 limited control of Call Control features.
 ****************************************************************************@*/

/*@*****************************************************************************
 * RvMtfChangeSipStackConfigEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This is a prototype for a callback that enables the application to
 *		   change the default settings of SIP Stack configuration parameters.
 *         When this function is called, pStackCfg is filled with default values
 *		   set by the MTF and SIP. The application can only change the values of
 *		   allowed parameters (for a complete list of these, see the
 *         Programmer Guide). After this callback returns, both the MTF and the
 *         SIP Stack perform validation checks on the returned values. If allowed
 *         parameters were set to invalid values, the values are changed to
 *		   default ones. If unallowed parameters were changed, they are ignored.
 *		   In both cases a warning is printed to the log output.
 *
 * Arguments:
 * Input:  pStackCfg - Pointer to the SIP Stack configuration filled with
 *                     default values.
 * Output: pStackCfg - Pointer to the SIP Stack configuration filled with
 *                     application values.
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfChangeSipStackConfigEv)(
							INOUT RvSipStackCfg* pStackCfg);

/*@*****************************************************************************
 * RvMtfRegisterSipStackEventsEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This is a prototype for a callback that enables the application to
 *		   register its own implementations to SIP Stack events.
 *         This callback enables the user to listen for SIP Stack events for
 *         which the MTF does not listen.
 *		   Note: The application must not override a callback that was already
 *         registered by the MTF. This can be avoided by checking whether the
 *         callback pointer is NULL or not (for an example, see the MTF Sample
 *         Application).
 *
 * Arguments:
 * Input:  hSipStack		-  Handle to the SIP Stack.
 *		   sipStackClbks	-  Structure with pointers to implementations of
 *							   MTF to SIP Stack callbacks.
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfRegisterSipStackEventsEv)(
					IN RvSipStackHandle				hSipStack,
					IN RvIppSipStackCallbacks*		sipStackClbks);

/*@*****************************************************************************
 * RvMtfPreCallCreatedIncomingEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called after a new incoming SIP Call-Leg is created,
 *		   and before the MTF processes the new call. At this point, no MTF
 *		   objects associated with the Call-Leg have been created yet, so the
 *         application cannot associate its data with the call. The data can be
 *		   associated either by calling rvMtfConnectionSetAppHandle()
 *		   after this callback is called or when the callback
 *		   RvMtfPostCallCreatedIncomingEv() is called. The main use of this
 *		   callback is for indicating to the MTF that this call should be ignored.
 *
 * Arguments:
 * Input:  hCallLeg - Handle to SIP Stack Call-Leg.
 *         hAppMtf  - Handle to application data associated with the MTF instance
 *					  (no MTF objects related to the call were created yet).
 *
 * Return Value: One of the following:
 *					- RV_MTF_IGNORE_BY_STACK �
 *					  This value is not relevant for this callback.
 *					- RV_MTF_IGNORE_BY_MTF �
 *					  This value indicates to the MTF to ignore the message,
 *					  but the SIP Stack will still process it.
 *					- RV_MTF_DONT_IGNORE �
 *					  This value indicates to both the SIP Stack and the MTF
 *					  to process the message.
 ****************************************************************************@*/
typedef RvMtfMsgProcessType (RVCALLCONV *RvMtfPreCallCreatedIncomingEv)(
    IN  RvSipCallLegHandle      hCallLeg,
    IN  RvMtfAppHandle			hAppMtf);

/*@*****************************************************************************
 * RvMtfPostCallCreatedIncomingEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called after a new incoming SIP Call-Leg is created,
 *		   and before the MTF processes the new call. At this point the MTF has
 *		   already created the objects that are related to the Call-Leg (hConn).
 *		   The application can set its data associated with the call.
 *
 * Arguments:
 * Input:  hCallLeg - Handle to the SIP Stack Call-Leg.
 * Output: hConnApp - Handle to the application data associated with the call.
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfPostCallCreatedIncomingEv)(
			IN RvSipCallLegHandle			hCallLeg,
			OUT RvMtfConnAppHandle*			hConnApp);

/*@*****************************************************************************
 * RvMtfPreCallCreatedOutgoingEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called after the MTF creates a new SIP Call-Leg
 *		   and before the MTF builds SIP headers in the Call-Leg object.
 *         The "to" and "from" values will be used for building TO and FROM
 *		   headers in the outgoing Invite message. The application can change
 *		   these values to different ones; those values will be used in the
 *		   TO and FROM headers. The application can also set its data associated
 *         with the call.
 *
 * Arguments:
 * Input:  hCallLeg     - Handle to the SIP Stack Call-Leg.
 *         hConn		- Handle to the connection object (associated with this
 *                        Call-Leg).
 *         to           - The destination address used for the TO header.
 *         from         - The source address used for the FROM header.
 * Output: to           - The destination address to be used for the TO header.
 *         from         - The source address to be used for the FROM header.
 *         hConnApp     - The handle to the application data associated with the
 *                        connection object (the call).
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfPreCallCreatedOutgoingEv)(
    IN RvSipCallLegHandle			hCallLeg,
	IN RvIppConnectionHandle		hConn,
    INOUT RvChar*					to,
    INOUT RvChar*					from,
    OUT RvMtfConnAppHandle*			hConnApp);


/*@*****************************************************************************
 * RvMtfPostCallCreatedOutgoingEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called after the MTF creates a new SIP Call-Leg,
 *		   i.e., after the MTF has built SIP headers in the Call-Leg object and
 *         before it sends out the Invite message. The application can set
 *         additional SIP headers to the outgoing Invite message,
 *		   or modify/remove the SIP headers set by the MTF (not recommended).
 *
 * Arguments:
 * Input:  hCallLeg    - Handle to the SIP Stack Call-Leg.
 *         hConn       - Handle to the connection object (associated with this
 *                       Call-Leg).
 *         hConnApp    - Handle to the application data associated with the
 *                       connection object (the call).
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfPostCallCreatedOutgoingEv)(
    IN RvSipCallLegHandle       hCallLeg,
    IN RvIppConnectionHandle    hConn,
    IN RvMtfConnAppHandle       hConnApp);

/*@*****************************************************************************
 * RvMtfPreCallLegStateChangedEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when the SIP Stack event
 *         RvSipCallLegStateChangedEv() is invoked, and before the MTF processes
 *		   this event. The application may retrieve information from the
 *         Call-Leg or the message, or may choose to indicate to the MTF to
 *		   ignore the event. If the application indicates to the MTF to ignore
 *		   the event, the application will be responsible for "wrapping out" the
 *		   scenario (releasing objects, etc.).
 *
 * Arguments:
 * Input:   hCallLeg    - Handle to the SIP Stack Call-Leg.
 *          hConn   	- Handle to the connection object (associated with this
 *                        call-leg).
 *          hConnApp    - Handle to the application data associated with the
 *                        connection object (the call).
 *          eState      - SIP Call-Leg state.
 *          eReason     - SIP reason for the change of state.
 *
 * Return Value: One of the following:
 *					- RV_MTF_IGNORE_BY_STACK �
 *					  This value is not relevant for this callback.
 *					- RV_MTF_IGNORE_BY_MTF �
 *					  This value indicates to the MTF to ignore
 *					  the message, but the SIP Stack will still process it.
 *					- RV_MTF_DONT_IGNORE �
 *					  This value indicates to both the SIP Stack and the MTF
 *					  to process the message.
 ****************************************************************************@*/
typedef RvMtfMsgProcessType (RVCALLCONV *RvMtfPreCallLegStateChangedEv)(
    IN RvSipCallLegHandle               hCallLeg,
    IN RvIppConnectionHandle            hConn,
    IN RvMtfConnAppHandle				hConnApp,
    IN RvSipCallLegState                eState,
    IN RvSipCallLegStateChangeReason    eReason);

/*@*****************************************************************************
 * RvMtfPostCallLegStateChangedEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is called when the SIP Stack event
 *         RvSipCallLegStateChangedEv() is invoked, and after the MTF processes
 *		   this event. The application may retrieve information from the
 *         Call-Leg or the message.
 *
 * Arguments:
 * Input:   hCallLeg    - Handle to the SIP Stack Call-Leg.
 *          hConn   	- Handle to the connection object (associated with this
 *                        Call-Leg).
 *          hConnApp    - Handle to the application data associated with the
 *                        connection object (the call).
 *          eState      - SIP Call-Leg state.
 *          eReason     - SIP reason for the change of state.
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfPostCallLegStateChangedEv)(
    IN RvSipCallLegHandle               hCallLeg,
    IN RvIppConnectionHandle            hConn,
    IN RvMtfConnAppHandle				hConnApp,
    IN RvSipCallLegState                eState,
    IN RvSipCallLegStateChangeReason    eReason);

/*@*****************************************************************************
 * RvMtfMsgToSendEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is invoked before the SIP message is sent and after the
 *         MTF adds its data to the message (SDP body, etc.). The application
 *		   can retrieve information from the outgoing message or add its own
 *		   data to the message (for example, it can add SIP headers, modify the
 *         SDP body set by the MTF, etc.).
 *
 * Arguments:
 * Input:   hCallLeg  - Handle to the SIP Stack Call-Leg.
 *          hConn     - Handle to the connection object (associated with this
 *                      Call-Leg).
 *          hConnApp  - Handle to the application data associated with the
 *                      connection object (the call).
 *          hMsg	  - Handle to the SIP message.
 *
 * Return Value: None.
 ****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfMsgToSendEv)(
    IN RvSipCallLegHandle       hCallLeg,
    IN RvIppConnectionHandle    hConn,
	IN RvMtfConnAppHandle		hConnApp,
    IN RvSipMsgHandle           hMsg);

/*@*****************************************************************************
 * RvMtfPreMsgReceivedEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is invoked when a new SIP message is received and
 *		   before the MTF and the SIP Stack process this message. The application
 *         may change the SIP message before it is processed by the MTF.
 *		   Also, the application may decide that a message will be processed
 *		   by the SIP Stack but ignored by the MTF, or ignored by both, or
 *         processed by both.
 *
 * Arguments:
 * Input:   hCallLeg    - Handle to the SIP Stack Call-Leg.
 *          hConn   	- Handle to the connection object (associated with this
 *                        Call-Leg).
 *          hConnApp    - Handle to the application data associated with the
 *                        connection object (the call).
 *          hMsg		- Handle to the SIP message.
 *
 * Return Value: One of the following:
 *				 - RV_MTF_IGNORE_BY_STACK �
 *				   This value indicates to both the SIP Stack and the MTF
 *				   to ignore the message. When this value is returned, the
 *				   callback RvIppSipPreCallLegCreatedIncomingCB() should also
 *                 return RV_MTF_IGNORE_BY_STACK, otherwise a memory leak will
 *                 occur (when RvIppSipPreCallLegCreatedIncomingCB()
 *				   is called, MTF resources are allocated but not released).
 *				 - RV_MTF_IGNORE_BY_MTF �
 *				   This value indicates to the MTF to ignore the message,
 *				   but the SIP Stack will still process it.
 *				 - RV_MTF_DONT_IGNORE �
 *				   This value indicates to both the SIP Stack and the MTF
 *				   to process the message.
 ****************************************************************************@*/
typedef RvMtfMsgProcessType (RVCALLCONV *RvMtfPreMsgReceivedEv)(
    IN RvSipCallLegHandle       hCallLeg,
    IN RvIppConnectionHandle    hConn,
    IN RvMtfConnAppHandle		hConnApp,
    IN RvSipMsgHandle           hMsg);

/*@*****************************************************************************
 * RvMtfPostMsgReceivedEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *         This callback is invoked when a new SIP message is received. This
 *		   should be done after the MTF processes the message, but before the SIP
 *		   Stack processes it. The application may change the SIP message after
 *         it is processed by the MTF.
 *
 * Arguments:
 * Input:   hCallLeg    - Handle to the SIP Stack Call-Leg.
 *          hConn   	- Handle to the connection object (associated with this
 *                        Call-Leg).
 *          hConnApp    - Handle to the application data associated with the
 *                        connection object (the call).
 *          hMsg		- Handle to the SIP message.
 *
 * Return Value:  None.
 ****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfPostMsgReceivedEv)(
    IN RvSipCallLegHandle       hCallLeg,
    IN RvIppConnectionHandle    hConn,
    IN RvMtfConnAppHandle		hConnApp,
    IN RvSipMsgHandle           hMsg);

/*@*****************************************************************************
 * RvMtfRegClientStateChangedEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *			This callback is invoked before the MTF handles registration state
 *			changes of the SIP RegClient. The RegClient state indicates the
 *          status of the registration with the SIP server.
 *
 * Arguments:
 * Input:  hRegClient       - Handle to the SIP reg-client object.
 *         hTerminal		- Handle to the terminal object associated with
 *                            this event.
 *         hAppTerminal     - Handle to the application data associated with
 *                            the terminal object.
 *         eState           - SIP reg-client state.
 *         eReason          - Reason for the reg-client change of state.
 *
 * Return Value:  One of the following:
 *					- RV_MTF_IGNORE_BY_STACK �
 *					  This value is not relevant for this callback.
 *					- RV_MTF_IGNORE_BY_MTF �
 *					  This value indicates to the MTF to ignore the message,
 *					  but the SIP Stack will still process it.
 *					- RV_MTF_DONT_IGNORE �
 *					  This value indicates to both the SIP Stack and the MTF
 *					  to process the message.
 ****************************************************************************@*/
typedef RvMtfMsgProcessType (RVCALLCONV *RvMtfRegClientStateChangedEv)(
			IN RvSipRegClientHandle             hRegClient,
			IN RvIppTerminalHandle              hTerminal,
			IN RvMtfTerminalAppHandle           hAppTerminal,
			IN RvSipRegClientState              eState,
			IN RvSipRegClientStateChangeReason  eReason);
/*@*****************************************************************************
* RvMtfRegClientMsgToSendEv  (RvMtfSipExtPkg)
* -----------------------------------------------------------------------------
* General:
*			This callback is invoked when a Register message is sent.
*           
* Arguments:
* Input:  hRegClient       - Handle to the SIP Stack register-client object.
*         hAppRegClient    - The application handle for this register-client.
*         hMsg             - Handle to the message to be sent.
*
* Return Value: RvStatus.
****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfRegClientMsgToSendEv )(
			IN RvSipRegClientHandle				hRegClient,
			IN RvIppTerminalHandle				hTerminal,
			IN RvMtfTerminalAppHandle			hAppTerminal,
			IN RvSipMsgHandle					hMsg);

/*@*****************************************************************************
* RvMtfRegClientMsgReceivedEv  (RvMtfSipExtPkg)
* -----------------------------------------------------------------------------
* General:
*			This callback is invoked when a Register response message is received.
*           
* Arguments:
* Input:  hRegClient       - Handle to the SIP Stack register-client object.
*         hAppRegClient    - The application handle for this register-client.
*         hMsg             - Handle to the received message.
*
* Return Value: RvStatus
*               RV_OK - The message was received and handled successfully.
****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfRegClientMsgReceivedEv )(
	IN RvSipRegClientHandle				hRegClient,
	IN RvIppTerminalHandle				hTerminal,
	IN RvMtfTerminalAppHandle			hAppTerminal,
	IN RvSipMsgHandle					hMsg);

/*@*****************************************************************************
 * RvMtfRegClientCreatedEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *			This callback is invoked after the MTF has created a SIP RegClient
 *          object.
 *			The user application can add any data it wants to this object.
 *
 * Arguments:
 * Input:  hRegClient       - Handle to the SIP RegClient object.
 *
 * Return Value:     RV_OK on success, error code otherwise.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfRegClientCreatedEv)(
			IN RvSipRegClientHandle             hRegClient);


/*@*****************************************************************************
 * RvMtfRegExpResolutionNeededEv (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * General:
 *        This callback is invoked before the MTF receives the
 *        RvSipTransmitterMgrRegExpResolutionNeededEv event from the SIP Stack.
 *		  It is called when the Tel-URI scheme ("tel:") is returned in the
 *		  callback RvMdmTermMapDialStringToAddressCB() and the outbound proxy
 *        was not configured.
 *
 * Arguments:
 * Input: hTrxMgr        - Transmitter manager.*
 *        hTrx           - Handle to the transmitter (NULL if the transmitter
 *                         is not an application transmitter).
 * Output: pRegExpParams - Structure that holds the information for the regular
 *                         expression application.
 *                         The pMatchArray should be filled in by
 *                         RvSipTransmitterRegExpResolutionNeededEv with
 *                         substring match addresses. Any unused structure
 *                         elements should contain the value -1.
 *                         Each startOffSet element that is not -1, indicates
 *                         the start offset of the next-largest substring match
 *                         in the string. The relative endOffSet element
 *                         indicates the end offset of the match.
 *
 * Return Value:  None.
 ****************************************************************************@*/
typedef RvStatus     (RVCALLCONV *RvMtfRegExpResolutionNeededEv)(
    IN  RvSipTransmitterMgrHandle                   hTrxMgr,
    IN  RvSipTransmitterHandle                      hTrx,
    INOUT RvSipTransmitterRegExpResolutionParams*   pRegExpParams);

/*@*****************************************************************************
*  RvMtfPreProcessEventEv (RvMtfCallControlExtPkg)
* -----------------------------------------------------------------------------
*  General:     This callback is invoked before an MDM event is processed in the
*               MTF state machine. The application can indicate to the MTF to
*               ignore this event by setting newEventId to RV_MTF_EVENT_NONE.
*               The application can also replace the event with a different one
*			    by setting newEventId to another event. In this case, the MTF
*				processes the event returned by the application instead of
*				the event passed in the callback.
*
*  Arguments:
*  Input:       hConn		- Handle to the connection object.
*               hConnApp	- Handle to the application data associated with
*                             the connection (the call).
*				connState	- Connection state.
*				eventId		- Event to be processed by the MTF.
*				reason		- Reason for the event.
*
*  Output:      newEventId	- Event to be processed instead of the original
*                             event. If it is not set, origEventId will be
*				              processed.
*				reason		- Reason for the event to be processed instead of
*                             the original event. If it is not set, origEventId
*                             will be processed.
*
*  Return Value:    None.
****************************************************************************@*/
typedef void  (RVCALLCONV *RvMtfPreProcessEventEv)(
                                        IN      RvIppConnectionHandle   hConn,
										IN		RvMtfConnAppHandle		hConnApp,
										IN		RvMtfConnectionState	connState,
                                        IN		RvMtfEvent				eventId,
										OUT		RvMtfEvent*				newEventId,
                                        INOUT   RvMtfReason*			reason);

/*@*****************************************************************************
*  RvMtfPostProcessEventEv (RvMtfCallControlExtPkg)
* -----------------------------------------------------------------------------
*  General:     This callback is invoked after an MDM event was processed by the
*               MTF state machine.
*
*  Arguments:
*  Input:       hConn		- Handle to the connection object.
*               hConnApp	- Handle to the application data associated with the
*                             connection (the call).
*				connState	- Connection state.
*				eventId		- Event that was processed by the MTF.
*				reason		- Reason for the event.
*
*  Return Value:    None.
****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfPostProcessEventEv)(
                                        IN  RvIppConnectionHandle   hConn,
										IN	RvMtfConnAppHandle		hConnApp,
										IN	RvMtfConnectionState	connState,
                                        IN  RvMtfEvent				eventId,
                                        IN  RvMtfReason				reason);

/*@*****************************************************************************
*  RvMtfConnStateChangedEv (RvMtfCallControlExtPkg)
* -----------------------------------------------------------------------------
*  General:     This callback is invoked when MTF state machine changes a 
*               connection state.
*
*  Arguments:
*  Input:       hConn		- Handle to the connection object.
*               hConnApp	- Handle to the application data associated with the
*                             connection (the call).
*				connState	- Connection state.
*				reason		- Reason for the event.
*
*  Return Value:    None.
****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfConnStateChangedEv)(
                                        IN  RvIppConnectionHandle   hConn,
										IN	RvMtfConnAppHandle		hConnApp,
										IN	RvMtfConnectionState	connState,
                                        IN  RvMtfCallStateReason	reason);

/*@*****************************************************************************
*  RvMtfUpdateTextDisplayEv (RvMtfCallControlExtPkg)
* -----------------------------------------------------------------------------
*  General:     This callback is invoked whenever the MTF indicates to the
*               application that the text display in the terminal should be
*				updated. The application should decide on the specific text
*               to be used by checking the states of the connection and the
*               terminal.
*
*  Arguments:
*  Input:       hConn		- Handle to the connection object.
*               hConnApp	- Handle to the application data associated with
*                             the connection (the call).
*				connState	- Connection state.
*				hTerminal	- Handle to the terminal object.
*				eventId		- Event that was processed by the MTF.
*				reason		- Reason for the event.
*
*  Return Value:    None.
****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfUpdateTextDisplayEv)(
    IN RvIppConnectionHandle    hConn,
	IN RvMtfConnAppHandle		hConnApp,
	IN RvMtfConnectionState		connState,
    IN RvIppTerminalHandle      hTerminal,
    IN RvMtfEvent			    eventId,
    IN RvMtfReason				reason);

/*@*****************************************************************************
* RvMtfTermRegistrationStateChangedEv (RvMtfCallControlExtPkg) 
* -----------------------------------------------------------------------------
* General: This callback is invoked when the terminal registration
*          state is changed. 
*
* Arguments:
* Input:  hTerminal		   - Handle to the terminal object associated with
*                            this event.
*         hAppTerminal     - Handle to the application data associated with
*                            the terminal object.
*         reportType       - Type of report.
*         pData            - Pointer to a structure containing state 
*                            information.
****************************************************************************@*/
typedef void (RVCALLCONV *RvMtfTermRegistrationStateChangedEv)(
	IN RvIppTerminalHandle              hTerminal,
	IN RvMtfTerminalAppHandle           hAppTerminal,
	IN RvMtfRegisterReportType          reportType,
	IN RvMtfTermRegistrationStatus*     pData);

/*-----------------------------------------------------------------------*/
/*                        SUBSCRIPTION CALLBACKS	 				     */
/*-----------------------------------------------------------------------*/

/*@*************************************************************************
 * RvMtfSubsStateChangedEv (RvMtfSipExtPkg)
 * ------------------------------------------------------------------------
 * General: This callback is invoked whenever the MTF is informed about
 *          a Subs state change.
 *          
 * Arguments:
 * Input:     hSubs    - The SIP Stack subscription handle.
 *            hAppSubs - The application handle for this subscription.
 *            eState   - The new subscription state.
 *            eReason  - The reason for the state change.
 *
 * Return Value:     RV_OK on success, error code otherwise.
 *************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfSubsStateChangedEv)(
								IN  RvSipSubsHandle            hSubs,
								IN  RvSipAppSubsHandle         hAppSubs,
								IN  RvSipSubsState             eState,
								IN  RvSipSubsStateChangeReason eReason);

/*@*************************************************************************
 * RvMtfSubsSubscriptionExpiredEv (RvMtfSipExtPkg)
 * ------------------------------------------------------------------------
 * General: This callback is invoked whenever the MTF is informed about
 *          the expiration of a Subscription. 
 *          
 * Arguments:
 * Input:     hSubs    - The SIP Stack Subscription handle.
 *            hAppSubs - The application handle for this Subscription.
 *
 * Return Value:     RV_OK on success, error code otherwise.
 *************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfSubsSubscriptionExpiredEv)(
								IN  RvSipSubsHandle            hSubs,
								IN  RvSipAppSubsHandle         hAppSubs);

/*@*************************************************************************
 * RvMtfSubsExpirationAlertEv (RvMtfSipExtPkg)
 * ------------------------------------------------------------------------
 * General: This callback is invoked whenever the MTF is alerted that
 *          a Subscription is about to expire.
 * Arguments:
 * Input:     hSubs    - The SIP Stack Subscription handle.
 *            hAppSubs - The application handle for this Subscription.
 *
 * Return Value:     RV_OK on success, error code otherwise.
 *************************************************************************@*/

typedef RvStatus (RVCALLCONV *RvMtfSubsExpirationAlertEv)(
								IN  RvSipSubsHandle            hSubs,
								IN  RvSipAppSubsHandle         hAppSubs);

/*@**************************************************************************
 * RvMtfSubsNotifyEv (RvMtfSipExtPkg)
 * ------------------------------------------------------------------------
 * General:
 *	Indicates the status of a NOTIFY. The NOTIFY status includes the
 *	received NOTIFY message and its related notification object
 *	handle. 
 *
 * Arguments:
 * Input:   hSubs            - The SIP Stack Subscription handle.
 *          hAppSubs         - The application handle for this Subscription.
 *          hNotification    - The SIP Stack notification object handle.
 *          hAppNotification - The application handle for this notification. 
 *                             (Relevant only for a notifier Subscription that set 
 *                             the hAppNotification in RvSipSubsCreateNotify()).
 *          eNotifyStatus    - The status of the notification object.
 *          eNotifyReason    - The reason for the indicated status.
 *          hNotifyMsg       - The received message (NOTIFY request).
 *
 * Return Value:     RV_OK on success, error code otherwise.
 **************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfSubsNotifyEv)(
								IN  RvSipSubsHandle			hSubs,
								IN  RvSipAppSubsHandle		hAppSubs,
								IN  RvSipNotifyHandle		hNotification,
								IN  RvSipAppNotifyHandle	hAppNotification,
								IN  RvSipSubsNotifyStatus	eNotifyStatus,
								IN  RvSipSubsNotifyReason	eNotifyReason,
								IN  RvSipMsgHandle			hNotifyMsg);

/*@*****************************************************************************
 * RvMtfSubsCreatedDueToForkingEv (RvMtfSipExtPkg)
 * ----------------------------------------------------------------------------
 * General:
 *	Notifies the application of the creation of a forked subscription. A forked
 *  subscription is created as a result of the arrival of a NOTIFY message
 *  that was sent in response to a forked SUBSCRIBE request. For information
 *  about forking determination criteria, see sections 3.3.3 and 4.4.9 of
 *  RFC 3265.
 *
 * Arguments:
 * Input:   hSubs       - The handle to the created forked Subscription.
 *          pExpires    - A pointer to the expiration value of the Subscription.
 *                        This value should be set in seconds. If the value was
 *                        not determined, it will be set to -1.
 *                        The value cannot be determined if it was not set in
 *                        the original Subscription. In this case,
 *                        the application should supply the value to limit
 *                        the life cycle of the forked Subscription.
 *                        The RvSipSubsUpdateSubscriptionTimer() function can
 *                        also be used for this purpose. On expiration,
 *                        the expiration callback will be called for the forked
 *                        Subscription.
 * Output:  pExpires    - A pointer to the memory in which the application can set
 *                        the expiration value.
 *          phAppSubs   - The handle that the application sets
 *                        for the Subscription.
 *          pRejectStatus-If the application decides to terminate this Subscription,
 *                        it should set the pointer to point to a positive
 *                        integer representing an error code. In this case, the Stack
 *                        will respond to the NOTIFY with an error code and
 *                        free the Subscription object and
 *                        all Subscription-related resources.
 *
 * Return Value:     RV_OK on success, error code otherwise.
 ****************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfSubsCreatedDueToForkingEv)(
								IN        RvSipSubsHandle    hSubs,
						    	INOUT     RvInt32            *pExpires,
							    OUT       RvSipAppSubsHandle *phAppSubs,
                                OUT       RvUint16           *pRejectStatus);

/*@*************************************************************************
 * RvMtfSubsMsgToSendEv (RvMtfSipExtPkg)
 * ------------------------------------------------------------------------
 * General:
 *	Notifies the application that an outgoing SUBCRIBE message or NOTIFY
 *  response (related to its components) is about to be sent.
 *
 * Arguments:
 * Input:     hSubs -      The SIP Stack Subscription handle.
 *            hAppSubs -   The application handle for this Subscription.
 *            hNotify -    The Notify object handle (relevant only for the Notify message).
 *            hAppNotify - The application Notify object handle (relevant only for the Notify message).
 *            hMsg -       Handle to the outgoing message.
 *
 * Return Value: RvStatus. The returning RV_ERROR_XXX will stop the sending of
 *                         the message.
 *************************************************************************@*/
typedef RvStatus (RVCALLCONV *RvMtfSubsMsgToSendEv)(
							   IN    RvSipSubsHandle      hSubs,
							   IN    RvSipAppSubsHandle   hAppSubs,
							   IN    RvSipNotifyHandle    hNotify,
							   IN    RvSipAppNotifyHandle hAppNotify,
							   IN    RvSipMsgHandle       hMsg);
									
/*@*************************************************************************
 * RvMtfSubsMsgReceivedEv (RvMtfSipExtPkg)
 * ------------------------------------------------------------------------
 * General:
 * Notifies the application that an incoming NOTIFY message or SUBSCRIBE
 * response (related to its components) was received.
 *
 * Arguments:
 * Input:     hSubs -      The SIP Stack Subscription handle.
 *            hAppSubs -   The application handle for this Subscription.
 *            hNotify -    The Notify object handle (relevant only for the Notify message).
 *            hAppNotify - The application Notify object handle (relevant only for the Notify message).
 *            hMsg -       Handle to the incoming message.
 * 
 * Return Value: One of the following:
 *				 - RV_MTF_IGNORE_BY_STACK �
 *				   This value indicates to both the SIP Stack and the MTF
 *				   to ignore the message. 
 *				 - RV_MTF_IGNORE_BY_MTF �
 *				   This value indicates to the MTF to ignore the message,
 *				   but the SIP Stack will still process it.
 *				 - RV_MTF_DONT_IGNORE �
 *				   This value indicates to both the SIP Stack and the MTF
 *				   to process the message.
 ****************************************************************************@*/
typedef RvMtfMsgProcessType (RVCALLCONV *RvMtfSubsMsgReceivedEv)(
							  IN  RvSipSubsHandle      hSubs,
							  IN  RvSipAppSubsHandle   hAppSubs,
							  IN  RvSipNotifyHandle    hNotify,
							  IN  RvSipAppNotifyHandle hAppNotify,
                              IN  RvSipMsgHandle       hMsg);

/*@*****************************************************************************
 * Type: RvMtfCallControlClbks (RvMtfCallControlExtPkg)
 * -----------------------------------------------------------------------------
 * Description: This structure includes Call Control Extensibility callbacks.
 * The application can use these callbacks to support proprietary behavior
 * of the terminal or to add new functionality from the user perspective (not
 * from the signaling perspective).
 ****************************************************************************@*/
typedef struct
{
    RvMtfPreProcessEventEv				preProcessEventCB;
        /* Enables the application to process an event before the MTF processes
	    it, or to handle its own events. */

    RvMtfPostProcessEventEv				postProcessEventCB;
        /* Enables the application to process an event after the MTF processes
	    it. */

	RvMtfConnStateChangedEv             connStateChangedCB;
	    /* Notifies the application of a change in a connection state. */

    RvMtfUpdateTextDisplayEv            updateTextDisplayCB;
        /* Enables the application to control the text display. */

	RvMtfTermRegistrationStateChangedEv             termRegistrationStateChangedCB;
	    /* Notifies the application about a change in a terminal registration state. */

} RvMtfCallControlClbks;


/*@*****************************************************************************
 * Type: RvMtfSubscribeClbks (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * Description: This structure contains SIP Stack Subscription callbacks that 
 *              the user application can implement to gain control over the
 *              SIP Stack.
 ****************************************************************************@*/
typedef struct
{
	RvMtfSubsStateChangedEv                     subsStateChangedCB;
	RvMtfSubsSubscriptionExpiredEv              subsSubscriptionExpiredCB;   
	RvMtfSubsExpirationAlertEv                  subsExpirationAlertCB;
	RvMtfSubsNotifyEv                           subsNotifyCB;
	RvMtfSubsCreatedDueToForkingEv              subsCreatedDueToForkingCB;								   
	RvMtfSubsMsgToSendEv                        subsMsgToSendCB;									
	RvMtfSubsMsgReceivedEv                      subsMsgReceivedCB;
	
} RvMtfSubscribeClbks;
								   

/*@*****************************************************************************
 * Type: RvMtfSipControlClbks (RvMtfSipExtPkg)
 * -----------------------------------------------------------------------------
 * Description: This structure contains SIP Stack callbacks that the user
 *              application can implement to gain control over the SIP Stack.
 ****************************************************************************@*/
typedef struct
{
    RvMtfChangeSipStackConfigEv             stackConfigCB;
		/* This callback enables modifying the SIP Stack configuration. */
    RvMtfRegisterSipStackEventsEv           registerStackEventsCB;
		/* This callback enables registering the application implementation
	       for SIP callbacks to the SIP Stack. */
    RvMtfPreCallCreatedIncomingEv		    preCallLegCreatedIncomingCB;
    RvMtfPostCallCreatedIncomingEv		    postCallLegCreatedIncomingCB;
    RvMtfPreCallCreatedOutgoingEv		    preCallLegCreatedOutgoingCB;
    RvMtfPostCallCreatedOutgoingEv		    postCallLegCreatedOutgoingCB;
    RvMtfPreCallLegStateChangedEv	        preStateChangedCB;
    RvMtfPostCallLegStateChangedEv          postStateChangedCB;
 //   RvMtfPreMsgToSendEv                   preMsgToSendCB;
    RvMtfMsgToSendEv		                postMsgToSendCB;
    RvMtfPreMsgReceivedEv	                preMsgReceivedCB;
    RvMtfPostMsgReceivedEv                  postMsgReceivedCB;
    RvMtfRegClientStateChangedEv			regClientStateChangedCB;
	RvMtfRegClientCreatedEv					regClientCreatedCB;
    RvMtfRegExpResolutionNeededEv		    regExpResolutionNeededCB;
	RvMtfRegClientMsgToSendEv				regClientMsgToSendCB;
    RvMtfRegClientMsgReceivedEv				regClientMsgReceivedCB;
	RvMtfSubscribeClbks                     subsClbks;

} RvMtfSipControlClbks;




#ifdef __cplusplus
}
#endif


#endif /*MTFCONTROL_TYPES_H*/


