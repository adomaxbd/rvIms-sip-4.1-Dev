/*****************************************************************************
Filename: rvalloccache.c
Description: Cache-driven allocator adaptor
******************************************************************************
                      Copyright (c) 2006 RADVision Inc.
******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision Inc.
No part of this publication may be reproduced in any form whatsoever without
written prior approval by RADVision Inc.

RADVision Inc. reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************
$Revision:$
$Date:$
$Author: Amir Shavit$
*****************************************************************************/
#define LOGSRC  LOGSRC_UTIL
#include <string.h>
#include "rvdefalloc.h"
#include "rvalloccache.h"
#include "rvalloccanaries.h"
#include "rvlock.h"
#include "rvassert.h"
#include "rvthread.h"
#include "rvptrlist.h"
#include "ipplog.h"
#include "rvmemory.h"


/************************************************************************/
/* Private Definitions                                                  */
/************************************************************************/

/* Some of the features of the rvAllocCache allocator can be disabled in order
to improve performance and to save memory. The following macros eliminate
unnecessary use of memory and remove unused code. */
#ifndef RV_MTF_PERFORMANCE_ON
#   define IF_CACHE_STATS(x) x;
#   define IF_CACHE_DEBUG(x) x;
#else
#   define IF_CACHE_STATS(x)
#   define IF_CACHE_DEBUG(x)
#endif

/* Number of cache-pools inside the cache manager*/
#define CACHE_TABLE_SIZE        (16)

/* Cache-pools are grouped by block size (each block size is 2^x) */
#define CACHE_BLOCK_GROUP_BITS  (7)

/* Cache group bitmask; Used in order to align-up block sizes */
#define CACHE_BLOCK_GROUP_BITMASK (RvSize_t)(~((~0)<<CACHE_BLOCK_GROUP_BITS))

/* Memory blocks above CACHE_SIZE_LIMIT will be allocated by the 'baseAlloc' */
#define CACHE_SIZE_LIMIT ( (1<<CACHE_BLOCK_GROUP_BITS) * CACHE_TABLE_SIZE )

/* Return the cache table index according to the block's size */
#define CACHE_IDX_BY_BLOCK_SIZE(size) (size >> CACHE_BLOCK_GROUP_BITS)

/* Returns the block size according to it's cache-table index */
#define CACHE_BLOCK_SIZE_BY_IDX(idx) ((1<<CACHE_BLOCK_GROUP_BITS)*(idx+1))

/* TLS var name */
#define RV_TLSSUBALLOC_VARNAME ("TlsSubAlloc")


/************************************************************************/
/* Private Type Definitions                                             */
/************************************************************************/

/* Points to the next cached block. */
typedef struct RvAllocCacheControlBlock_ {
    struct RvAllocCacheControlBlock_ * next;/* Pointer to the next CCB */
    RvUint32 size; /* Size of the block (for debug & for an 8 bytes align) */
} RvAllocCacheControlBlock;

/* Cache Config */
typedef struct
{
    RvUint32    lowerLimit;             /* ... of cached blocks */
    RvUint32    initialQuantity;        /* ... */
    RvUint32    initialLimit;
    RvUint32    upperLimit;             /* ... */

    RvUint32    limitRaiseDelta;        /* By how much should the limit be increased? */
    RvUint32    limitRaiseTriggerCount; /* Increase limit after how many bad allocs? */
    RvUint32    limitLowerDelta;        /* By how much should the limit be decreased? */
    RvUint32    limitLowerTriggerCount; /* Decrease limit after how many good frees? */

} RvAllocCacheConfig;

/* Holds the information for each "cache pool" */
typedef struct RvAllocCacheEntry_ {
    RvPoolNew   pool;                       /* Memory block pool */
    RvUint32    curCached;                  /* Number of cached blocks */
    RvUint32    limit;                      /* Max. allowed number of cached blocks */
    const RvAllocCacheConfig * configLimits;/* Matching RvAllocCacheConfig* entry */
    RvAllocCacheControlBlock * firstBlock;  /* First cached block (link-list) */
    RvLock      lock;                       /* Cache pool's lock */
    RvUint32    countRegAlloc;              /* Counts regular allocs (before modifying the limit) */
    RvUint32    countCacheFree;             /* counts cache frees (before modifying the limit) */
    /* Statistics */
    RvUint32 peak;        /* Peak number of cache blocks used */
    RvUint32 curUsed;     /* Number of regular blocks used */
    RvUint32 allocCache;   /* Number of cache allocs */
    RvUint32 allocReg;     /* Number of regular allocs */
    RvUint32 freeCache;    /* Number of cache free's */
    RvUint32 freeReg;      /* Number of regular free's */
} RvAllocCacheEntry;

/* Cache manager; Passed through the 'pool' member of the RvAlloc struct */
typedef struct RvAllocCacheManager_ {
    RvAlloc *           allocator;          /* Memory Allocator */
    RvAllocCacheEntry   cacheTable[CACHE_TABLE_SIZE];   /* Cache entries */
    RvAlloc *           parentAlloc;        /* Parent allocator (for sub-allocators) */
    IF_CACHE_DEBUG( RvAlloc allocForCanary )/* Holds the 'real' allocator; used by the canary */
    RvPtrList subAllocList;/* List of sub allocators */
} RvAllocCacheManager;


/************************************************************************/
/* Private Prototypes                                                   */
/************************************************************************/

/* Constructors/Destructors */
static RvAlloc * rvAllocCacheConstruct(RvAlloc * allocCache,RvAlloc * allocator,
                                       const RvAllocCacheConfig memoryConfig[CACHE_TABLE_SIZE]);
static void rvAllocCacheDestruct(RvAlloc * allocCache);
static RvAlloc * rvAllocCacheConstructSub(RvAlloc * subAlloc, RvAlloc * allocCache,
                                          const RvAllocCacheConfig memoryConfig[CACHE_TABLE_SIZE]);
static void rvAllocCacheDestructSub(RvAlloc * subAlloc);

/* RvAlloc callbacks for allocate and deallocate */
static void * rvCacheAlloc(void * pool, RvSize_t size);
static void rvCacheDealloc(void * pool, RvSize_t size, void * x);

/* Alloc/free initial memory blocks to/from the cache*/
static RvSize_t allocMemoryBlocks(RvAllocCacheEntry * tableEntry, RvUint32 Quantity, RvPoolNew * pool);
static void freeMemoryBlocks(RvAllocCacheEntry * srcEntry, RvAllocCacheEntry * dstEntry);

/* Transfer cached blocks between two cache entries */
static RvUint32 transferBlocks(RvAllocCacheEntry * srcEntry, RvBool srcThreadSafe,
                               RvAllocCacheEntry * dstEntry, RvBool dstThreadSafe,
                               RvUint32 transferAmount, RvBool freeSpare,
                               RvBool allocateMissing);

/* Initialize/finalize a cache table entry (used by the constructor) */
static RvBool initCacheTableEntry(RvAllocCacheEntry * tableEntry, RvUint32 entryIdx,
                                  const RvAllocCacheConfig* memoryConfig, RvBool isThreadSafe,
                                  RvAlloc * allocator);
static void finishCacheTableEntry(RvAllocCacheEntry * tableEntry, RvBool isThreadSafe);

/* Wrapper functions for supporting rvAllocCanaries on debug mode */
static RvAlloc * createCacheAllocator(RvAlloc * allocCache, RvAllocCacheManager * cacheMgr);
static RvAllocCacheManager * getCacheManager(RvAlloc * allocCache);
#ifndef RV_MTF_PERFORMANCE_ON
static RvAlloc * debugDestructCanary(RvAlloc * allocCache);
#endif /* #ifdef RV_MTF_PERFORMANCE_ON */

/* Return the base allocator from a 'RvAlloc' */
static RvAlloc * rvAllocCacheGetAllocator(RvAlloc * allocCache);

/* TLS/Sub Support */
static RvAllocCacheManager * rvCacheAllocGetMgrFromTls(void);
void rvAllocCacheSubBorrow(RvAlloc * subAlloc, RvAlloc * allocCache,
                           const RvAllocCacheConfig memoryConfig[CACHE_TABLE_SIZE]);
void rvAllocCacheSubReturn(RvAlloc * subAlloc, RvAlloc * allocCache);
static RvBool rvCacheAllocTlsVarConstructor(void ** pPoolPtr);
static void rvCacheAllocTlsVarDestructor(RvThread * thread, void * data, RvUint32 index);
static void * rvCacheAllocSub(void * pool, RvSize_t size);
static void rvCacheDeallocSub(void * pool, RvSize_t size, void * x);


/************************************************************************/
/* Globals                                                              */
/************************************************************************/

/* Default memory config tables */
static const RvAllocCacheConfig rvDefAllocCacheMemoryConfig[CACHE_TABLE_SIZE] =
{
    /*  ll     iv     il     ul     ib    itc     db    dtc */
    {   10 ,    0 , 1000 ,10000 ,    1 ,   10 ,    1 ,   50 },/* 0  */  /* <-- 128B */
    {   10 ,    0 , 1000 ,10000 ,    1 ,   10 ,    1 ,   50 },/* 1  */
    {   10 ,    0 , 1000 ,10000 ,    1 ,   10 ,    1 ,   50 },/* 2  */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    0 ,    5 },/* 3  */  /* <-- 0.5K */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    0 ,    5 },/* 4  */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    1 ,    5 },/* 5  */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    1 ,    5 },/* 6  */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    1 ,    5 },/* 7  */  /* <--   1K */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    1 ,    5 },/* 8  */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    1 ,    5 },/* 9  */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    1 ,    5 },/* 10 */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    1 ,    5 },/* 11 */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    1 ,    5 },/* 12 */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    1 ,    5 },/* 13 */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    1 ,    5 },/* 14 */
    {   10 ,    0 ,   50 ,  100 ,    1 ,    5 ,    1 ,    5 },/* 15 */  /* <--   2K */
};
static const RvAllocCacheConfig rvDefAllocCacheSubMemoryConfig[CACHE_TABLE_SIZE] =
{
    {   10 ,   10 ,   50 , 5000 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 , 5000 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 , 5000 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
    {   10 ,   10 ,   50 ,  100 ,    0 ,    0 ,    0 ,    0 },
};

/* Global Allocator (instance + refcount) */
static RvAlloc  globalAllocCache;
static RvUint32 globalAllocCache_refCount = 0;

/* Tls Allocator (index + exported RvAlloc) */
static RvUint32 rvAllocCacheTlsIndex = ~0U;
RvAlloc rvAllocCacheTlsAlloc = { 0, ~0U, rvCacheAllocSub, rvCacheDeallocSub };

/************************************************************************/
/* Implementation                                                       */
/************************************************************************/
static void * rvCacheAlloc(void * pool, RvSize_t size)
{
    RvAllocCacheManager * cacheMgr = NULL;
    RvAllocCacheEntry * ce = NULL;
    void * resPtr = NULL;

    RvAssert( NULL != pool );

    size |= CACHE_BLOCK_GROUP_BITMASK;

    if ( CACHE_SIZE_LIMIT <= size )
    {
        /* This allocator only caches small blocks; Bigger blocks go directly
        to the regular allocator. */
        return rvAllocAllocate(((RvAllocCacheManager*)pool)->allocator, size);
    }

    /* Find the suitable cache-table entry according to the block's size */
    cacheMgr = (RvAllocCacheManager*)pool;
    ce = &cacheMgr->cacheTable[ CACHE_IDX_BY_BLOCK_SIZE(size) ];

    RvLockGet(&ce->lock, NULL);

    if ( NULL != ce->firstBlock ) {
        /* There's a cached block that can be used */
        RvAllocCacheControlBlock * oldFirstBlock;
        IF_CACHE_DEBUG( ce->firstBlock->size = (RvUint32)size );

        resPtr = ce->firstBlock + 1;
        oldFirstBlock = ce->firstBlock;
        ce->firstBlock = ce->firstBlock->next;
        oldFirstBlock->next = NULL;
        ce->curCached--;

        IF_CACHE_STATS( ce->curUsed++ );
        IF_CACHE_STATS( ce->allocCache++ );
        RvLockRelease(&ce->lock, NULL);
    }
    else {
        RvAllocCacheControlBlock * newBlock = NULL;

        RvLockRelease(&ce->lock, NULL);

        /* The cache is empty; a new block has to be allocated (no parent)*/
        newBlock = rvPoolNewAllocBlock(&ce->pool);

        if ( NULL == newBlock ) {
            /* The allocator failed */
            resPtr = NULL;
        }
        else {
            /* Init the new block's control-block */
            newBlock->next = NULL;
            IF_CACHE_DEBUG( newBlock->size = (RvUint32)size );

            IF_CACHE_STATS( RvLockGet(&ce->lock, NULL)      );
            IF_CACHE_STATS( ce->curUsed++                   );
            IF_CACHE_STATS( ce->allocReg++                  );
            IF_CACHE_STATS( RvLockRelease(&ce->lock, NULL); );

            resPtr = newBlock+1;
        }

        /* Update the alloc-reg(no-cache) counter */
        if ( ce->countRegAlloc++ >= ce->configLimits->limitRaiseDelta ) {
            ce->limit = RvMin(ce->limit + ce->configLimits->limitRaiseDelta,
                ce->configLimits->upperLimit);
            ce->countRegAlloc = 0 ;
        }

    }

    return resPtr;
}

static void rvCacheDealloc(void * pool, RvSize_t size, void * x)
{
    RvAllocCacheManager * cacheMgr = NULL;
    RvAllocCacheEntry * ce = NULL;

    RvAssert( NULL != pool );
    RvAssert( NULL != x );

    /* Align-up the block size */
    size |= CACHE_BLOCK_GROUP_BITMASK;

    if ( CACHE_SIZE_LIMIT <= size ) {
        /* This allocator only caches small blocks. */
        rvAllocDeallocate(((RvAllocCacheManager*)pool)->allocator, size, x);
        return;
    }

    IF_CACHE_DEBUG( RvAssert( (((RvAllocCacheControlBlock*)x)-1)->size == size ) );

    /* Find the suitable cache-table entry according to the block's size */
    cacheMgr = (RvAllocCacheManager*)pool;
    ce = &cacheMgr->cacheTable[ CACHE_IDX_BY_BLOCK_SIZE(size) ];

    RvLockGet(&ce->lock, NULL);

    IF_CACHE_STATS(ce->curUsed--);

    /* A macro to detected double deallocation */
    RvAssert((NULL == (((RvAllocCacheControlBlock*)x)-1)->next) && "Deallocated Twice!");

    /* Make sure that the cache-pool's size limit isn't exceeded */
    if ( ce->curCached >= ce->limit ) {
        if ( NULL == cacheMgr->parentAlloc) {
            /* Exceeded; return this buffer to the pool */
            IF_CACHE_STATS( ce->freeReg++; );
            RvLockRelease(&ce->lock, NULL);
            rvPoolNewFreeBlock(
                &ce->pool,
                ((RvAllocCacheControlBlock*)x)-1);
        }
        else {
            /* Exceeded; return this buffer to the parent allocator */
            RvLockRelease(&ce->lock, NULL);
            rvCacheDealloc(cacheMgr->parentAlloc->pool, size, x);
        }
    }
    else {
        /* Add the buffer to the cache */
        RvAllocCacheControlBlock * newBlockCB = ((RvAllocCacheControlBlock*)x) - 1;

        newBlockCB->next = ce->firstBlock;
        IF_CACHE_DEBUG( newBlockCB->size = (RvUint32)size );
        ce->firstBlock = newBlockCB;

        ce->curCached++;
        IF_CACHE_STATS( if ( ce->curCached > ce->peak ) ce->peak = ce->curCached; );
        IF_CACHE_STATS( ce->freeCache++; );

        /* Update the cache-free counter */
        if ( ce->countCacheFree++ >= ce->configLimits->limitLowerTriggerCount ) {
            ce->limit = RvMax(ce->limit - ce->configLimits->limitLowerDelta,
                ce->configLimits->lowerLimit);
            ce->countCacheFree = 0 ;
        }

        RvLockRelease(&ce->lock, NULL);
    }
}

static RvSize_t allocMemoryBlocks(RvAllocCacheEntry * tableEntry, RvUint32 Quantity,
                                RvPoolNew * pool)
{
    RvSize_t count = 0;
    RvAssert( NULL != tableEntry );

    for ( count=0; count<Quantity; ++count) {

        /* Get a block */
        RvAllocCacheControlBlock * block = rvPoolNewAllocBlock(pool);

        if ( NULL == block ) {
            /* Failed to allocate a new block */
            break;
        }

        /* Set it's control block and add it to the list*/
        block->next = tableEntry->firstBlock;
        tableEntry->firstBlock = block;

        tableEntry->curCached++;
    }

    return count;
}

static void freeMemoryBlocks(RvAllocCacheEntry * srcEntry, RvAllocCacheEntry * dstEntry)
{
    while ( NULL != srcEntry->firstBlock ) {

        RvAllocCacheControlBlock * next = srcEntry->firstBlock->next;

        /* Free the block */
        rvPoolNewFreeBlock(&dstEntry->pool, srcEntry->firstBlock);

        srcEntry->firstBlock = next;
    }
}

static RvUint32 transferBlocks(
    IN  RvAllocCacheEntry *         srcEntry,
    IN  RvBool                      srcThreadSafe,
    IN  RvAllocCacheEntry *         dstEntry,
    IN  RvBool                      dstThreadSafe,
    IN  RvUint32                    transferAmount,
    IN  RvBool                      freeSpare,
    IN  RvBool                      allocateMissing)
{
    RvUint32 counter = 0;

    RvAssert( NULL != srcEntry );
    RvAssert( NULL != dstEntry );

    if ( srcThreadSafe ) {
        RvLockGet(&srcEntry->lock, NULL);
    }
    if ( dstThreadSafe ) {
        RvLockGet(&dstEntry->lock, NULL);
    }

    /* Make sure that the transfer won't exceed the entry's limit */
    if ( transferAmount > dstEntry->limit - dstEntry->curCached ) {
        transferAmount = dstEntry->limit - dstEntry->curCached;
    }

    for ( counter=0; counter<transferAmount; ++counter )
    {
        RvAllocCacheControlBlock * tempNext = NULL;

        if ( NULL == srcEntry->firstBlock ) {
            /* No more blocks available at the source */
            break;
        }

        /* TODO (starting simple): the following code can be optimized by
        traversing the first transferAmount members of the srcEntry->firstBlock
        linked-list, and only then inserting them all together into the
        dstEntry->firstBlock list. */

        tempNext = srcEntry->firstBlock->next;
        srcEntry->firstBlock->next = dstEntry->firstBlock;
        dstEntry->firstBlock = srcEntry->firstBlock;
        srcEntry->firstBlock = tempNext;
    }

    /* Update the cache blocks' cached block counters */
    srcEntry->curCached -= counter;
    dstEntry->curCached += counter;
    IF_CACHE_STATS( srcEntry->curUsed += counter );

    if ( RV_FALSE != allocateMissing ) {
        /* Allocate new blocks, if the source didn't have enough */
        RvSize_t allocCount = transferAmount-counter;
        allocCount = allocMemoryBlocks(dstEntry, (RvUint32)allocCount, &srcEntry->pool);
        counter += (RvUint32)allocCount;
        IF_CACHE_STATS( srcEntry->curUsed += (RvUint32)allocCount );
    }

    if ( freeSpare ) {
        freeMemoryBlocks(srcEntry, dstEntry);
    }

    if ( srcThreadSafe ) {
        RvLockRelease(&srcEntry->lock, NULL);
    }
    if ( dstThreadSafe ) {
        RvLockRelease(&dstEntry->lock, NULL);
    }

    return counter;
}

static RvBool initCacheTableEntry(
    OUT RvAllocCacheEntry *         tableEntry,
    IN  RvUint32                    entryIdx,
    IN  const RvAllocCacheConfig*   memoryConfig,
    IN  RvBool                      isThreadSafe,
    IN  RvAlloc *                   allocator)
{
    RvSize_t poolSize = 0;

    /* Sanity Checks */
    RvAssert( NULL != tableEntry );
    RvAssert( CACHE_TABLE_SIZE > entryIdx );
    RvAssert( NULL != memoryConfig );

    /* Initialize the entry's members */
    tableEntry->curCached       = 0;
    tableEntry->countRegAlloc   = 0;
    tableEntry->countCacheFree  = 0;
    tableEntry->limit           = memoryConfig->initialLimit;
    tableEntry->configLimits    = memoryConfig;
    tableEntry->firstBlock      = NULL;
    IF_CACHE_STATS( tableEntry->peak        = 0 );
    IF_CACHE_STATS( tableEntry->curUsed     = 0 );
    IF_CACHE_STATS( tableEntry->allocCache  = 0 );
    IF_CACHE_STATS( tableEntry->allocReg    = 0 );
    IF_CACHE_STATS( tableEntry->freeCache   = 0 );
    IF_CACHE_STATS( tableEntry->freeReg     = 0 );

    /* Create the pool */
    poolSize = CACHE_BLOCK_SIZE_BY_IDX(entryIdx)+sizeof(RvAllocCacheControlBlock);
    if ( NULL == rvPoolNewConstruct(&tableEntry->pool, poolSize,
        0, NULL, NULL, NULL, RV_FALSE, NULL, allocator) )
    {
        return RV_FALSE;
    }

    /* If thread-safty is required, create a lock */
    if ( isThreadSafe )
    {
        RvStatus status = RvLockConstruct(NULL, &tableEntry->lock);
        if ( RV_OK != status )
        {
            /* Failed to create lock; Free the blocks, the pool and leave */
            freeMemoryBlocks(tableEntry, tableEntry);
            rvPoolNewDestruct(&tableEntry->pool);
            return RV_FALSE;
        }
    }

    /* Allocate our memory bocks */
    if (memoryConfig->initialQuantity > 0)
    {
        if ( 0 == allocMemoryBlocks(tableEntry, memoryConfig->initialQuantity, &tableEntry->pool) )
        {
            /* Failed to create the memory blocks; destruct the pool and leave */
            rvPoolNewDestruct(&tableEntry->pool);
            return RV_FALSE;
        }
    }

    return RV_TRUE;
}

static void finishCacheTableEntry(
    OUT RvAllocCacheEntry *         tableEntry,
    IN  RvBool                      isThreadSafe)
{
    /* If thread-safty was required, destroy the lock */
    if ( isThreadSafe )
    {
        (void)RvLockDestruct(&tableEntry->lock, NULL);
    }

    /* Destruct the pool */
    rvPoolNewDestruct(&tableEntry->pool);
}

static RvAlloc * createCacheAllocator(RvAlloc * allocCache, RvAllocCacheManager * cacheMgr)
{
    /* On debug mode, this allocator should try to detected memory block corruptions
    using the rvAllocCanaries module. The caller transparently receives a canary
    allocator that uses the cache allocator as it 'parent' allocator */
#ifndef RV_MTF_PERFORMANCE_ON
    return rvAllocCanariesConstruct(
        allocCache,
        rvAllocConstruct(&cacheMgr->allocForCanary, cacheMgr, ~0U, rvCacheAlloc, rvCacheDealloc) );
#else
    return rvAllocConstruct(allocCache, cacheMgr, ~0U, rvCacheAlloc, rvCacheDealloc);
#endif /* RV_MTF_PERFORMANCE_ON */
}

static RvAllocCacheManager * getCacheManager(RvAlloc * allocCache)
{
    RvAssert( NULL != allocCache );
    RvAssert( NULL != allocCache->pool );

    /* On debug mode, rvAllocCache is wrapped with rvAllocCanaries (see createCacheAllocator). */
#ifndef RV_MTF_PERFORMANCE_ON
    return (RvAllocCacheManager*)rvAllocCanariesGetAllocator(allocCache)->pool;
#else
    return (RvAllocCacheManager*)allocCache->pool;
#endif /*RV_MTF_PERFORMANCE_ON*/
}

#ifndef RV_MTF_PERFORMANCE_ON
static RvAlloc * debugDestructCanary(RvAlloc * allocCache)
{
    RvAlloc * realAllocCache = rvAllocCanariesGetAllocator(allocCache);
    rvAllocCanariesDestruct(allocCache);
    memset(allocCache, 0, sizeof(RvAlloc));
    return realAllocCache;
}
#endif /* RV_MTF_PERFORMANCE_ON */

static RvAlloc * rvAllocCacheGetAllocator(
    IN  RvAlloc *                   allocCache)
{
    return getCacheManager(allocCache)->allocator;
}

static RvAlloc * rvAllocCacheConstruct(
    OUT RvAlloc *                   allocCache,
    IN  RvAlloc *                   allocator,
    IN  const RvAllocCacheConfig *  memoryConfig)
{
    RvAllocCacheManager * cacheMgr = NULL;
    RvSize_t i=0, j=0; /* iterators */

    /* Sanity Checks */
    RvAssert( NULL != allocCache );
    RvAssert( NULL != allocator );
    RvAssert( NULL != memoryConfig );

    /* Construct the cache manager */
    cacheMgr = rvAllocAllocate(allocator, sizeof(RvAllocCacheManager));
    if ( NULL == cacheMgr )
    {
        /* Failed to allocate memory for the cache manager */
        return NULL;
    }
    cacheMgr->allocator     = allocator;
    cacheMgr->parentAlloc   = NULL;

    /* For each entry in the cache table */
    for ( i=0; i<CACHE_TABLE_SIZE; ++i )
    {
        if ( RV_TRUE != initCacheTableEntry(&cacheMgr->cacheTable[i], (RvUint32)i, &memoryConfig[i], RV_TRUE, allocator) )
        {
            /* There's was an error in the creation of this entry; destroy everything. */
            for (j=0; j<i; ++j)
            {
                finishCacheTableEntry(&cacheMgr->cacheTable[i], RV_TRUE);
            }
            rvAllocDeallocate(allocator, sizeof(RvAllocCacheManager), cacheMgr);
            return NULL;
        }
    }

    IF_CACHE_STATS( rvPtrListConstruct(&cacheMgr->subAllocList, cacheMgr->allocator) );

    return createCacheAllocator(allocCache, cacheMgr);
}

#ifndef RV_MTF_PERFORMANCE_ON
static void rvAllocCacheEmitStatsCacheMgr(RvAllocCacheManager * cacheMgr)
{
    RvLogSource * ls = ippLogSource;
    RvLong i=0, memUsed=0, memCached=0;

    RvLogInfo(ls, (ls, "idx     , c.Cached, c.Used  , peak    , limit   , a.Cached, a.Reg   , f.Cached, f.Reg    \n"));
    RvLogInfo(ls, (ls, "-----------------------------------------------------------------------------------------\n"));
    for (i=0; i<CACHE_TABLE_SIZE; ++i)
    {
        RvLogInfo(ls, (ls, "%-8u, %-8u, %-8d, %-8u, %-8u, %-8u, %-8u, %-8u, %-8u\n",
            i,
            cacheMgr->cacheTable[i].curCached,
            cacheMgr->cacheTable[i].curUsed,
            cacheMgr->cacheTable[i].peak,
            cacheMgr->cacheTable[i].limit,
            cacheMgr->cacheTable[i].allocCache,
            cacheMgr->cacheTable[i].allocReg,
            cacheMgr->cacheTable[i].freeCache,
            cacheMgr->cacheTable[i].freeReg
            ));
        memUsed += CACHE_BLOCK_SIZE_BY_IDX(i) * cacheMgr->cacheTable[i].curUsed;
        memCached += CACHE_BLOCK_SIZE_BY_IDX(i) * cacheMgr->cacheTable[i].curCached;
    }
    /* vxWorks 6.3 can't handle flaoting points (causes a crashe), therefore we remove this print until a reasonable solution is found*/
	 /*   RvLogInfo(ls, (ls, "---[ Type: %s; Used:%d(%1.1fM); Cached:%d(%1.1fM); Total:%d:(%1.1fM)]---\n",
	        cacheMgr->parentAlloc ? "Sub-Allocator" : "Global",
	        memUsed, ((float)memUsed)/(1048576.0f),
	        memCached, ((float)memCached)/(1048576.0f),
        memUsed+memCached, ((float)memUsed+memCached)/(1048576.0f)));*/
}
#endif /*RV_MTF_PERFORMANCE_ON*/

void rvAllocCacheEmitStats(RvAlloc * allocCache)
{
#ifndef RV_MTF_PERFORMANCE_ON
    RvPtrListIter listIter;

    RvAllocCacheManager * cacheMgr = getCacheManager(
        allocCache ? allocCache : rvAllocCacheGlobalAcquire());

    /* Display the stats of 'allocCache' */
    rvAllocCacheEmitStatsCacheMgr(cacheMgr);

    /* Display the stats of all of it's sub-allocators */
    if ( ! rvPtrListEmpty(&cacheMgr->subAllocList) ) {
        for(listIter = rvPtrListBegin(&cacheMgr->subAllocList);
            listIter != rvPtrListEnd(&cacheMgr->subAllocList);
            listIter = rvPtrListIterNext(listIter))
        {
            rvAllocCacheEmitStatsCacheMgr( rvPtrListIterData(listIter) );
        }
    }

    if ( NULL == allocCache ) {
        rvAllocCacheGlobalRelease();
    }
#else
    RV_UNUSED_ARG(allocCache)

    RvLogInfo(ippLogSource, (ippLogSource, "MTF Allocator prints resources only without RV_MTF_PERFORMANCE_ON"));
#endif /*RV_MTF_PERFORMANCE_ON*/
}

static void rvAllocCacheDestruct(
    IN RvAlloc *                    allocCache)
{
    RvAllocCacheManager * cacheMgr = NULL;
    RvSize_t i=0;

    /* Sanity tests */
    RvAssert( NULL != allocCache );

    /* On debug mode, destroy the canary allocator */
    IF_CACHE_DEBUG( allocCache = debugDestructCanary(allocCache) );

    /* Get the cache manager */
    cacheMgr = (RvAllocCacheManager*)allocCache->pool;

    /* Destroy the cache table entries */
    for (i=0; i<CACHE_TABLE_SIZE; ++i)
    {
        freeMemoryBlocks(&cacheMgr->cacheTable[i], &cacheMgr->cacheTable[i]);
        finishCacheTableEntry(&cacheMgr->cacheTable[i], RV_TRUE);
    }

    /* Destruct the log source */
#if 0   // logsource
    RvLogSourceDestruct(&cacheMgr->logSource);
#endif

    /* Free the cache manager */
    rvAllocDeallocate(cacheMgr->allocator, sizeof(RvAllocCacheManager), cacheMgr);
}


/************************************************************************/
/* Global Cache Allocator (primarily used the TLS' sub allocators)      */
/************************************************************************/
RvAlloc * rvAllocCacheGlobalAcquire(void)
{
    /* If the cache-allocator wasn't construct before... */
    if ( 0 == globalAllocCache_refCount++ )
    {
        /* Construct the cache-allocator according to the default memory config */
        if ( NULL == rvAllocCacheConstruct(
            &globalAllocCache,
            &rvDefaultAlloc,
            rvDefAllocCacheMemoryConfig) )
        {
            /* Failed to construct the cache allocator */
            RvAssert( 0 );
            return NULL;
        }
    }
    return &globalAllocCache;
}

void rvAllocCacheGlobalRelease(void)
{
    RvAssert( 0 != globalAllocCache_refCount );

    if ( 0 == --globalAllocCache_refCount )
    {
        rvAllocCacheEmitStats(&globalAllocCache);
        rvAllocCacheDestruct(&globalAllocCache);
    }
}

/************************************************************************/
/* TLS Sub-Allocator Support                                            */
/************************************************************************/

static RvAlloc * rvAllocCacheConstructSub(
    OUT RvAlloc *                   subAlloc,
    IN  RvAlloc *                   allocCache,
    IN  const RvAllocCacheConfig *  memoryConfig)
{
    RvAllocCacheManager * cacheMgr = NULL;
    RvAlloc * allocator = rvAllocCacheGetAllocator(allocCache);
    RvSize_t i=0;

    /* Sanity checks */
    RvAssert( NULL != subAlloc );
    RvAssert( NULL != allocCache );

    /* If no memory config was specified; use the default one */
    if ( NULL == memoryConfig )
    {
        memoryConfig = rvDefAllocCacheSubMemoryConfig;
    }

    /* Construct the cache manager */
    cacheMgr = rvAllocAllocate(allocator, sizeof(RvAllocCacheManager));
    if ( NULL == cacheMgr )
    {
        /* Failed to allocate memory for the cache manager */
        return NULL;
    }
    cacheMgr->allocator     = allocator;
    cacheMgr->parentAlloc   = allocCache;

    /* For each entry in the cache-table */
    for ( i=0; i<CACHE_TABLE_SIZE; ++i )
    {
        cacheMgr->cacheTable[i].curCached       = 0;
        cacheMgr->cacheTable[i].countRegAlloc   = 0;
        cacheMgr->cacheTable[i].countCacheFree  = 0;
        cacheMgr->cacheTable[i].limit           = memoryConfig[i].initialQuantity;
        cacheMgr->cacheTable[i].firstBlock      = NULL;
        cacheMgr->cacheTable[i].configLimits    = &memoryConfig[i];

        IF_CACHE_STATS( cacheMgr->cacheTable[i].peak = 0 );
        IF_CACHE_STATS( cacheMgr->cacheTable[i].curUsed = 0 );
        IF_CACHE_STATS( cacheMgr->cacheTable[i].allocCache = 0 );
        IF_CACHE_STATS( cacheMgr->cacheTable[i].allocReg = 0 );
        IF_CACHE_STATS( cacheMgr->cacheTable[i].freeCache = 0 );
        IF_CACHE_STATS( cacheMgr->cacheTable[i].freeReg = 0 );
    }

    subAlloc->pool = cacheMgr;

    /* Borrow memory for the new subAlloc */
    rvAllocCacheSubBorrow(subAlloc, allocCache, memoryConfig);

    IF_CACHE_STATS( rvPtrListConstruct(&cacheMgr->subAllocList, cacheMgr->allocator) );
    IF_CACHE_STATS( rvPtrListPushBack(&getCacheManager(allocCache)->subAllocList, subAlloc->pool) );

    return subAlloc;
}

static void rvAllocCacheDestructSub(
    IN  RvAlloc *                   subAlloc)
{
    RvAllocCacheManager * cacheMgr = NULL;

    /* Sanity tests */
    RvAssert( NULL != subAlloc );

    /* On debug mode, destroy the canary allocator */
    IF_CACHE_DEBUG( subAlloc = debugDestructCanary(subAlloc) );

    /* Get the cache manager */
    cacheMgr = (RvAllocCacheManager*)subAlloc->pool;

    /* Transfer back all the blocks */
    rvAllocCacheSubReturn(subAlloc, cacheMgr->parentAlloc);

    /* Destruct the log source */
#if 0 // logsource?
    RvLogSourceDestruct(&cacheMgr->logSource);
#endif

    /* If collecting stats: Free from the sub-alloc list */
    IF_CACHE_STATS( rvPtrListPushBack(&getCacheManager(cacheMgr->parentAlloc)->subAllocList, subAlloc) );

    /* Free the cache manager */
    rvAllocDeallocate(cacheMgr->allocator, sizeof(RvAllocCacheManager), cacheMgr);
}

void rvAllocCacheSubBorrow(
    IN  RvAlloc *                   subAlloc,
    IN  RvAlloc *                   allocCache,
    IN  const RvAllocCacheConfig *  memoryConfig)
{
    RvSize_t i=0;

    /* Sanity checks */
    RvAssert( NULL != subAlloc );
    RvAssert( NULL != allocCache );
    RvAssert( NULL != memoryConfig );

    for ( i=0; i<CACHE_TABLE_SIZE; ++i )
    {
        transferBlocks(
            &getCacheManager(allocCache)->cacheTable[i],
            RV_TRUE,
            &getCacheManager(subAlloc)->cacheTable[i],
            RV_FALSE,
            memoryConfig[i].initialQuantity,
            RV_FALSE, /* don't free spare blocks */
            RV_TRUE /* allocate new blocks if needed */
            );
    }
}

void rvAllocCacheSubReturn(
    IN  RvAlloc *                   subAlloc,
    IN  RvAlloc *                   allocCache)
{
    RvSize_t i=0;

    for ( i=0; i<CACHE_TABLE_SIZE; ++i )
    {
        transferBlocks(
            &getCacheManager(subAlloc)->cacheTable[i],
            RV_FALSE,
            &getCacheManager(allocCache)->cacheTable[i],
            RV_TRUE,
            ~0U, /* transfer everything */
            RV_TRUE, /* free spare blocks */
            RV_FALSE /* don't allocate new blocks */
            );
    }
}

RvBool rvCacheAllocTlsInit()
{
    RvStatus status = RV_FALSE;

    /* Create the TLS variable */
    status = RvThreadCreateVar(rvCacheAllocTlsVarDestructor, RV_TLSSUBALLOC_VARNAME,
        NULL, &rvAllocCacheTlsIndex);

    return ( RV_OK == status );
}

void rvCacheAllocTlsFinish()
{
    /* Destroy the TLS variable */
    (void)RvThreadDeleteVar(rvAllocCacheTlsIndex, NULL);
}

static RvBool rvCacheAllocTlsVarConstructor(
    OUT     void **                         pPoolPtr)
{
    RvAlloc subAlloc;

    /* Create a new sub allocator */
    if ( NULL == rvAllocCacheConstructSub(&subAlloc, rvAllocCacheGlobalAcquire(), NULL) )
    {
        /* Failed to create the sub allocator */
        return RV_FALSE;
    }

    /* Save the sub-allocators' pool in the TLS */
    if ( RV_OK != RvThreadSetVar(rvAllocCacheTlsIndex, subAlloc.pool, NULL) )
    {
        /* Failed to set the TLS var */
        rvAllocCacheDestructSub(&subAlloc);
        rvAllocCacheGlobalRelease();
        return RV_FALSE;
    }

    /* Success */
    *pPoolPtr = subAlloc.pool;
    return RV_TRUE;
}

static void rvCacheAllocTlsVarDestructor(
    IN      RvThread *                      thread,
    IN      void *                          data,
    IN      RvUint32                        index)
{
    RV_UNUSED_ARG( thread );
    RV_UNUSED_ARG( index );

    /* Destruct the cache sub allocator if it was created. */
    if ( NULL != data )
    {
        RvAlloc stubAlloc;

        /* Destruct the sub allocator */

        stubAlloc.pool = data;
        rvAllocCacheDestructSub(&stubAlloc);

        /* Decrease the ref. count on the global allocator */
        rvAllocCacheGlobalRelease();
    }
}

static RvAllocCacheManager * rvCacheAllocGetMgrFromTls(void)
{
    RvAllocCacheManager * cacheMgr = NULL;

    /* Get the cacheMgr from the TLS */
    if ( RV_OK == RvThreadGetVar(rvAllocCacheTlsIndex, NULL, (void**)&cacheMgr) )
    {
        /* If it equals to NULL, we need to construct it */
        if ( NULL == cacheMgr )
        {
            /* Construct a new cacheMgr for this thread */
            (void)rvCacheAllocTlsVarConstructor((void**)&cacheMgr);
        }
    }
    return cacheMgr;
}

static void * rvCacheAllocSub(void * pool, RvSize_t size)
{
    RvAllocCacheManager * cacheMgr  = rvCacheAllocGetMgrFromTls(); /* our cacheMgr (from the TLS) */
    RvAllocCacheEntry * ce          = NULL; /* the maching cache entry */
    RvSize_t tblIdx                 = 0;
    void * resPtr                   = NULL;
    RvAllocCacheControlBlock * oldFirstBlock;

    RV_UNUSED_ARG(pool);
    if ( NULL == cacheMgr ) return NULL;

    /* Find the suiteable cache-table index for 'size' */
    size |= CACHE_BLOCK_GROUP_BITMASK;
    if ( CACHE_SIZE_LIMIT <= size )
    {
        /* This allocator only caches small blocks; Bigger blocks go directly
        to the regular allocator. */
        return rvAllocAllocate(cacheMgr->allocator, size);
    }
    tblIdx = CACHE_IDX_BY_BLOCK_SIZE(size);

    /* Get pointers to the cacheMgr and the matching cache table entry */
    ce = &cacheMgr->cacheTable[tblIdx];

    /* If there are no blocks at the cache, get new ones from the parent cache
    allocator */
    if ( NULL == ce->firstBlock )
    {
        if ( 0 == transferBlocks(
            &getCacheManager(cacheMgr->parentAlloc)->cacheTable[tblIdx],
            RV_TRUE,                            /* parent is thread safe */
            ce,
            RV_FALSE,                           /* we're not thread safe */
            ce->configLimits->initialQuantity,
            RV_FALSE,                           /* don't free spare blocks*/
            RV_TRUE                             /* allocate new blocks */
            ) )
        {
            /* Failed to transfer any blocks */
            return NULL;
        }

        /* Update the alloc-reg(no-cache) counter */
        if ( ce->countRegAlloc++ >= ce->configLimits->limitRaiseDelta ) {
            ce->limit = RvMin(ce->limit + ce->configLimits->limitRaiseDelta,
                ce->configLimits->upperLimit);
            ce->countRegAlloc = 0 ;
        }

        IF_CACHE_STATS( ce->allocReg += 10 );
    }

    IF_CACHE_DEBUG( ce->firstBlock->size = (RvUint32)size );

    resPtr = ce->firstBlock + 1;

    oldFirstBlock = ce->firstBlock;
    ce->firstBlock = ce->firstBlock->next;

    oldFirstBlock->next = NULL;
    ce->curCached--;

    IF_CACHE_STATS( ce->curUsed++ );
    IF_CACHE_STATS( ce->allocCache++ );

    return resPtr;
}

static void rvCacheDeallocSub(void * pool, RvSize_t size, void * x)
{
    RvAllocCacheManager * cacheMgr  = rvCacheAllocGetMgrFromTls(); /* our cacheMgr (from the TLS) */
    RvAllocCacheEntry * ce          = NULL; /* the matching cache entry */
    RvSize_t tblIdx                 = 0;

    RV_UNUSED_ARG(pool);
    if ( NULL == cacheMgr ) return;

    /* Find the suiteable cache-table index for 'size' */
    size |= CACHE_BLOCK_GROUP_BITMASK;
    if ( CACHE_SIZE_LIMIT <= size )
    {
        /* This allocator only caches small blocks. */
        rvAllocDeallocate(cacheMgr->allocator, size, x);
        return;
    }
    tblIdx = CACHE_IDX_BY_BLOCK_SIZE(size);

    /* Get pointers to the cacheMgr and the matching cache table entry */
    ce = &cacheMgr->cacheTable[tblIdx];

    /* A macro to detected double deallocation */
    RvAssert((NULL == (((RvAllocCacheControlBlock*)x)-1)->next) && "Deallocated Twice!");

     /* Make sure we table entry's cache amount doesn't exceed it's limit */
    if ( ce->curCached >= ce->limit )
    {
        /* We're not allowed to cache this block; pass it the parent allocator */
        rvCacheDealloc( getCacheManager(cacheMgr->parentAlloc), size, x);
        IF_CACHE_STATS( ce->freeReg++; );
    }
    else
    {
        /* Add the block to the cache */
        RvAllocCacheControlBlock * newBlockCB = ((RvAllocCacheControlBlock*)x) - 1;

        newBlockCB->next = ce->firstBlock;
        IF_CACHE_DEBUG( newBlockCB->size = (RvUint32)size );
        ce->firstBlock = newBlockCB;

        ce->curCached++;
        IF_CACHE_STATS( if ( ce->curCached > ce->peak ) ce->peak = ce->curCached; );
        IF_CACHE_STATS( ce->freeCache++; );

        /* Update the cache-free counter */
        if ( ce->countCacheFree++ >= ce->configLimits->limitLowerTriggerCount ) {
            ce->limit = RvMax(ce->limit - ce->configLimits->limitLowerDelta,
                ce->configLimits->lowerLimit);
            ce->countCacheFree = 0 ;
        }
    }

    IF_CACHE_STATS( ce->curUsed-- );
}
