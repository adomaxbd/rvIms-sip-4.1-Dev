/*****************************************************************************
Filename: rvpoolnew.c
Description: Replacement candidate for rvPool.
******************************************************************************
                      Copyright (c) 2006 RADVision Inc.
******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision Inc.
No part of this publication may be reproduced in any form whatsoever without
written prior approval by RADVision Inc.

RADVision Inc. reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************
$Revision: $
$Date: $ 
$Author: Amir Shavit$
*****************************************************************************/
#include "rvpoolnew.h"
#include "rvassert.h"
#include "rvmemory.h"
#include "ipplog.h"

/************************************************************************/
/* Private Definitions                                                  */
/************************************************************************/

/* Policy for determining the number of blocks per page */
#define RV_POOLNEW_MINBLOCKSPERPAGE (2)         /* Min nu# of blocks per page */
#define RV_POOLNEW_MAXBLOCKSPERPAGE (256)       /* Max nu# of blocks per page */ 
#define RV_POOLNEW_MAXPAGESIZE      (1 * 128) /* Maximum page size */

/* Remove a RvPoolNewPage from it's linked-list */
#define RV_POOLNEW_REMOVEPAGE(page, pool, binIdx)                               \
    if ( page->prev) {                                                          \
        page->prev->next = page->next;                                          \
    } else {                                                                    \
        pool->bins[binIdx] = page->next;                                        \
    }                                                                           \
    if ( page->next ) {                                                         \
        page->next->prev = page->prev;                                          \
    }

/* Insert a RvPoolNewPage into a RvPoolNew's bin */
#define RV_POOLNEW_INSERTPAGE(page, pool, binIdx)                               \
    page->next = pool->bins[binIdx];                                            \
    page->prev = NULL;                                                          \
    pool->bins[binIdx] = page;                                                  \
    if ( page->next ) {                                                         \
        page->next->prev = page;                                                \
    }

#define RV_POOLNEW_GETBINIDX(page, pool)                                        \
    (((page->availableBlocks*RV_POOLNEW_BIN_COUNT)/((pool->blocksPerPage+1)*RV_POOLNEW_BIN_COUNT))+\
    (page->availableBlocks != 0));
    

/************************************************************************/
/* Implementation                                                       */
/************************************************************************/

/* If blocksPerPage isn't given to the constructor, this function 
calculates a value for it */
static RvSize_t rvPoolNewCalcBlocksPerPage(
    IN      RvSize_t                        blockSize) 
{
    RvSize_t blocksPerPage = 
        (RV_POOLNEW_MAXPAGESIZE - sizeof(RvPoolNewPage)) / 
        (sizeof(RvPoolNewBlock)+blockSize);

    if ( blocksPerPage < RV_POOLNEW_MINBLOCKSPERPAGE ) {
        blocksPerPage  = RV_POOLNEW_MINBLOCKSPERPAGE;
    }

    if ( blocksPerPage > RV_POOLNEW_MAXBLOCKSPERPAGE ) {
        blocksPerPage = RV_POOLNEW_MAXBLOCKSPERPAGE;
    }

    return blocksPerPage;
}

/* Constructor */
RvPoolNew* rvPoolNewConstruct(
    OUT     RvPoolNew *                     pool,
    IN      RvSize_t                        blockSize,
    IN      RvSize_t                        blocksPerPage,  /* can be zero */
    IN      RvPoolNewCtorCB                 ctor,           /* can be NULL */
    IN      RvPoolNewDtorCB                 dtor,           /* can be NULL */
    IN      void *                          data,           /* can be NULL */
    IN      RvBool                          freeUnusedPages,
    IN      RvLogMgr *                      logMgr,
    IN      RvAlloc *                       alloc)
{
    RvSize_t i=0;
    
    RvAssert( NULL != pool );   
    RvAssert( NULL != alloc );
    RvAssert( 0 < blockSize );

    /* Create a lock for the pool */
    if ( RV_OK != RvLockConstruct(logMgr, &pool->lock) ) {
        /* Failed to create the pool's lock */
        return NULL;
    }

    /* Initalize the pool */
    pool->blockSize         = RvAlignValue(blockSize);
    pool->blocksPerPage     = blocksPerPage ? blocksPerPage : rvPoolNewCalcBlocksPerPage(pool->blockSize);
    pool->ctor              = ctor;
    pool->dtor              = dtor;
    pool->data              = data;
    pool->freeUnusedPages   = freeUnusedPages;
    pool->logMgr            = logMgr;
    pool->alloc             = alloc;
        
    for ( i=0; i<RV_POOLNEW_BIN_COUNT+1; ++i ) {
        pool->bins[i] = NULL;
    }

    pool->realPageSize = sizeof(RvPoolNewPage) + (sizeof(RvPoolNewBlock)+pool->blockSize) * pool->blocksPerPage;

    return pool;
}

/* Destructor (RvAsserts memory leaks) */
void rvPoolNewDestruct(
    IN      RvPoolNew *                     pool)
{
    RvSize_t i = 0;
 
    RvAssert( NULL != pool );
 
    /* For each bin (0..RV_POOLNEW_BIN_COUNT) */
    for ( i=0; i<=RV_POOLNEW_BIN_COUNT; ++i )
    {
        /* Free all pages */
        while ( NULL != pool->bins[i] )
        {
            RvPoolNewPage * next = pool->bins[i]->next;
            rvAllocDeallocate(pool->alloc, pool->realPageSize, pool->bins[i]);
            pool->bins[i] = next;
        }
    }
 
    /* Destruct the pool's lock */
    RvLockDestruct(&pool->lock, pool->logMgr);
}

/* Assumes that the pool's mutex is locked */
static RvPoolNewBlock * rvPoolNewAllocBlockFromNewPage(
    IN      RvPoolNew *                     pool)
{  
    char * newPage = NULL;
    RvPoolNewPage * pageHdr = NULL;
    RvPoolNewBlock * blockHdr = NULL;
    RvSize_t i = 0;

    RvAssert( NULL != pool );

    /* Allocate a memory buffer for the page */
    newPage = rvAllocAllocate(pool->alloc, pool->realPageSize);
    if ( NULL == newPage ) {
        /* Failed to allocate page */
        return NULL;
    }

    /* Initialize the page and it's blocks */
    pageHdr = (RvPoolNewPage*)newPage;
    blockHdr = (RvPoolNewBlock*)(pageHdr+1);

    pageHdr->availableBlocks = pool->blocksPerPage;
    pageHdr->blockList = blockHdr;

    for ( i=0; i<pool->blocksPerPage; ++i ) {
        blockHdr->next = (RvPoolNewBlock*)(((char*)blockHdr) + sizeof(RvPoolNewBlock) + pool->blockSize);
        blockHdr->page = pageHdr;
        blockHdr = blockHdr->next;
    }

    /* Take the first page (this could've been done earlier, but I chose readability over it) */
    blockHdr = pageHdr->blockList;
    pageHdr->blockList = pageHdr->blockList->next;
    pageHdr->availableBlocks--;
    
    /* Add the page to the last bin */
    RV_POOLNEW_INSERTPAGE(pageHdr, pool, RV_POOLNEW_BIN_COUNT);

    return blockHdr;
}

/* Block Allocator */
void * rvPoolNewAllocBlock(
    IN OUT  RvPoolNew *                     pool)
{
    RvSize_t binIdx = 0, newIdx = 0;
    RvPoolNewPage * page = NULL;
    RvPoolNewBlock * newBlock = NULL;

    RvAssert( NULL != pool );

    RvLockGet(&pool->lock, pool->logMgr);

    /* Go through all bins; Start with the one that has the least number of free blocks */
    for ( binIdx=1; binIdx<RV_POOLNEW_BIN_COUNT+1; ++binIdx ) {
    
        /* Get the first page from the bin */
        page = pool->bins[binIdx];
        if ( NULL == page ) {
            /* The bin empty, continue to the next bin */
            continue;
        }

        RvAssert( 0 != page->availableBlocks ); /* Empty pools are only in bin#0 */

        /* Get a block from the page */
        newBlock = page->blockList;
        page->blockList = newBlock->next;
        page->availableBlocks--;

        /* If necessary, more the page into a lower bin */
        newIdx = RV_POOLNEW_GETBINIDX(page, pool);
        if ( newIdx != binIdx ) {
            RV_POOLNEW_REMOVEPAGE(page, pool, binIdx);
            RV_POOLNEW_INSERTPAGE(page, pool, newIdx);
        }

        /* And we're done */
        break;
    }

    /* If we couldn't find a block, try to get one from a new page */
    if ( NULL == newBlock ) {
        newBlock = rvPoolNewAllocBlockFromNewPage(pool);
    }

    RvLockRelease(&pool->lock, pool->logMgr);

    /* If we finally got a block, call the user's constructor */
    if ( NULL != newBlock ) {
        if ( pool->ctor ) {
            pool->ctor(newBlock+1, pool->data);
        }
        return newBlock+1;
    }
    else {
        /* Failure */
        return NULL;
    }
}

/* Block Deallocator */
void rvPoolNewFreeBlock(
    IN OUT  RvPoolNew *                     pool,
    IN      void *                          ptr)
{
    RvPoolNewBlock * block;
    RvPoolNewPage * page;
    RvSize_t curIdx, newIdx;

    /* Sanity checks */
    RvAssert( NULL != pool );
    RvAssert( NULL != ptr );

    /* Call the block's destructor */
    if ( pool->dtor ) {
        pool->dtor(ptr, pool->data);
    }

    block = (RvPoolNewBlock*)ptr - 1;
    page = block->page;

    RvLockGet(&pool->lock, pool->logMgr);

    /* Insert the block back into it's page */
    curIdx = RV_POOLNEW_GETBINIDX(page, pool);
    block->next = page->blockList;
    page->blockList = block;
    page->availableBlocks++;

    /* If all blocks are available, free the page, unless there are no pages in the last bin */
    if (pool->freeUnusedPages &&
        page->availableBlocks == pool->blocksPerPage && NULL != pool->bins[RV_POOLNEW_BIN_COUNT] &&
        (page != pool->bins[RV_POOLNEW_BIN_COUNT] || page->next ) ) 
    {
        RV_POOLNEW_REMOVEPAGE(page, pool, RV_POOLNEW_BIN_COUNT);
        rvAllocDeallocate(pool->alloc, pool->realPageSize, page);
    }
    else {
        /* If necessary, move the page into a higher bin */
        newIdx = RV_POOLNEW_GETBINIDX(page, pool)
        if ( newIdx != curIdx ) {
            RV_POOLNEW_REMOVEPAGE(page, pool, curIdx);
            RV_POOLNEW_INSERTPAGE(page, pool, newIdx);
        }
    }

    RvLockRelease(&pool->lock, pool->logMgr);
}
