/*****************************************************************************
Filename: rvalloccanaries.c
Description: Allocator adaptor for detection of memory corruptions
******************************************************************************
                      Copyright (c) 2006 RADVision Inc.
******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision Inc.
No part of this publication may be reproduced in any form whatsoever without
written prior approval by RADVision Inc.

RADVision Inc. reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************
$Revision:$
$Date:$
$Author: Amir Shavit
*****************************************************************************/
#define LOGSRC	LOGSRC_UTIL
#include <string.h>
#include "rvalloccanaries.h"
#include "rvassert.h"
#include "rvmemory.h"
#include "ipplog.h"

/************************************************************************/
/* CANARY   | LENGTH   | BUFFER                              | CANARY   */
/* RvUint32 | RvUint32 | Variable Length (LENGTH)            | RvUint32 */
/************************************************************************/

static void * rvAllocCanariesAllocator(void * pool, RvSize_t size)
{
    RvAlloc * baseAlloc = NULL;
    char * ptr = NULL;                      /* holds the new buffer */
    RvUint32 canary = 0;                    /* the canary's ("cookie") value */

	baseAlloc = (RvAlloc*)pool;             /* the base (parent) allocator */
    /* Sanity test */
    RvAssert( NULL != baseAlloc );

    /* Generate a random value for the canary */
    canary = 0xdeadbeef; /* TODO: that's not random! */

    /* Allocate the requested buffer */
    ptr = rvAllocAllocate(baseAlloc, size + 3*sizeof(RvUint32));

    if ( NULL == ptr ) {
        return ptr;
    }

    /* Place the canaries */
    *(RvUint32*)(ptr) = *(RvUint32*)(ptr+size+2*sizeof(RvUint32)) = canary;

    /* And the size */
    *(RvUint32*)(ptr+sizeof(RvUint32)) = (RvUint32)size;

    /* ...and return the buffer in between */
    return ptr + 2*sizeof(RvUint32);
}

static void rvAllocCanariesDeallocator(void * pool, RvSize_t size, void * x)
{
    RvAlloc * baseAlloc = NULL;

	baseAlloc = (RvAlloc*)pool;   /* the base (parent) allocator */
    /* Sanity tests */
    RvAssert( NULL != baseAlloc );
    RvAssert( NULL != x );

    /* If the reported size is incorrect, then there's a problem... */
    RvAssert( size == *( ((RvUint32*)x)-1 ) );

    /* Check the canaries (a little obfuscated...) */
    if ( *( ((RvUint32*)x)-2 ) != *((RvUint32*)(((char*)x)+size)) ) {
        /* Gotcha! memory corruption */
        RvAssert( 0 && "Memory Corruption Detected" );
    }
    else {
        /* Everything is ok, erase the buffer (on debug mode) and free it */
#if defined(RV_DEBUG)
        memset(x, 0xe1, size);
#endif
        rvAllocDeallocate(
            baseAlloc,
            size + 3*sizeof(RvUint32),  /* including our data */
            ((RvUint32*)x)-2);          /* revert to original ptr. */
    }
}

RvAlloc * rvAllocCanariesConstruct(RvAlloc * alloc, RvAlloc * baseAlloc)
{
    RvAssert( NULL != alloc );
    RvAssert( NULL != baseAlloc );

    alloc->pool     = baseAlloc;
    alloc->maxSize  = ~0U;
    alloc->alloc    = rvAllocCanariesAllocator;
    alloc->dealloc  = rvAllocCanariesDeallocator;
    return alloc;
}

RvAlloc * rvAllocCanariesGetAllocator(RvAlloc * alloc)
{
    RvAssert( NULL != alloc );

    return alloc->pool;
}

void rvAllocCanariesDestruct(RvAlloc * alloc)
{
    RvAssert( NULL != alloc );

    /* Set invalid values */
    alloc->pool     = NULL;
    alloc->maxSize  = 0;
    alloc->alloc    = NULL;
    alloc->dealloc  = NULL;
}
