/*****************************************************************************
Filename: mtfalloc.c
Description:
******************************************************************************
                      Copyright (c) 2006 RADVision Inc.
******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision Inc.
No part of this publication may be reproduced in any form whatsoever without
written prior approval by RADVision Inc.

RADVision Inc. reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************
$Revision: $
$Date: $
$Author: Amir Shavit$
*****************************************************************************/
#define LOGSRC  LOGSRC_UTIL
#include "ipp_inc_std.h"
#include "rvmtfalloc.h"



#if defined (RV_DEBUG)
static RvInt totalAllocatedMtf = 0;
#endif

#ifdef RV_MTF_USE_CACHE_ALLOCATOR

static RvAlloc *gs_pMtfDefAlloc = NULL;

/* Initializes the cache allocator module */
RVCOREAPI RvBool rvMtfAllocatorInit(void)
{
    gs_pMtfDefAlloc = rvAllocCacheGlobalAcquire();
    return ( NULL == gs_pMtfDefAlloc ) ? RV_TRUE : RV_TRUE;
}


/* Returns a handle to the a TLS allocator */
RVCOREAPI RvAlloc* rvMtfAllocatorGet()
{
    return gs_pMtfDefAlloc;
}

/* Finalizes the cache allocator module */
RVCOREAPI void rvMtfAllocatorFinish(void)
{
    rvAllocCacheGlobalRelease();
}

#endif /* RV_MTF_USE_CACHE_ALLOCATOR*/

/* Deallocates memory*/
RVCOREAPI RvBool rvMtfAllocatorDealloc(IN void *ptr, RvSize_t size)
{
#ifndef RV_MTF_USE_CACHE_ALLOCATOR
    RV_UNUSED_ARG(size);
    /* RvMemoryFree calls direct OS function, and will enable printing of unreleased memory in shutdown */
    RvMemoryFree(ptr, IppLogMgr());
#else
    /* rvAllocDeallocate uses our Cache Allocator instead of direct OS calls */
    rvAllocDeallocate(rvMtfAllocatorGet(), size, ptr);
#if defined (RV_DEBUG)
    totalAllocatedMtf -= size;
#endif /* RV_DEBUG */
#endif /* RV_MTF_USE_CACHE_ALLOCATOR*/

    return rvTrue;
}

#if defined (RV_DEBUG)
RVCOREAPI RvInt rvMtfGetTotalAllocsFromCacheAllocator()
{
    return totalAllocatedMtf;

}

void rvMtfIncreaseTotalAllocs(RvInt size)
{
   
    totalAllocatedMtf += size;
    
}
#endif


