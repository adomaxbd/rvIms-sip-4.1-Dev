#if (0)
******************************************************************************
Filename    :
Description :
******************************************************************************
                Copyright (c) 1999 RADVision Inc.
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision LTD.
No part of this publication may be reproduced in any form whatsoever 
without written prior approval by RADVision LTD..

RADVision LTD. reserves the right to revise this publication and make 
changes without obligation to notify any person of such revisions or 
changes.
******************************************************************************
$Revision:$
$Date:$
$Author: S. Cipolli$
******************************************************************************
#endif

#include "rvptrlist.h"

rvDefineList(RvVoidPtr)

/* these functions didn't pass the porting well, however are not used
in IPP, so meanwhile commented */
/*rvDefineListRemoveIf(RvVoidPtr)

RvVoidPtr rvPtrListFront(RvPtrList* l) {
	return *rvListFront(l);
}
RvVoidPtr rvPtrListBack(RvPtrList* l) {
	return *rvListBack(l);
}
void rvPtrListPushFront(RvPtrList* l, RvVoidPtr x) {
	RvVoidPtr* rx = &x;
	rvListPushFront(RvVoidPtr)(l, rx);
}

RvPtrListIter rvPtrListInsert(RvPtrList* l, RvPtrListIter i, RvVoidPtr x) 
{	
	RvVoidPtr* rx = &x;
	return rvListInsert(RvVoidPtr)(l, i, rx);
}


  RvVoidPtr rvPtrListPopFront( RvPtrList* l)	
{	
	RvVoidPtr rx = (RvVoidPtr)rvListFront( l);
	rvListPopFront(RvVoidPtr)(l);
	return rx; 

}

*/
void rvPtrListPushBack(RvPtrList* l, RvVoidPtr x)	
{	
	RvVoidPtr* rx = &x;
	rvListPushBack(RvVoidPtr)(l, rx);
}

RvPtrListIter rvPtrListRemove(RvPtrList* l, RvVoidPtr x) 
{	
	RvVoidPtr* rx = &x;
	return rvListRemove(RvVoidPtr)(l, rx);
}




