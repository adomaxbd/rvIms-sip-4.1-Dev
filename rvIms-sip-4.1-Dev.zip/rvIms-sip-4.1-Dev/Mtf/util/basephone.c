/******************************************************************************
Filename   : basePhone.c
Description: Base Phone Header
******************************************************************************
                Copyright (c) 2005 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************
$Revision:$
$Date:	 02.01.05$
$Author: Mark Appel$
******************************************************************************/
#define LOGSRC	LOGSRC_UTIL
#include "ipp_inc_std.h"

#include "basephone.h"
#include "rvccterminalmdm.h"
#include "rvccprovidermdm.h"
#include "rvccconnmdm.h"
#include "rvmdmtermevent.h"


/*GLOBALS*/
/*********/
RvCCBasePhone g_basePhone;

/******************************************************************************
*  rvCCBasePhoneConstruct
*  ---------------------------------
*  General :
*
*
******************************************************************************/
void rvCCBasePhoneConstruct(RvCCBasePhone* x)
{
	memset(x,0,sizeof(RvCCBasePhone));

	rvCCCallMgrConstructA(&x->callMgr, prvDefaultAlloc);
}

/******************************************************************************
*  rvCCBasePhoneDestruct
*  ---------------------------------
*  General :
*
*
******************************************************************************/
void rvCCBasePhoneDestruct(RvCCBasePhone* x)
{
	rvCCCallMgrDestruct(&x->callMgr);
}

/**********************************************************************************
						G E T T E R S / S E T T E R S
**********************************************************************************/

/******************************************************************************
*  rvCCBasePhoneGetBasePhone
*  ---------------------------------
*  General : returns Base Phone
*
*
******************************************************************************/
RvCCBasePhone*	rvCCBasePhoneGetBasePhone(void)
{
	return &g_basePhone;
}

/******************************************************************************
*  rvCCBasePhoneGetCallMgr
*  ---------------------------------
*  General : returns Call Manager
*
*
******************************************************************************/
RvCCCallMgr*	rvCCBasePhoneGetCallMgr(void)		
{ 
	return &g_basePhone.callMgr;
}

/******************************************************************************
*  rvCCBasePhoneGetMdmProvider
*  ---------------------------------
*  General : returns MDM provider
*
*
******************************************************************************/
RvCCProvider*	rvCCBasePhoneGetMdmProvider(void)	
{ 
	return &(g_basePhone.pmdmProvider);
}

/******************************************************************************
*  rvCCBasePhoneGetNetProvider
*  ---------------------------------
*  General : returns network provider (h323 or sip)
*
*
******************************************************************************/
RvCCProvider*	rvCCBasePhoneGetNetProvider_(int provider)	
{ 
	return &g_basePhone.pnetProvider[provider];
}

RvBool	rvCCBasePhoneIsUsed_(int provider)
{
	return g_basePhone.usedProvider[provider];
}
void	rvCCBasePhoneUse_(int provider)
{
	g_basePhone.usedProvider[provider]=RV_TRUE;
}
