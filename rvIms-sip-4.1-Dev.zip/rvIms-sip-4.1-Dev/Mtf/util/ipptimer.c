/******************************************************************************
Filename   : ipptimer.c
Description: Implements Mdm Connection Object
******************************************************************************
                Copyright (c) 2001 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************
$Revision:$
$Date:   16.06.04$
$Author: Mark Appel$
******************************************************************************/
#define LOGSRC  LOGSRC_UTIL
#include "ipp_inc_std.h"
#include "rvselect.h"
#include "ipptimer.h"

/*********************************************************************/
static RvTimerQueue *g_timerQ;

static RvSelectEngine *g_selectEngine;




RvStatus IppTimerConstruct(
                            IppTimer* t,
                            RvUint32   ms,
                            RvTimerFunc func,
                            void* userdata
                            )
{
    if (ms == 0) ms = 1;

    memset(&t->timer, 0, sizeof(t->timer));
    t-> delay     = (RvInt64)ms * (RvInt64)1000000;
    t-> callback  = func;
    t-> userdata = userdata;

    RvLogDebug(ippLogSource, (ippLogSource,  "IppTimerConstruct: t=%p, delay(msec)=%d, ms=%d", &t->timer, (t->delay)/1000000, ms));

    return RV_OK;
}

/*********************************************************************/
RvStatus IppTimerDestruct(IppTimer* t)
{
    RvStatus rc;

    if ((rc = IppTimerStop(t)) != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,  "IppTimerDestruct Failed: t=%p, delay(msec)=%d, error=%d", &t->timer, (t->delay)/1000000, rc));
    }
    else
    {
        RvLogDebug(ippLogSource, (ippLogSource,  "IppTimerDestruct Succeeded: t=%p, delay(msec)=%d", &t->timer, (t->delay)/1000000));
    }

    memset(t, 0, sizeof(IppTimer));
    return RV_OK;
}

/*********************************************************************/
RVAPI RvStatus RVCALLCONV IppTimerStart(
    IN IppTimer*            t,
    IN IppIfAlreadyStarted  ifAlreadyStarted,
    IN RvUint32             msDelay) /* if 0 then t->delay is used */
{
    RvStatus    rc      = RV_OK;
	RvInt64		nsDelay;

    switch(ifAlreadyStarted)
    {
        case    IPP_TIMER_RETURN_IF_STARTED:
            nsDelay = ((msDelay)? (RvInt64FromRvUint32(msDelay)*1000000) : t->delay);
            rc = RvTimerStart(
                &t->timer,
                g_timerQ,
                RV_TIMER_TYPE_ONESHOT,
                nsDelay,
                t->callback,
                t->userdata);           
            break;

        case    IPP_TIMER_RESTART_IF_STARTED:
            rc = RvTimerCancel( &t->timer, RV_TIMER_CANCEL_DONT_WAIT_FOR_CB);
            
			/* No break!!! */

        case    IPP_TIMER_DONT_CHECK_IF_STARTED:
            if(rc==RV_OK || (RvErrorGetCode(rc)== RV_TIMER_WARNING_BUSY))
            {
                nsDelay = ((msDelay)? (RvInt64FromRvUint32(msDelay)*1000000) : t->delay);
                rc = RvTimerStart(
                                    &t->timer,
                                    g_timerQ,
                                    RV_TIMER_TYPE_ONESHOT,
                                    nsDelay,
                                    t->callback,
                                    t->userdata);
            }
            else
            {
                RvLogError(ippLogSource, (ippLogSource,  "IppTimerStart: RvTimerCancel Failed, error=%d, ifAlreadyStarted=%d", rc, ifAlreadyStarted));
            }
    }

    if (rc != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,  "IppTimerStart: RvTimerStart Failed, error=%d, ifAlreadyStarted=%d", rc, ifAlreadyStarted));
    }

    else
    {
        RvLogDebug(ippLogSource, (ippLogSource,  "IppTimerStart: RvTimerStart Succeeded: t=%p, delay(msec)=%d, msDelay=%d, ifAlreadyStarted=%d", &t->timer, (t->delay)/1000000, msDelay, ifAlreadyStarted));
    }

  return rc;
}

/*********************************************************************/
RvStatus IppTimerStop(IppTimer* t)
{
    RvStatus    rc = RV_OK;

 
    rc = RvTimerCancel( &t->timer, RV_TIMER_CANCEL_DONT_WAIT_FOR_CB);
    if (rc != RV_OK)
    {
        /* RV_TIMER_WARNING_BUSY is not really an error, since it only means that timer callback is currently
		   executed. In this case, after calling RvTimerCancel() the timer won't wake anymore and that 
		   was the sole purpose of RvTimerCancel().*/
        if (RvErrorGetCode(rc) == RV_TIMER_WARNING_BUSY)
        {
            RvLogDebug(ippLogSource, (ippLogSource,  "IppTimerStop: RvTimerCancel Succeeded (returned RV_TIMER_WARNING_BUSY), t=%p, error=%d", &t->timer, rc));
        }
        else
        {
            RvLogError(ippLogSource, (ippLogSource,  "RvTimerCancel failed error %d", RvErrorGetCode(rc)));
        }
    }
    else
    {
        RvLogDebug(ippLogSource, (ippLogSource,  "IppTimerStop: RvTimerCancel Succeeded, t=%p", &t->timer));
    }

    memset( &t->timer, 0, sizeof( t->timer));

    return rc;
}

/*
 * IppTimerInit() should be called in stack thread after IppH323StackConstruct(). Else maxHashSize in RvSelectConstruct() may unfit H323 stack needs.
 */
RvStatus IppTimerInit(void)
{
    RvStatus status;

    /*
     *  We call RvSelectConstruct() in order to define number of needed timers. Parameter - maxHashSize - isn't relevant
     * because IppH323StackConstruct() already defined one.
     */
    status = RvSelectConstruct(1024, IPP_MAX_NUM_TIMERS, IppLogMgr(), &g_selectEngine);
    if ((status == RV_OK) && (g_selectEngine != NULL))
    {
        status = RvSelectGetTimeoutInfo(g_selectEngine, NULL, &g_timerQ);
        if (status != RV_OK)
        {
            RvSelectDestruct(g_selectEngine, IPP_MAX_NUM_TIMERS);
            g_selectEngine = NULL;
            g_timerQ = NULL;
        }
    }
    if (g_timerQ == NULL)
    {
        RvLogError(ippLogSource, (ippLogSource,  "IppTimerInit: RvSelectGetTimeoutInfo Failed, error=%d", status));
    }
    else
    {
        RvLogDebug(ippLogSource, (ippLogSource,  "IppTimerInit: RvSelectGetTimeoutInfo Succeeded"));
    }

    return status;
}

/*
 * IppTimerEnd() should be called in stack thread
 */
void IppTimerEnd(void)
{
    RvSelectDestruct(g_selectEngine, IPP_MAX_NUM_TIMERS);

    g_selectEngine = NULL;
    g_timerQ = NULL;

    RvLogDebug(ippLogSource, (ippLogSource,  "IppTimerEnd"));
}


RvTimerQueue* IppGetTimerQueue()
{
    return g_timerQ;
}

