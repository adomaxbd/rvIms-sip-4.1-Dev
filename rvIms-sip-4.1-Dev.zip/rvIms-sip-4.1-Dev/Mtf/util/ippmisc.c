#include "ippmisc.h"
#define LOGSRC	LOGSRC_UTIL

/************************************************************************
 * IppUtilIsNumberValid
 * purpose: check if the string is from a valid number
 * input  : tel		- the string that we are going to check
 * output :	none
 * return : rvTrue for number, rvFalse for string
 *         
 ************************************************************************/
RvBool IppUtilIsNumberValid(const char *tel)
{
	while (*tel)
    {
		if ( (*tel>='0')&&(*tel<='9'))
			tel++;
		else
			return rvFalse;
	}
	return rvTrue;
}


/***************************************************************************
 * IppUtilIsIpAddress
 * ------------------------------------------------------------------------
 * General: The function checks whether an input string is a valid Ip
            Address.
			An Ip address with 'e' separators is converted to a normal format
 * Return Value: RvBool - True if the string is a valid Ip address.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: str - a pointer to the checked string
 *		  
 ***************************************************************************/

RvBool IppUtilIsIpAddress(char* str)
{
    int n1, n2, n3, n4;
	int matchingNums;
    char  c;
	RvBool    ret_val = rvFalse;

	if (str == NULL)
		return rvFalse;

	if ((matchingNums = sscanf(str,"%d.%d.%d.%d", &n1,&n2,&n3,&n4)) > 1)
    {	
		/* This is the dot seperated Ip address format (xxx.xxx.xxx.xxx). *
		 * Verify it is valid.                                            */
		ret_val = (matchingNums == 4) && (n1 <256) && (n2 <256) &&
			      (n3 <256) && (n4 <256);
    }	
	else
    {
		/* Check if this is an Ip address in the format of xxxexxxexxxexxxe  *
		 *  which is generated when an IpPhone user dials an Ip address.     *
		 * In this case the 'e''s are replaced by '.' to generate a valid    *
		 * Ip address.                                                       */
		if ((matchingNums = sscanf(str,"%de%de%de%d%c", &n1,&n2,&n3,&n4,&c)) == 5)
		{
			ret_val = (n1 <256) && (n2 <256) && (n3 <256) && (n4 <256) && (c == 'e');
			if (ret_val)
			{
				/* replace the "e"'s by "."  */
				sprintf(str, "%d.%d.%d.%d", n1,n2,n3,n4);
				
			}
		}
    }
		return ret_val;
}  /* IppUtilIsIpAddress  */
/************************************************************************************
 * IppUtilIsIpV4
 * ----------------------------------------------------------------------------------
 * General: check if the string is an ip4 address
 *
 * Return Value: RV_TRUE - ip4 address, RV_FALSE - not ip4 address
 * ----------------------------------------------------------------------------------
 * Arguments:
 * Input:   StringIp - the source string
 * Output:  (-)
 ***********************************************************************************/
RVAPI RvBool IppUtilIsIpV4(const RvChar* StringIp)
{
    RvUint32 ip1;
    RvUint32 ip2;
    RvUint32 ip3;
    RvUint32 ip4;

	if (StringIp != NULL)
	{
		if (sscanf(StringIp, "%d.%d.%d.%d", &ip1, &ip2, &ip3, &ip4) != 4)
		{
			return RV_FALSE;
		}
	}

    return RV_TRUE;
}
#if (RV_NET_TYPE & RV_NET_IPV6)
/***************************************************************************************
 * IppUtilIsIpV6
 * -------------------------------------------------------------------------------------
 * General:   checks if an ip address is of ipv6 class or ipv4 class
 * Return Value: RV_TRUE - ipv6
 *               RV_FALSE - ipv4
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:    szAddress  - a NULL terminated the  address.
 * Output:   none
 **************************************************************************************/
RvBool IppUtilIsIpV6(IN const RvChar* szAddress)
{
    RvSize_t i;
    RvSize_t addrStrLen = strlen(szAddress);
    for (i=0;i<addrStrLen;i++)
    {
        if (':' == szAddress[i])
        {
            return RV_TRUE;
        }
    }
    return RV_FALSE;
}
#endif /* RV_NET_IPV6 */
/************************************************************************************
 * IppUtilConvertString2Address
 * ----------------------------------------------------------------------------------
 * General: make RV_LI_AddressType from string
 *
 * Return Value: none
 * ----------------------------------------------------------------------------------
 * Arguments:
 * Input:   StringIp - the source string
 *			address - the address in RV_LI_AddressType format
 *          bIsIpV4   - Defines if the address is ip4 or ip6
 *      
 * Output:  address - the address in RV_LI_AddressType format
 ***********************************************************************************/
RvStatus IppUtilConvertString2Address(IN  RvChar*                StringIp,
                                      OUT RvAddress*			 address,
                                      IN  RvBool                 bIsIpV4)
{
    RvStatus rv = RV_OK;
    if (bIsIpV4 == RV_TRUE)
    {
        if (NULL == RvAddressSetString(StringIp,address))
        {
            rv = RV_ERROR_UNKNOWN;
        }
    }
#if (RV_NET_TYPE & RV_NET_IPV6)
    else if (bIsIpV4 == RV_FALSE)
    {
        RvChar   tempChar          = '\0';
        RvChar*  pScopeIdLocation  = NULL;
        RvChar   tmpstrBuff[RV_IPP_LEN_STRING_IP];

        strcpy(tmpstrBuff,StringIp);

        /* checking for scope id in the address */
        pScopeIdLocation = strchr(tmpstrBuff,'%');
        if (NULL != pScopeIdLocation)
        {
            RvAddressSetIpv6Scope(address, (RvUint32)atoi(pScopeIdLocation+1));
            *pScopeIdLocation = '\0';
        }
        else
        {
            RvAddressSetIpv6Scope(address,0);
        }
        if (tmpstrBuff[0] == '[')
        {
            /* avoiding the square parenthesis */
            tempChar = tmpstrBuff[strlen(tmpstrBuff) - 1];
            tmpstrBuff[strlen(tmpstrBuff) - 1] = '\0';
            if (NULL == RvAddressSetString(tmpstrBuff + 1,address))
                rv = RV_ERROR_BADPARAM;
            tmpstrBuff[strlen(tmpstrBuff)] = tempChar;
        }
        else
        {
            if (NULL == RvAddressSetString(tmpstrBuff,address))
                rv = RV_ERROR_BADPARAM;
        }
        if (NULL != pScopeIdLocation)
        {
            *pScopeIdLocation = '%';
        }
    }
#endif /* RV_NET_IPV6 */
    else
    {
        rv = RV_ERROR_BADPARAM;
    }
    return rv;
}
#if (RV_NET_TYPE & RV_NET_IPV6)
/************************************************************************************
 * IppUtilRemoveScopeIdFromIpv6String
 * ----------------------------------------------------------------------------------
 * General: remove the scopeId from IPv6 string
 *
 * Return Value: none
 * ----------------------------------------------------------------------------------
 * Arguments:
 * Input:   StringIp - the source string IPv6
 *          
 *      
 * Output:  string - input parameter without scope id
 ***********************************************************************************/
void IppUtilRemoveScopeIdFromIpv6String(OUT RvChar* StringIp)
{
    RvChar*  pScopeIdLocation  = NULL;

	/* checking for scope id in the address */
    pScopeIdLocation = strchr(StringIp,'%');
	if (NULL != pScopeIdLocation)
    {
        *pScopeIdLocation = '\0';
    }

}

/************************************************************************************
 * IppUtilGetScopeIdFromIpv6String
 * ----------------------------------------------------------------------------------
 * General: return the scopeId of an IPv6 string
 *
 * Return Value: none
 * ----------------------------------------------------------------------------------
 * Arguments:
 * Input:   StringIp - the source string IPv6
 *          
 *      
 * Output:  scopeId  - the extracted scope id
 ***********************************************************************************/
void IppUtilGetScopeIdFromIpv6String(IN RvChar* StringIp, OUT RvInt *scopeId)
{
    RvChar*  pScopeIdLocation  = NULL;

	/* checking for scope id in the address */
    pScopeIdLocation = strchr(StringIp,'%');
	if (NULL != pScopeIdLocation)
    {
        *scopeId = atoi(pScopeIdLocation + 1);
    }
	else
	{
		*scopeId = 0;
	}
}

/************************************************************************************
 * IppUtilRemoveBracketsFromIpv6String
 * ----------------------------------------------------------------------------------
 * General: 
 *
 * Return Value: RvStatus
 * ----------------------------------------------------------------------------------
 * Arguments:
 * Input:   StringIp - the source string IPv6
 *          
 *      
 * Output:  string - StringIp without square brackets and scopeId
 ***********************************************************************************/
void IppUtilRemoveBracketsFromIpv6String(OUT  RvChar*  StringIp)
{
	RvChar*  pScopeIdLocation  = NULL;
    RvChar   tmpstrBuff[RV_IPP_LEN_STRING_IP];

	strcpy(tmpstrBuff,StringIp);
	pScopeIdLocation = strchr(tmpstrBuff,'%');
	if (NULL != pScopeIdLocation)
	{
		*pScopeIdLocation = '\0';
	}
    
    if (tmpstrBuff[0] == '[')
    {	
		tmpstrBuff[strlen(tmpstrBuff) - 1] = '\0';	
		strcpy(StringIp,tmpstrBuff+1);
	}
}
#endif /* RV_NET_IPV6 */
/************************************************************************************
 * RvAddressConstructFromString
 * ----------------------------------------------------------------------------------
 * General: gets address in string format (ipv6/ipv4) and construct RvAddress
 *
 * Return Value: RvStatus
 * ----------------------------------------------------------------------------------
 * Arguments:
 * Input:   ipString - address in string format
 *          addr - the address in RV_LI_AddressType format
 *      
 * Output:  addr - the address in RV_LI_AddressType format
 ***********************************************************************************/
RVAPI RvStatus RvAddressConstructFromString(IN RvChar* ipString, INOUT RvAddress *addr)
{
	RvBool	bIsIpV4;

	bIsIpV4 = IppUtilIsIpV4(ipString);

	if (bIsIpV4 == RV_TRUE)
	{
		if (NULL == RvAddressConstruct(RV_ADDRESS_TYPE_IPV4,addr))
		{
			return RV_ERROR_UNKNOWN;
		}
		
	}
#if (RV_NET_TYPE & RV_NET_IPV6)
	else
		if(bIsIpV4 == RV_FALSE)
		{
			if (NULL == RvAddressConstruct(RV_ADDRESS_TYPE_IPV6,addr))
			{
				return RV_ERROR_UNKNOWN;
			}
		}
#endif /* RV_NET_IPV6 */
	return IppUtilConvertString2Address((RvChar*)ipString,addr,bIsIpV4);
}


/************************************************************************************
 * RvAddressConstructCopy
 * ----------------------------------------------------------------------------------
 * General: construct source address and copy address from source address
 *
 * Return Value: RvStatus
 * ----------------------------------------------------------------------------------
 * Arguments:
 * Input:   addrSrc  - pointer to the source address
 *          addrDest - pointer to the destination address
 *			addrtype - address type (IPv4 or IPv6)
 *      
 * Output:  addr - the source address in RV_LI_AddressType format
 ***********************************************************************************/
RVAPI RvStatus RvAddressConstructCopy(IN RvAddress* addrSrc,OUT RvAddress* addrDest)
{
	if (NULL == RvAddressConstruct(addrSrc->addrtype,addrDest))
	{
		return RV_ERROR_UNKNOWN;
	}
	if (NULL == RvAddressCopy(addrSrc,addrDest))
	{
		return RV_ERROR_UNKNOWN;
	}
	return RV_OK;
}


/************************************************************************************
 * IppUtilPrintMemoryAllocations
 * ----------------------------------------------------------------------------------
 * General: This function prints to log (Core - Memory module, Debug level) all
 *			memory allocations made so far and the file name who called them.
 *
 * Return Value: RvStatus
 * ----------------------------------------------------------------------------------
 * Arguments:
 * Input:   None
 *      
 * Output:  None
 ***********************************************************************************/
RVAPI RvStatus IppUtilPrintMemoryAllocations()
{
#if (RV_MEMORY_DEBUGINFO == RV_YES)
	RvMemoryInfo memInfo;
	RvLogMgr* logMgr;

	if ((logMgr = IppLogMgr()) == NULL)
		return RV_ERROR_UNKNOWN;

	if ((RvMemoryGetInfo(NULL, logMgr, &memInfo)) != RV_OK)
		return RV_ERROR_UNKNOWN;

	return RvMemoryPrintDbg(NULL, logMgr);
#else
	return RV_OK;

#endif

}

/***************************************************************************
 * IppPrintSdp
 * ------------------------------------------------------------------------
 * General: The function prints SDP message as text.
 * Return Value: True if SDP was successfuly parsed, False if not.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: sdp - a pointer to SDP message
 *        title	 - a string to be printed before the SDP message.
 *		  
 ***************************************************************************/
RVAPI RvBool	IppPrintSdp( RvSdpMsg *sdp, const char* title)
{
	char	buf[2048];
	int		len = sizeof(buf) -1;
	RvSdpStatus  stat;

	if (sdp == NULL)
	{
           	RvLogError(ippLogSource,(ippLogSource,"%s IppPrintSdp() failed", title));
            	return rvFalse;
	}

	rvSdpMsgEncodeToBuf( sdp, buf, len, &stat);
	if (stat != RV_SDPSTATUS_OK)
	{
		/* SDP message failed to be encoded to buffer */
		RvLogError(ippLogSource, (ippLogSource, "IppPrintSdp() - SDP message failed to be encoded to buffer, sdp=0x%p, status=%d",
			sdp, stat));
		return RV_FALSE;
	}
	
	RvLogDebug(ippLogSource,(ippLogSource, "%s\n%s\n", title, buf));
	return rvTrue;
}

/***************************************************************************
 * IppUtil_itoa
 * ------------------------------------------------------------------------
 * General: The function convert integer to string.
 * Return Value: None.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: number - The integer value.
 *        str	 - The buffer that will contain the string of the integer.
 *		  
 ***************************************************************************/
RVAPI char *IppUtil_itoa(int number, char *str)
{
  if (!str) return NULL;

  sprintf(str, "%d", number);
  return str;
}
