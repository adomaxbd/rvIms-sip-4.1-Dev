#if (0)
******************************************************************************
Filename:
Description: C/Macro-based allocator
******************************************************************************
                Copyright (c) 1999 RADVision Inc.
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVision LTD..

RADVision LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************
$Revision:$
$Date:$
$Author: S. Cipolli$
******************************************************************************
#endif
#define LOGSRC	LOGSRC_UTIL
#include "rvmemory.h"
#include "ipplog.h"
#include "rvdefalloc.h"
#include "ipplog.h"

#if defined(__cplusplus)
extern "C" {
#endif

/* Default allocator */
static void* alloc_(void* pool, RvSize_t s) 
{
	void* memPtr;

	RV_UNUSED_ARG(pool);

	RvMemoryAlloc(NULL, s, IppLogMgr(), &memPtr);

	return memPtr;
}

static void dealloc_(void *pool, RvSize_t s, void* x) 
{ 
	RV_UNUSED_ARG(pool);
	RV_UNUSED_ARG(s);

	RvMemoryFree(x, IppLogMgr()); 
}

RvAlloc rvDefaultAlloc = {0, ~0U, alloc_, dealloc_};

#if defined(__cplusplus)
}
#endif

