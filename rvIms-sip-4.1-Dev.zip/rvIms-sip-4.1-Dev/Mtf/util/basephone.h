/******************************************************************************
Filename:    basephone.h
Description: Base Phone Header
*******************************************************************************
                Copyright (c) 2005 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever 
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#ifndef BASEPHONE_H
#define BASEPHONE_H

#include "rvcccall.h"
#include "rvccapi.h"


typedef struct
{
	RvCCCallMgr		callMgr;
	RvCCProvider	pmdmProvider;				/*initialized by Sip/H323 phone constructor*/
	RvBool          usedProvider[RV_MTF_PROTOCOL_NUM];   /*which protocols are in use*/
	RvCCProvider	pnetProvider[RV_MTF_PROTOCOL_NUM];	/*initialized by Sip/H323 phone constructor*/
}RvCCBasePhone;

void rvCCBasePhoneConstruct(RvCCBasePhone* x);

void rvCCBasePhoneDestruct(RvCCBasePhone* x);

/*
 *	access to global object
 */
RvCCBasePhone*	rvCCBasePhoneGetBasePhone(void);

RvCCCallMgr*	rvCCBasePhoneGetCallMgr(void);
RvCCProvider*	rvCCBasePhoneGetMdmProvider(void);

RvCCProvider*	rvCCBasePhoneGetNetProvider_(int provider);
RvBool	rvCCBasePhoneIsUsed_(int provider);
void	rvCCBasePhoneUse_(int provider);

#define	rvCCBasePhoneGetNetProvider() rvCCBasePhoneGetNetProvider_(PROTOCOL)
#define	rvCCBasePhoneIsUsed() rvCCBasePhoneIsUsed_(PROTOCOL)
#define	rvCCBasePhoneUse() rvCCBasePhoneUse_(PROTOCOL)


#endif /*BASEPHONE_H*/
