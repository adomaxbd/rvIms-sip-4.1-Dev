/******************************************************************************
Filename:    rvmdmobjects.c
Description: MDM objects
*******************************************************************************
                Copyright (c) 2000 RADVision Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVision Inc.
No part of this publication may be reproduced in any form whatsoever without
written prior approval by RADVision Inc.

RADVision Inc. reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#define LOGSRC  LOGSRC_MDM
#include "ipp_inc_std.h"
#include <ctype.h>
#include "rvmdmobjects.h"
#include "rvclock.h"
#include "rvtime.h"
#include "rvstr.h"
#include "rvassert.h"


unsigned int  g_dwDigitMatchType = 1;

void Psip_SetDigitMatchType(unsigned int dwDigitMatchType)
{
    g_dwDigitMatchType = dwDigitMatchType;
}

unsigned int g_dwDigitFQuickRpt = 0;
void Psip_SetDigitFQuickRpt(unsigned int dwQuickRptFlag)
{
    g_dwDigitFQuickRpt = dwQuickRptFlag;
}

extern int PSip_IsIntelligentPhoneNumber(char * strPhoneNumber);

#define RVMTF_DIGITMAP_DEF_START_TIMEOUT	1600
#define RVMTF_DIGITMAP_DEF_SHORT_TIMEOUT	4
#define RVMTF_DIGITMAP_DEF_LONG_TIMEOUT		16


#define nprn(_s) ( (_s != NULL) ? (_s) : "(null)" )

static RvBool rvMdmPackageItemLess(const RvMdmPackageItem *a, const RvMdmPackageItem *b);

/*#define rvNeverEqual(a, b) ((a)==(b))*/

#define RvMdmPackageItemConstructCopy rvMdmPackageItemConstructCopy
#define RvMdmPackageItemDestruct rvMdmPackageItemDestruct
#define RvMdmPackageItemEqual rvMdmPackageItemEqual
#define RvMdmPackageItemLess rvMdmPackageItemLess
#define RvMdmParameterValueConstructCopy rvMdmParameterValueConstructCopy
#define RvMdmParameterValueDestruct rvMdmParameterValueDestruct
#define RvMdmDigitPositionConstructCopy rvMdmDigitPositionConstructCopy
#define RvMdmDigitPositionDestruct rvMdmDigitPositionDestruct
#define RvMdmDigitPositionEqual rvNeverEqual
#define RvMdmDigitStringConstructCopy rvMdmDigitStringConstructCopy
#define RvMdmDigitStringDestruct rvMdmDigitStringDestruct
#define RvMdmDigitStringEqual rvNeverEqual
#define RvMdmSignalExConstructCopy rvMdmSignalExConstructCopy
#define RvMdmSignalExDestruct rvMdmSignalExDestruct
#define RvMdmSignalExEqual rvNeverEqual
#define RvMdmSignalExListConstructCopy rvMdmSignalExListConstructCopy
#define RvMdmSignalExListDestruct rvMdmSignalExListDestruct
#define RvMdmSignalExListEqual rvNeverEqual
#define RvMdmRequestedEventConstructCopy rvMdmRequestedEventConstructCopy
#define RvMdmRequestedEventDestruct rvMdmRequestedEventDestruct
#define RvMdmRequestedEventEqual rvNeverEqual
#define RvMdmStreamDescriptorConstructCopy rvMdmStreamDescriptorConstructCopy
#define RvMdmStreamDescriptorDestruct rvMdmStreamDescriptorDestruct
#define RvMdmStreamDescriptorEqual rvNeverEqual
#define RvMdmEventConstructCopy rvMdmEventConstructCopy
#define RvMdmEventDestruct rvMdmEventDestruct
#define RvMdmEventEqual rvNeverEqual
#define RvStringAndIntConstructCopy rvStringAndIntConstructCopy
#define RvStringAndIntDestruct rvStringAndIntDestruct
#define RvStringAndIntEqual rvStringAndIntEqual

/*lint -save -e550 -e774 -e613 */
rvDefineMap(RvMdmPackageItem, RvMdmParameterValue)
rvDefineVector(RvMdmDigitPosition)
rvDefineVector(RvMdmDigitString)
rvDefineVector(RvMdmSignalEx)
rvDefineVector(RvMdmSignalExList)
rvDefineVector(RvMdmRequestedEvent)
rvDefineVector(RvMdmStreamDescriptor)
rvDefineVector(RvMdmEvent)
/*lint -restore */


/*$
{function:
	{name: rvMdmPackageItemConstruct}
	{class: RvMdmPackageItem}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a package item object.}
	}
	{proto: RvMdmPackageItem *rvMdmPackageItemConstruct(RvMdmPackageItem *x, const char *pkg, const char *item);}
	{params:
		{param: {n:x} {d:The package item object.}}
		{param: {n:pkg} {d:The name of the package the item belongs to.}}
		{param: {n:item} {d:The name of the item.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmPackageItem* RVCALLCONV rvMdmPackageItemConstruct(
    IN RvMdmPackageItem*    x,
    IN const RvChar*        pkg,
    IN const RvChar*        item)
{
    RvMdmPackageItem *obj;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmPackageItemConstruct(x=%p,pkg=%s,item=%s)", x, pkg, item));

    obj = rvMdmPackageItemConstructA(x, pkg, item, prvDefaultAlloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmPackageItemConstruct()=%p", obj));

    return obj;
}


/*$
{function:
    {name: rvMdmPackageItemConstructA}
    {class: RvMdmPackageItem}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a package item object.}
    }
    {proto: RvMdmPackageItem *rvMdmPackageItemConstructA(RvMdmPackageItem *x, const char *pkg, const char *item, RvAlloc *alloc);}
    {params:
        {param: {n:x} {d:The package item object.}}
        {param: {n:pkg} {d:The name of the package the item belongs to.}}
        {param: {n:item} {d:The name of the item.}}
        {param: {n:alloc} {d:The allocator to use.}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmPackageItem* RVCALLCONV rvMdmPackageItemConstructA(
    IN RvMdmPackageItem*    x,
    IN const RvChar*        pkg,
    IN const RvChar*        item,
    IN RvAlloc*             alloc)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmPackageItemConstructA(x=%p,pkg=%s,item=%s,alloc=%p)", x, pkg, item, alloc));

    rvStringConstruct(&x->package, pkg, alloc);
    rvStringConstruct(&x->item, item, alloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmPackageItemConstructA()=%p)", x));

    return x;
}


/*$
{function:
    {name: rvMdmPackageItemConstructCopy}
    {class: RvMdmPackageItem}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a copy of a package item object.}
    }
    {proto: RvMdmPackageItem *rvMdmPackageItemConstructCopy(RvMdmPackageItem *d, const RvMdmPackageItem *s, RvAlloc *alloc);}
    {params:
        {param: {n:d} {d:The destination package item object.}}
        {param: {n:s} {d:The package item object to copy.}}
        {param: {n:alloc} {d:The allocator to use.}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmPackageItem* RVCALLCONV rvMdmPackageItemConstructCopy(
    IN RvMdmPackageItem*        d,
    IN const RvMdmPackageItem*  s,
    IN RvAlloc*                 alloc)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmPackageItemConstructCopy(d=%p,s=%p,alloc=%p)", d, s, alloc));

    rvStringConstructCopy(&d->package, &s->package, alloc);
    rvStringConstructCopy(&d->item, &s->item, alloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmPackageItemConstructCopy()=%p", d));

    return d;
}


/*$
{function:
    {name: rvMdmPackageItemDestruct}
    {class: RvMdmPackageItem}
    {include: rvmdmobjects.h}
    {description:
        {p: Destroys a package item object.}
    }
    {proto: void rvMdmPackageItemDestruct(RvMdmPackageItem *x);}
    {params:
        {param: {n:x} {d:The package item object.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmPackageItemDestruct(IN RvMdmPackageItem* x)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmPackageItemDestruct(x=%p)", x));

    rvStringDestruct(&x->package);
    rvStringDestruct(&x->item);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmPackageItemDestruct()"));
}


/*$
{function:
    {name: rvMdmPackageItemCopy}
    {class: RvMdmPackageItem}
    {include: rvmdmobjects.h}
    {description:
        {p: Copies the value of one package item object to another.}
    }
    {proto: RvMdmPackageItem *rvMdmPackageItemCopy(RvMdmPackageItem *d, const RvMdmPackageItem *s);}
    {params:
        {param: {n:d} {d:The destination package item object.}}
        {param: {n:s} {d:The package item object to copy.}}
    }
    {returns: A pointer to the destination object, or NULL if the copy failed.}
}
$*/
RVAPI RvMdmPackageItem* RVCALLCONV rvMdmPackageItemCopy(
    IN RvMdmPackageItem*        d,
    IN const RvMdmPackageItem*  s)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmPackageItemCopy(d=%p,s=%p)", d, s));

    rvStringCopy(&d->package, &s->package);
    rvStringCopy(&d->item, &s->item);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmPackageItemCopy()=%p", d));

    return d;
}


/*$
{function:
    {name: rvMdmPackageItemEqual}
    {class: RvMdmPackageItem}
    {include: rvmdmobjects.h}
    {description:
        {p: Compares two package item objects for equality.}
    }
    {proto: RvBool rvMdmPackageItemEqual(const RvMdmPackageItem *a, const RvMdmPackageItem *b);}
    {params:
        {param: {n:a} {d:The first package item object.}}
        {param: {n:b} {d:The second package item object.}}
    }
    {returns: rvTrue if the objects are equal, rvFalse if not.}
}
$*/
RVAPI RvBool RVCALLCONV rvMdmPackageItemEqual(
    IN const RvMdmPackageItem*  a,
    IN const RvMdmPackageItem*  b)
{
    RvBool isEqual;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmPackageItemEqual(a=%p,b=%p)", a, b));

    isEqual = rvStringEqualIgnoreCase(&a->item, &b->item) &&
        rvStringEqualIgnoreCase(&a->package, &b->package);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmPackageItemEqual()=%d", isEqual));

    return isEqual;
}


static RvBool rvMdmPackageItemLess(const RvMdmPackageItem *a, const RvMdmPackageItem *b)
{
	return rvStringEqualIgnoreCase(&a->package, &b->package) ?
		rvStringLessIgnoreCase(&a->item, &b->item) :
		rvStringLessIgnoreCase(&a->package, &b->package);
}


/*$
{function:
	{name: rvMdmPackageItemGetPackage}
	{class: RvMdmPackageItem}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the package name of the package item object.}
	}
	{proto: const char *rvMdmPackageItemGetPackage(const RvMdmPackageItem *x);}
	{params:
		{param: {n:x} {d:The package item object.}}
	}
	{returns: The package name.}
}
$*/
RVAPI const RvChar* RVCALLCONV rvMdmPackageItemGetPackage(IN const RvMdmPackageItem *x)
{
    const RvChar* data;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmPackageItemGetPackage(x=%p)", x));

    data = rvStringGetData(&x->package);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmPackageItemGetPackage()=%s", nprn(data)));

    return data;
}


/*$
{function:
    {name: rvMdmPackageItemGetItem}
    {class: RvMdmPackageItem}
    {include: rvmdmobjects.h}
    {description:
        {p: Gets the name of the package item object.}
    }
    {proto: const char *rvMdmPackageItemGetItem(const RvMdmPackageItem *x);}
    {params:
        {param: {n:x} {d:The package item object.}}
    }
    {returns: The name of the item.}
}
$*/
RVAPI const RvChar* RVCALLCONV rvMdmPackageItemGetItem(IN const RvMdmPackageItem *x)
{
    const RvChar* item;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmPackageItemGetItem(x=%p)", x));

    item = rvStringGetData(&x->item);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmPackageItemGetItem()=%s", nprn(item)));

    return item;
}


/*$
{function:
    {name: rvMdmParameterValueConstruct}
    {class: RvMdmParameterValue}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a parameter value object.}
    }
    {proto: RvMdmParameterValue *rvMdmParameterValueConstruct(RvMdmParameterValue *x, const char *val);}
    {params:
        {param: {n:x} {d:The parameter value object.}}
        {param: {n:val} {d:The parameter value.}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
    {notes:
        {note: For under-specified and over-specified parameters use one of the special RvMdmParameterValue constructors instead.}
    }
}
$*/
RVAPI RvMdmParameterValue* RVCALLCONV rvMdmParameterValueConstruct(
    IN RvMdmParameterValue* x,
    IN const RvChar*        val)
{
    RvMdmParameterValue*    v;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterValueConstruct(x=%p,val=%s)", x, val));

    v = rvMdmParameterValueConstructA(x, val, prvDefaultAlloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterValueConstruct()=%p", v));

    return v;
}


/*$
{function:
    {name: rvMdmParameterValueConstructA}
    {class: RvMdmParameterValue}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a parameter value object.}
    }
    {proto: RvMdmParameterValue *rvMdmParameterValueConstructA(RvMdmParameterValue *x, const char *val, RvAlloc *alloc);}
    {params:
        {param: {n:x} {d:The parameter value object.}}
        {param: {n:val} {d:The parameter value.}}
        {param: {n:alloc} {d:The allocator to use.}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
    {notes:
        {note: For under-specified and over-specified parameters use one of the special RvMdmParameterValue constructors instead.}
    }
}
$*/
RVAPI RvMdmParameterValue* RVCALLCONV rvMdmParameterValueConstructA(
    IN RvMdmParameterValue* x,
    IN const RvChar*        val,
    IN RvAlloc*             alloc)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterValueConstructA(x=%p,val=%s,alloc=%p)", x, val, alloc));

    x->type = RV_MDM_RELATION_EQUAL;
    rvStringListConstructA(&x->values, alloc);
    rvStringListAdd(&x->values, val);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterValueConstructA()=%p", x));

    return x;
}

/*$
{function:
    {name: rvMdmParameterValueConstructList}
    {class: RvMdmParameterValue}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a parameter value object that represents a list of possible values.}
    }
    {proto: RvMdmParameterValue *rvMdmParameterValueConstructList(RvMdmParameterValue *x, RvMdmRelation type);}
    {params:
        {param: {n:x} {d:The parameter value object.}}
        {param: {n:type} {d:The type of list, either "AND" or "OR".}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmParameterValue* RVCALLCONV rvMdmParameterValueConstructList(
    IN RvMdmParameterValue* x,
    IN RvMdmRelation        type)
{
    RvMdmParameterValue* value;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterValueConstructList(x=%p,type=%d)", x, type));

    value = rvMdmParameterValueConstructListA(x, type, prvDefaultAlloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterValueConstructList()=%p", value));

    return value;
}

/*$
{function:
    {name: rvMdmParameterValueConstructListA}
    {class: RvMdmParameterValue}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a parameter value object.}
    }
    {proto: RvMdmParameterValue *rvMdmParameterValueConstructListA(RvMdmParameterValue *x, RvMdmRelation type, RvAlloc *alloc);}
    {params:
        {param: {n:x} {d:The parameter value object.}}
        {param: {n:type} {d:The type of list, either "AND" or "OR".}}
        {param: {n:alloc} {d:The allocator to use.}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmParameterValue* RVCALLCONV rvMdmParameterValueConstructListA(
    IN RvMdmParameterValue* x,
    IN RvMdmRelation        type,
    IN RvAlloc*             alloc)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterValueConstructListA(x=%p,type=%d,alloc=%p)", x, type, alloc));

    RvAssert(type == RV_MDM_RELATION_AND || type == RV_MDM_RELATION_OR);
    x->type = type;
    rvStringListConstructA(&x->values, alloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterValueConstructListA()=%p", x));

    return x;
}

/*$
{function:
    {name: rvMdmParameterValueConstructCopy}
    {class: RvMdmParameterValue}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a copy of a parameter value object.}
    }
    {proto: RvMdmParameterValue *rvMdmParameterValueConstructCopy(RvMdmParameterValue *d, const RvMdmParameterValue *s, RvAlloc *alloc);}
    {params:
        {param: {n:d} {d:The destination parameter value object.}}
        {param: {n:s} {d:The parameter value object to copy.}}
        {param: {n:alloc} {d:The allocator to use.}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmParameterValue* RVCALLCONV rvMdmParameterValueConstructCopy(
    IN RvMdmParameterValue*         d,
    IN const RvMdmParameterValue*   s,
    IN RvAlloc*                     alloc)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterValueConstructCopy(d=%p,s=%p,alloc=%p)", d, s, alloc));

    d->type = s->type;
    rvStringListConstructCopy(&d->values, &s->values, alloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterValueConstructCopy()=%p", d));

    return d;
}
/*$
{function:
    {name: rvMdmParameterValueDestruct}
    {class: RvMdmParameterValue}
    {include: rvmdmobjects.h}
    {description:
        {p: Destroys a parameter value object.}
    }
    {proto: void rvMdmParameterValueDestruct(RvMdmParameterValue *x);}
    {params:
        {param: {n:x} {d:The parameter value object.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmParameterValueDestruct(IN RvMdmParameterValue* x)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterValueDestruct(x=%p)", x));

    rvStringListDestruct(&x->values);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterValueDestruct()=%p", x));
}


/*$
{function:
    {name: rvMdmParameterValueAddToList}
    {class: RvMdmParameterValue}
    {include: rvmdmobjects.h}
    {description:
        {p: Add a value to a list of possible values. }
    }
    {proto: void rvMdmParameterValueAddToList(RvMdmParameterValue *x, const char *val);}
    {params:
        {param: {n:x} {d:The parameter value object.}}
        {param: {n:val} {d:The value.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmParameterValueAddToList(
    IN RvMdmParameterValue* x,
    IN const RvChar*        val)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterValueAddToList(x=%p,val=%s)", x, val));

    RvAssert(x->type == RV_MDM_RELATION_AND || x->type == RV_MDM_RELATION_OR);
    rvStringListAdd(&x->values, val);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterValueAddToList()"));
}


void rvMdmParameterValueAddToListUnique(RvMdmParameterValue *x, const char *val)
{
    size_t i;
    RvAssert(x->type == RV_MDM_RELATION_AND || x->type == RV_MDM_RELATION_OR);
    for(i=0; i<rvStringListGetSize(&x->values); ++i)
    {
        if(rvStrIcmp(rvStringListGetElem(&x->values, i), val) == 0)
            return;
    }
    rvStringListAdd(&x->values, val);
}


void rvMdmParameterValueAnd(RvMdmParameterValue *x, const char *val)
{
    RvAssert(x->type == RV_MDM_RELATION_EQUAL || x->type == RV_MDM_RELATION_AND);
    x->type = RV_MDM_RELATION_AND;
    rvMdmParameterValueAddToListUnique(x, val);
}


void rvMdmParameterValueOr(RvMdmParameterValue *x, const char *val)
{
    RvAssert(x->type == RV_MDM_RELATION_EQUAL || x->type == RV_MDM_RELATION_OR);
    x->type = RV_MDM_RELATION_OR;
    rvMdmParameterValueAddToListUnique(x, val);
}


/*$
{function:
    {name: rvMdmParameterValueGetType}
    {class: RvMdmParameterValue}
    {include: rvmdmobjects.h}
    {description:
        {p: Gets the type of the parameter value object.}
    }
    {proto: RvMdmRelation rvMdmParameterValueGetType(const RvMdmParameterValue *x);}
    {params:
        {param: {n:x} {d:The parameter value object.}}
    }
    {returns: The type.}
}
$*/
RVAPI RvMdmRelation RVCALLCONV rvMdmParameterValueGetType(
    IN const RvMdmParameterValue*   x)
{
    RvMdmRelation type;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterValueGetType(x=%p)", x));

    type = x->type;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterValueGetType()=%d", type));

    return type;
}


/*$
{function:
    {name: rvMdmParameterValueGetValue}
    {class: RvMdmParameterValue}
    {include: rvmdmobjects.h}
    {description:
        {p: Gets the value of the parameter value object.}
    }
    {proto: const char *rvMdmParameterValueGetValue(const RvMdmParameterValue *x);}
    {params:
        {param: {n:x} {d:The parameter value object.}}
    }
    {returns: The value.}
    {notes:
        {note: Not valid for lists and ranges.}
    }
}
$*/
RVAPI const RvChar* RVCALLCONV rvMdmParameterValueGetValue(IN const RvMdmParameterValue *x)
{
    const RvChar* value;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterValueGetValue(x=%p)", x));

    RvAssert(x->type != RV_MDM_RELATION_AND && x->type != RV_MDM_RELATION_OR);
    value = rvStringListGetElem(&x->values, 0);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterValueGetValue()=%s", value));

    return value;
}


/*$
{function:
    {name: rvMdmParameterValueGetListSize}
    {class: RvMdmParameterValue}
    {include: rvmdmobjects.h}
    {description:
        {p: Gets the number of possible values for a parameter value object that is a list.}
    }
    {proto: size_t rvMdmParameterValueGetListSize(const RvMdmParameterValue *x);}
    {params:
        {param: {n:x} {d:The parameter value object.}}
    }
    {returns: The list size.}
}
$*/
RVAPI RvSize_t RVCALLCONV rvMdmParameterValueGetListSize(IN const RvMdmParameterValue* x)
{
    RvSize_t size;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterValueGetListSize(x=%p)", x));

    RvAssert(x->type == RV_MDM_RELATION_AND || x->type == RV_MDM_RELATION_OR);
    size = rvStringListGetSize(&x->values);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterValueGetListSize()=%d", size));

    return size;
}


/*$
{function:
    {name: rvMdmParameterValueGetListValue}
    {class: RvMdmParameterValue}
    {include: rvmdmobjects.h}
    {description:
        {p: Gets one value of a parameter value object that is a list.}
    }
    {proto: const char *rvMdmParameterValueGetListValue(const RvMdmParameterValue *x, size_t index);}
    {params:
        {param: {n:x} {d:The parameter value object.}}
        {param: {n:index} {d:The index.}}
    }
    {returns: The value.}
}
$*/
RVAPI const RvChar* RVCALLCONV rvMdmParameterValueGetListValue(
    IN const RvMdmParameterValue*   x,
    IN RvSize_t                     index)
{
    const RvChar* v;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterValueGetListValue(x=%p,index=%d)", x, index));

    RvAssert(x->type == RV_MDM_RELATION_AND || x->type == RV_MDM_RELATION_OR);
    v = rvStringListGetElem(&x->values, index);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterValueGetListSize()=%s", v));

    return v;
}


/*$
{function:
    {name: rvMdmParameterListConstruct}
    {class: RvMdmParameterList}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a parameter list object.}
    }
    {proto: RvMdmParameterList *rvMdmParameterListConstruct(RvMdmParameterList *x);}
    {params:
        {param: {n:x} {d:The parameter list object.}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmParameterList* RVCALLCONV rvMdmParameterListConstruct(IN RvMdmParameterList* x)
{
    RvMdmParameterList* lst;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterListConstruct(x=%p)", x));

    lst = rvMdmParameterListConstructA(x, prvDefaultAlloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterListConstruct()=%p", lst));

    return lst;
}


/*$
{function:
    {name: rvMdmParameterListConstructA}
    {class: RvMdmParameterList}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a parameter list object.}
    }
    {proto: RvMdmParameterList *rvMdmParameterListConstructA(RvMdmParameterList *x, RvAlloc *alloc);}
    {params:
        {param: {n:x} {d:The parameter list object.}}
        {param: {n:alloc} {d:The allocator to use.}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmParameterList* RVCALLCONV rvMdmParameterListConstructA(
    IN RvMdmParameterList*  x,
    IN RvAlloc*             alloc)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterListConstructA(x=%p,alloc=%p)", x, alloc));

    rvMapConstruct(RvMdmPackageItem, RvMdmParameterValue)(&x->list, alloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterListConstructA()=%p", x));

    return x;
}


/*$
{function:
    {name: rvMdmParameterListConstructCopy}
    {class: RvMdmParameterList}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a copy of a parameter list object.}
    }
    {proto: RvMdmParameterList *rvMdmParameterListConstructCopy(RvMdmParameterList *d, const RvMdmParameterList *s, RvAlloc *alloc);}
    {params:
        {param: {n:d} {d:The destination parameter list object.}}
        {param: {n:s} {d:The parameter list object to copy.}}
        {param: {n:alloc} {d:The allocator to use.}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmParameterList* RVCALLCONV rvMdmParameterListConstructCopy(
    IN RvMdmParameterList*          d,
    IN const RvMdmParameterList*    s,
    IN RvAlloc*                     alloc)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterListConstructCopy(d=%p,s=%p,alloc=%p)", d, s, alloc));

    rvMapConstructCopy(&d->list, &s->list, alloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterListConstructCopy()=%p", d));

    return d;
}


/*$
{function:
	{name: rvMdmParameterListDestruct}
	{class: RvMdmParameterList}
	{include: rvmdmobjects.h}
	{description:
		{p: Destroys a parameter list object.}
	}
	{proto: void rvMdmParameterListDestruct(RvMdmParameterList *x);}
	{params:
		{param: {n:x} {d:The parameter list object.}}
	}
}
$*/
RVAPI void RVCALLCONV rvMdmParameterListDestruct(IN RvMdmParameterList* x)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterListDestruct(x=%p)", x));

    rvMapDestruct(&x->list);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterListDestruct()"));
}


/*$
{function:
	{name: rvMdmParameterListCopy}
	{class: RvMdmParameterList}
	{include: rvmdmobjects.h}
	{description:
		{p: Copies the value of one parameter list object to another.}
	}
	{proto: RvMdmParameterList *rvMdmParameterListCopy(RvMdmParameterList *d, const RvMdmParameterList *s);}
	{params:
		{param: {n:d} {d:The destination parameter list object.}}
		{param: {n:s} {d:The parameter list object to copy.}}
	}
	{returns: A pointer to the destination object, or NULL if the copy failed.}
}
$*/
RVAPI RvMdmParameterList* RVCALLCONV rvMdmParameterListCopy(
    IN RvMdmParameterList*          d,
    IN const RvMdmParameterList*    s)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterListCopy(d=%p,s=%p)", d, s));

    rvMapCopy(&d->list, &s->list);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterListCopy()=%p", d));

    return d;
}

/*$
{function:
	{name: rvMdmParameterListAnd}
	{class: rvMdmParameterList}
	{include: rvmdmobjects.h}
	{description:
		{p: Adds a parameter to the parameter list with "And" relation to the other parameters.}
	}
	{proto: void rvMdmParameterListAnd(RvMdmParameterList *x, const RvMdmPackageItem *name, const char *value);}
	{params:
		{param: {n:x} {d:The destination parameter list object.}}
		{param: {n:name} {d:The parameter name.}}
		{param: {n:value} {d:The parameter value.}}
	}
}
$*/
void rvMdmParameterListAnd(RvMdmParameterList *x, const RvMdmPackageItem *name, const char *value)
{
	RvMdmParameterValue *curValue = rvMapFindValue(RvMdmPackageItem, RvMdmParameterValue)(&x->list, name);

	if(curValue == NULL)
	{
		RvMdmParameterValue pv;
		rvMdmParameterValueConstruct(&pv, value);
		rvMapSetValue(RvMdmPackageItem, RvMdmParameterValue)(&x->list, name, &pv);
		rvMdmParameterValueDestruct(&pv);
	}
	else
		rvMdmParameterValueAnd(curValue, value);
}

/*$
{function:
	{name: rvMdmParameterListOr}
	{class: rvMdmParameterList}
	{include: rvmdmobjects.h}
	{description:
		{p: Adds a parameter to the parameter list with "Or" relation to the other parameters.}
	}
	{proto: void rvMdmParameterListOr(RvMdmParameterList *x, const RvMdmPackageItem *name, const char *value);}
	{params:
		{param: {n:x} {d:The destination parameter list object.}}
		{param: {n:name} {d:The parameter name.}}
		{param: {n:value} {d:The parameter value.}}
	}
}
$*/
RVAPI void RVCALLCONV rvMdmParameterListOr(
    IN RvMdmParameterList*      x,
    IN const RvMdmPackageItem*  name,
    IN const RvChar*            value)
{
    RvMdmParameterValue *curValue;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterListOr(x=%p,name=%p,value=%s)", x, name, value));

    curValue = rvMapFindValue(RvMdmPackageItem, RvMdmParameterValue)(&x->list, name);

    if (curValue == NULL)
    {
        RvMdmParameterValue pv;
        rvMdmParameterValueConstruct(&pv, value);
        rvMapSetValue(RvMdmPackageItem, RvMdmParameterValue)(&x->list, name, &pv);
        rvMdmParameterValueDestruct(&pv);
    }
    else
        rvMdmParameterValueOr(curValue, value);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterListOr()"));
}

/* PRIVATE
{function:
    {name: rvMdmParameterListSet2}
    {class: RvMdmParameterList}
    {include: rvmdmobjects.h}
    {description:
        {p: Sets a parameter in a parameter list object.}
    }
    {proto: void rvMdmParameterListSet2(RvMdmParameterList *x, const char *name, const RvMdmParameterValue *value);}
    {params:
        {param: {n:x} {d:The parameter list object.}}
        {param: {n:name} {d:The parameter name.}}
        {param: {n:value} {d:The parameter value.}}
    }
}
*/
void rvMdmParameterListSet2(RvMdmParameterList *x, const char *name, const RvMdmParameterValue *value)
{
    RvMdmPackageItem item;
    rvMdmPackageItemConstruct(&item, "", name);
    rvMdmParameterListSet(x, &item, value);
    rvMdmPackageItemDestruct(&item);
}

/*$
{function:
    {name: rvMdmParameterListSet}
    {class: RvMdmParameterList}
    {include: rvmdmobjects.h}
    {description:
        {p: Sets a parameter in a parameter list object.}
    }
    {proto: void rvMdmParameterListSet(RvMdmParameterList *x, const RvMdmPackageItem *name, const RvMdmParameterValue *value);}
    {params:
        {param: {n:x} {d:The parameter list object.}}
        {param: {n:name} {d:The parameter name.}}
        {param: {n:value} {d:The parameter value.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmParameterListSet(
    IN RvMdmParameterList*          x,
    IN const RvMdmPackageItem*      name,
    IN const RvMdmParameterValue*   value)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterListSet(x=%p,name=%p,value=%p)", x, name, value));

    rvMapSetValue(RvMdmPackageItem, RvMdmParameterValue)(&x->list, name, value);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterListSet()"));
}


/* PRIVATE
{function:
    {name: rvMdmParameterListGet}
    {class: RvMdmParameterList}
    {include: rvmdmobjects.h}
    {description:
        {p: Gets the value of a parameter in a parameter list object.}
    }
    {proto: const RvMdmParameterValue *rvMdmParameterListGet(const RvMdmParameterList *x, const RvMdmPackageItem *name);}
    {params:
        {param: {n:x} {d:The parameter list object.}}
        {param: {n:name} {d:The parameter name.}}
    }
    {returns: The parameter value.}
}
$*/
RVAPI const RvMdmParameterValue* RVCALLCONV rvMdmParameterListGet(
    IN const RvMdmParameterList*    x,
    IN const RvMdmPackageItem*      name)
{
    const RvMdmParameterValue*  v;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterListGet(x=%p,name=%p)", x, name));

    v = rvMapGetValue(RvMdmPackageItem, RvMdmParameterValue)(&x->list, name);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterListGet()=%p", v));

    return v;
}


/*$
{function:
    {name: rvMdmParameterListGet2}
    {class: RvMdmParameterList}
    {include: rvmdmobjects.h}
    {description:
        {p: Gets the value of a parameter in a parameter list object.}
    }
    {proto: const RvMdmParameterValue *rvMdmParameterListGet2(const RvMdmParameterList *x, const char *name);}
    {params:
        {param: {n:x} {d:The parameter list object.}}
        {param: {n:name} {d:The parameter name.}}
    }
    {returns: The parameter value.}
}
$*/
RVAPI const RvMdmParameterValue* RVCALLCONV rvMdmParameterListGet2(
    IN const RvMdmParameterList*    x,
    IN const RvChar*                name)
{
    RvMdmPackageItem            item;
    const RvMdmParameterValue*  v;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterListGet2(x=%p,name=%s)", x, name));

    rvMdmPackageItemConstruct(&item, "", name);
    v = rvMdmParameterListGet(x, &item);
    rvMdmPackageItemDestruct(&item);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterListGet2()=%p", v));

    return v;
}

/*$
{function:
    {name: rvMdmParameterListForEach}
    {class: RvMdmParameterList}
    {include: rvmdmobjects.h}
    {description:
        {p: Call a function for each parameter in a parameter list object.}
    }
    {proto: void rvMdmParameterListForEach(const RvMdmParameterList *x, RvMdmParameterFunc f, void *data);}
    {params:
        {param: {n:x} {d:The parameter list object.}}
        {param: {n:f} {d:The function.}}
        {param: {n:data} {d:Any user data.}}
    }
    {notes:
        {note: typedef void (*RvMdmParameterFunc)(const RvMdmPackageItem *name, const RvMdmParameterValue *value, void *data);}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmParameterListForEach(
    IN const RvMdmParameterList*    x,
    IN RvMdmParameterFunc           f,
    IN void*                        data)
{
    RvMapIter(RvMdmPackageItem, RvMdmParameterValue) iter;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterListForEach(x=%p,f=%p,data=%p)", x, f, data));

    for(iter = rvMapBegin(RvMdmPackageItem, RvMdmParameterValue)(&x->list);
        iter != rvMapEnd(RvMdmPackageItem, RvMdmParameterValue)(&x->list);
        iter = rvMapIterNext(iter))
    {
        f(rvMapIterGetKey(RvMdmPackageItem, RvMdmParameterValue)(iter),
            rvMapIterGetValue(RvMdmPackageItem, RvMdmParameterValue)(iter), data);
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterListForEach()"));
}


/*$
{function:
    {name: rvMdmParameterListIsEmpty}
    {class: RvMdmParameterList}
    {include: rvmdmobjects.h}
    {description:
        {p: Checks whether the parameter list object is empty.}
    }
    {proto: RvBool rvMdmParameterListIsEmpty(const RvMdmParameterList *x);}
    {params:
        {param: {n:x} {d:The parameter list object.}}
    }
    {returns: rvTrue if the object is empty, rvFalse if not.}
}
$*/
RVAPI RvBool RVCALLCONV rvMdmParameterListIsEmpty(IN const RvMdmParameterList* x)
{
    RvBool isEmpty;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmParameterListIsEmpty(x=%p)", x));

    isEmpty = (rvMapSize(&x->list) == 0);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmParameterListIsEmpty()=%d", isEmpty));

    return isEmpty;
}

static int rvMdmDigitPositionBitValue(char c)
{
    return isdigit(c) ? (1 << (c - '0')) : ((1 << 9) << (c & 15));
}


/*$
{function:
    {name: rvMdmDigitPositionConstruct}
    {class: RvMdmDigitPosition}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a digit position object.}
    }
    {proto: RvMdmDigitPosition *rvMdmDigitPositionConstruct(RvMdmDigitPosition *x);}
    {params:
        {param: {n:x} {d:The digit position object.}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmDigitPosition* RVCALLCONV rvMdmDigitPositionConstruct(IN RvMdmDigitPosition* x)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitPositionConstruct(x=%p)", x));

    memset(x, 0, sizeof(*x));

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitPositionConstruct()=%p", x));

    return x;
}


/*$
{function:
    {name: rvMdmDigitPositionAddEvents}
    {class: RvMdmDigitPosition}
    {include: rvmdmobjects.h}
    {description:
        {p: Add a range of DTMF events to a digit position object.}
    }
    {proto: void rvMdmDigitPositionAddEvents(RvMdmDigitPosition *x, char c1, char c2);}
    {params:
        {param: {n:x} {d:The digit position object.}}
        {param: {n:c1} {d:The first event in the range.}}
        {param: {n:c2} {d:The last event in the range.}}
    }
    {notes:
        {note: set c1 = c2 to add one event.}
        {note: c1 and c2 must be both numbers or both letters.}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmDigitPositionAddEvents(
    IN RvMdmDigitPosition*  x,
    IN RvChar               c1,
    IN RvChar               c2)
{
    int b1 = rvMdmDigitPositionBitValue(c1);
    int b2 = rvMdmDigitPositionBitValue(c2);

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitPositionAddEvents(x=%p,c1=%c,c2=%c)", x, c1, c2));

    RvAssert(c1 <= c2);
    x->events |= (b2 - b1) | b2;
    

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitPositionAddEvents()"));
}


/*$
{function:
    {name: rvMdmDigitPositionSetMultipleFlag}
    {class: RvMdmDigitPosition}
    {include: rvmdmobjects.h}
    {description:
        {p: Sets the multiple flag of the digit position object.}
        {p: Set this flag to indicate that zero or more repetitions of the digit position are allowed at this point in a digit string.}
    }
    {proto: void rvMdmDigitPositionSetMultipleFlag(RvMdmDigitPosition *x, RvBool enable);}
    {params:
        {param: {n:x} {d:The digit position object.}}
        {param: {n:enable} {d:The new value of the flag.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmDigitPositionSetMultipleFlag(
    IN RvMdmDigitPosition*  x,
    IN RvBool               enable)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitPositionSetMultipleFlag(x=%p,enable=%d)", x, enable));

    x->multiple = enable;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitPositionSetMultipleFlag()"));
}


/*$
{function:
    {name: rvMdmDigitPositionSetTimerMode}
    {class: RvMdmDigitPosition}
    {include: rvmdmobjects.h}
    {description:
        {p: Sets the timer mode of the digit position object.}
        {p: Sets the timer to be used when matching the events in this position and those after it.}
    }
    {proto: void rvMdmDigitPositionSetTimerMode(RvMdmDigitPosition *x, RvMdmDigitPositionTimerMode mode);}
    {params:
        {param: {n:x} {d:The digit position object.}}
        {param: {n:mode} {d:The timer mode.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmDigitPositionSetTimerMode(
    IN RvMdmDigitPosition*          x,
    IN RvMdmDigitPositionTimerMode  mode)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitPositionSetTimerMode(x=%p,mode=%d)", x, mode));

    x->timerMode = mode;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitPositionSetTimerMode()"));
}

static RvBool rvMdmDigitPositionMatchEvent(const RvMdmDigitPosition *x, char c)
{
    return (x->events & rvMdmDigitPositionBitValue(c)) != 0;
}


/*$
{function:
    {name: rvMdmDigitPositionIsMultiple}
    {class: RvMdmDigitPosition}
    {include: rvmdmobjects.h}
    {description:
        {p: Gets the multiple flag of the digit position object.}
    }
    {proto: RvBool rvMdmDigitPositionIsMultiple(const RvMdmDigitPosition *x);}
    {params:
        {param: {n:x} {d:The digit position object.}}
    }
    {returns: The multiple flag.}
}
$*/
RvBool rvMdmDigitPositionIsMultiple(const RvMdmDigitPosition *x)
{
    return x->multiple;
}





/*$
{function:
    {name: rvMdmDigitStringConstruct}
    {class: RvMdmDigitString}
    {include: rvmdmobjects.h}
    {description:
        {p: Constructs a digit string object.}
    }
    {proto: RvMdmDigitString *rvMdmDigitStringConstruct(RvMdmDigitString *x);}
    {params:
        {param: {n:x} {d:The digit string object.}}
    }
    {returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmDigitString* RVCALLCONV rvMdmDigitStringConstruct(IN RvMdmDigitString* x)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitStringConstruct(x=%p)", x));

    rvVectorConstruct(RvMdmDigitPosition)(&x->elements, prvDefaultAlloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitStringConstruct()=%p", x));

    return x;
}


/*$
{function:
	{name: rvMdmDigitStringConstructCopy}
	{class: RvMdmDigitString}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a copy of a digit string object.}
	}
	{proto: RvMdmDigitString *rvMdmDigitStringConstructCopy(RvMdmDigitString *d, const RvMdmDigitString *s, RvAlloc *alloc);}
	{params:
		{param: {n:d} {d:The destination digit string object.}}
		{param: {n:s} {d:The digit string object to copy.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmDigitString *rvMdmDigitStringConstructCopy(RvMdmDigitString *d, const RvMdmDigitString *s, RvAlloc *alloc)
{
	rvVectorConstructCopy(RvMdmDigitPosition)(&d->elements, &s->elements, alloc);
	return d;
}


/*$
{function:
	{name: rvMdmDigitStringDestruct}
	{class: RvMdmDigitString}
	{include: rvmdmobjects.h}
	{description:
		{p: Destroys a digit string object.}
	}
	{proto: void rvMdmDigitStringDestruct(RvMdmDigitString *x);}
	{params:
		{param: {n:x} {d:The digit string object.}}
	}
}
$*/
RVAPI void RVCALLCONV rvMdmDigitStringDestruct(IN RvMdmDigitString* x)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitStringDestruct(x=%p)", x));

    rvVectorDestruct(RvMdmDigitPosition)(&x->elements);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitStringDestruct()"));
}


/*$
{function:
	{name: rvMdmDigitStringAddElement}
	{class: RvMdmDigitString}
	{include: rvmdmobjects.h}
	{description:
		{p: Adds a digit position object to a digit string object.}
	}
	{proto: void rvMdmDigitStringAddElement(RvMdmDigitString *x, const RvMdmDigitPosition *pos);}
	{params:
		{param: {n:x} {d:The digit string object.}}
		{param: {n:pos} {d:The digit position object.}}
	}
}
$*/
RVAPI void RVCALLCONV rvMdmDigitStringAddElement(
    IN RvMdmDigitString*            x,
    IN const RvMdmDigitPosition*    pos)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitStringAddElement(x=%p,pos=%p)", x, pos));

    rvVectorPushBack(RvMdmDigitPosition)(&x->elements, pos);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitStringAddElement()"));
}

/*$
{function:
    {name: rvMdmDigitStringClear}
    {class: RvMdmDigitString}
    {include: rvmdmobjects.h}
    {description:
        {p: Removes all digit position objects from a digit string object.}
    }
    {proto: void rvMdmDigitStringClear(RvMdmDigitString *x);}
    {params:
        {param: {n:x} {d:The digit string object.}}
    }
}
$*/
void rvMdmDigitStringClear(RvMdmDigitString *x)
{
	rvVectorClear(RvMdmDigitPosition)(&x->elements);
}

typedef enum
{
	RV_MDMDIGITSTRING_UNMATCHED,
	RV_MDMDIGITSTRING_MATCHPOSSIBLE,
	RV_MDMDIGITSTRING_MATCHEDANDWAITING,
	RV_MDMDIGITSTRING_MATCHED,
	RV_MDMDIGITSTRING_MATCHEDANDWAITING_POUND,
} RvMdmDigitStringMatchType;


static RvMdmDigitStringMatchType rvMdmDigitStringMatchSection(const RvMdmDigitPosition *patIt, const RvMdmDigitPosition *patEnd,
	const char *strIt,	const char *strEnd,	RvMdmDigitPositionTimerMode *timerToUse)
{
	if(strIt == strEnd)
	{
		if(patIt == patEnd)
			return RV_MDMDIGITSTRING_MATCHED;
		if(rvMdmDigitPositionIsMultiple(patIt) && patIt + 1 == patEnd)
			return RV_MDMDIGITSTRING_MATCHEDANDWAITING;

	    if(rvMdmDigitPositionIsMultiple(patIt) \
	        && patIt + 2 == patEnd \
	        && patIt != patEnd \
	        && (patIt + 1)->events == rvMdmDigitPositionBitValue('f'))
	    {
	        return RV_MDMDIGITSTRING_MATCHEDANDWAITING_POUND;
	    }
	    
		return RV_MDMDIGITSTRING_MATCHPOSSIBLE;
	}
	if(patIt == patEnd)
		return RV_MDMDIGITSTRING_UNMATCHED;

    if (patIt->timerMode != RV_MDMDIGITPOSITION_NOCHANGE)
        *timerToUse = patIt->timerMode;
    if(!patIt->events)
        return rvMdmDigitStringMatchSection(patIt + 1, patEnd, strIt, strEnd, timerToUse);

	if(rvMdmDigitPositionIsMultiple(patIt))
	{
		RvMdmDigitStringMatchType m0 = rvMdmDigitStringMatchSection(patIt + 1, patEnd, strIt, strEnd, timerToUse);
		if(m0 == RV_MDMDIGITSTRING_MATCHED)
			return RV_MDMDIGITSTRING_MATCHED;
		{
		RvMdmDigitStringMatchType m1 = rvMdmDigitPositionMatchEvent(patIt, *strIt) ?
			rvMdmDigitStringMatchSection(patIt, patEnd, strIt + 1, strEnd, timerToUse)
			: RV_MDMDIGITSTRING_UNMATCHED;
		    
		return m0 > m1 ? m0 : m1; /* dependent on enum values. fix? */
		}
	}

	if(rvMdmDigitPositionMatchEvent(patIt, *strIt))
		return rvMdmDigitStringMatchSection(patIt + 1, patEnd, strIt + 1, strEnd, timerToUse);

	return RV_MDMDIGITSTRING_UNMATCHED;
}

static RvMdmDigitStringMatchType rvMdmDigitStringMatch(const RvMdmDigitString *x, const char *dialString, RvMdmDigitPositionTimerMode *timerToUse)
{
	return rvMdmDigitStringMatchSection(rvVectorBegin(&x->elements), rvVectorEnd(&x->elements),
	                                       dialString, dialString + strlen(dialString), timerToUse);
}


/*$
{function:
	{name: rvMdmDigitMapConstruct}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a digit map object.}
	}
	{proto: RvMdmDigitMap *rvMdmDigitMapConstruct(RvMdmDigitMap *x);}
	{params:
		{param: {n:x} {d:The digit map object.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RVAPI RvMdmDigitMap* RVCALLCONV rvMdmDigitMapConstruct(IN RvMdmDigitMap *x)
{
    RvMdmDigitMap* result;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitMapConstruct(x=%p)", x));

    result = rvMdmDigitMapConstructA(x, prvDefaultAlloc);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitMapConstruct()=%p", result));

    return result;
}


/*$
{function:
	{name: rvMdmDigitMapConstructA}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a digit map object.}
	}
	{proto: RvMdmDigitMap *rvMdmDigitMapConstructA(RvMdmDigitMap *x, RvAlloc *alloc);}
	{params:
		{param: {n:x} {d:The digit map object.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmDigitMap* 	 rvMdmDigitMapConstructA(
    IN RvMdmDigitMap*   x,
    IN RvAlloc*         alloc)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitMapConstructA(x=%p,alloc=%p)", x, alloc));

    x->patterns.data = NULL;
    rvVectorConstruct(RvMdmDigitString)(&x->patterns, alloc);
    x->startTimeout = RVMTF_DIGITMAP_DEF_START_TIMEOUT;
    x->shortTimeout = RVMTF_DIGITMAP_DEF_SHORT_TIMEOUT;
    x->longTimeout = RVMTF_DIGITMAP_DEF_LONG_TIMEOUT;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitMapConstructA()=%p", x));

    return x;
}


/*$
{function:
	{name: rvMdmDigitMapConstructCopy}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a copy of a digit map object.}
	}
	{proto: RvMdmDigitMap *rvMdmDigitMapConstructCopy(RvMdmDigitMap *d, const RvMdmDigitMap *s, RvAlloc *alloc);}
	{params:
		{param: {n:d} {d:The destination digit map object.}}
		{param: {n:s} {d:The digit map object to copy.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmDigitMap *rvMdmDigitMapConstructCopy(RvMdmDigitMap *d, const RvMdmDigitMap *s, RvAlloc *alloc)
{
	d->patterns.data = NULL;
	rvVectorConstructCopy(RvMdmDigitString)(&d->patterns, &s->patterns, alloc);
	d->startTimeout = s->startTimeout;
	d->shortTimeout = s->shortTimeout;
	d->longTimeout = s->longTimeout;
	return d;
}


/*$
{function:
	{name: rvMdmDigitMapDestruct}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Destroys a digit map object.}
	}
	{proto: void rvMdmDigitMapDestruct(RvMdmDigitMap *x);}
	{params:
		{param: {n:x} {d:The digit map object.}}
	}
}
$*/
RVAPI void RVCALLCONV rvMdmDigitMapDestruct(IN RvMdmDigitMap* x)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitMapDestruct(x=%p)", x));

    rvVectorDestruct(RvMdmDigitString)(&x->patterns);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitMapDestruct()"));
}

/*$
{function:
	{name: rvMdmDigitMapCopy}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Copies the value of one digit map object to another.}
	}
	{proto: RvMdmDigitMap *rvMdmDigitMapCopy(RvMdmDigitMap *d, const RvMdmDigitMap *s);}
	{params:
		{param: {n:d} {d:The destination digit map object.}}
		{param: {n:s} {d:The digit map object to copy.}}
	}
	{returns: A pointer to the destination object, or NULL if the copy failed.}
}
$*/
RVAPI RvMdmDigitMap* RVCALLCONV rvMdmDigitMapCopy(
    IN RvMdmDigitMap*       d,
    IN const RvMdmDigitMap* s)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitMapCopy(d=%p,s=%p)", d, s));

    rvVectorCopy(RvMdmDigitString)(&d->patterns, &s->patterns);
    d->startTimeout = s->startTimeout;
    d->shortTimeout = s->shortTimeout;
    d->longTimeout = s->longTimeout;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitMapCopy()=%p", d));

    return d;
}


/*$
{function:
	{name: rvMdmDigitMapAddPattern}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Adds a digit string object to a digit map object.}
	}
	{proto: void rvMdmDigitMapAddPattern(RvMdmDigitMap *x, const RvMdmDigitString *s);}
	{params:
		{param: {n:x} {d:The digit map object.}}
		{param: {n:s} {d:The digit string object.}}
	}
}
$*/
RVAPI void RVCALLCONV rvMdmDigitMapAddPattern(
    IN RvMdmDigitMap*           x,
    IN const RvMdmDigitString*  s)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitMapAddPattern(x=%p,s=%p)", x, s));

    rvVectorPushBack(RvMdmDigitString)(&x->patterns, s);

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitMapAddPattern()"));
}

/*$
{function:
	{name: rvMdmDigitMapGetSize}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Returns how many digit string objects are contained in the digit map object.}
	}
	{proto: size_t rvMdmDigitMapGetSize(const RvMdmDigitMap *x);}
	{params:
		{param: {n:x} {d:The digit map object.}}
	}
	{returns: The number of digit strings.}
}
$*/
size_t rvMdmDigitMapGetSize(const RvMdmDigitMap *x)
{
	return rvVectorSize(&x->patterns);
}

/*$
{function:
	{name: rvMdmDigitMapSetStartTimeout}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Sets the start timeout of the digit map object.}
	}
	{proto: void rvMdmDigitMapSetStartTimeout(RvMdmDigitMap *x, unsigned int val);}
	{params:
		{param: {n:x} {d:The digit map object.}}
		{param: {n:val} {d:The start timeout.}}
	}
}
$*/
RVAPI void RVCALLCONV rvMdmDigitMapSetStartTimeout(
    IN RvMdmDigitMap*   x,
    IN RvUint32         val)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitMapSetStartTimeout(x=%p,val=%d)", x, val));

    x->startTimeout = val;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitMapSetStartTimeout()"));
}

/*$
{function:
    {name: rvMdmDigitMapSetShortTimeout}
    {class: RvMdmDigitMap}
    {include: rvmdmobjects.h}
    {description:
        {p: Sets the short timeout of the digit map object.}
    }
    {proto: void rvMdmDigitMapSetShortTimeout(RvMdmDigitMap *x, unsigned int val);}
    {params:
        {param: {n:x} {d:The digit map object.}}
        {param: {n:val} {d:The short timeout.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmDigitMapSetShortTimeout(
    IN RvMdmDigitMap*   x,
    IN RvUint32         val)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitMapSetShortTimeout(x=%p,val=%d)", x, val));

    x->shortTimeout = val;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitMapSetShortTimeout()"));
}


/*$
{function:
    {name: rvMdmDigitMapSetLongTimeout}
    {class: RvMdmDigitMap}
    {include: rvmdmobjects.h}
    {description:
        {p: Sets the long timeout of the digit map object.}
    }
    {proto: void rvMdmDigitMapSetLongTimeout(RvMdmDigitMap *x, unsigned int val);}
    {params:
        {param: {n:x} {d:The digit map object.}}
        {param: {n:val} {d:The long timeout.}}
    }
}
$*/
RVAPI void RVCALLCONV rvMdmDigitMapSetLongTimeout(
    IN RvMdmDigitMap*   x,
    IN RvUint32         val)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmDigitMapSetLongTimeout(x=%p,val=%d)", x, val));

    x->longTimeout = val;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmDigitMapSetLongTimeout()"));
}


/*$
{function:
    {name: rvMdmDigitMapGetStartTimeout}
    {class: RvMdmDigitMap}
    {include: rvmdmobjects.h}
    {description:
        {p: Gets the start timeout of the digit map object.}
    }
    {proto: unsigned int rvMdmDigitMapGetStartTimeout(const RvMdmDigitMap *x);}
    {params:
        {param: {n:x} {d:The digit map object.}}
    }
    {returns: The start timeout.}
}
$*/
RvUint32 rvMdmDigitMapGetStartTimeout(IN const RvMdmDigitMap *x)
{
    return x->startTimeout;
}

/*$
{function:
	{name: rvMdmDigitMapMatch}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Test a dial string against a digit map for a match.}
		{p: Use of Digit Map class:}
		{p: Start the interdigit timer with the value returned by rvMdmDigitMapGetStartTimeout.}
		{p: When a digit is received, add it to the dial string and call rvMdmDigitMapMatch. }
		{p: If rvMdmDigitMapMatch returns RV_MDMDIGITMAP_UNAMBIGUOUSMATCH, send a notify with dd/Meth=UM.}
		{p:	If rvMdmDigitMapMatch returns RV_MDMDIGITMAP_PARTIALMATCH, reset the timer to the
		value loaded into timerDuration. If timer expires before next digit, send notify with dd/Meth=PM.}
		{p: If rvMdmDigitMapMatch returns RV_MDMDIGITMAP_FULLMATCH, reset the timer to the
		value loaded into timerDuration. If timer expires before next digit, send notify with dd/Meth=FM.}
		{p: If rvMdmDigitMapMatch returns RV_MDMDIGITMAP_NOMATCH, remove the last digit from
		the dial string and send notify. Set dd/Meth to PM if previous call to rvMdmDigitMapMatch
		returned RV_MDMDIGITMAP_PARTIALMATCH or to FM if previous call to rvMdmDigitMapMatch
		returned RV_MDMDIGITMAP_FULLMATCH.}
	}
	{proto: RvMdmDigitMapMatchType rvMdmDigitMapMatch(const RvMdmDigitMap *x, const char *dialString, unsigned int *timerDuration);}
	{params:
		{param: {n:x} {d:The digit map object.}}
		{param: {n:dialString} {d:The dial string.}}
		{param: {n:timerDuration} {d:The new timer value. (Pointer)}}
	}
	{returns: The type of match.}
}
$*/
RvMdmDigitMapMatchType rvMdmDigitMapMatch(const RvMdmDigitMap *x, const char *dialString, unsigned int *timerDuration)
{
    RvMdmDigitMapMatchType matchType;
    RvMdmDigitPositionTimerMode timerToUse = RV_MDMDIGITPOSITION_NOCHANGE;
    size_t numMatched = 0, numWaiting = 0, numPossible = 0;
    size_t waitingPound = 0;
    size_t i;
    for(i=0; i<rvMdmDigitMapGetSize(x); ++i)
    {
        RvMdmDigitPositionTimerMode mode = RV_MDMDIGITPOSITION_NOCHANGE;
        switch(rvMdmDigitStringMatch(rvMdmDigitMapGetElem(x, i), dialString, &mode))
        {
        case RV_MDMDIGITSTRING_MATCHED:
            numMatched++;
            break;
        case RV_MDMDIGITSTRING_MATCHEDANDWAITING:
            numWaiting++;
            if(mode != RV_MDMDIGITPOSITION_NOCHANGE)
                timerToUse = mode;
            break;
        case RV_MDMDIGITSTRING_MATCHEDANDWAITING_POUND:
            numPossible++;
            waitingPound ++;
            if(mode != RV_MDMDIGITPOSITION_NOCHANGE)
                timerToUse = mode;
            break;
        case RV_MDMDIGITSTRING_MATCHPOSSIBLE:
            numPossible++;
            if(mode != RV_MDMDIGITPOSITION_NOCHANGE)
                timerToUse = mode;
            break;
        case RV_MDMDIGITSTRING_UNMATCHED:
            break; /* Do nothing */
        }
    }
    
    printf("numMatched = %d, numWaiting = %d,numPossible = %d,waitingPound = %d,timerToUse=%d\n",\
                    numMatched,numWaiting,numPossible,waitingPound,timerToUse);
    
    /*match max*/
    if(g_dwDigitMatchType == 1)
    {
        switch(numMatched)
        {
        case 0:
            matchType = numWaiting ? RV_MDMDIGITMAP_FULLMATCH :
                        numPossible ? RV_MDMDIGITMAP_PARTIALMATCH : RV_MDMDIGITMAP_NOMATCH;
            break;
        case 1:
            matchType = (numWaiting || numPossible) ? RV_MDMDIGITMAP_FULLMATCH :
                        RV_MDMDIGITMAP_UNAMBIGUOUSMATCH;
            break;
        default:
            matchType = RV_MDMDIGITMAP_FULLMATCH;
            break;
        }
    }
    else if(g_dwDigitMatchType == 2) /*exact match max*/
    {
        switch(numMatched)
        {
            case 0:
                matchType = (numWaiting > 1) ? RV_MDMDIGITMAP_FULLMATCH :
                            numPossible ? RV_MDMDIGITMAP_PARTIALMATCH : RV_MDMDIGITMAP_NOMATCH;
                break;
            case 1: 
            default:
                {
                    if(numPossible >= 1)
                    {
                        matchType = RV_MDMDIGITMAP_FULLMATCH;
                    }
                    else
                    {
                        matchType = RV_MDMDIGITMAP_UNAMBIGUOUSMATCH;
                    }
                    
                }
                break;
        }
    }
    else /*match min*/
    {
        switch(numMatched)
        {
            case 0:
                matchType = numWaiting ? RV_MDMDIGITMAP_FULLMATCH :
                            numPossible ? RV_MDMDIGITMAP_PARTIALMATCH : RV_MDMDIGITMAP_NOMATCH;
                break;
            default:
                matchType = RV_MDMDIGITMAP_UNAMBIGUOUSMATCH;
                break;
        }
    }


    
    if(PSip_IsIntelligentPhoneNumber(dialString) == 1)
    {
        matchType = RV_MDMDIGITMAP_UNAMBIGUOUSMATCH;
    }
    
    switch(matchType)
    {
    case RV_MDMDIGITMAP_PARTIALMATCH: /* use long timer by default */
        *timerDuration = timerToUse == RV_MDMDIGITPOSITION_SHORTTIMER ?
            x->shortTimeout : x->longTimeout;
        break;
    case RV_MDMDIGITMAP_FULLMATCH: /* use short timer by default */
        *timerDuration = timerToUse == RV_MDMDIGITPOSITION_LONGTIMER ?
            x->longTimeout : x->shortTimeout;

        if(g_dwDigitMatchType == 2 && numMatched >= 1 && numPossible == 1 && waitingPound == 1)
        {
            *timerDuration = 2;
        }
        
        if(g_dwDigitMatchType == 2 && numMatched == 0 && numWaiting >= 2)
        {
            *timerDuration = x->shortTimeout;
        }
        
        if(g_dwDigitMatchType == 2 && numMatched == 1 && numPossible > 1)
        {
            *timerDuration = x->shortTimeout;
        }
        
        break;
    case RV_MDMDIGITMAP_NOMATCH:
    case RV_MDMDIGITMAP_UNAMBIGUOUSMATCH:
    default:
        *timerDuration = 0;
        break;
    }
 
    /* if the last digit is # */
    if(g_dwDigitFQuickRpt == 1)
    {
        if(strlen(dialString) > 1 && dialString[strlen(dialString)-1] == 'f')
        {
            if(dialString[0] >='0' && dialString[0]<= '9' )
            {
               matchType =  RV_MDMDIGITMAP_UNAMBIGUOUSMATCH;
               *timerDuration = 0;
            }
        }
    }
    printf("DigitTimer = %d s\n",*timerDuration);
    
    return matchType;
}

/*$
{function:
	{name: rvMdmDigitMapGetElem}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets one digit string object in a digit map object.}
	}
	{proto: const RvMdmDigitString *rvMdmDigitMapGetElem(const RvMdmDigitMap *x, size_t index);}
	{params:
		{param: {n:x} {d:The digit map object.}}
		{param: {n:index} {d:The index.}}
	}
	{returns: The digit string.}
}
$*/
const RvMdmDigitString *rvMdmDigitMapGetElem(const RvMdmDigitMap *x, size_t index)
{
	return rvVectorAt(&x->patterns, index);
}

/*$
{function:
	{name: rvMdmDigitMapGetShortTimeout}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the short timeout of the digit map object.}
	}
	{proto: unsigned int rvMdmDigitMapGetShortTimeout(const RvMdmDigitMap *x);}
	{params:
		{param: {n:x} {d:The digit map object.}}
	}
	{returns: The short timeout.}
}
$*/
unsigned int rvMdmDigitMapGetShortTimeout(const RvMdmDigitMap *x)
{
	return x->shortTimeout;
}


/*$
{function:
	{name: rvMdmDigitMapGetLongTimeout}
	{class: RvMdmDigitMap}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the long timeout of the digit map object.}
	}
	{proto: unsigned int rvMdmDigitMapGetLongTimeout(const RvMdmDigitMap *x);}
	{params:
		{param: {n:x} {d:The digit map object.}}
	}
	{returns: The long timeout.}
}
$*/
unsigned int rvMdmDigitMapGetLongTimeout(const RvMdmDigitMap *x)
{
	return x->longTimeout;
}


/*$
{function:
	{name: rvMdmDigitMapDescriptorConstruct}
	{class: RvMdmDigitMapDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a digit map descriptor object.}
		{p: A digit map descriptor may contain a digit map, a previously defined digit map name,
		or a new digit map name and its definition.}
	}
	{proto: RvMdmDigitMapDescriptor *rvMdmDigitMapDescriptorConstruct(RvMdmDigitMapDescriptor *x, const char *name, const RvMdmDigitMap *map);}
	{params:
		{param: {n:x} {d:The digit map descriptor object.}}
		{param: {n:name} {d:The name of the digit map.}}
		{param: {n:map} {d:The digit map.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
	{notes:
		{note:  A digit map descriptor embedded in an events descriptor
			cannot contain both a name and a digit map.}
	}
}
$*/
RvMdmDigitMapDescriptor *rvMdmDigitMapDescriptorConstruct(RvMdmDigitMapDescriptor *x, const char *name, const RvMdmDigitMap *map)
{
	return rvMdmDigitMapDescriptorConstructA(x, name, map, prvDefaultAlloc);
}


/*$
{function:
	{name: rvMdmDigitMapDescriptorConstructA}
	{class: RvMdmDigitMapDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a digit map descriptor object.}
		{p: A digit map descriptor may contain a digit map, a previously defined digit map name,
		or a new digit map name and its definition.}
	}
	{proto: RvMdmDigitMapDescriptor *rvMdmDigitMapDescriptorConstructA(RvMdmDigitMapDescriptor *x, const char *name, const RvMdmDigitMap *map, RvAlloc *alloc);}
	{params:
		{param: {n:x} {d:The digit map descriptor object.}}
		{param: {n:name} {d:The name of the digit map.}}
		{param: {n:map} {d:The digit map.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
	{notes:
		{note:  A digit map descriptor embedded in an events descriptor
			cannot contain both a name and a digit map.}
	}
}
$*/
RvMdmDigitMapDescriptor *rvMdmDigitMapDescriptorConstructA(RvMdmDigitMapDescriptor *x, const char *name, const RvMdmDigitMap *map, RvAlloc *alloc)
{
	rvStringConstruct(&x->name, name, alloc);
	rvMdmDigitMapConstructCopy(&x->digitMap, map, alloc);
	return x;
}

static RvMdmDigitMapDescriptor *rvMdmDigitMapDescriptorConstructBlankA(RvMdmDigitMapDescriptor *x, RvAlloc *alloc)
{
	RvMdmDigitMap blank;
	rvMdmDigitMapConstructA(&blank, alloc);
	rvMdmDigitMapDescriptorConstructA(x, "", &blank, alloc);
	rvMdmDigitMapDestruct(&blank);
	return x;
}


/*$
{function:
	{name: rvMdmDigitMapDescriptorConstructCopy}
	{class: RvMdmDigitMapDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a copy of a digit map descriptor object.}
	}
	{proto: RvMdmDigitMapDescriptor *rvMdmDigitMapDescriptorConstructCopy(RvMdmDigitMapDescriptor *d, const RvMdmDigitMapDescriptor *s, RvAlloc *alloc);}
	{params:
		{param: {n:d} {d:The destination digit map descriptor object.}}
		{param: {n:s} {d:The digit map descriptor object to copy.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmDigitMapDescriptor *rvMdmDigitMapDescriptorConstructCopy(RvMdmDigitMapDescriptor *d, const RvMdmDigitMapDescriptor *s, RvAlloc *alloc)
{
	rvStringConstructCopy(&d->name, &s->name, alloc);
	rvMdmDigitMapConstructCopy(&d->digitMap, &s->digitMap, alloc);
	return d;
}


/*$
{function:
	{name: rvMdmDigitMapDescriptorDestruct}
	{class: RvMdmDigitMapDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Destroys a digit map descriptor object.}
	}
	{proto: void rvMdmDigitMapDescriptorDestruct(RvMdmDigitMapDescriptor *x);}
	{params:
		{param: {n:x} {d:The digit map descriptor object.}}
	}
}
$*/
void rvMdmDigitMapDescriptorDestruct(RvMdmDigitMapDescriptor *x)
{
	rvStringDestruct(&x->name);
	rvMdmDigitMapDestruct(&x->digitMap);
}


/*$
{function:
	{name: rvMdmDigitMapDescriptorCopy}
	{class: RvMdmDigitMapDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Copies the value of one digit map descriptor object to another.}
	}
	{proto: RvMdmDigitMapDescriptor *rvMdmDigitMapDescriptorCopy(RvMdmDigitMapDescriptor *d, const RvMdmDigitMapDescriptor *s);}
	{params:
		{param: {n:d} {d:The destination digit map descriptor object.}}
		{param: {n:s} {d:The digit map descriptor object to copy.}}
	}
	{returns: A pointer to the destination object, or NULL if the copy failed.}
}
$*/
RvMdmDigitMapDescriptor *rvMdmDigitMapDescriptorCopy(RvMdmDigitMapDescriptor *d, const RvMdmDigitMapDescriptor *s)
{
	rvStringCopy(&d->name, &s->name);
	rvMdmDigitMapCopy(&d->digitMap, &s->digitMap);
	return d;
}


/*$
{function:
	{name: rvMdmDigitMapDescriptorGetName}
	{class: RvMdmDigitMapDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the name of the digit map from the digit map descriptor object.}
	}
	{proto: const char *rvMdmDigitMapDescriptorGetName(const RvMdmDigitMapDescriptor *x);}
	{params:
		{param: {n:x} {d:The digit map descriptor object.}}
	}
	{returns: The name.}
}
$*/
const char *rvMdmDigitMapDescriptorGetName(const RvMdmDigitMapDescriptor *x)
{
	return rvStringGetData(&x->name);
}


/*$
{function:
	{name: rvMdmDigitMapDescriptorGetDigitMap}
	{class: RvMdmDigitMapDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the digit map from the digit map descriptor object.}
	}
	{proto: const RvMdmDigitMap *rvMdmDigitMapDescriptorGetDigitMap(const RvMdmDigitMapDescriptor *x);}
	{params:
		{param: {n:x} {d:The digit map descriptor object.}}
	}
	{returns: The digit map.}
}
$*/
const RvMdmDigitMap *rvMdmDigitMapDescriptorGetDigitMap(const RvMdmDigitMapDescriptor *x)
{
	return &x->digitMap;
}


/*$
{function:
	{name: rvMdmDigitMapDescriptorIsSet}
	{class: RvMdmDigitMapDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Checks whether the digit map descriptor object is set.}
	}
	{proto: RvBool rvMdmDigitMapDescriptorIsSet(const RvMdmDigitMapDescriptor *x);}
	{params:
		{param: {n:x} {d:The digit map descriptor object.}}
	}
	{returns: rvTrue if the object is set, rvFalse if not.}
}
$*/
RvBool rvMdmDigitMapDescriptorIsSet(const RvMdmDigitMapDescriptor *x)
{
	return *rvMdmDigitMapDescriptorGetName(x) != 0 ||
		rvMdmDigitMapGetSize(rvMdmDigitMapDescriptorGetDigitMap(x));
}

/*$
{function:
	{name: rvMdmEventConstructA}
	{class: RvMdmEvent}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs an event object.}
	}
	{proto: RvMdmEvent *rvMdmEventConstructA(RvMdmEvent *x, const RvMdmPackageItem *name, RvAlloc *alloc);}
	{params:
		{param: {n:x} {d:The event object.}}
		{param: {n:name} {d:The event name.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmEvent *rvMdmEventConstructA(RvMdmEvent *x, const RvMdmPackageItem *name, RvAlloc *alloc)
{
	rvMdmPackageItemConstructCopy(&x->name, name, alloc);
	rvMdmParameterListConstructA(&x->parameters, alloc);
	return x;
}


/*$
{function:
	{name: rvMdmEventConstructCopy}
	{class: RvMdmEvent}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a copy of an event object.}
	}
	{proto: RvMdmEvent *rvMdmEventConstructCopy(RvMdmEvent *d, const RvMdmEvent *s, RvAlloc *alloc);}
	{params:
		{param: {n:d} {d:The destination event object.}}
		{param: {n:s} {d:The event object to copy.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmEvent *rvMdmEventConstructCopy(RvMdmEvent *d, const RvMdmEvent *s, RvAlloc *alloc)
{
	rvMdmPackageItemConstructCopy(&d->name, &s->name, alloc);
	rvMdmParameterListConstructCopy(&d->parameters, &s->parameters, alloc);
	return d;
}


/*$
{function:
	{name: rvMdmEventDestruct}
	{class: RvMdmEvent}
	{include: rvmdmobjects.h}
	{description:
		{p: Destroys an event object.}
	}
	{proto: void rvMdmEventDestruct(RvMdmEvent *x);}
	{params:
		{param: {n:x} {d:The event object.}}
	}
}
$*/
void rvMdmEventDestruct(RvMdmEvent *x)
{
	rvMdmPackageItemDestruct(&x->name);
	rvMdmParameterListDestruct(&x->parameters);
}

/*$
{function:
	{name: rvMdmEventSetParameter}
	{class: RvMdmEvent}
	{include: rvmdmobjects.h}
	{description:
		{p: Sets a parameter in the event object.}
	}
	{proto: void rvMdmEventSetParameter(RvMdmEvent *x, const char *name, const RvMdmParameterValue *value);}
	{params:
		{param: {n:x} {d:The event object.}}
		{param: {n:name} {d:The parameter name.}}
		{param: {n:value} {d:The parameter value.}}
	}
}
$*/
void rvMdmEventSetParameter(RvMdmEvent *x, const char *name, const RvMdmParameterValue *value)
{
	rvMdmParameterListSet2(&x->parameters, name, value);
}


RVAPI const RvMdmPackageItem* RVCALLCONV rvMdmEventGetName(IN const RvMdmEvent* x)
{
    const RvMdmPackageItem* item;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmEventGetName(x=%p)", x));

    item = &x->name;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmEventGetName()=%p", item));

    return item;
}


RVAPI const RvMdmParameterList* RVCALLCONV rvMdmEventGetParameterList(IN const RvMdmEvent *x)
{
    const RvMdmParameterList* params;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmEventGetParameterList(x=%p)", x));

    params = &x->parameters;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmEventGetParameterList()=%p", params));

    return params;
}

/*$
{function:
	{name: rvMdmEventSetParametersList}
	{class: RvMdmEvent}
	{include: rvmdmobjects.h}
	{description:
		{p: Sets the parameter list of the event object.}
	}
	{proto: void rvMdmEventSetParametersList(RvMdmEvent *x, RvMdmParameterList* params);}
	{params:
		{param: {n:x} {d:The event object.}}
		{param: {n:params} {d:The parameter list.}}
	}
}
$*/
void rvMdmEventSetParametersList(RvMdmEvent *x, RvMdmParameterList* params)
{
	rvMdmParameterListCopy(&x->parameters, params);
}

/*$
{function:
	{name: rvMdmRequestedEventConstruct}
	{class: RvMdmRequestedEvent}
	{include: RvMdmobjects.h}
	{description:
		{p: Constructs a requested event object.}
	}
	{proto: RvMdmRequestedEvent *rvMdmRequestedEventConstruct(RvMdmRequestedEvent *x, const RvMdmPackageItem *name);}
	{params:
		{param: {n:x} {d:The requested event object.}}
		{param: {n:name} {d:The event name.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmRequestedEvent *rvMdmRequestedEventConstruct(RvMdmRequestedEvent *x, const RvMdmPackageItem *name)
{
	return rvMdmRequestedEventConstructA(x, name, prvDefaultAlloc);
}



/*$
{function:
	{name: rvMdmRequestedEventConstructA}
	{class: RvMdmRequestedEvent}
	{include: RvMdmobjects.h}
	{description:
		{p: Constructs a requested event object.}
	}
	{proto: RvMdmRequestedEvent *rvMdmRequestedEventConstructA(RvMdmRequestedEvent *x, const RvMdmPackageItem *name, RvAlloc *alloc);}
	{params:
		{param: {n:x} {d:The requested event object.}}
		{param: {n:name} {d:The event name.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmRequestedEvent *rvMdmRequestedEventConstructA(RvMdmRequestedEvent *x, const RvMdmPackageItem *name, RvAlloc *alloc)
{
	rvMdmEventConstructA(&x->event, name, alloc);
	rvMdmDigitMapDescriptorConstructBlankA(&x->digitMap, alloc);
	rvMdmSignalsDescriptorConstructA(&x->signals, alloc);
	x->events = NULL;
	return x;
}

/*$
{function:
	{name: rvMdmRequestedEventConstructCopy}
	{class: RvMdmRequestedEvent}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a copy of a requested event object.}
	}
	{proto: RvMdmRequestedEvent *rvMdmRequestedEventConstructCopy(RvMdmRequestedEvent *d, const RvMdmRequestedEvent *s, RvAlloc *alloc);}
	{params:
		{param: {n:d} {d:The destination requested event object.}}
		{param: {n:s} {d:The requested event object to copy.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmRequestedEvent *rvMdmRequestedEventConstructCopy(RvMdmRequestedEvent *d, const RvMdmRequestedEvent *s, RvAlloc *alloc)
{
	rvMdmEventConstructCopy(&d->event, &s->event, alloc);
	rvMdmDigitMapDescriptorConstructCopy(&d->digitMap, &s->digitMap, alloc);
	rvMdmSignalsDescriptorConstructCopy(&d->signals, &s->signals, alloc);
	if(s->events == NULL)
	{
		d->events = NULL;
	}
	else
	{
		rvMtfAllocatorAlloc( sizeof(RvMdmEventsDescriptor), (void**)&d->events);
		rvMdmEventsDescriptorConstructCopy(d->events, s->events, alloc);
	}
	return d;
}

/*$
{function:
	{name: rvMdmRequestedEventDestruct}
	{class: RvMdmRequestedEvent}
	{include: RvMdmobjects.h}
	{description:
		{p: Destroys a requested event object.}
	}
	{proto: void rvMdmRequestedEventDestruct(RvMdmRequestedEvent *x);}
	{params:
		{param: {n:x} {d:The requested event object.}}
	}
}
$*/
void rvMdmRequestedEventDestruct(RvMdmRequestedEvent *x)
{
	rvMdmEventDestruct(&x->event);
	rvMdmDigitMapDescriptorDestruct(&x->digitMap);
	rvMdmSignalsDescriptorDestruct(&x->signals);
	if(x->events != NULL)
	{
		rvMdmEventsDescriptorDestruct(x->events);
		rvMtfAllocatorDealloc(x->events, sizeof(RvMdmEventsDescriptor));
	}
}

/*$
{function:
	{name: rvMdmRequestedEventGetEmbDigitMap}
	{class: RvMdmRequestedEvent}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the embedded digit map of the requested event object.}
	}
	{proto: const RvMdmDigitMapDescriptor *rvMdmRequestedEventGetEmbDigitMap(const RvMdmRequestedEvent *x);}
	{params:
		{param: {n:x} {d:The requested event object.}}
	}
	{returns: The digit map.}
}
$*/
const RvMdmDigitMapDescriptor *rvMdmRequestedEventGetEmbDigitMap(const RvMdmRequestedEvent *x)
{
	return &x->digitMap;
}

/*$
{function:
	{name: rvMdmEventsDescriptorConstruct}
	{class: RvMdmEventsDescriptor}
	{include: RvMdmobjects.h}
	{description:
		{p: Constructs an events descriptor object.}
	}
	{proto: RvMdmEventsDescriptor *rvMdmEventsDescriptorConstruct(RvMdmEventsDescriptor *x, unsigned int id);}
	{params:
		{param: {n:x} {d:The events descriptor object.}}
		{param: {n:id} {d:The request identifier.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmEventsDescriptor *rvMdmEventsDescriptorConstruct(RvMdmEventsDescriptor *x, unsigned int id)
{
	return rvMdmEventsDescriptorConstructA(x, id, prvDefaultAlloc);
}


/*$
{function:
	{name: rvMdmEventsDescriptorConstructA}
	{class: RvMdmEventsDescriptor}
	{include: RvMdmobjects.h}
	{description:
		{p: Constructs an events descriptor object.}
	}
	{proto: RvMdmEventsDescriptor *rvMdmEventsDescriptorConstructA(RvMdmEventsDescriptor *x, unsigned int id, RvAlloc *alloc);}
	{params:
		{param: {n:x} {d:The events descriptor object.}}
		{param: {n:id} {d:The request identifier.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmEventsDescriptor *rvMdmEventsDescriptorConstructA(RvMdmEventsDescriptor *x, unsigned int id, RvAlloc *alloc)
{
	x->requestId = id;
	rvVectorConstruct(RvMdmRequestedEvent)(&x->events, alloc);
	x->events.data = NULL;
	return x;
}

/*$
{function:
	{name: rvMdmEventsDescriptorConstructCopy}
	{class: RvMdmEventsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a copy of an events descriptor object.}
	}
	{proto: RvMdmEventsDescriptor *rvMdmEventsDescriptorConstructCopy(RvMdmEventsDescriptor *d, const RvMdmEventsDescriptor *s, RvAlloc *alloc);}
	{params:
		{param: {n:d} {d:The destination events descriptor object.}}
		{param: {n:s} {d:The events descriptor object to copy.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmEventsDescriptor *rvMdmEventsDescriptorConstructCopy(RvMdmEventsDescriptor *d, const RvMdmEventsDescriptor *s, RvAlloc *alloc)
{
	d->requestId = s->requestId;
	rvVectorConstructCopy(RvMdmRequestedEvent)(&d->events, &s->events, alloc);
	return d;
}

/*$
{function:
	{name: rvMdmEventsDescriptorCopy}
	{class: RvMdmEventsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Copies the value of one events descriptor object to another.}
	}
	{proto: RvMdmEventsDescriptor *rvMdmEventsDescriptorCopy(RvMdmEventsDescriptor *d, const RvMdmEventsDescriptor *s);}
	{params:
		{param: {n:d} {d:The destination events descriptor object.}}
		{param: {n:s} {d:The events descriptor object to copy.}}
	}
	{returns: A pointer to the destination object, or NULL if the copy failed.}
}
$*/
RvMdmEventsDescriptor *rvMdmEventsDescriptorCopy(RvMdmEventsDescriptor *d, const RvMdmEventsDescriptor *s)
{
	d->requestId = s->requestId;
	rvVectorCopy(RvMdmRequestedEvent)(&d->events, &s->events);
	return d;
}

/*$
{function:
	{name: rvMdmEventsDescriptorDestruct}
	{class: RvMdmEventsDescriptor}
	{include: RvMdmobjects.h}
	{description:
		{p: Destroys an events descriptor object.}
	}
	{proto: void rvMdmEventsDescriptorDestruct(RvMdmEventsDescriptor *x);}
	{params:
		{param: {n:x} {d:The events descriptor object.}}
	}
}
$*/
void rvMdmEventsDescriptorDestruct(RvMdmEventsDescriptor *x)
{
	rvVectorDestruct(RvMdmRequestedEvent)(&x->events);
}



/*$
{function:
	{name: rvMdmEventsDescriptorAddEvent}
	{class: RvMdmEventsDescriptor}
	{include: RvMdmobjects.h}
	{description:
		{p: Adds an event to an events descriptor object.}
	}
	{proto: void rvMdmEventsDescriptorAddEvent(RvMdmEventsDescriptor *x, const RvMdmRequestedEvent *event);}
	{params:
		{param: {n:x} {d:The events descriptor object.}}
		{param: {n:event} {d:The event.}}
	}
}
$*/
void rvMdmEventsDescriptorAddEvent(RvMdmEventsDescriptor *x, const RvMdmRequestedEvent *event)
{
	rvVectorPushBack(RvMdmRequestedEvent)(&x->events, event);
}

/*$
{function:
	{name: rvMdmEventsDescriptorGetEvent}
	{class: RvMdmEventsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets one event in an events descriptor object.}
	}
	{proto: const RvMdmRequestedEvent *rvMdmEventsDescriptorGetEvent(const RvMdmEventsDescriptor *x, size_t index);}
	{params:
		{param: {n:x} {d:The events descriptor object.}}
		{param: {n:index} {d:The index.}}
	}
	{returns: The event.}
}
$*/
const RvMdmRequestedEvent *rvMdmEventsDescriptorGetEvent(const RvMdmEventsDescriptor *x, size_t index)
{
	return rvVectorAt(&x->events, index);
}

/*$
{function:
	{name: rvMdmEventsDescriptorGetNumEvents}
	{class: RvMdmEventsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the number of events in an events descriptor object.}
	}
	{proto: size_t rvMdmEventsDescriptorGetNumEvents(const RvMdmEventsDescriptor *x);}
	{params:
		{param: {n:x} {d:The events descriptor object.}}
	}
	{returns: The number of events.}
}
$*/
size_t rvMdmEventsDescriptorGetNumEvents(const RvMdmEventsDescriptor *x)
{
	return rvVectorSize(&x->events);
}


/*$
{function:
	{name: rvMdmEventsDescriptorIsSet}
	{class: RvMdmEventsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Checks whether the events descriptor object is set.}
	}
	{proto: RvBool rvMdmEventsDescriptorIsSet(const RvMdmEventsDescriptor *x);}
	{params:
		{param: {n:x} {d:The events descriptor object.}}
	}
	{returns: rvTrue if the object is set, rvFalse if not.}
}
$*/
RvBool rvMdmEventsDescriptorIsSet(const RvMdmEventsDescriptor *x)
{
	return rvMdmEventsDescriptorGetNumEvents(x) != 0;
}

/*$
{function:
	{name: rvMdmEventsDescriptorClear}
	{class: RvMdmEventsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Removes all events from an events descriptor object.}
	}
	{proto: void rvMdmEventsDescriptorClear(RvMdmEventsDescriptor *x);}
	{params:
		{param: {n:x} {d:The events descriptor object.}}
	}
}
$*/
void rvMdmEventsDescriptorClear(RvMdmEventsDescriptor *x)
{
	rvVectorClear(RvMdmRequestedEvent)(&x->events);
}


const RvMdmStreamId rvMdmStreamIdDefault = 1;


/*$
{function:
	{name: rvMdmStreamDescriptorConstructA}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a stream descriptor object.}
	}
	{proto: RvMdmStreamDescriptor *rvMdmStreamDescriptorConstructA(RvMdmStreamDescriptor *x, RvMdmStreamId streamId, RvAlloc *alloc);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
		{param: {n:streamId} {d:The stream identifier.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmStreamDescriptor *rvMdmStreamDescriptorConstructA(RvMdmStreamDescriptor *x, RvMdmStreamId streamId, RvAlloc *alloc)
{
	x->id = streamId;
	rvSdpMsgListConstructA(&x->localDescriptors, alloc);
	rvSdpMsgListConstructA(&x->remoteDescriptors, alloc);
	x->isLocalSet = x->isRemoteSet = rvFalse;
	x->mode = RV_MDMSTREAMMODE_NOTSET;
	rvMdmParameterListConstructA(&x->parameters, alloc);
	return x;
}

/*$
{function:
	{name: rvMdmStreamDescriptorConstructCopy}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a copy of a stream descriptor object.}
	}
	{proto: RvMdmStreamDescriptor *rvMdmStreamDescriptorConstructCopy(RvMdmStreamDescriptor *d, const RvMdmStreamDescriptor *s, RvAlloc *alloc);}
	{params:
		{param: {n:d} {d:The destination stream descriptor object.}}
		{param: {n:s} {d:The stream descriptor object to copy.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmStreamDescriptor *rvMdmStreamDescriptorConstructCopy(RvMdmStreamDescriptor *d, const RvMdmStreamDescriptor *s, RvAlloc *alloc)
{
	d->id = s->id;
	rvSdpMsgListConstructCopyA(&d->localDescriptors, &s->localDescriptors, alloc);
	rvSdpMsgListConstructCopyA(&d->remoteDescriptors, &s->remoteDescriptors, alloc);
    d->isLocalSet = s->isLocalSet;
	d->isRemoteSet = s->isRemoteSet;
	d->mode = s->mode;
	rvMdmParameterListConstructCopy(&d->parameters, &s->parameters, alloc);
	return d;
}
/*$
{function:
	{name: rvMdmStreamDescriptorDestruct}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Destroys a stream descriptor object.}
	}
	{proto: void rvMdmStreamDescriptorDestruct(RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
}
$*/
void rvMdmStreamDescriptorDestruct(RvMdmStreamDescriptor *x)
{
	rvSdpMsgListDestruct(&x->localDescriptors);
	rvSdpMsgListDestruct(&x->remoteDescriptors);
	rvMdmParameterListDestruct(&x->parameters);
}

/*$
{function:
	{name: rvMdmStreamDescriptorGetMode}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the mode of the stream descriptor object.}
	}
	{proto: RvMdmStreamMode rvMdmStreamDescriptorGetMode(const RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
	{returns: The mode.}
}
$*/
RvMdmStreamMode rvMdmStreamDescriptorGetMode(const RvMdmStreamDescriptor *x)
{
	return x->mode;
}

/*$
{function:
	{name: rvMdmStreamDescriptorSetMode}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Sets the mode of the stream descriptor object.}
	}
	{proto: void rvMdmStreamDescriptorSetMode(RvMdmStreamDescriptor *x, RvMdmStreamMode mode);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
		{param: {n:mode} {d:The mode.}}
	}
}
$*/
void rvMdmStreamDescriptorSetMode(RvMdmStreamDescriptor *x, RvMdmStreamMode mode)
{
	x->mode = mode;
}
/*$
{function:
	{name: rvMdmStreamDescriptorGetId}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the stream identifier of the stream descriptor object.}
	}
	{proto: RvMdmStreamId rvMdmStreamDescriptorGetId(const RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
	{returns: The stream identifier.}
}
$*/
RvMdmStreamId rvMdmStreamDescriptorGetId(const RvMdmStreamDescriptor *x)
{
	return x->id;
}

/*$
{function:
	{name: rvMdmStreamDescriptorSetId}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Sets the stream identifier of the stream descriptor object.}
	}
	{proto: void rvMdmStreamDescriptorGetId(const RvMdmStreamDescriptor *x, RvMdmStreamId id);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
		{param: {n:id} {d:The stream id.}}
	}
}
$*/
void rvMdmStreamDescriptorSetId(RvMdmStreamDescriptor *x, RvMdmStreamId id)
{
	x->id = id;
}
/*$
{function:
	{name: rvMdmStreamDescriptorAddLocalDescriptor}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Adds a local SDP descriptor to the stream descriptor object.}
	}
	{proto: void rvMdmStreamDescriptorAddLocalDescriptor(RvMdmStreamDescriptor *x, const RvSdpMsg *msg);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
		{param: {n:msg} {d:The SDP message to add.}}
	}
}
$*/
void rvMdmStreamDescriptorAddLocalDescriptor(RvMdmStreamDescriptor *x, const RvSdpMsg *msg)
{
	rvSdpMsgListInsertMsg(&x->localDescriptors, msg);
	x->isLocalSet = rvTrue;
}


/*$
{function:
	{name: rvMdmStreamDescriptorAddRemoteDescriptor}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Adds a remote SDP descriptor to the stream descriptor object.}
	}
	{proto: void rvMdmStreamDescriptorAddRemoteDescriptor(RvMdmStreamDescriptor *x, const RvSdpMsg *msg);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
		{param: {n:msg} {d:The SDP message to add.}}
	}
}
$*/
void rvMdmStreamDescriptorAddRemoteDescriptor(RvMdmStreamDescriptor *x, const RvSdpMsg *msg)
{
	rvSdpMsgListInsertMsg(&x->remoteDescriptors, msg);
	x->isRemoteSet = rvTrue;
}

/*$
{function:
	{name: rvMdmStreamDescriptorGetNumLocalDescriptors}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the number of local SDP descriptors in the stream descriptor object.}
	}
	{proto: size_t rvMdmStreamDescriptorGetNumLocalDescriptors(const RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
	{returns: The number of local SDP descriptors.}
}
$*/
size_t rvMdmStreamDescriptorGetNumLocalDescriptors(const RvMdmStreamDescriptor *x)
{
	return rvSdpMsgListGetSize(&x->localDescriptors);
}


/*$
{function:
	{name: rvMdmStreamDescriptorGetNumRemoteDescriptors}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the number of remote SDP descriptors in the stream descriptor object.}
	}
	{proto: size_t rvMdmStreamDescriptorGetNumRemoteDescriptors(const RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
	{returns: The number of remote SDP descriptors.}
}
$*/
size_t rvMdmStreamDescriptorGetNumRemoteDescriptors(const RvMdmStreamDescriptor *x)
{
	return rvSdpMsgListGetSize(&x->remoteDescriptors);
}


/*$
{function:
	{name: rvMdmStreamDescriptorGetLocalDescriptor}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets one local SDP descriptor from a stream descriptor object.}
	}
	{proto: const RvSdpMsg *rvMdmStreamDescriptorGetLocalDescriptor(const RvMdmStreamDescriptor *x, size_t index);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
		{param: {n:index} {d:The index.}}
	}
	{returns: The local SDP descriptor.}
}
$*/
const RvSdpMsg *rvMdmStreamDescriptorGetLocalDescriptor(const RvMdmStreamDescriptor *x, size_t index)
{
	return rvSdpMsgListGetElement((RvSdpMsgList *)&x->localDescriptors, index);
}


/*$
{function:
	{name: rvMdmStreamDescriptorGetRemoteDescriptor}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets one remote SDP descriptor from a stream descriptor object.}
	}
	{proto: const RvSdpMsg *rvMdmStreamDescriptorGetRemoteDescriptor(const RvMdmStreamDescriptor *x, size_t index);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
		{param: {n:index} {d:The index.}}
	}
	{returns: The remote SDP descriptor.}
}
$*/
const RvSdpMsg *rvMdmStreamDescriptorGetRemoteDescriptor(const RvMdmStreamDescriptor *x, size_t index)
{
	return rvSdpMsgListGetElement((RvSdpMsgList *)&x->remoteDescriptors, index);
}


/*$
{function:
	{name: rvMdmStreamDescriptorIsLocalDescriptorSet}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Checks if the local SDP descriptor is set in a stream descriptor object.}
	}
	{proto: RvBool rvMdmStreamDescriptorIsLocalDescriptorSet(const RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
	{returns: rvTrue if the local SDP descriptor is set, rvFalse if not.}
	{notes:
		{note: Call this function when rvMdmStreamDescriptorGetNumLocalDescriptors
		returns 0 to determine if the local descriptor is empty or absent.
		If rvMdmStreamDescriptorIsLocalDescriptorSet returns rvTrue, the descriptor
		is set but empty. If it returns rvFalse, the descriptor is absent.}
	}
}
$*/
RvBool rvMdmStreamDescriptorIsLocalDescriptorSet(const RvMdmStreamDescriptor *x)
{
	return x->isLocalSet;
}


/*$
{function:
	{name: rvMdmStreamDescriptorIsRemoteDescriptorSet}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Checks if the remote SDP descriptor is set in a stream descriptor object.}
	}
	{proto: RvBool rvMdmStreamDescriptorIsRemoteDescriptorSet(const RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
	{returns: rvTrue if the remote SDP descriptor is set, rvFalse if not.}
	{notes:
		{note: Call this function when rvMdmStreamDescriptorGetNumRemoteDescriptors
		returns 0 to determine if the remote descriptor is empty or absent.
		If rvMdmStreamDescriptorIsRemoteDescriptorSet returns rvTrue, the descriptor
		is set but empty. If it returns rvFalse, the descriptor is absent.}
	}
}
$*/
RvBool rvMdmStreamDescriptorIsRemoteDescriptorSet(const RvMdmStreamDescriptor *x)
{
	return x->isRemoteSet;
}


/*$
{function:
	{name: rvMdmStreamDescriptorGetParameter}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets a parameter from the stream descriptor object.}
	}
	{proto: const RvMdmParameterValue *rvMdmStreamDescriptorGetParameter(RvMdmStreamDescriptor *x, const RvMdmPackageItem *name);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
		{param: {n:name} {d:The parameter name.}}
	}
	{returns: The parameter value.}
}
$*/
const RvMdmParameterValue *rvMdmStreamDescriptorGetParameter(RvMdmStreamDescriptor *x, const RvMdmPackageItem *name)
{
	return rvMdmParameterListGet(&x->parameters, name);
}


/*$
{function:
	{name: rvMdmStreamDescriptorGetParameterList}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the parameter list of the stream descriptor object.}
	}
	{proto: const RvMdmParameterList *rvMdmStreamDescriptorGetParameterList(const RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
	{returns: The parameter list.}
}
$*/
const RvMdmParameterList *rvMdmStreamDescriptorGetParameterList(const RvMdmStreamDescriptor *x)
{
	return &x->parameters;
}


/*$
{function:
	{name: rvMdmStreamDescriptorIsSet}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Checks whether the stream descriptor object is set.}
	}
	{proto: RvBool rvMdmStreamDescriptorIsSet(const RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
	{returns: rvTrue if the object is set, rvFalse if not.}
}
$*/
RvBool rvMdmStreamDescriptorIsSet(const RvMdmStreamDescriptor *x)
{
	return x->isLocalSet || x->isRemoteSet || x->mode != RV_MDMSTREAMMODE_NOTSET ||
		!rvMdmParameterListIsEmpty(&x->parameters);
}


/*$
{function:
	{name: rvMdmStreamDescriptorAddEmptyLocalDescriptor}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Adds an empty local SDP descriptor to the stream descriptor object,
		signifying a request to release any resources reserved for the media
		flow received.}
	}
	{proto: void rvMdmStreamDescriptorAddEmptyLocalDescriptor(RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
}
$*/
void rvMdmStreamDescriptorAddEmptyLocalDescriptor(RvMdmStreamDescriptor *x)
{
	rvMdmStreamDescriptorClearLocalDescriptors(x);
	x->isLocalSet = rvTrue;
}


/*$
{function:
	{name: rvMdmStreamDescriptorAddEmptyRemoteDescriptor}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Adds an empty remote SDP descriptor to the stream descriptor object,
		signifying a request to release any resources reserved for the media
		flow sent.}
	}
	{proto: void rvMdmStreamDescriptorAddEmptyRemoteDescriptor(RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
}
$*/
void rvMdmStreamDescriptorAddEmptyRemoteDescriptor(RvMdmStreamDescriptor *x)
{
	rvMdmStreamDescriptorClearRemoteDescriptors(x);
	x->isRemoteSet = rvTrue;
}

/*$
{function:
	{name: rvMdmStreamDescriptorClearLocalDescriptors}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Removes all local SDP descriptors from the stream descriptor object.}
	}
	{proto: void rvMdmStreamDescriptorClearLocalDescriptors(RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
}
$*/
void rvMdmStreamDescriptorClearLocalDescriptors(RvMdmStreamDescriptor *x)
{
	rvSdpMsgListClear(&x->localDescriptors);
	x->isLocalSet = rvFalse;
}


/*$
{function:
	{name: rvMdmStreamDescriptorClearRemoteDescriptors}
	{class: RvMdmStreamDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Removes all remote SDP descriptors from the stream descriptor object.}
	}
	{proto: void rvMdmStreamDescriptorClearRemoteDescriptors(RvMdmStreamDescriptor *x);}
	{params:
		{param: {n:x} {d:The stream descriptor object.}}
	}
}
$*/
void rvMdmStreamDescriptorClearRemoteDescriptors(RvMdmStreamDescriptor *x)
{
	rvSdpMsgListClear(&x->remoteDescriptors);
	x->isRemoteSet = rvFalse;
}


/*$
{function:
	{name: rvMdmMediaDescriptorConstructA}
	{class: RvMdmMediaDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a media descriptor object.}
	}
	{proto: RvMdmMediaDescriptor *rvMdmMediaDescriptorConstructA(RvMdmMediaDescriptor *x, RvAlloc *alloc);}
	{params:
		{param: {n:x} {d:The media descriptor object.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmMediaDescriptor *rvMdmMediaDescriptorConstructA(RvMdmMediaDescriptor *x, RvAlloc *alloc)
{
	rvVectorConstruct(RvMdmStreamDescriptor)(&x->streams, alloc);
	x->streams.data = NULL;
	return x;
}


/*$
{function:
	{name: rvMdmMediaDescriptorDestruct}
	{class: RvMdmMediaDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Destroys a media descriptor object.}
	}
	{proto: void rvMdmMediaDescriptorDestruct(RvMdmMediaDescriptor *x);}
	{params:
		{param: {n:x} {d:The media descriptor object.}}
	}
}
$*/
void rvMdmMediaDescriptorDestruct(RvMdmMediaDescriptor *x)
{
	rvVectorDestruct(RvMdmStreamDescriptor)(&x->streams);
}


/*$
{function:
	{name: rvMdmMediaDescriptorAddStream}
	{class: RvMdmMediaDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Adds a stream to the media descriptor object.}
	}
	{proto: void rvMdmMediaDescriptorAddStream(RvMdmMediaDescriptor *x, const RvMdmStreamDescriptor *stream);}
	{params:
		{param: {n:x} {d:The media descriptor object.}}
		{param: {n:stream} {d:The stream.}}
	}
}
$*/
void rvMdmMediaDescriptorAddStream(RvMdmMediaDescriptor *x, const RvMdmStreamDescriptor *stream)
{
	rvVectorPushBack(RvMdmStreamDescriptor)(&x->streams, stream);
}

/*$
{function:
	{name: rvMdmMediaDescriptorClearStreams}
	{class: RvMdmMediaDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Removes all streams from the media descriptor object.}
	}
	{proto: void rvMdmMediaDescriptorClearStreams(RvMdmMediaDescriptor *x);}
	{params:
		{param: {n:x} {d:The media descriptor object.}}
	}
}
$*/
void rvMdmMediaDescriptorClearStreams(RvMdmMediaDescriptor *x)
{
	rvVectorClear(RvMdmStreamDescriptor)(&x->streams);
}

/*$
{function:
	{name: rvMdmMediaDescriptorGetNumStreams}
	{class: RvMdmMediaDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the number of streams in the media descriptor object.}
	}
	{proto: size_t rvMdmMediaDescriptorGetNumStreams(const RvMdmMediaDescriptor *x);}
	{params:
		{param: {n:x} {d:The media descriptor object.}}
	}
	{returns: The number of streams.}
}
$*/
size_t rvMdmMediaDescriptorGetNumStreams(const RvMdmMediaDescriptor *x)
{
	return rvVectorSize(&x->streams);
}


/*$
{function:
	{name: rvMdmMediaDescriptorGetStream}
	{class: RvMdmMediaDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets one stream of the media descriptor object.}
	}
	{proto: const RvMdmStreamDescriptor *rvMdmMediaDescriptorGetStream(const RvMdmMediaDescriptor *x, size_t index);}
	{params:
		{param: {n:x} {d:The media descriptor object.}}
		{param: {n:index} {d:The index.}}
	}
	{returns: The stream.}
}
$*/
const RvMdmStreamDescriptor *rvMdmMediaDescriptorGetStream(const RvMdmMediaDescriptor *x, size_t index)
{
	return rvVectorAt(&x->streams, index);
}



rvDefineFindIf(RvVectorIter, RvMdmStreamDescriptor)

/*$
{function:
	{name: rvMdmSignalExGetType}
	{class: RvMdmSignalEx}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the type of the signal object.}
	}
	{proto: RvMdmSignalType rvMdmSignalExGetType(const RvMdmSignalEx *x);}
	{params:
		{param: {n:x} {d:The signal object.}}
	}
	{returns: The type.}
}
$*/
RvMdmSignalType rvMdmSignalExGetType(const RvMdmSignalEx *x)
{
	return x->type;
}


/*$
{function:
	{name: rvMdmSignalExGetDuration}
	{class: RvMdmSignalEx}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the duration of the signal object.}
	}
	{proto: unsigned int rvMdmSignalExGetDuration(const RvMdmSignalEx *x);}
	{params:
		{param: {n:x} {d:The signal object.}}
	}
	{returns: The duration in hundredths of seconds.}
}
$*/
unsigned int rvMdmSignalExGetDuration(const RvMdmSignalEx *x)
{
	return x->duration;
}

/*$
{function:
	{name: rvMdmSignalExListConstructCopy}
	{class: RvMdmSignalExList}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a copy of a signal list object.}
	}
	{proto: RvMdmSignalExList *rvMdmSignalExListConstructCopy(RvMdmSignalExList *d, const RvMdmSignalList *s, RvAlloc *alloc);}
	{params:
		{param: {n:d} {d:The destination signal list object.}}
		{param: {n:s} {d:The signal list object to copy.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmSignalExList *rvMdmSignalExListConstructCopy(RvMdmSignalExList *d, const RvMdmSignalExList *s, RvAlloc *alloc)
{
	d->id = s->id;
	rvVectorConstructCopy(RvMdmSignalEx)(&d->signals, &s->signals, alloc);
	return d;
}

/*$
{function:
	{name: rvMdmSignalExListDestruct}
	{class: RvMdmSignalExList}
	{include: rvmdmobjects.h}
	{description:
		{p: Destroys a signal list object.}
	}
	{proto: void rvMdmSignalExListDestruct(RvMdmSignalExList *x);}
	{params:
		{param: {n:x} {d:The signal list object.}}
	}
}
$*/
void rvMdmSignalExListDestruct(RvMdmSignalExList *x)
{
	rvVectorDestruct(RvMdmSignalEx)(&x->signals);
}

/*$
{function:
	{name: rvMdmSignalExListGetId}
	{class: RvMdmSignalExList}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the identifier of the signal list object.}
	}
	{proto: unsigned int rvMdmSignalExListGetId(const RvMdmSignalExList *x);}
	{params:
		{param: {n:x} {d:The signal list object.}}
	}
	{returns: The identifier.}
}
$*/
unsigned int rvMdmSignalExListGetId(const RvMdmSignalExList *x)
{
	return x->id;
}


/*$
{function:
	{name: rvMdmSignalExConstructA}
	{class: RvMdmSignalEx}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a signal object.}
	}
	{proto: RvMdmSignalEx *rvMdmSignalExConstructA(RvMdmSignalEx *x, const RvMdmPackageItem *name, RvAlloc *alloc);}
	{params:
		{param: {n:x} {d:The signal object.}}
		{param: {n:name} {d:The signal name.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmSignalEx *rvMdmSignalExConstructA(RvMdmSignalEx *x, const RvMdmPackageItem *name, RvAlloc *alloc)
{
	rvMdmEventConstructA(&x->event, name, alloc);
	x->type = RV_MDMSIGNAL_DEFAULTTYPE;
	x->duration = 0;
	return x;
}

/*$
{function:
	{name: rvMdmSignalExConstructCopy}
	{class: RvMdmSignalEx}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a copy of a signal object.}
	}
	{proto: RvMdmSignalEx *rvMdmSignalExConstructCopy(RvMdmSignalEx *d, const RvMdmSignalEx *s, RvAlloc *alloc);}
	{params:
		{param: {n:d} {d:The destination signal object.}}
		{param: {n:s} {d:The signal object to copy.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmSignalEx *rvMdmSignalExConstructCopy(RvMdmSignalEx *d, const RvMdmSignalEx *s, RvAlloc *alloc)
{
	rvMdmEventConstructCopy(&d->event, &s->event, alloc);
	d->type = s->type;
	d->duration = s->duration;
	return d;
}

/*$
{function:
	{name: rvMdmSignalExDestruct}
	{class: RvMdmSignalEx}
	{include: rvmdmobjects.h}
	{description:
		{p: Destroys a signal object.}
	}
	{proto: void rvMdmSignalExDestruct(RvMdmSignalEx *x);}
	{params:
		{param: {n:x} {d:The signal object.}}
	}
}
$*/
void rvMdmSignalExDestruct(RvMdmSignalEx *x)
{
	rvMdmEventDestruct(&x->event);
}


/*$
{function:
	{name: rvMdmSignalExSetType}
	{class: RvMdmSignalEx}
	{include: rvmdmobjects.h}
	{description:
		{p: Sets the type of the signal object.}
	}
	{proto: void rvMdmSignalExSetType(RvMdmSignalEx *x, RvMdmSignalType type);}
	{params:
		{param: {n:x} {d:The signal object.}}
		{param: {n:type} {d:The type.}}
	}
}
$*/
void rvMdmSignalExSetType(RvMdmSignalEx *x, RvMdmSignalType type)
{
	x->type = type;
}


/*$
{function:
	{name: rvMdmSignalExSetDuration}
	{class: RvMdmSignalEx}
	{include: rvmdmobjects.h}
	{description:
		{p: Sets the duration of the signal object.}
	}
	{proto: void rvMdmSignalExSetDuration(RvMdmSignalEx *x, unsigned int duration);}
	{params:
		{param: {n:x} {d:The signal object.}}
		{param: {n:duration} {d:The duration in hundredths of seconds.}}
	}
}
$*/
void rvMdmSignalExSetDuration(RvMdmSignalEx *x, unsigned int duration)
{
	x->duration = duration;
}


/*$
{function:
	{name: rvMdmSignalExListGetSize}
	{class: RvMdmSignalExList}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the number of signals in a signal list object.}
	}
	{proto: size_t rvMdmSignalExListGetSize(const RvMdmSignalExList *x);}
	{params:
		{param: {n:x} {d:The signal list object.}}
	}
	{returns: The number of signals.}
}
$*/
size_t rvMdmSignalExListGetSize(const RvMdmSignalExList *x)
{
	return rvVectorSize(&x->signals);
}


/*$
{function:
	{name: rvMdmSignalExListGetElem}
	{class: RvMdmSignalExList}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets one signal from a signal list object.}
	}
	{proto: const RvMdmSignalEx *rvMdmSignalExListGetElem(const RvMdmSignalExList *x, size_t index);}
	{params:
		{param: {n:x} {d:The signal list object.}}
		{param: {n:index} {d:The index.}}
	}
	{returns: The signal.}
}
$*/
const RvMdmSignalEx *rvMdmSignalExListGetElem(const RvMdmSignalExList *x, size_t index)
{
	return rvVectorAt(&x->signals, index);
}



/*$
{function:
	{name: rvMdmSignalsDescriptorConstructA}
	{class: RvMdmSignalsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a signals descriptor object.}
	}
	{proto: RvMdmSignalsDescriptor *rvMdmSignalsDescriptorConstructA(RvMdmSignalsDescriptor *x, RvAlloc *alloc);}
	{params:
		{param: {n:x} {d:The signals descriptor object.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmSignalsDescriptor *rvMdmSignalsDescriptorConstructA(RvMdmSignalsDescriptor *x, RvAlloc *alloc)
{
	rvVectorConstruct(RvMdmSignalExList)(&x->lists, alloc);
	x->lists.data = NULL;
	rvVectorConstruct(RvMdmSignalEx)(&x->signals, alloc);
	x->signals.data = NULL;
	return x;
}

/*$
{function:
	{name: rvMdmSignalsDescriptorConstructCopy}
	{class: RvMdmSignalsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a copy of a signals descriptor object.}
	}
	{proto: RvMdmSignalsDescriptor *rvMdmSignalsDescriptorConstructCopy(RvMdmSignalsDescriptor *d, const RvMdmSignalsDescriptor *s, RvAlloc *alloc);}
	{params:
		{param: {n:d} {d:The destination signals descriptor object.}}
		{param: {n:s} {d:The signals descriptor object to copy.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmSignalsDescriptor *rvMdmSignalsDescriptorConstructCopy(RvMdmSignalsDescriptor *d, const RvMdmSignalsDescriptor *s, RvAlloc *alloc)
{
	d->lists.data=NULL;
	d->signals.data=NULL;
	rvVectorConstructCopy(RvMdmSignalExList)(&d->lists, &s->lists, alloc);
	rvVectorConstructCopy(RvMdmSignalEx)(&d->signals, &s->signals, alloc);
	return d;
}
/*$
{function:
	{name: rvMdmSignalsDescriptorDestruct}
	{class: RvMdmSignalsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Destroys a signals descriptor object.}
	}
	{proto: void rvMdmSignalsDescriptorDestruct(RvMdmSignalsDescriptor *x);}
	{params:
		{param: {n:x} {d:The signals descriptor object.}}
	}
}
$*/
void rvMdmSignalsDescriptorDestruct(RvMdmSignalsDescriptor *x)
{
	rvVectorDestruct(RvMdmSignalExList)(&x->lists);
	rvVectorDestruct(RvMdmSignalEx)(&x->signals);
}


/*$
{function:
	{name: rvMdmSignalsDescriptorCopy}
	{class: RvMdmSignalsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Copies the value of one signals descriptor object to another.}
	}
	{proto: RvMdmSignalsDescriptor *rvMdmSignalsDescriptorCopy(RvMdmSignalsDescriptor *d, const RvMdmSignalsDescriptor *s);}
	{params:
		{param: {n:d} {d:The destination signals descriptor object.}}
		{param: {n:s} {d:The signals descriptor object to copy.}}
	}
	{returns: A pointer to the destination object, or NULL if the copy failed.}
}
$*/
RvMdmSignalsDescriptor *rvMdmSignalsDescriptorCopy(RvMdmSignalsDescriptor *d, const RvMdmSignalsDescriptor *s)
{
	rvVectorCopy(RvMdmSignalExList)(&d->lists, &s->lists);
	rvVectorCopy(RvMdmSignalEx)(&d->signals, &s->signals);
	return d;
}



/*$
{function:
	{name: rvMdmSignalsDescriptorAddSignal}
	{class: RvMdmSignalsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Adds a signal to a signals descriptor object.}
	}
	{proto: void rvMdmSignalsDescriptorAddSignal(RvMdmSignalsDescriptor *x, const RvMdmSignalEx *signal);}
	{params:
		{param: {n:x} {d:The signals descriptor object.}}
		{param: {n:signal} {d:The signal.}}
	}
}
$*/
void rvMdmSignalsDescriptorAddSignal(RvMdmSignalsDescriptor *x, const RvMdmSignalEx *signal)
{
	rvVectorPushBack(RvMdmSignalEx)(&x->signals, signal);
}

/*$
{function:
	{name: rvMdmSignalsDescriptorGetNumSignals}
	{class: RvMdmSignalsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the number of signals in a signals descriptor object.}
	}
	{proto: size_t rvMdmSignalsDescriptorGetNumSignals(const RvMdmSignalsDescriptor *x);}
	{params:
		{param: {n:x} {d:The signals descriptor object.}}
	}
	{returns: The number of signals.}
}
$*/
size_t rvMdmSignalsDescriptorGetNumSignals(const RvMdmSignalsDescriptor *x)
{
	return rvVectorSize(&x->signals);
}

/*$
{function:
	{name: rvMdmSignalsDescriptorGetSignal}
	{class: RvMdmSignalsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets one signal of a signals descriptor object.}
	}
	{proto: const RvMdmSignalEx *rvMdmSignalsDescriptorGetSignal(const RvMdmSignalsDescriptor *x, size_t index);}
	{params:
		{param: {n:x} {d:The signals descriptor object.}}
		{param: {n:index} {d:The index.}}
	}
	{returns: The signal.}
}
$*/
const RvMdmSignalEx *rvMdmSignalsDescriptorGetSignal(const RvMdmSignalsDescriptor *x, size_t index)
{
	return rvVectorAt(&x->signals, index);
}


/*$
{function:
	{name: rvMdmSignalsDescriptorGetNumSignalLists}
	{class: RvMdmSignalsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the number of signal lists in the signals descriptor object.}
	}
	{proto: size_t rvMdmSignalsDescriptorGetNumSignalLists(const RvMdmSignalsDescriptor *x);}
	{params:
		{param: {n:x} {d:The signals descriptor object.}}
	}
	{returns: The number of signal lists.}
}
$*/
size_t rvMdmSignalsDescriptorGetNumSignalLists(const RvMdmSignalsDescriptor *x)
{
	return rvVectorSize(&x->lists);
}


/*$
{function:
	{name: rvMdmSignalsDescriptorGetSignalList}
	{class: RvMdmSignalsDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets one signal list in a signals descriptor object.}
	}
	{proto: const RvMdmSignalExList *rvMdmSignalsDescriptorGetSignalList(const RvMdmSignalsDescriptor *x, size_t index);}
	{params:
		{param: {n:x} {d:The signals descriptor object.}}
		{param: {n:index} {d:The index.}}
	}
	{returns: The signal list.}
}
$*/
const RvMdmSignalExList *rvMdmSignalsDescriptorGetSignalList(const RvMdmSignalsDescriptor *x, size_t index)
{
	return rvVectorAt(&x->lists, index);
}



/*$
{function:
	{name: rvMdmPackagesDescriptorConstructA}
	{class: RvMdmPackagesDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Constructs a packages descriptor object.}
	}
	{proto: RvMdmPackagesDescriptor *rvMdmPackagesDescriptorConstructA(RvMdmPackagesDescriptor *x, RvAlloc *alloc);}
	{params:
		{param: {n:x} {d:The packages descriptor object.}}
		{param: {n:alloc} {d:The allocator to use.}}
	}
	{returns: A pointer to the constructed object, or NULL if construction failed.}
}
$*/
RvMdmPackagesDescriptor *rvMdmPackagesDescriptorConstructA(RvMdmPackagesDescriptor *x, RvAlloc *alloc)
{
    rvVectorConstruct(RvString)(&x->packages, alloc);
	return x;
}

/*$
{function:
	{name: rvMdmPackagesDescriptorDestruct}
	{class: RvMdmPackagesDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Destroys a packages descriptor object.}
	}
	{proto: void rvMdmPackagesDescriptorDestruct(RvMdmPackagesDescriptor *x);}
	{params:
		{param: {n:x} {d:The packages descriptor object.}}
	}
}
$*/
void rvMdmPackagesDescriptorDestruct(RvMdmPackagesDescriptor *x)
{
    rvVectorDestruct(RvString)(&x->packages);
}


/*$
{function:
	{name: rvMdmPackagesDescriptorGetNumPackages}
	{class: RvMdmPackagesDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the number of packages in a packages descriptor object.}
	}
	{proto: size_t rvMdmPackagesDescriptorGetNumPackages(const RvMdmPackagesDescriptor *x);}
	{params:
		{param: {n:x} {d:The packages descriptor object.}}
	}
	{returns: The number of packages.}
}
$*/
size_t rvMdmPackagesDescriptorGetNumPackages(const RvMdmPackagesDescriptor *x)
{
	return rvVectorSize(&x->packages);
}


/*$
{function:
	{name: rvMdmPackagesDescriptorGetPackageName}
	{class: RvMdmPackagesDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Gets the name of one package in a packages descriptor object.}
	}
	{proto: const char *rvMdmPackagesDescriptorGetPackageName(const RvMdmPackagesDescriptor *x, size_t index);}
	{params:
		{param: {n:x} {d:The packages descriptor object.}}
		{param: {n:index} {d:The index.}}
	}
	{returns: The package name.}
}
$*/
const char *rvMdmPackagesDescriptorGetPackageName(const RvMdmPackagesDescriptor *x, size_t index)
{
    return rvStringGetData(rvVectorAt(&x->packages, index));
}


/*$
{function:
	{name: rvMdmPackagesDescriptorAddPackage}
	{class: RvMdmPackagesDescriptor}
	{include: rvmdmobjects.h}
	{description:
		{p: Adds a package to a packages descriptor object.}
	}
	{proto: void rvMdmPackagesDescriptorAddPackage(RvMdmPackagesDescriptor *x, const char *name, unsigned int version);}
	{params:
		{param: {n:x} {d:The packages descriptor object.}}
		{param: {n:name} {d:The package name.}}
		{param: {n:version} {d:The package version.}}
	}
}
$*/
void rvMdmPackagesDescriptorAddPackage(
    IN RvMdmPackagesDescriptor* x,
    IN const RvChar*            name)
{
    RvString t;
    rvStringConstructA(&t, name, rvVectorGetAllocator(&x->packages));
    rvVectorPushBack(RvString)(&x->packages, &t);
    rvStringDestruct(&t);
}



/*------------------------------------------------------------------------------*/
/* RvMdmTermPresentationInfo methods                                                           */
/*------------------------------------------------------------------------------*/

RVAPI RvMdmTermPresentationInfo* RVCALLCONV rvMdmTermPresentationInfoConstruct(
    IN RvMdmTermPresentationInfo* x)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoConstruct(x=%p)", x));

    x->presentationName[0] = '\0';
    x->callerIdPermission = RV_MDM_PRSENTATION_RESTRICTED;
    x->calleeIdPermission = RV_MDM_PRSENTATION_RESTRICTED;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoConstruct()=%p", x));

    return x;
}


RVAPI RvBool RVCALLCONV rvMdmTermPresentationInfoGetName(
    IN  RvMdmTermPresentationInfo*  x,
    OUT RvChar*                     name,
    IN  RvInt32                     nameLen)
{
    RvBool result = RV_FALSE;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoGetName(x=%p,name=%p,len=%d)", x, name, nameLen));

    if ((x != NULL) && (name != NULL) && (x->presentationName[0] != '\0'))
    {
        if (nameLen > 0)
        {
            strncpy(name, x->presentationName, (RvSize_t)nameLen-1);
            name[nameLen-1] = '\0';
        }
        else
        {
            RvLogWarning(ippLogSource,(ippLogSource,"rvMdmTermPresentationInfoGetName(nameLen=0)!"));
        }
        result = RV_TRUE;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoGetName()=%d", result));

    return result;
}


RVAPI RvMdmTermPresentationType RVCALLCONV rvMdmTermPresentationInfoGetCallerPermission(
    IN RvMdmTermPresentationInfo* x)
{
    RvMdmTermPresentationType type = RV_MDM_PRSENTATION_RESTRICTED;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoGetCallerPermission(x=%p)", x));

    if (x != NULL)
        type = x->callerIdPermission;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoGetCallerPermission()=%d", type));

    return type;
}


RVAPI RvMdmTermPresentationType RVCALLCONV rvMdmTermPresentationInfoGetCalleePermission(
    IN RvMdmTermPresentationInfo* x)
{
    RvMdmTermPresentationType type = RV_MDM_PRSENTATION_RESTRICTED;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoGetCalleePermission(x=%p)", x));

    if (x != NULL)
        type = x->calleeIdPermission;

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoGetCalleePermission()=%d", type));

    return type;
}


/******************************************************************************
 * rvMdmTermPresentationInfoSetName
 * ----------------------------------------------------------------------------
 * General:
 *  Sets the presentation name.
 * Arguments:
 * Input:  x        - The Presentation Info object.
 *         name     - The presentation name to set. The name will be truncated
 *                    if the given string is too long.
 * Output: None.
 *
 * Return Value: RV_TRUE if successful, RV_FALSE otherwise.
 *****************************************************************************/
RVAPI RvBool RVCALLCONV rvMdmTermPresentationInfoSetName(
    IN RvMdmTermPresentationInfo*   x,
    IN const RvChar*                name)
{
    RvBool status = RV_FALSE;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoSetName(x=%p,name=%s)", x, nprn(name)));

    if ((x != NULL) && (name != NULL) && (name[0] != '\0'))
    {
        strncpy(x->presentationName, name, sizeof(x->presentationName)-1);
        x->presentationName[sizeof(x->presentationName)-1] = '\0';
        status = RV_TRUE;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoSetName()=%d", status));

    return status;
}


RVAPI RvBool RVCALLCONV rvMdmTermPresentationInfoSetCallerPermission(
    IN RvMdmTermPresentationInfo*   x,
    IN RvMdmTermPresentationType    permission)
{
    RvBool ret = RV_FALSE;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoSetCallerPermission(x=%p,permission=%d)",
        x, permission));

    if (x != NULL)
{
        x->callerIdPermission = permission;
        ret = RV_TRUE;
}

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoSetCallerPermission()=%d", ret));

    return ret;
}


RVAPI RvBool RVCALLCONV rvMdmTermPresentationInfoSetCalleePermission(
    IN RvMdmTermPresentationInfo*   x,
    IN RvMdmTermPresentationType    permission)
{
    RvBool ret = RV_FALSE;

    RvLogEnter(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoSetCalleePermission(x=%p,permission=%d)",
        x, permission));

    if (x != NULL)
	{
        x->calleeIdPermission = permission;
        ret = RV_TRUE;
	}

    RvLogLeave(ippLogSource,(ippLogSource, "rvMdmTermPresentationInfoSetCalleePermission()=%d", ret));

    return ret;
}


RvStatus rvMdmTermPhoneNumbersAdd(
    IN RvMdmTermPhoneNumbers*   x,
    IN const RvChar*            number)
{
	RvUint i;
        RvSize_t strLen;

	if (number == NULL)
        return RV_ERROR_NULLPTR;

        strLen = strlen(number);
    if ((strLen == 0) || (strLen >= RV_NAME_STR_SZ))
        return RV_ERROR_OUTOFRANGE;

	if (x->phoneNumbersNum >= RV_MDM_PHONENUMBERS_SIZE)
        return RV_ERROR_OUTOFRESOURCES;

    /* Don't add if number is already in list */
	for (i=0; i < x->phoneNumbersNum; i++)
	{
		if (!strcmp(x->phoneNumbers[i], number))
            return RV_OK;   /* number is already in list */
	}

    /* * Add the number in end of list */
	strcpy(x->phoneNumbers[x->phoneNumbersNum], number);
    x->phoneNumbersNum++;

    return RV_OK;
}


const RvChar* rvMdmTermPhoneNumbersGetByIndex(
    IN RvMdmTermPhoneNumbers*   x,
    IN RvSize_t                 index)
{
	if (index >= x->phoneNumbersNum)
		return NULL;

	return (x->phoneNumbers[index]);
}


