/******************************************************************************
Filename:    rvccapi.c
Description: Generic call control API
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/


#define LOGSRC	LOGSRC_CALLCONTROL
#include "ipp_inc_std.h"
#include "mdmControlInt.h"
#include "rvccapi.h"
#include "rvcctext.h"
#include "rvccterminalmdm.h"
#include "rvcctext.h"
#include "ippcodec.h"


/*zhangcg: 20110411*/
extern void Psip_rvCCConnectionSetStateCB(RvCCConnection*     x,RvCCConnState       state,RvCCConnState       eOldstate);


/*==================================================================================
================= C O N N E C T I O N S		F U N C T I O N S ======================
===================================================================================*/
void rvCCConnectionResetState(RvCCConnection* x)
{
	if (x == NULL)
	{
		return;
	}

	x->mediaState = RV_CCMEDIASTATE_NONE;
	x->state = RV_CCCONNSTATE_IDLE;
	x->termState = RV_CCTERMCONSTATE_IDLE;
	x->call = NULL;
	x->curParty = NULL;
	x->userData = NULL;

	if (x->transferLine != NULL)
    {
		/*Set other party's Transfer line to NULL too*/
		rvCCConnectionSetTransferLine(x->transferLine, NULL);
		x->transferLine = NULL;
	}

	rvCCConnectionClearNewMedia(x);

    RvLogInfo(ippLogSource,
        (ippLogSource, "rvCCConnectionResetState:: for conn=%p", x));

}

void rvCCConnectionConstruct(
                RvCCConnection*                 x,
                RvCCTerminal*                   term,
                void*                           conn,
                RvCCConnType                    type,
			    struct RvCCConnectionFuncs_*    funcs,
			    struct RvCCConnectionClbks_*    clbks)
{
	if (x == NULL)
	{
		return;
	}

	x->clbks = clbks;
	x->funcs = funcs;
	x->type = type;
	x->connection = conn;
	x->term = term;
	x->lineId = 0;
	x->userData = NULL;
	x->transferLine = NULL;
	x->updateState = RV_CCUPDATESTATE_NONE;
    x->transferState = RV_CCCONNSTATE_TRANSFER_IDLE;
	x->lastReceivedCallStateReason = RV_MTF_CALL_STATE_REASON_NORMAL;
	memset(x->thirdPartyDestAddress, 0, sizeof(x->thirdPartyDestAddress));
	rvMdmMediaStreamInfoConstructA(&x->newMediaStream, 0, prvDefaultAlloc);
	rvCCConnectionResetState(x);
	RvMutexConstruct( IppLogMgr(), &x->mutex);

	/*Presentation Info*/
	rvMdmTermPresentationInfoConstruct(&x->remotePresentationInfo);

	rvStringConstruct(&x->distinctiveRinging,"",prvDefaultAlloc);
	rvStringConstruct(&x->distinctiveRingback,"",prvDefaultAlloc);

    RvLogInfo(ippLogSource,
        (ippLogSource, "Connection Constructed (%p) for Terminal: %s", x, rvCCTerminalGetId(term)));

}



void rvCCConnectionDestruct(RvCCConnection* x)
{
	if (x == NULL)
	{
		return;
	}

	rvCCConnectionResetState(x);
	RvMutexDestruct(   &x->mutex, IppLogMgr());
	rvStringDestruct(&x->distinctiveRinging);
	rvStringDestruct(&x->distinctiveRingback);

    RvLogDebug(ippLogSource,
        (ippLogSource, "Connection Destructed (%p) for Terminal: %s",
        x, rvCCTerminalGetId(x->term)));

}


/***************************************************************************
 * rvCCConnectionGetThirdPartyDestAddress
 * ------------------------------------------------------------------------
 * General: Get the thirdPartyDestAddress field from the X connection
 * Return Value: none
 * ------------------------------------------------------------------------
 * Arguments:
 * input:	x		- connection
 * output:	address	- content of thirdPartyDestAddress
 * Return:	none
 ***************************************************************************/
void rvCCConnectionGetThirdPartyDestAddress(
                IN RvCCConnection*      x,
                OUT char*               address)
{
	if ((x != NULL) && (address != NULL))
	{
    	strncpy(address, (char *)(x->thirdPartyDestAddress), strlen(x->thirdPartyDestAddress));
    }
    else if (address != NULL)
    {
        address[0] = '\0';
    }
}


/***************************************************************************
 * rvCCConnectionSetThirdPartyDestAddress
 * ------------------------------------------------------------------------
 * General: Set the thirdPartyDestAddress field in the X connection with address value
 * Return Value: none
 * ------------------------------------------------------------------------
 * Arguments:
 * input:	x		- connection
 * output:	address	- address to fill with the thirdPArtyDestAddress field
 * Return:	none
 ***************************************************************************/
void rvCCConnectionSetThirdPartyDestAddress(
                IN RvCCConnection*     x,
                IN char*               address)
{
	if ((x != NULL) && (address != NULL))
    {
	    strncpy(x->thirdPartyDestAddress, address, sizeof(x->thirdPartyDestAddress)-1);
        x->thirdPartyDestAddress[sizeof(x->thirdPartyDestAddress)-1] = '\0';
    }
}

void rvCCConnectionSetMediaState(
				RvCCConnection* x,
				RvCCMediaState  state)
{	
	if (x != NULL)
	{
		RvLogDebug(ippLogSource,
			(ippLogSource,"rvCCConnectionSetMediaState for conn=%p, State = %s",
             x, rvCCTextMediaState(state)));
		
		x->mediaState = state;
	}
}

void rvCCConnectionSetLineId(
                RvCCConnection*     x,
                int                 lineId)
{
	if (x != NULL)
	{
	    x->lineId = lineId;
    }
}

int  rvCCConnectionGetLineId(RvCCConnection* x)
{
	if (x != NULL)
	{
	    return x->lineId;
    }

    return RV_ERROR_NULLPTR;
}

void rvCCConnectionSetConnectParty(
                RvCCConnection*     x,
                RvCCConnection*     party)
{
    if (x != NULL)
    {
        RvLogDebug(ippLogSource,
            (ippLogSource,"rvCCConnectionSetConnectParty for conn=%p, Line=%d, party=%p, Line=%d",
            x, rvCCConnectionGetLineId(x), party, rvCCConnectionGetLineId(party)));

        x->curParty = party;
    }

}

RvCCConnection *rvCCConnectionGetConnectParty(RvCCConnection *x)
{
	if (x != NULL)
	    return (x->curParty);

    return NULL;
}

void rvCCConnectionSetTransferLine(
                RvCCConnection*     x,
                RvCCConnection*     transferLine)
{
    if (x != NULL)
    {
        RvLogDebug(ippLogSource,
            (ippLogSource,"rvCCConnectionSetTransferLine for conn=%p, Line=%d",
            x, rvCCConnectionGetLineId(x)));

        x->transferLine = transferLine;
    }
}

RvCCConnection* rvCCConnectionGetTransferLine(RvCCConnection*     x)
{
    if (x != NULL)
        return (x->transferLine);

    return NULL;
}

void rvCCConnectionSetTransferState(
                RvCCConnection*          x,
                RvCCConnTransferState    transferState)
{
    if (x != NULL)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"Change Transfer State from: %s to: %s, Line=%d for conn=%p",
            rvCCTextConnTransferState(x->transferState), rvCCTextConnTransferState(transferState),
            rvCCConnectionGetLineId(x), x));

        x->transferState = transferState;
    }
}

RvCCConnTransferState rvCCConnectionGetTransferState(RvCCConnection*     x)
{
    if (x != NULL)
        return (x->transferState);

    return RV_CCCONNSTATE_TRANSFER_IDLE;
}

void rvCCConnectionSetState(
                RvCCConnection*     x,
                RvCCConnState       state)
{
	if (x != NULL)
	{
        RvLogInfo(ippLogSource,
            (ippLogSource,"Change Connection State: %s -> %s, Line=%d for conn=%p",
            rvCCTextConnState(x->state), rvCCTextConnState(state),
            rvCCConnectionGetLineId(x), x));

        /*zhangcg: 20110411 added for call state*/
        Psip_rvCCConnectionSetStateCB(x,state,x->state);

	    x->state = state;
	    
    }
    
}

void rvCCConnectionSetLastReceivedCallStateReason(
	RvCCConnection*     x,
	RvMtfCallStateReason     reason)
{
	if (x != NULL)
	{
		x->lastReceivedCallStateReason = reason;
	}
}

RvMtfCallStateReason rvCCConnectionGetLastReceivedCallStateReason(RvCCConnection*     x)
{
	if (x != NULL)
	{
		return x->lastReceivedCallStateReason;
	}

	return RV_MTF_CALL_STATE_REASON_NORMAL;
}
/*==========================================================================*/
/*                 Distinctive Ring Setters and Getters                     */
/*==========================================================================*/

const char* rvCCConnectionGetDistinctiveRinging(RvCCConnection* c)
{
	if (c != NULL)
	{
	    return	rvStringGetData(&(c)->distinctiveRinging);
    }
    else
    {
        return NULL; /*TODO: return NULL or empty string?*/
    }
}

const char* rvCCConnectionGetDistinctiveRingback(RvCCConnection* c)
{
	if (c != NULL)
	{
	    return	rvStringGetData(&(c)->distinctiveRingback);
    }
    else
    {
        return NULL; /*TODO: return NULL or empty string?*/
    }
}

void rvCCConnectionSetDistinctiveRinging(
                RvCCConnection*     c,
                char*               ringStr)
{
	if (c != NULL)
	{
	    rvStringAssign(&(c)->distinctiveRinging,ringStr);
    }
}

void rvCCConnectionSetDistinctiveRingback(
                RvCCConnection*     c,
                char*               ringStr)
{
	if (c != NULL)
	{
	    rvStringAssign(&(c)->distinctiveRingback,ringStr);
    }
}

void rvCCConnectionResetDistinctiveRinging(RvCCConnection* c)
{
	if (c != NULL)
	{
	    rvStringAssign(&(c)->distinctiveRinging,"");
    }
}

void rvCCConnectionResetDistinctiveRingback(RvCCConnection* c)
{
	if (c != NULL)
	{
    	rvStringAssign(&(c)->distinctiveRingback,"");
    }
}

/***************************************************************************
 * rvCCConnectionIsCallOnHold
 * ------------------------------------------------------------------------
 * General: This function checks if at least one side of the connections is
 *			in hold.
 *			In case of blind transfer and call exist on the connection,
 *			ignore this hold checking and return false as if no side is on hold
 *
 * Return Value: RV_TRUE - in case at least one side of the connection is on hold
 *			(excpet blind transfer case)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	x			- connection
  ***************************************************************************/
RvBool rvCCConnectionIsCallOnHold(RvCCConnection* x)
{
	RvCCTermConnState   state;

	if (x == NULL)
	{
		return RV_FALSE;
	}

	/* In case of Blind Transfer, ignore this hold checking and return false
       as if no side is on hold */
	if ((rvCCConnectionGetCall(x) != NULL) &&
        (rvCCCallGetTransferType(rvCCConnectionGetCall(x)) == RV_CCCALL_TRANSFER_BLIND))
    {
        RvLogInfo(ippLogSource,
            (ippLogSource, "rvCCConnectionIsCallOnHold: not relevant for Blind Transfer, returning False, conn=%p, Line=%d",
            x, rvCCConnectionGetLineId(x)));
        return RV_FALSE;
    }

	state = x->termState;

    /* Check if call is on Hold by local party, by remote party or by both */
    return ( (state == RV_CCTERMCONSTATE_HELD) ||
		(state == RV_CCTERMCONSTATE_REMOTE_HELD ) ||
		(state == RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD ));
}


/***************************************************************************
 * rvCCConnectionSetThirdPartyAddress
 * ------------------------------------------------------------------------
 * General: This function is used during Transfer to set third party dest address field
 *			in the third party connection if exists. Third party connection
 *
 * Return Value: -
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	c			- connection
 *			found destAddress	- the destination address
  ***************************************************************************/
void rvCCConnectionSetThirdPartyAddress(
                RvCCConnection*     c,
                char*               foundDestAddress)
{
	RvCCTerminal*       t;
	RvCCConnection*     thirdPartyDestConn = NULL;

	if ((c == NULL) || (foundDestAddress == NULL))
	{
		return;
	}

	t = rvCCConnectionGetTerminal(c);

    /* Get third party in case of Blind Transfer */
	if (rvCCCallGetTransferType(rvCCConnectionGetCall(c)) == RV_CCCALL_TRANSFER_BLIND)
	{
		thirdPartyDestConn = rvCCConnectionGetConnectParty(c);
        RvLogDebug(ippLogSource,
            (ippLogSource, "rvCCConnectionSetThirdPartyAddress: case of Blind Transfer, thirdPartyDestConn = %p", thirdPartyDestConn));
	}

    /* Get third party in case of Attended or Semi-Attended Transfer */
	else if (rvCCConnectionGetTransferLine(c) != NULL)
	{
		thirdPartyDestConn = rvCCConnectionGetConnectParty(rvCCConnectionGetTransferLine(c));
        RvLogDebug(ippLogSource,
            (ippLogSource, "rvCCConnectionSetThirdPartyAddress: case of Attended or Semi-Attended Transfer, thirdPartyDestConn = %p", thirdPartyDestConn));
	}

    /* Get third party in case of New Transfer */
	else if (rvCCTerminalMdmOtherHeldConnExist(t, c))
	{
		thirdPartyDestConn = rvCCConnectionGetConnectParty(rvCCTerminalMdmGetHoldingConn(t));
        RvLogDebug(ippLogSource,
            (ippLogSource, "rvCCConnectionSetThirdPartyAddress: case of New Transfer, thirdPartyDestConn = %p", thirdPartyDestConn));
	}

	if (thirdPartyDestConn != NULL)
	{
		rvCCConnectionSetThirdPartyDestAddress(thirdPartyDestConn, foundDestAddress);
        RvLogInfo(ippLogSource,
            (ippLogSource, "rvCCConnectionSetThirdPartyAddress: foundDestAddress = %s, thirdPartyDestConn = %p", foundDestAddress, thirdPartyDestConn));
	}

}
void rvCCConnectionSetTermState(
                RvCCConnection*     x,
                RvCCTermConnState   state)
{
	RvLogInfo(ippLogSource,
        (ippLogSource,"ConnTermState Changed from %s to %s, Line = %d, x = %p",
         rvCCTextTermConnState( x->termState), rvCCTextTermConnState(state), rvCCConnectionGetLineId(x), x));

    x->termState = state;
}

RvMdmMediaStreamInfo* rvCCConnectionGetNewMedia(RvCCConnection* x)
{
	if (x != NULL)
	{
        return &(x->newMediaStream);
	}

	return NULL;

}

void rvCCConnectionSetNewMedia(
                RvCCConnection*         x,
                RvMdmMediaStreamInfo*   media)
{
	if ((x == NULL) || (media == NULL))
	{
		return;
	}

	RvMdmMediaStreamInfoDestruct( &(x->newMediaStream));
	RvMdmMediaStreamInfoConstructCopy( &(x->newMediaStream), media, prvDefaultAlloc);

    rvCCTextPrintMedia(x, media, "rvCCConnectionSetNewMedia", RV_LOGLEVEL_DEBUG);

}

void rvCCConnectionAddNewMediaLocalDescr(
                RvCCConnection*     x,
                RvSdpMsg*           sdpMsg)
{
	if ((x == NULL) || (sdpMsg == NULL))
	{
		return;
	}

	rvMdmMediaStreamInfoAddLocalDescriptor(&x->newMediaStream, sdpMsg);
    RvLogDebug(ippLogSource,
        (ippLogSource, "rvCCConnectionAddNewMediaLocalDescr: for connection %p, Line = %d", x, rvCCConnectionGetLineId(x)));

}
void rvCCConnectionAddNewMediaRemoteDescr(
                RvCCConnection*     x,
                RvSdpMsg*           sdpMsg)
{
    if ((x == NULL) || (sdpMsg == NULL))
    {
        return;
    }

	rvMdmMediaStreamInfoAddRemoteDescriptor(&x->newMediaStream, sdpMsg);
    RvLogDebug(ippLogSource,
        (ippLogSource, "rvCCConnectionAddNewMediaRemoteDescr: for connection %p, Line = %d", x, rvCCConnectionGetLineId(x)));
}

void rvCCConnectionClearNewMedia(RvCCConnection* x)
{
	if (x == NULL)
	{
		return;
	}

	rvMdmMediaStreamInfoClearLocal(&x->newMediaStream);
	rvMdmMediaStreamInfoClearRemote(&x->newMediaStream);

    RvLogDebug(ippLogSource,
        (ippLogSource, "rvCCConnectionClearNewMedia: for connection %p, Line = %d", x, rvCCConnectionGetLineId(x)));
}

RvBool rvCCConnectionSetRemotePresentationInfo(
                RvCCConnection*				    x,
				RvMdmTermPresentationInfo*      presentationInfo)
{
	if ((x == NULL) || (presentationInfo == NULL))
	{
		return RV_FALSE;
	}

	rvMdmTermPresentationInfoCopy(&x->remotePresentationInfo, presentationInfo);

    RvLogDebug(ippLogSource,
        (ippLogSource, "rvCCConnectionSetRemotePresentationInfo: for connection %p, Line = %d", x, rvCCConnectionGetLineId(x)));

	return RV_TRUE;
}

RvMdmTermPresentationInfo* rvCCConnectionGetRemotePresentationInfo(RvCCConnection* x)
{
	if (x == NULL)
	{
		return NULL;
	}

	return &(x->remotePresentationInfo);
}

void rvCCConnectionAccept(
                RvCCConnection*     x,
                RvSdpMsg*           inMedia)
{
	/* inMedia may be NULL*/
	if ((x == NULL) || (x->funcs->acceptF == NULL))
	{
		return;
	}

    x->funcs->acceptF(x, inMedia);
}

void rvCCConnectionReject(
                RvCCConnection*     x,
                RvCCEventCause      reason)
{
    if ((x == NULL) || (x->funcs->rejectF == NULL))
    {
        return;
    }

	x->funcs->rejectF(x, reason);
}

void rvCCConnectionMakeCall(
                RvCCConnection*     x,
                RvSdpMsg*           inMedia)
{
	/* inMedia may be NULL*/
    if ((x == NULL) || (x->funcs->makeCallF == NULL))
    {
        return;
    }

	x->funcs->makeCallF(x,inMedia);
}

void rvCCConnectionCallAnswered(
                RvCCConnection*     x,
                RvSdpMsg*           inMedia)
{
    if ((x == NULL) || (x->funcs->callAnsweredF == NULL))
    {
        return;
    }

	x->funcs->callAnsweredF(x, inMedia);
}

/* Disconnect a connection and associated media.
Connection drops from the call. */
void rvCCConnectionDisconnect(
                RvCCConnection*     x,
                RvCCEventCause      cause)
{
    if ((x == NULL) || (x->funcs->disconnectF == NULL))
    {
        return;
    }

	x->funcs->disconnectF(x, cause);
}

/*
Start a ringback in the connection
Connection must be in ESTABLISHED state
Ringback will stop in modify media or moving out of ESTABLISHED ?
*/
void rvCCConnectionRingback(
                RvCCConnection*     x,
                RvCCEventCause      cause)
{
    if ((x == NULL) || (x->funcs->ringbackF == NULL))
    {
        return;
    }

	x->funcs->ringbackF(x, cause);
}

RvStatus rvCCConnectionForwardCall(
                RvCCConnection*     x,
                RvChar*             sendToAddress)
{
    if ((x == NULL) || (sendToAddress == NULL) || (x->funcs->forwardCallF == NULL))
    {
        return RV_ERROR_NULLPTR;
    }

	return (x->funcs->forwardCallF(x, sendToAddress));
}

RvSdpMsg* rvCCConnectionGetMedia(RvCCConnection* x)
{
    if ((x == NULL) || (x->funcs->getMediaF == NULL))
    {
        return NULL;
    }

	return x->funcs->getMediaF(x);
}

RvSdpMsg* rvCCConnectionGetMediaCaps(RvCCConnection* x)
{
    if ((x == NULL) || (x->funcs->getMediaCapsF == NULL))
    {
        return NULL;
    }

	return x->funcs->getMediaCapsF(x);
}

RvCCMediaState rvCCConnectionCreateMedia(
                RvCCConnection*     x,
                RvSdpMsg*           inMedia)
{
    /* inMedia may be NULL*/
    if ((x == NULL) || (x->funcs->createMediaF == NULL))
    {
        return RV_CCMEDIASTATE_NONE;
    }

	return x->funcs->createMediaF(x, inMedia);
}


RvBool rvCCConnectionSetRemoteMedia(
                RvCCConnection*     x,
                RvSdpMsg*           inMedia)
{
	/* inMedia may be NULL*/
    if ((x == NULL) || (x->funcs->setRemoteMediaF == NULL))
    {
        return RV_FALSE;
    }
	/* set remote media and (in H323 calls) invoke modify media callback */
	return x->funcs->setRemoteMediaF(x,inMedia, RV_TRUE);
}


RvSdpMsg* rvCCConnectionSetLocalMedia(
                RvCCConnection*     x,
                RvSdpMsg*           capsSubset)
{
    if ((x == NULL) || (capsSubset == NULL) || (x->funcs->setLocalMediaF == NULL))
    {
        return NULL;
    }

	return x->funcs->setLocalMediaF(x, capsSubset);
}

RvBool rvCCConnectionRestartMedia(RvCCConnection* x)
{
    if ((x == NULL) || (x->funcs->restartMediaF == NULL))
    {
        return RV_FALSE;
    }

	return x->funcs->restartMediaF(x);
}

RvBool rvCCConnectionModifyMedia(
                RvCCConnection*         x,
                RvMdmMediaStreamInfo*   streamDescr)
{
    if ((x == NULL) || (streamDescr == NULL) || (x->funcs->modifyMediaF == NULL))
    {
        return RV_FALSE;
    }

	return x->funcs->modifyMediaF(x, streamDescr);
}

void rvCCConnectionModifyMediaDone(
                    RvCCConnection*             x,
                    RvBool                      status,
                    RvMdmMediaStreamInfo*       mediaStream,
                    RvMdmTermReasonModifyMedia  reason)
{
    if ((x == NULL) || (mediaStream == NULL) || (x->funcs->modifyMediaDoneF == NULL))
    {
        return;
    }

	x->funcs->modifyMediaDoneF(x, status, mediaStream, reason);
}

#ifdef RV_MTF_SECOND_VIDEO
RvStatus rvCCConnectionSecondVideoIsSupportedByRemote(RvCCConnection* x,   
													  RvBool* isSupported)
{
	if ((x == NULL) || (x->funcs->secondVideoIsSupportedByRemoteF == NULL))
	{
		return  RV_ERROR_NOTSUPPORTED;
	}

	return x->funcs->secondVideoIsSupportedByRemoteF(x, isSupported);
}

RvStatus rvCCConnectionSecondVideoStreamOpen(RvCCConnection* x,
											 RvMtfSecondVideoMediaSubType mediaSubType)   
{
	if ((x == NULL) || (x->funcs->secondVideoStreamOpenF == NULL))
	{
		return  RV_ERROR_NOTSUPPORTED;
	}

	return x->funcs->secondVideoStreamOpenF(x, mediaSubType);
}

RvStatus rvCCConnectionSecondVideoStreamClose(RvCCConnection* x)   
{
	if ((x == NULL) || (x->funcs->secondVideoStreamCloseF == NULL))
	{
		return  RV_ERROR_NOTSUPPORTED;
	}

	return x->funcs->secondVideoStreamCloseF(x);
}

RvStatus rvCCConnectionPresentationTokenMsgSend(RvCCConnection* x,     
												RvMtfPresentationTokenMsgParams* params)
{
	if ((x == NULL) || (x->funcs->presentationTokenMsgSendF == NULL))
	{
		return  RV_ERROR_NOTSUPPORTED;
	}

	return x->funcs->presentationTokenMsgSendF(x, params);
}

RvStatus rvCCConnectionFlowControlRelMsgSend(RvCCConnection* x,
											 RvMtfMediaStreamHandle hStream,
											 RvMtfFlowControlRelMsgParams* params)
{
	if ((x == NULL) || (x->funcs->flowControlRelMsgSendF == NULL))
	{
		return  RV_ERROR_NOTSUPPORTED;
	}

	return x->funcs->flowControlRelMsgSendF(x, hStream, params);
}	
#endif /*RV_MTF_SECOND_VIDEO*/


/* Digit collection has been completed */
RvCCConnection* rvCCConnectionAddressAnalyze(
                IN RvCCConnection*      x,
                OUT RvCCEventCause*     reason)
{
    if ((x == NULL) || (reason == NULL) || (x->funcs->addressAnalyzeF == NULL))
    {
        return NULL;
    }

	return x->funcs->addressAnalyzeF(x, reason);
}

/* Connection can be released */
void rvCCConnectionRelease(RvCCConnection* x)
{
    if ((x == NULL) || (x->funcs->releaseF == NULL))
    {
        return;
    }

	x->funcs->releaseF(x);
}

/* Drop the connection, this connection is usually in hold */
/* It goes away silently, another connection exist to go on hook */
void rvCCConnectionDrop(RvCCConnection* x)
{
    if ((x == NULL) || (x->funcs->dropF == NULL))
    {
        return;
    }

	x->funcs->dropF(x);
}

/* Transfer - close existing media and open new one */
void rvCCConnectionTransferInit(RvCCConnection* x)
{
    if ((x == NULL) || (x->funcs->transferInitF == NULL))
    {
        return;
    }

	x->funcs->transferInitF(x);
}

void rvCCConnectionTransferOffered(
                RvCCConnection*     x,
                RvSdpMsg*           origMedia)
{
    if ((x == NULL) || (x->funcs->transferOfferedF == NULL))
    {
        return;
    }

	x->funcs->transferOfferedF(x, origMedia);
}

RvCCConnection* rvCCConnectionTransferConnected(
                RvCCConnection*     x,
                RvSdpMsg*           origMedia)
{
    if ((x == NULL) || (origMedia == NULL) || (x->funcs->transferConnectedF == NULL))
    {
        return NULL;
    }

	return x->funcs->transferConnectedF(x, origMedia);
}

void rvCCConnectionTransferInProgress(RvCCConnection* x)
{
    if ((x == NULL) || (x->funcs->transferInProgressF == NULL))
    {
        return;
    }

	x->funcs->transferInProgressF(x);
}

RvBool rvCCConnectionIsTransferedConn(
                RvCCConnection*     x,
                char*               data)
{
    if ((x == NULL) || (data == NULL) || (x->funcs->isTransferedConnF == NULL))
    {
        return RV_FALSE;
    }

	return x->funcs->isTransferedConnF(x, data);
}

const char* rvCCConnectionGetCallerId(RvCCConnection* x)
{
    if ((x == NULL) || (x->funcs->getCallerIdF == NULL))
    {
        return NULL;
    }

	return x->funcs->getCallerIdF(x);
}

const char* rvCCConnectionGetCallerName(RvCCConnection* x)
{
    if ((x == NULL) || (x->funcs->getCallerNameF == NULL))
    {
        return NULL;
    }

	return x->funcs->getCallerNameF(x);
}

/**************************************************************************
* rvCCConnectionGetRemoteDisplayName
* ------------------------------------------------------------------------
* General: call to suitable function in order to get Display Name
*		   of the remote party
* Arguments:
* input:	x		- connection
* Return:	pointer to chart contains the Remote Display Name 
***************************************************************************/
const char* rvCCConnectionGetRemoteDisplayName(RvCCConnection* x)
{
	if ((x == NULL) || (x->funcs->getRemoteDisplayNameF == NULL))
	{
		return NULL;
	}

	return x->funcs->getRemoteDisplayNameF(x);
}

/**************************************************************************
* rvCCConnectionGetRemotePhoneNumber
* ------------------------------------------------------------------------
* General: call to suitable function in order to get Phone Number
*		   of the remote party
*
* Arguments:
* input:	x		- connection
* Return:	pointer to chart contains the Remote Phone Number
***************************************************************************/
const char* rvCCConnectionGetRemotePhoneNumber(RvCCConnection* x)
{
	if ((x == NULL) || (x->funcs->getRemotePhoneNumberF == NULL))
	{
		return NULL;
	}

	return x->funcs->getRemotePhoneNumberF(x);
}
/**************************************************************************
* rvCCConnectionGetRemoteUri
* ------------------------------------------------------------------------
* General: call to suitable function in order to get Remote Uri 
*		   of the remote party
* Arguments:
* input:	x		- connection
* Return:	pointer to chart contains the Remote Uri 
***************************************************************************/
const char* rvCCConnectionGetRemoteUri(RvCCConnection* x)
{
	if ((x == NULL) || (x->funcs->getRemoteUriF == NULL))
	{
		return NULL;
	}

	return x->funcs->getRemoteUriF(x);
}
const char* rvCCConnectionGetCallerAddress(RvCCConnection* x)
{
    if ((x == NULL) || (x->funcs->getCallerAddressF == NULL))
    {
        return NULL;
    }

	return x->funcs->getCallerAddressF(x);
}

const char* rvCCConnectionGetCallerNumber(
                RvCCConnection*     x,
                int                 index)
{
    if ((x == NULL) || (x->funcs->getCallerNumberF == NULL))
    {
        return NULL;
    }

	return x->funcs->getCallerNumberF(x,index);
}

#ifndef RV_MTF_N_LINES
RvBool rvCCConnectionJoinConference(
                RvCCConnection*     x,
                RvCCConnection*     confControl)
{
    if ((x == NULL) || (confControl == NULL) || (x->funcs->joinConferenceF == NULL))
    {
        return RV_FALSE;
    }

	return x->funcs->joinConferenceF(x, confControl);
}

RvBool rvCCConnectionLeaveConference(
                RvCCConnection*     x,
                RvCCConnection*     confControl)
{
    if ((x == NULL) || (confControl == NULL) || (x->funcs->leaveConferenceF == NULL))
    {
        return RV_FALSE;
    }

	return x->funcs->leaveConferenceF(x, confControl);
}
#else
RvBool rvCCConnectionJoinConference(
									RvCCConnection*		x, 
									RvPtrList			connectionsList)
{
    if ((x == NULL) || (x->funcs->joinConferenceF == NULL))
    {
        return RV_FALSE;
    }
	
	return x->funcs->joinConferenceF(x, connectionsList);
}

RvBool rvCCConnectionLeaveConference(
									 RvCCConnection*     x,
									 RvPtrList			connectionsList)
{
    if ((x == NULL) || (x->funcs->leaveConferenceF == NULL))
    {
        return RV_FALSE;
    }
	
	return x->funcs->leaveConferenceF(x, connectionsList);
}

#endif /*RV_MTF_N_LINES*/

void rvCCConnectionProcessTermEvent(
                RvCCConnection*     x,
                RvCCTerminalEvent   eventId,
                RvBool*            callStillAlive,
				RvCCEventCause      reason)
{
    if ((x == NULL) || (callStillAlive == NULL) || (x->funcs->processTermEventF == NULL))
    {
        return;
    }

	x->funcs->processTermEventF(x, eventId, callStillAlive, reason);
}

void rvCCConnectionTerminate(RvCCConnection* x)
{
    if ((x == NULL) || (x->funcs->terminateF == NULL))
    {
        return;
    }

	x->funcs->terminateF(x);
}

/*==================================================================================
==================== T E R M I N A L	C O N N E C T I O N	 F U N C T I O N S    ==
===================================================================================*/
void rvCCConnectionTermSetHoldIndicator(
                RvCCConnection*     x,
                RvBool             on)
{
    if ((x == NULL) || (x->funcs->setHoldIndicatorF == NULL))
    {
        return;
    }

	x->funcs->setHoldIndicatorF(x,on);
}

void rvCCConnectionTermSetMuteIndicator(RvCCConnection* x, RvBool on)
{
    if ((x == NULL) || (x->funcs->setMuteIndicatorF == NULL))
    {
        return;
    }

	x->funcs->setMuteIndicatorF(x,on);
}

/* Stop sending media to party */
RvBool rvCCConnectionTermRemoteHold(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTermRemoteHold: connection is NULL"));
        return RV_FALSE;
	}
	if (x->funcs->remoteHoldF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTermRemoteHold: no remoteHold function for connection (%p)", x));
        return RV_FALSE;
	}
	return x->funcs->remoteHoldF(x);
}

/* resume sending/receiving  media to party */
RvBool rvCCConnectionTermRemoteUnhold(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTermRemoteUnhold: connection is NULL"));
        return RV_FALSE;
	}
	if (x->funcs->remoteUnholdF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTermRemoteUnhold: no remoteUnhold function for connection (%p)", x));
        return RV_FALSE;
	}
	return x->funcs->remoteUnholdF(x);
}

/* Stop sending media to all parties, ignore all incoming media  */
RvBool rvCCConnectionTermHold(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTermHold: connection is NULL"));
        return RV_FALSE;
	}
	if (x->funcs->holdF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTermHold: no hold function for connection (%p)", x));
        return RV_FALSE;
	}
	return x->funcs->holdF(x);
}

/* Resume sending and receiving media to all parties */
RvBool rvCCConnectionTermUnhold(RvCCConnection*         x,
								RvMdmMediaStreamInfo*   streamDescr)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTermUnhold: connection is NULL"));
        return RV_FALSE;
	}
	if (x->funcs->unholdF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTermUnhold: no unhold function for connection (%p)", x));
        return RV_FALSE;
	}
	return x->funcs->unholdF(x, streamDescr);
}

/* Disconnect the audio */
void rvCCConnectionTermDisconnectMedia(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTermDisconnectMedia: connection is NULL"));
		return;
	}
	if (x->funcs->disconnectMediaF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTermDisconnectMedia: no disconnectMedia function for connection (%p)", x));
		return;
	}
	x->funcs->disconnectMediaF(x);
}

/* Connect the audio (to current active audio termination) */
void rvCCConnectionTermConnectMedia(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTermConnectMedia: connection is NULL"));
		return;
	}
	if (x->funcs->connectMediaF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTermConnectMedia: no connectMedia function for connection (%p)", x));
		return;
	}
	x->funcs->connectMediaF(x);
}

void rvCCConnectionTermPlayDtmf(IN RvCCConnection* x, IN RvDtmfParameters* dtmfParam)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTermPlayDtmf: connection is NULL"));
		return;
	}
	if (x->funcs->playDtmfF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTermPlayDtmf: no playDtmf function for connection (%p)", x));
		return;
	}
	x->funcs->playDtmfF(x, dtmfParam);
}

void rvCCConnectionTermMute(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTermMute: connection is NULL"));
		return;
	}
	if (x->funcs->muteF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTermMute: no mute function for connection (%p)", x));
		return;
	}
	x->funcs->muteF(x);
}

void rvCCConnectionTermUnmute(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTermUnmute: connection is NULL"));
		return;
	}
	if (x->funcs->UnmuteF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTermUnmute: no Unmute function for connection (%p)", x));
		return;
	}
	x->funcs->UnmuteF(x);
}

#ifdef RV_MTF_VIDEO
RvStatus	rvCCConnectionSendFastUpdatePicture(RvCCConnection* x,
												RvMtfMediaStreamHandle hStream)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionSendFastUpdatePicture: connection is NULL"));
		return RV_ERROR_NULLPTR;
	}
	if (x->funcs->videoFastUpdatePictureF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionSendFastUpdatePicture: no videoFastUpdatePicture function for connection (%p)", x));
		return RV_ERROR_NULLPTR;
	}
	return x->funcs->videoFastUpdatePictureF(x, hStream);
}

RvStatus rvCCConnectionSendFastUpdateGOB(RvCCConnection* x,
										 RvMtfMediaStreamHandle hStream,
										RvUint firstGob,
										RvUint numGobs)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionSendFastUpdateGOB: connection is NULL"));
		return RV_ERROR_NULLPTR;
	}
	if (x->funcs->videoFastUpdateGOBF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionSendFastUpdateGOB: no videoFastUpdateGOB function for connection (%p)", x));
		return RV_ERROR_NULLPTR;
	}
	return x->funcs->videoFastUpdateGOBF(x, hStream, firstGob, numGobs);
}

RvStatus rvCCConnectionSendFastUpdateMB(RvCCConnection* x,
										RvMtfMediaStreamHandle hStream,
									   RvUint firstGob,
									   RvUint firstMb,
									   RvUint numMbs)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionSendFastUpdateMB: connection is NULL"));
		return RV_ERROR_NULLPTR;
	}
	if (x->funcs->videoFastUpdateMBF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionSendFastUpdateMB: no videoFastUpdateMB function for connection (%p)", x));
		return RV_ERROR_NULLPTR;
	}
	return x->funcs->videoFastUpdateMBF(x, hStream, firstGob, firstMb, numMbs);
}


RvStatus rvCCConnectionSendFastUpdatePictureFreeze(RvCCConnection* x, RvMtfMediaStreamHandle hStream)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionSendFastUpdatePictureFreeze: connection is NULL"));
		return RV_ERROR_NULLPTR;
	}
	if (x->funcs->videoFastUpdatePictureFreezeF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionSendFastUpdatePictureFreeze: no videoFastUpdatePictureFreeze function for connection (%p)", x));
		return RV_ERROR_NULLPTR;
	}
	return x->funcs->videoFastUpdatePictureFreezeF(x, hStream);
}
#endif /* RV_MTF_VIDEO */
/*==================================================================================
================= C O N N E C T I O N S		C A L L B A C K S ======================
===================================================================================*/
void rvCCConnectionInitiatedCB(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionInitiatedCB: connection is NULL"));
		return;
	}
	if (x->clbks->initiatedCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionInitiatedCB: no initiatedCB for connection (%p)", x));
		return;
	}
	x->clbks->initiatedCB(x);
}

void rvCCConnectionNewDigitCB(RvCCConnection* x,RvCCEventCause reason)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionNewDigitCB: connection is NULL"));
		return;
	}
	if (x->clbks->newDigitCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionNewDigitCB: no newDigitCB for connection (%p)", x));
		return;
	}
	x->clbks->newDigitCB(x,reason);
}

RvCCConnection* rvCCConnectionAddressAnalyzeCB(RvCCConnection* x,const char* address, RvCCEventCause inReason, RvCCEventCause* outReason)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionAddressAnalyzeCB: connection is NULL"));
		return NULL;
	}
	if (x->clbks->addressAnalyzeCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionAddressAnalyzeCB: no addressAnalyzeCB for connection (%p)", x));
		return NULL;
	}
	return x->clbks->addressAnalyzeCB(x,address, inReason, outReason);
}

void rvCCConnectionInProcessCB(RvCCConnection* x,RvCCEventCause reason)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionInProcessCB: connection is NULL"));
		return;
	}
	if (x->clbks->inProcessCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionInProcessCB: no inProcessCB for connection (%p)", x));
		return;
	}
	x->clbks->inProcessCB(x,reason);
}

void rvCCConnectionTransferInProcessCB(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTransferInProcessCB: connection is NULL"));
		return;
	}
	if (x->clbks->transferInProcessCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTransferInProcessCB: no transferInProcessCB for connection (%p)", x));
		return;
	}
	x->clbks->transferInProcessCB(x);
}

void rvCCConnectionCallDeliveredCB(RvCCConnection* x,RvCCEventCause reason)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionCallDeliveredCB: connection is NULL"));
		return;
	}
	if (x->clbks->callDeliveredCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionCallDeliveredCB: no callDeliveredCB for connection (%p)", x));
		return;
	}
	x->clbks->callDeliveredCB(x,reason);
}

RvCCMediaState rvCCConnectionOfferedCB(RvCCConnection* x,RvCCEventCause reason)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionOfferedCB: connection is NULL"));
		return RV_CCMEDIASTATE_FAILED;
	}
	if (x->clbks->offeredCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionOfferedCB: no offeredCB for connection (%p)", x));
		return RV_CCMEDIASTATE_FAILED;
	}
	return x->clbks->offeredCB(x,reason);
}

RvBool rvCCConnectionCallAnsweredCB(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionCallAnsweredCB: connection is NULL"));
        return RV_FALSE;
	}
	if (x->clbks->callAnsweredCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionCallAnsweredCB: no callAnsweredCB for connection (%p)", x));
        return RV_FALSE;
	}
	return x->clbks->callAnsweredCB(x);
}


void rvCCConnectionMediaCreatedCB(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionMediaCreatedCB: connection is NULL"));
		return;
	}
	if (x->clbks->mediaCreatedCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionMediaCreatedCB: no mediaCreatedCB for connection (%p)", x));
		return;
	}
	x->clbks->mediaCreatedCB(x);
}

RvBool rvCCConnectionMediaUpdatedCB(RvCCConnection* x, RvSdpMsg* inMedia)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionMediaUpdatedCB: connection is NULL"));
        return RV_FALSE;
	}
	if (x->clbks->mediaUpdatedCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionMediaUpdatedCB: no mediaUpdatedCB for connection (%p)", x));
        return RV_FALSE;
	}
	return x->clbks->mediaUpdatedCB(x, inMedia);
}


RvBool rvCCConnectionMediaModifiedCB(RvCCConnection* x,RvMdmMediaStreamInfo* streamDescr)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionMediaModifiedCB: connection is NULL"));
        return RV_FALSE;
	}
	if (x->clbks->mediaModifiedCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionMediaModifiedCB: no mediaModifiedCB for connection (%p)", x));
        return RV_FALSE;
	}
	return x->clbks->mediaModifiedCB(x,streamDescr);
}

RvSdpMsg* rvCCConnectionCapsUpdatedCB(RvCCConnection* x, RvSdpMsg* capsSubSet)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionCapsUpdatedCB: connection is NULL"));
		return NULL;
	}
	if (x->clbks->capsUpdatedCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionCapsUpdatedCB: no capsUpdatedCB for connection (%p)", x));
		return NULL;
	}
	return x->clbks->capsUpdatedCB(x, capsSubSet);
}

RvCCMediaState rvCCConnectionTransferOfferedCB(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTransferOfferedCB: connection is NULL"));
		return RV_CCMEDIASTATE_FAILED;
	}
	if (x->clbks->transferOfferedCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTransferOfferedCB: no transferOfferedCB for connection (%p)", x));
		return RV_CCMEDIASTATE_FAILED;
	}
	return x->clbks->transferOfferedCB(x);
}

RvCCMediaState rvCCConnectionTransferInitCB(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionTransferInitCB: connection is NULL"));
		return RV_CCMEDIASTATE_FAILED;
	}
	if (x->clbks->transferInitCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionTransferInitCB: no transferInitCB for connection (%p)", x));
		return RV_CCMEDIASTATE_FAILED;
	}
	return x->clbks->transferInitCB(x);
}

RvBool rvCCConnectionConferenceJoinedCB(RvCCConnection* x)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionConferenceJoinedCB: connection is NULL"));
        return RV_FALSE;
	}
	if (x->clbks->conferenceJoinedCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionConferenceJoinedCB: no conferenceJoinedCB for connection (%p)", x));
        return RV_FALSE;
	}
	return x->clbks->conferenceJoinedCB(x);
}

void rvCCConnectionSendUserEventCB(RvCCConnection* x,
									 RvCCTerminalEvent event, RvCCEventCause* reason)
{
	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCConnectionSendUserEventCB: connection is NULL"));
		return;
	}
	if (x->clbks->sendUserEventCB == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCConnectionSendUserEventCB: no sendUserEventCB for connection (%p)", x));
		return;
	}
	x->clbks->sendUserEventCB(x, event, reason);
}

/*==================================================================================
==================== T E R M I N A L	C O N N E C T I O N	 C A L L B A C K S    ==
===================================================================================*/

void rvCCTerminalCfwActivateCompletedCB(
                RvCCTerminal*           t,
                RvIppCfwType		    cfwType,
                char*				    cfwDestination,
                RvIppCfwReturnReasons   returnCode)
{
	RvCCTerminalMdm				*mdmTerminal;
	RvCCProvider				*p;
	RvCCProviderMdm				*provider;

	if ((t == NULL) || (cfwDestination == NULL))
	{
		return;
	}

	mdmTerminal =   rvCCTerminalMdmGetImpl(t);
	p =             rvCCTerminalMdmGetProvider(mdmTerminal);
	provider =      rvCCProviderMdmGetImpl(p);

    /* Call user calbback to notify CFW activation process is completed*/
	if (provider->cfwCallCfg.cfwCallBacks.activateCompleted != NULL)
	{
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvTerminalCfwActivateCompletedCB: Calling user callback rvIppCfwActivateCompletedCB() for Terminal=%s, cfwDestination = %s, cfwType = %d, returnCode = %d",
                    rvCCTerminalGetId(t), cfwDestination, cfwType, returnCode));

		provider->cfwCallCfg.cfwCallBacks.activateCompleted((RvIppTerminalHandle)t, cfwType, cfwDestination, returnCode);
	}
	else /* User didn't register this CB */
	{
		RvLogInfo(ippLogSource,
            (ippLogSource,"rvTerminalCfwActivateCompletedCB: User did not register callback rvIppCfwActivateCompletedCB() for Terminal=%s",
            rvCCTerminalGetId(t)));
	}
}



void rvCCTerminalCfwDeactivateCompletedCB(
                RvCCTerminal*           t,
                RvIppCfwType 	 	    cfwType,
                RvIppCfwReturnReasons   returnCode)
{
	RvCCTerminalMdm				*mdmTerminal;
	RvCCProvider				*p;
	RvCCProviderMdm				*provider;

	if (t == NULL)
	{
		return;
	}

	mdmTerminal =   rvCCTerminalMdmGetImpl(t);
	p =             rvCCTerminalMdmGetProvider(mdmTerminal);
	provider =      rvCCProviderMdmGetImpl(p);

    /* Call user calbback to notify CFW deactivation process is completed*/
	if (provider->cfwCallCfg.cfwCallBacks.deactivateCompleted != NULL)
	{
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCTerminalCfwDeactivateCompletedCB: Calling user callback rvIppCfwDeactivateCompletedCB() for Terminal: %s, cfwType = %d, returnCode = %d",
            rvCCTerminalGetId(t), cfwType, returnCode));

		provider->cfwCallCfg.cfwCallBacks.deactivateCompleted((RvIppTerminalHandle)t, cfwType, returnCode);
	}
	else /* User didn't register this CB */
	{
		RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCTerminalCfwDeactivateCompletedCB: User did not register callback rvIppCfwDeactivateCompletedCB() for Terminal=%s",
            rvCCTerminalGetId(t)));
	}
}

/*==================================================================================
==================== E X T E N S I O N 	C O N N E C T I O N	 C A L L B A C K S    ==
===================================================================================*/

void rvCCConnectionDisplay(
                RvCCConnection*     x,
                RvCCTerminal*       term,
				RvCCTerminalEvent   event,
                RvCCEventCause      cause,
				void*               displayData)
{	
#ifdef RV_MTF_N_LINES
	RvCCCall *call = NULL;
	unsigned int connectionsListSize = 0, index;
	RvPtrListIter		i;
	call = rvCCConnectionGetCall(x);
	if (call !=NULL)
	{
		connectionsListSize = rvListSize(&call->connections);
		if (connectionsListSize > 0)  
		{
			i=rvListBegin(&call->connections);	
			for (index = 0; index < connectionsListSize; index++)
			{
				RvCCConnection* otherConn = (RvCCConnection *)RvPtrListIterData(i);
				if ((otherConn != NULL) && (rvCCConnectionGetState(otherConn) != RV_CCCONNSTATE_IDLE) && (rvCCConnectionGetType(otherConn) == RV_CCCONNTYPE_MDM))
				{
					rvIppMdmExtDisplayCB(otherConn, term, event, cause, displayData);
				}
				i=rvListIterNext(i);
			}
		}
	}
#endif /* RV_MTF_N_LINES */

    rvIppMdmExtDisplayCB(x, term, event, cause, displayData);
}

/*==================================================================================
==================== T E R M I N A L		F U N C T I O N S ======================
===================================================================================*/

void rvCCTerminalInit(
    IN RvCCTerminal*       x,
    IN void*               term,
    IN RvCCTerminalClbks*  clbks)
{
	if ((x == NULL) || (term == NULL))
	{
		return;
	}

    memset(x, 0, sizeof(*x));

	x->terminal = term;
	x->audioTermState = RV_CCAUDIOTERM_PASSIVE;
	x->clbks = clbks;
	RvMutexConstruct(IppLogMgr(), &x->activeConnMutex);

    RvLogDebug(ippLogSource,(ippLogSource, "rvCCTerminalInit: term = %p", x));
}

/******************************************************************************
*  rvCCTerminalGetNumberOfLines
*  --------------------------------------
*  General :        Get number of lines.
*					If the user set a specific numberOfLines for this terminal, 
*					This value will be taken.
*					Otherwise,  The value will be taken from the provider.
*
*  Return Value:    None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          t            terminal object.
*				   numberOfLines The number of lines to be set
*  Output          None.
******************************************************************************/
RvInt rvCCTerminalGetNumberOfLines(RvCCTerminal *t)
{
#ifdef RV_MTF_N_LINES
	
	RvCCTerminalMdm	*term = rvCCTerminalMdmGetImpl(t);
	
	if (term->defaultState.numberOfLines != 0)
	{
		return(term->defaultState.numberOfLines);
	}
	else
	{
		RvCCProvider* p = rvCCTerminalMdmGetProvider(term);
		RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);
		return (provider->numberOfLines);		
	}
#else
	RV_UNUSED_ARG(t);
	return RV_CCTERMINAL_MAXCONNS;
#endif
}


const RvChar* rvCCTerminalGetId(RvCCTerminal* x)
{
    if (x != NULL)
	{
        return rvCCTerminalMdmGetTermId(x);
	}
    else
	{
        RvLogDebug(ippLogSource,(ippLogSource, "rvCCTerminalGetId(x=NULL)"));
		return NULL;
	}
}



RvCCTerminalEvent rvCCTerminalMapEvent(RvCCTerminal* x, const char* pkg, const char* id,
									   void * args, char* key)
{
	RvCCTerminalEvent retEvent = RV_CCTERMEVENT_NONE;

	if (x == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCTerminalMapEvent: terminal is NULL"));
		return retEvent;
	}

    retEvent = rvCCTerminalMdmMapEvent(x, pkg, id, args, key);

    /* If event is not found, call user map event function */
    if (retEvent == RV_CCTERMEVENT_UNKNOWN)
	{
	/* If event is not found, call user map event function */
		return rvIppMdmExtMapUserEventCB(pkg, id, args, key);
	}
	return retEvent;
}


/* Connection functions */
int rvCCTerminalGetActiveConnectionId(RvCCTerminal* x)
{
	int id;

	if (x == NULL)
	{
		return RV_ERROR_NULLPTR;
	}

    RvMutexLock(&x->activeConnMutex, IppLogMgr());
	id =  x->activeConnection;
	RvMutexUnlock(&x->activeConnMutex, IppLogMgr());

	return id;
}

void rvCCTerminalSetActiveConnectionId(
                RvCCTerminal*   x,
                int             id)
{
	if (x == NULL)
	{
		return;
	}

	RvMutexLock(&x->activeConnMutex, IppLogMgr());

    RvLogDebug(ippLogSource,
        (ippLogSource,"rvCCTerminalSetActiveConnectionId: for Terminal=%s, from line = %d to line = %d, Conn = %p",
        rvCCTerminalGetId(x), x->activeConnection, id, rvCCTerminalGetActiveConnection(x)));

	x->activeConnection = id;

	RvMutexUnlock(&x->activeConnMutex, IppLogMgr());
}


static RvCCConnection* rvGetConnection(
                RvCCTerminal*   x,
                int             id)
{
	if (x == NULL)
	{
		RvLogWarning(ippLogSource,(ippLogSource, "rvGetConnection(x=NULL)"));
		return NULL;
	}
	
	if(rvCCTerminalGetNumberOfLines(x) <= 0)
	{
		RvLogWarning(ippLogSource,(ippLogSource, "rvGetConnection: rvCCTerminalGetNumberOfLines return value <= 0"));
		return NULL;
	}
	
	return x->connections[id];
}

RvCCConnection* rvCCTerminalGetActiveConnection(RvCCTerminal* x)
{
	RvCCConnection* c;

	if (x == NULL)
	{
		return NULL;
	}

	RvMutexLock(&x->activeConnMutex, IppLogMgr());
	c = rvGetConnection(x,rvCCTerminalGetActiveConnectionId(x));
	RvMutexUnlock(&x->activeConnMutex, IppLogMgr());

	return c;
}

RvCCConnection* rvCCTerminalFindFreeConnection(RvCCTerminal* x)
{
	RvCCConnection*     c;
	RvInt              i;
	RvInt maxConnections;
	
	if (x == NULL)
	{
		return NULL;
	}
	
	maxConnections = rvCCTerminalGetNumberOfLines(x);

	RvMutexLock(&x->activeConnMutex, IppLogMgr());
	
	for(i=0;i<maxConnections;i++)
	{
		c = x->connections[i] ;
		if (c != NULL)
        {
            if (c->state == RV_CCCONNSTATE_IDLE)
            {
			    /* If this is not the active connection, we have another call so
			       the terminal state should be "BRIDGED" */
			    if(i != rvCCTerminalGetActiveConnectionId(x))
				    rvCCConnectionSetTermState(c, RV_CCTERMCONSTATE_BRIDGED);

			    RvMutexUnlock(&x->activeConnMutex, IppLogMgr());

                RvLogInfo(ippLogSource,
                    (ippLogSource, "rvCCTerminalFindFreeConnection: for terminal = %s, free connection found: %p, Line = %d",
                     rvCCTerminalGetId(x), c, rvCCConnectionGetLineId(c)));

                /* We found free connection */
			    return c;
		    }
        }
	}

	/* All connections are busy */
	RvMutexUnlock(&x->activeConnMutex, IppLogMgr());

	RvLogError(ippLogSource,(ippLogSource,"rvCCTerminalFindFreeConnection: No free Connection was found for Terminal: %s", rvCCTerminalGetId(x)));
	return NULL;
}

/* This function looks for an active connection, in addition to the current one */
int rvCCTerminalFindNextActiveConnection(
                RvCCTerminal*       x,
                RvCCConnection*     cur)
{
	RvCCConnection*     c;
    RvInt              i;
	RvInt maxConnections;
	
	if (x == NULL)
	{
		return RV_ERROR_NULLPTR;
	}

	maxConnections = rvCCTerminalGetNumberOfLines(x);

	RvMutexLock(&x->activeConnMutex, IppLogMgr());
	for(i=0;i<maxConnections;i++)
    {
		c = x->connections[i] ;

		if((c->state != RV_CCCONNSTATE_IDLE) && (c != cur))
        {
			RvMutexUnlock(&x->activeConnMutex, IppLogMgr());

            RvLogInfo(ippLogSource,
                (ippLogSource, "rvCCTerminalFindNextActiveConnection: additional active connection (i=%d) was found for termId = %s, conn = %p, LineId = %d",
                i, rvCCTerminalGetId(x), c, rvCCConnectionGetLineId(c)));

			return i;
		}
	}
	/* No additional active connection was found */
	RvMutexUnlock(&x->activeConnMutex, IppLogMgr());

    RvLogInfo(ippLogSource,(ippLogSource, "rvCCTerminalFindNextActiveConnection: no additional active connection was found, termId = %s", rvCCTerminalGetId(x)));

	return -1;
}

RvCCConnection* rvCCTerminalGetConnectionByIndex(
                RvCCTerminal*   x,
                int             i)
{
	RvInt maxConnections;

	if (x == NULL)
	{
		return NULL;
	}
	
	maxConnections = rvCCTerminalGetNumberOfLines(x);

	if(i >= maxConnections)
		return NULL;
	
    if (i >= rvCCTerminalGetNumberOfLines(x))
		return NULL;
	
    RvLogDebug(ippLogSource,
        (ippLogSource, "rvCCTerminalGetConnectionByIndex: return conn = %p, LineId = %d",
        x->connections[i], rvCCConnectionGetLineId(x->connections[i])));
	
	return x->connections[i];
}


/***************************************************************************
 * rvCCTerminalGetNumActiveConnections
 * ------------------------------------------------------------------------
 * General: This function counts the number of Terminal's active connections.
 *          The connection is considered Active if it's not in IDLE state.
 *          The terminals with states DISCONNECTED, REJECTED, FAILED are active
 *			because they still are not set to IDLE.
 * Return Value: Number of active connection
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	x			-	CC Termination
 ***************************************************************************/
int rvCCTerminalGetNumActiveConnections(RvCCTerminal* x)
{
	int i, cnt=0;
	RvInt maxConnections;

	if (x == NULL)
	{
		return RV_ERROR_NULLPTR;
	}

	maxConnections = rvCCTerminalGetNumberOfLines(x);
	
	for(i=0;i<maxConnections;i++)
	{
		RvCCConnection* c = x->connections[i];
		if(c->state != RV_CCCONNSTATE_IDLE)
		{
			cnt++;
		}
	}

    RvLogDebug(ippLogSource,
        (ippLogSource, "rvCCTerminalGetNumActiveConnections: termId = %s, count = %d",
        rvCCTerminalGetId(x), cnt));

	return cnt;
}


/* Call when the active connection goes back to idle
   Then either look for a connection with a state different than idle,
   (some connection in hold, etc) or set the first connection as
   the active one */
void rvCCTerminalResetActiveConnection(RvCCTerminal* x)
{
	int                 i,activeId = 0;
	RvCCConnection*     c;
	RvInt maxConnections;

	if (x == NULL)
	{
		return;
	}

	maxConnections = rvCCTerminalGetNumberOfLines(x);
	
	RvMutexLock(&x->activeConnMutex, IppLogMgr());

	for (i=0;i<maxConnections;i++)
    {
		c = x->connections[i] ;
		if (c->state != RV_CCCONNSTATE_IDLE)
        {
			activeId = i;
			break;
		}
	}

	/* Revert to first connection by default */
	rvCCTerminalSetActiveConnectionId(x, activeId);

	RvMutexUnlock(&x->activeConnMutex, IppLogMgr());
}



int rvCCTerminalParseConnectionId(const char* line)
{
	int id;

	if (line == NULL)
	{
		return RV_ERROR_NULLPTR;
	}

	id = (line[1]-'0')*100 + (line[2]-'0')*10 + (line[3]-'0');

	return id;
}

/* Use to set connection in ephemeral termination */
void rvCCTerminalSetEphemeralActiveConnection(
                RvCCTerminal*       x,
                RvCCConnection*     conn)
{
	if (x == NULL)
	{
		return;
	}

	x->activeConnection = 0;
	x->connections[0] = conn;
}

void rvCCTerminalSetState(
                RvCCTerminal*       x,
                RvCCTerminalState   state)
{
	if (x == NULL)
	{
		return;
	}

	x->state = state;
}


RvCCTerminalState rvCCTerminalGetState(RvCCTerminal *x)
{
	if (x == NULL)
	{
		return RV_CCTERMINAL_ERROR_STATE;
	}

	return (x->state);
}


/*==================================================================================
==================== P R O V I D E R		F U N C T I O N S ======================
===================================================================================*/

/* Initialize a connection to a terminal (address) in an idle state */
/* To route a call to this connection, call Accept */
RvCCConnection* rvCCProviderCreateConnection(
            RvCCProvider*   x,
            RvCCTerminal*   t)
{
	if (x == NULL)
	{
		return NULL;
	}

	return x->funcs->createConnectionF(x,t);
}


/******************************************************************************
*  rvCCTextPrintEvent
*  ----------------------------
*  General :       Prints the connection Terminal Events.
*
*  Return Value:   None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          conn                 pointer to Call Control Connection
*       .          origEventId          pointer to original Event
*                  newEventId           new event
*                  reason               Event Cause
*  Output          None.
*
*
*
******************************************************************************/
#if (RV_LOGMASK & RV_LOGLEVEL_INFO)
void rvCCTextPrintEvent(
    IN      RvCCConnection*     conn,
    INOUT   RvCCTerminalEvent*  origEventId,
    IN      RvCCTerminalEvent   newEventId,
    INOUT   RvCCEventCause*     origReason,
    IN      RvCCEventCause      newReason)
{
    /* Print only if event was changed since last print */
    if (*origEventId != newEventId)
    {
        RvCCConnState       state = rvCCConnectionGetState(conn);
        RvCCTermConnState   termConnState = rvCCConnectionGetTermState(conn);

		RvLogInfo(ippLogSource,(ippLogSource,"**%s-STATE MACHINE** [Event=%s, Reason=%s] -> [Event=%s, Reason=%s] <ConnState=%s> <TermConnState=%s> <Conn=%p, Line=%d>",
            (rvCCConnectionGetType(conn) == RV_CCCONNTYPE_MDM) ? "MDM": "SIP",
            rvCCTextEvent(*origEventId), rvCCTextCause(*origReason),
            rvCCTextEvent(newEventId), rvCCTextCause(newReason),
            rvCCTextConnState(state), rvCCTextTermConnState(termConnState),
            conn, rvCCConnectionGetLineId(conn)));

        *origEventId = newEventId;
        *origReason = newReason;
    }
}

/******************************************************************************
*  rvCCTextPrintMedia
*  ----------------------------
*  General :       Returns a string containing media capabilities
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:           x                     Connection for which media are printed
*                   media                 Object containing Media Capabilities
*                   headline              String to be printed as headline
*                   logLevelDebug         Indicates in which log level fucntion will print
*                                         the media parameters
*       
*  Output           None.
*
******************************************************************************/
void rvCCTextPrintMedia(
                RvCCConnection*                 x, 
                const RvMdmMediaStreamInfo*     media, 
                char*                           headline,
                RvLogMessageType                logLevel)
{
#define BUFLEN  2048
#define MSGLEN  48
    const RvMdmStreamDescriptor*  descr = rvMdmMediaStreamInfoGetStreamDescriptor(media);
    const RvSdpMsg*         sdp;
    char                    buf[BUFLEN];
    char                    logstr[BUFLEN*2 + MSGLEN*3];
    char                    msg[BUFLEN + MSGLEN]; /* TODO: This can be removed altogether if written properly */
    RvSdpStatus             stat = RV_SDPSTATUS_OK;
    
    /* Start with printing the headline of this whole block */
    RvSprintf(logstr, "******%s (Line=%d):\n", headline, rvCCConnectionGetLineId(x));
    
    /* Print Stream Mode */
    RvSprintf(msg, "******Stream Mode = %s\n", rvCCTextStreamMode(rvMdmStreamDescriptorGetMode(descr)));
    strcat(logstr, msg);
    
    /* Print Local Media */
    if (rvMdmStreamDescriptorIsLocalDescriptorSet(descr) == rvTrue)
    {
        sdp = rvMdmStreamDescriptorGetLocalDescriptor(descr, 0);
        rvSdpMsgEncodeToBuf((RvSdpMsg*)sdp, buf, BUFLEN, &stat);
		if (stat != RV_SDPSTATUS_OK)
		{
			/* SDP message failed to be encoded to buffer */
			RvLogError(ippLogSource, (ippLogSource, "SDP message failed to be encoded to buffer, sdp=0x%p, status=%d",
						sdp, stat));
			return;
		}
        RvSnprintf(msg, sizeof(msg), "******Local Media:\n%s\n", buf);
        strcat(logstr, msg);
    }

	switch (logLevel)
	{
	case RV_LOGLEVEL_INFO:
		RvLogInfo(ippLogSource, (ippLogSource, logstr));
		break;
	case RV_LOGLEVEL_DEBUG:
		RvLogDebug(ippLogSource, (ippLogSource, logstr));
		break;
	default:
		RvLogDebug(ippLogSource, (ippLogSource, logstr));
		break;
	}

    /* Print Remote Media */
    if (rvMdmStreamDescriptorIsRemoteDescriptorSet(descr) == rvTrue) 
    {
        sdp = rvMdmStreamDescriptorGetRemoteDescriptor(descr, 0);
        rvSdpMsgEncodeToBuf((RvSdpMsg*)sdp, buf, BUFLEN, &stat);
		if (stat != RV_SDPSTATUS_OK)
		{
			/* SDP message failed to be encoded to buffer */
			RvLogError(ippLogSource, (ippLogSource, "SDP message failed to be encoded to buffer, sdp=0x%p, status=%d",
				sdp, stat));
			return;
		}
        RvSnprintf(msg,sizeof(msg), "******Remote Media:\n%s\n", buf);
       // strcat(logstr, msg);
    }
    
    switch (logLevel)
    {
        case RV_LOGLEVEL_INFO:
            RvLogInfo(ippLogSource, (ippLogSource, msg));
            break;
        case RV_LOGLEVEL_DEBUG:
            RvLogDebug(ippLogSource, (ippLogSource, msg));
            break;
        default:
            RvLogDebug(ippLogSource, (ippLogSource, msg));
            break;
    }
}
/******************************************************************************
*  rvCCTextPrintSdpMsg
*  ----------------------------
*  General :       Returns a string containing media capabilities
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:           sdp                   SDP message to be printed
*                   headline              String to be printed as headline
*                   logLevelDebug         Indicates in which log level fucntion will print
*                                         the media parameters
*       
*  Output           None.
*
******************************************************************************/
void rvCCTextPrintSdpMsg(
                        RvSdpMsg*           sdp, 
                        char*               headline,
                        RvLogMessageType    logLevel)
{
    RvSdpStatus     stat = RV_SDPSTATUS_OK;
    char            buf[2048];
    
    rvSdpMsgEncodeToBuf(sdp, buf, 2048, &stat);
	if (stat != RV_SDPSTATUS_OK)
	{
		/* SDP message failed to be encoded to buffer */
		RvLogError(ippLogSource, (ippLogSource, "SDP message failed to be encoded to buffer, sdp=0x%p, status=%d",
			sdp, stat));
		return;
	}
    
    switch (logLevel)
    {
    case RV_LOGLEVEL_INFO:
        RvLogInfo(ippLogSource, (ippLogSource, "****** Media of %s\n%s\n", headline, buf));
        break;
    case RV_LOGLEVEL_DEBUG:
        RvLogDebug(ippLogSource, (ippLogSource, "****** Media of %s\n%s\n", headline, buf));
        break;
    default:
        RvLogDebug(ippLogSource, (ippLogSource, "****** Media of %s\n%s\n", headline, buf));
        break;
    }
}

/******************************************************************************
*  rvCCTextPrintMediaStreamDescr
*  ----------------------------
*  General :       Returns a string containing media capabilities
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:           streamDescr           media descriptor to be printed
*                   headline              String to be printed as headline
*                   logLevelDebug         Indicates in which log level function will print
*                                         the media parameters
*       
*  Output           None.
*
******************************************************************************/
void rvCCTextPrintMediaStreamDescr(
									RvSdpMediaDescr*	streamDescr, 
									char*               headline,
									RvLogMessageType    logLevel)
{

    RvStatus		stat = RV_OK;
    char            buf[2048];
    
	if ((stat = IppSerializeSdpDescrTo( buf, 2048, streamDescr)) != RV_OK)
	{
		/* SDP descriptor failed to be encoded to buffer */
		RvLogError(ippLogSource, (ippLogSource, "media descriptor failed to be encoded to buffer, streamDescr=0x%p, status=%d",
			streamDescr, stat));
		return;
	}
    
    switch (logLevel)
    {
    case RV_LOGLEVEL_INFO:
        RvLogInfo(ippLogSource, (ippLogSource, "****** Media of %s\n%s\n", headline, buf));
        break;
    case RV_LOGLEVEL_DEBUG:
        RvLogDebug(ippLogSource, (ippLogSource, "****** Media of %s\n%s\n", headline, buf));
        break;
    default:
        RvLogDebug(ippLogSource, (ippLogSource, "****** Media of %s\n%s\n", headline, buf));
        break;
    }
}
#endif /* (RV_LOGMASK & RV_LOGLEVEL_INFO) */

/******************************************************************************
*  rvCCConnSetUpdateState
*  ----------------------------
*  General :        Sets the state of UPDATE handling.
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                pointer to CC connection object
*                  updateState      UPDATE handling state
*
*  Output:         none
******************************************************************************/
void rvCCConnSetUpdateState(IN RvCCConnection* x,IN RvMtfUpdateState updateState)
{
	x->updateState = updateState;
}

/******************************************************************************
*  rvCCConnGetUpdateState
*  ----------------------------
*  General :       Gets the state of UPDATE handling.
*
*  Return Value:   UPDATE handling state
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                pointer to CC connection object
*
*  Output:         updateState      UPDATE msg handling state
******************************************************************************/

RvMtfUpdateState rvCCConnGetUpdateState(IN RvCCConnection* x)
{
	return x->updateState;
}

void rvCCTerminalMdmSetConferenceFlag(RvCCConnection* c, RvInt32 flag)
{
    c->conferenceFlag = flag;

}

