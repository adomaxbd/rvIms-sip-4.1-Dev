/******************************************************************************
Filename:    rvccCfwMgr.c
Description: Generic call control API
*******************************************************************************
                Copyright (c) 2005 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/

#define LOGSRC	LOGSRC_MDMCONTROL

#include "ipp_inc_std.h"
#include "rvsdp.h"
#include "rvccapi.h"
#include "rvcctext.h"
#include "rvccterminalmdm.h"
#include "rvccprovidermdm.h"
#include "rvIppCfwApi.h"
#include "rvccCfwMgr.h"


/************************************************************************************/
/*					Static Function													*/
/************************************************************************************/
/***************************************************************************
* cfwDataSetTypeInfo
* ------------------------------------------------------------------------
* General: Set cfw data inforamtion of specific type
*			NOTE: All the input parameters should be valid when this function is called.
* Return Value:
*			None
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	cfwData - Pointer to cfw data
*			typeNumber - cfw type
*			state - cfw state
*			sendToAddress - pointer to a diverted to address
*			cfnrTimeout - cfnr timeout value.
*
*  Output:	None
***************************************************************************/
static void cfwDataSetTypeInfo(
                rvCCCfwData*    cfwData, 
                RvIppCfwType    typeNumber, 
                RvCCCfwState    state,
				RvChar*         sendToAddress, 
                RvUint          cfnrTimeout)
{

	cfwData->cfwTypes[typeNumber].cfwState = state;
	cfwData->cfwTypes[typeNumber].cfwType = typeNumber;
    
	if (sendToAddress != NULL)
	{
		strncpy(cfwData->cfwTypes[typeNumber].sendToAddress, sendToAddress,
            sizeof(cfwData->cfwTypes[typeNumber].sendToAddress)-1);
        cfwData->cfwTypes[typeNumber].sendToAddress[sizeof(cfwData->cfwTypes[typeNumber].sendToAddress)-1] = '\0';
	}
	else
	{
		cfwData->cfwTypes[typeNumber].sendToAddress[0] = '\0';
	}
	cfwData->cfwTypes[typeNumber].cfnrTimeout = cfnrTimeout;
    
	RvLogInfo(ippLogSource,(ippLogSource,
		"cfwDataSetTypeInfo: type=%s, state=%s, sendToAddress=%s, cfnrTimeout=%d",
		rvCCTextCfwType(typeNumber),  rvCCTextCfwState(state), sendToAddress, cfnrTimeout));
}


/***************************************************************************
* cfwDataSetState
* ------------------------------------------------------------------------
* General: Set state in cfw data of specific type
*			NOTE: All the input parameters should be valid when this function is called.
* Return Value:
*			None
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	cfwData - Pointer to cfw data
*			typeNumber - cfw type
*			state - cfw state to be set
*
*  Output:	None
***************************************************************************/
static void cfwDataSetState(
                rvCCCfwData*    cfwData, 
                RvIppCfwType    typeNumber, 
                RvCCCfwState    state)
{
	cfwData->cfwTypes[typeNumber].cfwState = state;
}

/***************************************************************************
* cfwDataGetState
* ------------------------------------------------------------------------
* General: Get state of cfw data of specific type
*			NOTE: All the input parameters should be valid when this function is called.
* Return Value:
*			state - cfw state of the required cfw type number
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	cfwData - Pointer to cfw data
*			typeNumber - cfw type
*
*  Output:	None
***************************************************************************/
static RvCCCfwState cfwDataGetState(
                rvCCCfwData*    cfwData, 
                RvIppCfwType    typeNumber)
{
	return (cfwData->cfwTypes[typeNumber].cfwState);
}

/***************************************************************************
* cfwHandleDeactivateRequestinActivatedState
* ------------------------------------------------------------------------
* General:	A request to activate cfw on specific terminal is received.
*			The current cfw state of the type in the terminal is ACTIVATE_START.
*			In this case, the request is blocked and can not be performed,
*			since, in this state, the state machine wait for digits events.
* Return Value:
*			None.
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	t - pointer to terminal.
*			typeNumber - cfw type number
*			timeoutValue - value of the timeout. this is relevant ONLY in cfw type: CFNR.
*
*  Output:	None
***************************************************************************/
static RvCCTerminalEvent cfwHandleDeactivateRequestinActivatedState(
                RvCCTerminal*   t,
				RvIppCfwType    typeNumber)
{
	RvCCTerminalMdm*    mdmTerminal;

    RvLogInfo(ippLogSource,
        (ippLogSource,"cfwHandleDeactivateRequestinActivatedState:: Terminal=%s, Type=%s",
        rvCCTerminalMdmGetTermId(t), rvCCTextCfwType(typeNumber)));

	mdmTerminal = rvCCTerminalMdmGetImpl(t);

	/* was in activate completed state and got "off".
			it is needed to deactivate   */
	cfwDataSetTypeInfo(&mdmTerminal->cfwData, typeNumber, RV_IPP_CFW_STATE_DEACTIVATED, 0, 0);
	rvCCTerminalSetState(t, RV_CCTERMINAL_IDLE_STATE);

	return(RV_CCTERMEVENT_DISCONNECTING);
}



/***************************************************************************
* cfwHandleActivateRequestInDeactivatedState
* ------------------------------------------------------------------------
* General:	A request to activate cfw on specific terminal is received.
*			The current cfw state of the type in the terminal is ACTIVATE_START.
*			In this case, the request is blocked and can not be performed,
*			since, in this state, the state machine wait for digits events.
* Return Value:
*			void.
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	t - pointer to terminal.
*			typeNumber - cfw type number
*			timeoutValue - value of the timeout. this is relevant ONLY in cfw type: CFNR.
*
*  Output:	None
***************************************************************************/
static RvCCTerminalEvent cfwHandleActivateRequestInDeactivatedState(
                RvCCTerminal*   t,
				RvIppCfwType    typeNumber,
				RvUint          timeoutValue)
{
    RvCCTerminalMdm*    mdmTerminal;

	RvLogInfo(ippLogSource,
        (ippLogSource,"cfwHandleActivateRequestInDeactivatedState:: Terminal=%s, Type=%s, timeout=%d",
		 rvCCTerminalMdmGetTermId(t), rvCCTextCfwType(typeNumber), timeoutValue));

    mdmTerminal = rvCCTerminalMdmGetImpl(t);
    
	/* Initialize cfwData in the typeNumber entry */
	cfwDataSetTypeInfo(&mdmTerminal->cfwData, typeNumber, RV_IPP_CFW_STATE_ACTIVATE_START,
						0, timeoutValue);

    /* Change the state machine to wait for digits events */    
	rvCCTerminalSetState(t, RV_CCTERMINAL_CFW_ACTIVATING_STATE);
	return (RV_CCTERMEVENT_LINE);
}




/***************************************************************************
* cfwActivate
* ------------------------------------------------------------------------
* General:	General function on mdm terminal to handle cfw request, either, activation
*			("on) or deactivation ("off).
*			According to recieved type  and the current state of this type,
*			This function:
*			Calls user callback to indicate result of request.
*			Changes state of CFW according to request
* Return Value:
*			none.
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	t			- terminal.
*			typeNumber	- cfw type number
*			isActivate - rvTrue = "on" or rvFalse = "off"
*			timeoutValue - value of the timeout. this is relevant ONLY in cfw type: CFNR.
*
*  Output:	None
***************************************************************************/
RvCCTerminalEvent cfwActivate(
                RvCCTerminal*   t,
				RvIppCfwType    typeNumber,
				RvBool		    isActivate,
				RvUint		    timeoutValue)
{
	/* When entering this procedure, we can assume all the input parameters are valid. */

	RvCCTerminalMdm*    mdmTerminal;
	RvCCTerminalEvent	eventId = RV_CCTERMEVENT_NONE;

	/* Get cfw event parameters */
	mdmTerminal = rvCCTerminalMdmGetImpl(t);

    /* CFW is Activated */
    /* ---------------- */
	if (isActivate == rvTrue)
	{
        RvLogInfo(ippLogSource,
            (ippLogSource,"cfwActivate:: Handling CFW Activate request for Terminal=%s, Type=%s, timeout=%u",
             rvCCTerminalMdmGetTermId(t), rvCCTextCfwType(typeNumber), timeoutValue));
        
		switch (mdmTerminal->cfwData.cfwTypes[typeNumber].cfwState)
		{
		case RV_IPP_CFW_STATE_ACTIVATE_START:
            /* Calling user callback to notify CFW activation is not allowed at this stage*/
			rvCCTerminalCfwActivateCompletedCB(t, typeNumber, mdmTerminal->cfwData.cfwTypes[typeNumber].sendToAddress, RV_IPP_CFW_NOT_ALLOWED);
			break;
		case RV_IPP_CFW_STATE_ACTIVATE_COMPLETED:
            /* CFW is already activated got Activated again, we will deactivate and
			   activate again.
	           NOTE: we don't call suer callback when deactivating, so we don't bother
               the user with our implementation... */
	        eventId = cfwHandleDeactivateRequestinActivatedState(t, typeNumber);
	        eventId = cfwHandleActivateRequestInDeactivatedState(t, typeNumber, timeoutValue);
			break;
		case RV_IPP_CFW_STATE_DEACTIVATED:
			eventId = cfwHandleActivateRequestInDeactivatedState(t, typeNumber, timeoutValue);
			break;
        case RV_IPP_CFW_STATE_NUM:
		default:
			RvLogError(ippLogSource,(ippLogSource,"cfwActivate: Illegal state=%s, Terminal=%s", 
                rvCCTextCfwState(mdmTerminal->cfwData.cfwTypes[typeNumber].cfwState),
                rvCCTerminalMdmGetTermId(t)));
		}
	}

    /* CFW is Deactivated */
    /* ------------------ */
	else 
	{
        RvLogInfo(ippLogSource,
            (ippLogSource,"cfwActivate:: Handling CFW Deactivate request for Terminal=%s, Type=%s, timeout=%u",
            rvCCTerminalMdmGetTermId(t), rvCCTextCfwType(typeNumber), timeoutValue));

		switch (mdmTerminal->cfwData.cfwTypes[typeNumber].cfwState)
		{
		case RV_IPP_CFW_STATE_ACTIVATE_START:
            /* If the user presses CFW, then presses partial digits or nothing, and then
		    CFW again, cancel the Activate request. Handle this as in deactivate state */
			eventId = cfwHandleDeactivateRequestinActivatedState(t, typeNumber);
			RvLogError(ippLogSource,(ippLogSource,"cfwActivate:: Illegal to Activate CFW now since we are collecting digits, Terminal=%s",
                rvCCTerminalMdmGetTermId(t)));
			break;
		case RV_IPP_CFW_STATE_ACTIVATE_COMPLETED:
			eventId = cfwHandleDeactivateRequestinActivatedState(t, typeNumber);
			rvCCTerminalCfwDeactivateCompletedCB(t, typeNumber, RV_IPP_CFW_SUCCESS);
			break;
		case RV_IPP_CFW_STATE_DEACTIVATED:
			rvCCTerminalCfwDeactivateCompletedCB(t, typeNumber, RV_IPP_CFW_INVALID_DEACTIVATION);
			break;
        case RV_IPP_CFW_STATE_NUM:
		default:
			RvLogError(ippLogSource,(ippLogSource,"cfwActivate: Illegal cfw state=%s, Terminal=%s", 
                rvCCTextCfwState(mdmTerminal->cfwData.cfwTypes[typeNumber].cfwState), rvCCTerminalMdmGetTermId(t)));
		}
	} /* End else */
	return(eventId);
}


RVAPI RvIppCfwType RVCALLCONV rvCCCfwGetTypeNumber(IN const RvChar *typeValue)
{
    RvIppCfwType type;

	if (strncmp (typeValue, "cfwu", 4) == 0)
	{
		type = RV_IPP_CFW_TYPE_UNCONDITIONAL;
	}
	else if (strncmp (typeValue, "cfwb", 4) == 0)
	{
		type = RV_IPP_CFW_TYPE_BUSY;
	}
	else if (strncmp (typeValue, "cfnr", 4) == 0)
	{
		type = RV_IPP_CFW_TYPE_NO_REPLY;
	}
    else
    {
        type = RV_IPP_CFW_TYPE_NONE; /* unknown type */
    }

    return type;
}




/***************************************************************************
* rvCCCfwHandleCallForwardTerminalEvent
* ------------------------------------------------------------------------
* General:	This function handles event of call forward.
*			It validates the event parameters, and calls to function to
*			handle the event
* Return Value:
*			none.
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	t			- terminal.

*  Output:	None
***************************************************************************/
RvCCTerminalEvent rvCCCfwHandleCallForwardTerminalEvent(RvCCTerminal *t)
{
	const RvMdmEvent			*event;
	const RvMdmParameterValue	*type;
	const RvMdmParameterValue	*activate;
	const RvMdmParameterList	*args;
	const RvChar				*typeValue;
	const RvChar				*activateValue;
	const RvMdmParameterValue	*timeout;
	const RvChar				*timeoutValue = 0;
	RvUint						timeoutIntValue = 0;
	RvCCTerminalMdm				*mdmTerm;
	RvIppCfwType				typeNumber;
	RvBool						isActivate;

	if (t == NULL)
	{
		return RV_CCTERMEVENT_NONE;
	}

	/* Get cfw event parameters */
	mdmTerm = rvCCTerminalMdmGetImpl(t);
	event = rvCCTerminalMdmGetLastEvent(mdmTerm);
	args = rvMdmEventGetParameterList(event);
	type = rvMdmParameterListGet2(args, "keyId");
	activate = rvMdmParameterListGet2(args, "activate");

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCfwHandleCallForwardTerminalEvent:: Received CFW event for Terminal=%s ", 
        rvCCTerminalGetId(t)));

	if ((type == NULL) || (activate == NULL))
	{
		RvLogError(ippLogSource,
            (ippLogSource,"rvCCCfwHandleCallForwardTerminalEvent:: NULL parameters for Terminal=%s", 
            rvCCTerminalGetId(t)));
		return RV_CCTERMEVENT_NONE;
	}

	typeValue = rvMdmParameterValueGetValue(type);
	/* cfw Type parameter validation */
	if ((typeNumber = rvCCCfwGetTypeNumber(typeValue)) == RV_IPP_CFW_TYPE_NONE) /* Invalid TypeNumber */
	{
        RvLogError(ippLogSource,
            (ippLogSource,"rvCCCfwHandleCallForwardTerminalEvent:: Unknown CFW Type (%s) for Terminal=%s", 
            typeValue, rvCCTerminalGetId(t)));
        
		return RV_CCTERMEVENT_NONE;	/* Don't handle the CFW Event in case of error validation */
	}

	activateValue = rvMdmParameterValueGetValue(activate);
	/* Activate parameter validation */
	if (strncmp (activateValue, "on", 2) == 0)
	{
		isActivate = rvTrue;
	}
	else if (strncmp (activateValue, "off", 3) == 0)
	{
		isActivate = rvFalse;
	}
	else /* Invalid parameter */
	{
        RvLogError(ippLogSource,
            (ippLogSource,"rvCCCfwHandleCallForwardTerminalEvent:: Unknown activateValue (%s) for Terminal=%s", 
            activateValue, rvCCTerminalGetId(t)));
		return RV_CCTERMEVENT_NONE;	/* Don't handle the CFW Event in case of error validation */
	}

	if (strncmp(typeValue, "cfnr", 4) == 0)
	{
		timeout = rvMdmParameterListGet2(args, "timeout");

		if (timeout == NULL)
		{
			timeoutValue = 0;
		}
		else
		{
			timeoutValue = rvMdmParameterValueGetValue(timeout);
			if (timeoutValue != NULL)
			{
				timeoutIntValue = (RvUint)atoi(timeoutValue);
				RvLogInfo(ippLogSource,(ippLogSource, "rvCCCfwHandleCallForwardTerminalEvent: timeout=%d, term id=%s", timeoutIntValue, rvCCTerminalMdmGetTermId(t)));
			}
		}
	}

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCfwHandleCallForwardTerminalEvent:: About to handle CFW event for Terminal=%s: Type=%s, Activate=%s, Timeout=%d", 
         rvCCTerminalGetId(t), rvCCTextCfwType(typeNumber), activateValue, timeoutIntValue));

	return (cfwActivate(t, typeNumber, isActivate, timeoutIntValue));
}



/***************************************************************************
* rvCCCfwHandleActivationCompleted
* ------------------------------------------------------------------------
* General:	This function handles the case when the activation completed.
*			In case of failure, a warning tone is started
*			NOTE: This warning tone will be stopped when the user will press
*			on any button of cfw.
*			In any case the states are updated and a user call back is called
*			to indicate the result of the activation process.
* Return Value:
*			void
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	t			- terminal.
*			IsCompletedSuccessfully - true: success, false: otherwise
*			returnReason: reason of failure in case of activation completed failure.
*  Output:	None
***************************************************************************/
RvCCTerminalEvent rvCCCfwHandleActivationCompleted(
                RvCCTerminal*           t,
				RvBool			        IsCompletedSuccessfully,
				RvIppCfwReturnReasons	returnReason)
{
/*LOGGING*/
	RvUint				typeNumber;
	RvCCTerminalMdm		*mdmTerm;
	RvCCTerminalEvent   retEvent = RV_CCTERMEVENT_NONE;

	mdmTerm = rvCCTerminalMdmGetImpl(t);

	for (typeNumber = 0; typeNumber < RV_IPP_CFW_MAX_NUMBER_OF_TYPES; typeNumber++)
	{
		if (cfwDataGetState(&mdmTerm->cfwData, (RvIppCfwType)typeNumber) == RV_IPP_CFW_STATE_ACTIVATE_START)
		{
            /* Activation Failed */
			if (IsCompletedSuccessfully == rvFalse) 
			{
                RvLogInfo(ippLogSource,
                    (ippLogSource,"rvCCCfwHandleActivationCompleted:: CFW Activation Failed for Terminal=%s, reason=%s", 
                    rvCCTerminalGetId(t), rvCCTextCfwReason(returnReason)));
                
				rvCCTerminalMdmStartWarningSignal(t);
				rvCCTerminalMdmResetDialString(t);

				cfwDataSetState(&mdmTerm->cfwData, (RvIppCfwType)typeNumber, RV_IPP_CFW_STATE_DEACTIVATED);
				rvCCTerminalSetState(t, RV_CCTERMINAL_IDLE_STATE);
				rvCCTerminalCfwActivateCompletedCB(t, (RvIppCfwType)typeNumber, mdmTerm->cfwData.cfwTypes[typeNumber].sendToAddress, returnReason);
				retEvent = RV_CCTERMEVENT_NONE;
			}

            /* Activation Succeeded */
			else
			{
                RvLogInfo(ippLogSource,
                    (ippLogSource,"rvCCCfwHandleActivationCompleted:: CFW Activation Succeeded for Terminal=%s", 
                    rvCCTerminalGetId(t)));

				cfwDataSetState(&mdmTerm->cfwData, (RvIppCfwType)typeNumber, RV_IPP_CFW_STATE_ACTIVATE_COMPLETED);
				rvCCTerminalSetState(t, RV_CCTERMINAL_IDLE_STATE);
				rvCCTerminalCfwActivateCompletedCB(t, (RvIppCfwType)typeNumber, mdmTerm->cfwData.cfwTypes[typeNumber].sendToAddress, RV_IPP_CFW_SUCCESS);
				retEvent = RV_CCTERMEVENT_DISCONNECTING;
			}
		}
	}
	return retEvent;
}



/***************************************************************************
* rvCCCfwUpdateCfwAddress
* ------------------------------------------------------------------------
* General:	This function updates the cfw type which is in activate start state
*			with the found destination address.
* Return Value:
*			void
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	t			- terminal.
*			destAddress - Address of the diverted-to number.
*			destAddressLen - length of the diverted-to address.
*  Output:	None
***************************************************************************/
void rvCCCfwUpdateCfwAddress(
                RvCCTerminal*   t, 
                char*           destAddress, 
                RvUint          destAddressLen)
{
	RvUint				typeNumber;
	RvCCTerminalMdm		*mdmTerm;
	rvCCCfwData			*cfwData;
	RvIppCfwTypeInfo	*cfwTypeInfo;
	RvUint				srcLen;

	mdmTerm = rvCCTerminalMdmGetImpl(t);

	for (typeNumber = 0; typeNumber < RV_IPP_CFW_MAX_NUMBER_OF_TYPES; typeNumber++)
	{
		cfwData = &mdmTerm->cfwData;
        /* Look for the right CFW type first - the one that is in activation process*/
		if (cfwDataGetState(cfwData, (RvIppCfwType)typeNumber) == RV_IPP_CFW_STATE_ACTIVATE_START)
		{
            /* Get destination address length */
			srcLen = sizeof(cfwData->cfwTypes[typeNumber].sendToAddress);

			if (destAddress != NULL)
			{
				cfwTypeInfo = &cfwData->cfwTypes[typeNumber];
                /* Copy the new address to our database */
				strncpy((char *)cfwTypeInfo->sendToAddress, destAddress, srcLen);
				cfwTypeInfo->sendToAddress[destAddressLen] = '\0';

                RvLogInfo(ippLogSource,
                    (ippLogSource,"rvCCCfwUpdateCfwAddress: Updating address to %s for Terminal=%s", 
                    cfwTypeInfo->sendToAddress, rvCCTerminalGetId(t)));
			}
		
			break; /* CFW type was found, no need to continue checking */
		}
	}
}



/***************************************************************************
 * rvCCCfwSendCallForward
 * ------------------------------------------------------------------------
 * General: This function processes the call to be forwarded.
 *
 * Return Value: rvTrue in case of regular call,
 *				rvFalse if call was forwarded successfully and there is
 *				nothing else to process.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	data			- user data which is the cfw data.
  ***************************************************************************/
RvBool rvCCCfwSendCallForward(
                RvCCTerminal*   t,
                RvCCConnection* c,
				RvIppCfwType    cfwType)
{
	RvChar	        divertedToAddress[RV_IPP_ADDRESS_SIZE];
	RvCCConnection* connectParty = rvCCConnectionGetConnectParty(c);
    /* Assume that by default the call is forwarded successfully,
	   so no need to continue processing the call as a normal call */
	RvBool	        rc = rvFalse; 

	if (connectParty == NULL)
	{
		RvLogWarning(ippLogSource,(ippLogSource,"rvCCCfwSendCallForward: No connect Party, Terminal=%s",
            rvCCTerminalGetId(t)));
		/* Continue handling the incoming call normally, failed to forward the call */
		rc = rvTrue;
	}
	else
	{
		memset (divertedToAddress, 0, RV_IPP_ADDRESS_SIZE);
		rvCCCfwGetDivertedToAddress(t, cfwType, sizeof(divertedToAddress), divertedToAddress);

        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCfwSendCallForward: Forwarding call to %s for Terminal=%s",
            divertedToAddress, rvCCTerminalGetId(t)));

		if (rvCCConnectionForwardCall(connectParty, divertedToAddress) != RV_OK)
		{
			RvLogError(ippLogSource,
                (ippLogSource,"rvCCCfwSendCallForward: Failed to Forward call to %s for Terminal=%s",
                 divertedToAddress, rvCCTerminalGetId(t)));
			rc = rvTrue;
		}
	}
	/* The call was forwarded successfully */
	return rc; /* Return False when call is forwarded */
}



/***************************************************************************
 * rvCCfwNoReplyTimerExpires
 * ------------------------------------------------------------------------
 * General: This function is called when the cfnr timer is expired.
 *
 * Return Value: RvBool (rvTrue in case of success, rvFalse in case of failure
 * ------------------------------------------------------------------------
 * Arguments:
 * Input: 	data			- user data which is the cfw data.
  ***************************************************************************/
RvBool rvCCfwNoReplyTimerExpires(void* data)
{

	RvCCConnection	*c;
	RvCCTerminal	*t		= (RvCCTerminal *)data;
	int				index = 0;

    RvLogInfo(ippLogSource,(ippLogSource,
        "rvCCfwNoReplyTimerExpires: CFW Timer expired - looking for the connection... Terminal=%s", 
        rvCCTerminalMdmGetTermId(t)));

	while ((c = rvCCTerminalGetConnectionByIndex(t, index)) != NULL)
	{
		if (rvCCConnectionGetState(c) == RV_CCCONNSTATE_ALERTING)
		{
			RvLogInfo(ippLogSource,(ippLogSource,
                "rvCCfwNoReplyTimerExpires: CFW Timer expired - Forwarding the call, conn=%p, Line=%d, Terminal=%s", 
                c, rvCCConnectionGetLineId(c), rvCCTerminalMdmGetTermId(t)));
			return rvCCCfwSendCallForward(t, c, RV_IPP_CFW_TYPE_NO_REPLY);
		}
        
		index++;
	}

	return rvTrue;
}


/***************************************************************************
* rvCfwDataInitToDefaultValues
* ------------------------------------------------------------------------
* General: Initialize cfwData structure to default values
* Return Value:
*			None
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	cfwData - Pointer to cfw data
*
*  Output:	None
***************************************************************************/
void rvCCCfwDataInitToDefaultValues(rvCCCfwData *cfwData)
{
	RvUint			typeNumber;

	for (typeNumber = 0; typeNumber < RV_IPP_CFW_MAX_NUMBER_OF_TYPES; typeNumber++)
	{
		cfwDataSetTypeInfo(cfwData, (RvIppCfwType)typeNumber, RV_IPP_CFW_STATE_DEACTIVATED, 0, 0);
	}

}
/***************************************************************************
* rvCCCfwProcessIncomingCall
* ------------------------------------------------------------------------
* General: Process the incoming call. If there is an activated cfw type,
*			get the one with the highest priority, and process the incoming
*			call accordingly.
*			NOTE: All the input parameters should be valid when this function is called.
* Return Value:
*			rvTrue: the incoming call should be process as a normal call,
*			rvFalse: the incoming call was handled as a forward call.
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	x - pointer to connection
*
*  Output:	None
***************************************************************************/
RvBool rvCCCfwProcessIncomingCall(RvCCConnection* x)
{
	RvBool				result          = rvTrue; /* By default, continue handle the incoming call normally */
	RvCCTerminal		*t              = rvCCConnectionGetTerminal(x);
	RvCCTerminalMdm		*mdmTerminal    = rvCCTerminalMdmGetImpl(t);
	RvIppCfwType		cfwType         = RV_IPP_CFW_TYPE_NONE; /* By default, no type is activating */
	RvUint				cfnrTimeout     = 0;
	RvCCConnMdm			*connMdm        = rvCCConnMdmGetIns(x);

	/* Get the CFW type with the highest priority that is active, if any. */
	if (cfwDataGetState(&mdmTerminal->cfwData, RV_IPP_CFW_TYPE_UNCONDITIONAL) == RV_IPP_CFW_STATE_ACTIVATE_COMPLETED)
	{
		cfwType = RV_IPP_CFW_TYPE_UNCONDITIONAL;
	}
	else 
    {
        /* If Busy activated, check if the terminal is busy. Terminal is defined as 
           busy when all of its connections are active */
        if ((cfwDataGetState(&mdmTerminal->cfwData, RV_IPP_CFW_TYPE_BUSY) == RV_IPP_CFW_STATE_ACTIVATE_COMPLETED) &&
//add by zhuhaibo 20110324 for CFW
		   // (rvCCTerminalGetNumActiveConnections(t) >= (rvCCTerminalGetNumberOfLines(t)-1)))
		    (rvCCTerminalGetNumActiveConnections(t) >= 1))
//add end
	    {
		    cfwType = RV_IPP_CFW_TYPE_BUSY;
	    }
	    else 
        {
            if (cfwDataGetState(&mdmTerminal->cfwData, RV_IPP_CFW_TYPE_NO_REPLY) == RV_IPP_CFW_STATE_ACTIVATE_COMPLETED)
	        {
		        cfwType = RV_IPP_CFW_TYPE_NO_REPLY;
	        }
        }
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCfwProcessIncomingCall:: Activated Type=%s, for conn=%p, Line=%d, Terminal=%s",
         rvCCTextCfwType(cfwType), x, rvCCConnectionGetLineId(x), rvCCTerminalMdmGetTermId(t)));

    /* Decide how to handle the call according to the activated CFW type */
	switch(cfwType)
    {
	    case RV_IPP_CFW_TYPE_UNCONDITIONAL:
	    case RV_IPP_CFW_TYPE_BUSY:
            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCfwProcessIncomingCall:: Forwarding call for conn=%p, Line=%d, Terminal=%s",
                 x, rvCCConnectionGetLineId(x), rvCCTerminalMdmGetTermId(t)));
		    result = rvCCCfwSendCallForward(t, x, cfwType);
		    break;

	    case RV_IPP_CFW_TYPE_NO_REPLY:
		    rvCCCfwGetCfnrTimeout(t,  &cfnrTimeout);
		    /* start timer. when timer expires, callForward will be called */
		    IppTimerStart(&connMdm->cfnrTimer,IPP_TIMER_RESTART_IF_STARTED, cfnrTimeout*1000 /* To get milliseconds */);
            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCfwProcessIncomingCall:: Starting CFW Timer, timeout=%d (sec) for conn=%p, Line=%d, Terminal=%s",
                 cfnrTimeout, x, rvCCConnectionGetLineId(x), rvCCTerminalMdmGetTermId(t)));
		    break;

        case RV_IPP_CFW_TYPE_NONE:
	    default:
            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCfwProcessIncomingCall:: No CFW type is activated for conn=%p, Line=%d, Terminal=%s, processing call as normal",
                 x, rvCCConnectionGetLineId(x), rvCCTerminalMdmGetTermId(t)));
		    break;/* No type is activated, continue handling the incoming call as usual */
	}
    
	return result;
}



/***************************************************************************
* rvCCCfwGetDivertedToAddress
* ------------------------------------------------------------------------
* General: Get address of the diverted to user within specific cfw type.
*			NOTE: All the input parameters should be valid when this function is called.
* Return Value:
*			RvStatus
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	t - pointer to terminal
*			typeNumber - cfw type
*			addressLen - length of the diverted to address
*
*  Output:	divertedToAddress - Address of the diverted-to user.
*			The user that the call will be forwarded to.
***************************************************************************/
RvStatus rvCCCfwGetDivertedToAddress(
    IN  RvCCTerminal*   t,
    IN  RvIppCfwType    typeNumber,
    IN  RvUint          addressLen,
    OUT RvChar*         divertedToAddress)
{
	RvCCTerminalMdm		*mdmTerminal;

	mdmTerminal = rvCCTerminalMdmGetImpl(t);
    
	strncpy(divertedToAddress, mdmTerminal->cfwData.cfwTypes[typeNumber].sendToAddress, addressLen);
	divertedToAddress[addressLen-1] = '\0';

	return RV_OK;
}


/***************************************************************************
* rvCCCfwGetCFNRTimeout
* ------------------------------------------------------------------------
* General: Get timeout value of the call forward no reply..
*			NOTE: All the input parameters should be valid when this function is called.
* Return Value:
*			RvStatus
* ------------------------------------------------------------------------
*  Arguments:
*  Input:	t - pointer to terminal
*			typeNumber - cfw type
*
*  Output:	cfnrTimeout - timeoutvalue of cfnr timeout
***************************************************************************/
RvStatus rvCCCfwGetCfnrTimeout(RvCCTerminal *t, RvUint *cfnrTimeout)
{
	RvCCTerminalMdm		*mdmTerminal;

	mdmTerminal = rvCCTerminalMdmGetImpl(t);

	*cfnrTimeout = mdmTerminal->cfwData.cfwTypes[RV_IPP_CFW_TYPE_NO_REPLY].cfnrTimeout;

	return (RV_OK);
}


