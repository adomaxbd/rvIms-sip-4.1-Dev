/******************************************************************************
Filename:    rvcccall.c
Description: Generic call API
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#define LOGSRC  LOGSRC_CALLCONTROL
#include "ipp_inc_std.h"
#include "rvcccall.h"
#include "rvlog.h"
#include "rvcctext.h"
#include "rvccCfwMgr.h"
#include "rvccterminalmdm.h"
#include "rvmdmtermevent.h"

/*===============================================================================*/
/*======================= C A L L   F U N C T I O N S ===========================*/
/*===============================================================================*/

void rvCCCallSetState(
                RvCCCall*       call,
                RvCCCallState   state)
{
    if (call == NULL)
    {
        return;
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"Change Call State from %s to %s for Call = %p",
        rvCCTextCallState(call->state), rvCCTextCallState(state), call));

    call->state = state;
}

void rvCCCallConnect(
                RvCCConnection*     origConn,
                RvCCConnection*     destConn)
{
    RvSdpMsg*   origMedia;

    if ((origConn == NULL) || (destConn == NULL))
    {
        return;
    }

    origMedia = (RvSdpMsg*)rvCCConnectionGetMedia(origConn);
    rvCCConnectionSetConnectParty(destConn, origConn);

    /* Pass user data from SIP connection to MDM connection, or vice versa */
    destConn->userData = origConn->userData;

    rvCCConnectionMakeCall(destConn, origMedia);

    RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallConnect:: origConn=%p, Type=%s, Line=%d <<->> destConn=%p, Type=%s, Line=%d",
            origConn, rvCCTextConnectionType(rvCCConnectionGetType(origConn)), rvCCConnectionGetLineId(origConn),
            destConn, rvCCTextConnectionType(rvCCConnectionGetType(destConn)), rvCCConnectionGetLineId(destConn)));
}

/*Add an additional party to the call (one-step conferencing)*/
void rvCCCallAddParty(
                RvCCCall*           call,
                RvCCConnection*     party)
{
    if ((call == NULL) || (party == NULL))
    {
        return;
    }

    rvCCConnectionSetCall(party, call);
    rvPtrListPushBack(&call->connections, party);
    call->connNum++;

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallAddParty:: Add Connection=%p, Line=%d, Type=%s to Call=%p, Total number of connections=%u",
        party, rvCCConnectionGetLineId(party),
        rvCCTextConnectionType(rvCCConnectionGetType(party)), call, call->connNum));
}

void rvCCCallSetConference(
                RvCCCall*           call,
                RvCCConnection*     party)
{
    if ((call == NULL) || (party == NULL))
    {
        return;
    }

    call->conferenceControl = rvCCConnectionGetTerminal(party);
    rvCCCallSetState(call, RV_CCCALLSTATE_CONFERENCE_INIT);

    /*TODO: do we need logging here?*/
}

/*Add an additional party to the call (one-step conferencing)*/
void rvCCCallAddConferenceParty(
                RvCCCall*           call,
                RvCCConnection*     party)
{
    if ((call == NULL) || (party == NULL))
    {
        return;
    }

    rvCCCallAddParty(call, party);
    rvCCCallSetConference(call, party);

    /*TODO: do we need logging here?*/

}

/***************************************************************************
 * rvCCCallClearTransferParties
 * ------------------------------------------------------------------------
 * General: Clear Transfer lines mutually,
 *          and goes into Normal state in the MDM connections               *

 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   mdmConnLine1 - mdm connection of line 1.
 *          mdmConnLine2 - mdm connection of line 2.
 ***************************************************************************/
void rvCCCallClearTransferParties(
                RvCCConnection*     mdmConnLine1,
                RvCCConnection*     mdmConnLine2)
{
    RvCCCall*   call;

    /*Set 1st call's states*/
    if ((mdmConnLine1 != NULL) && ((call = rvCCConnectionGetCall(mdmConnLine1)) != NULL))
    {
        rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);
        rvCCCallSetTransferType(call, RV_CCCALL_TRANSFER_NONE);
        rvCCConnectionSetTransferLine(mdmConnLine1, NULL);
        /* Set the sip conn state to connected since in this point it is in state of TRANSFER_INIT */
        rvCCConnectionSetState(rvCCConnectionGetConnectParty(mdmConnLine1), RV_CCCONNSTATE_CONNECTED);

        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallClearTransferParties:: Clear first call=%p, conn=%p, Line=%d",
            call, mdmConnLine1, rvCCConnectionGetLineId(mdmConnLine1)));
    }

    /*Set 2nd call's states*/
    if ((mdmConnLine2 != NULL) && ((call = rvCCConnectionGetCall(mdmConnLine2)) != NULL))
    {
        rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);
        rvCCCallSetTransferType(call, RV_CCCALL_TRANSFER_NONE);
        rvCCConnectionSetTransferLine(mdmConnLine2, NULL);

        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallClearTransferParties:: Clear second call=%p, conn=%p, Line=%d",
            call, mdmConnLine2, rvCCConnectionGetLineId(mdmConnLine2)));
    }
}


/*Set Transfer lines mutually, and goes into Transfer state*/
void rvCCCallSetTransferParties(
                RvCCConnection*     x,
                RvCCConnection*     party)
{
    RvCCCall*       call;

    if ((x == NULL) || (party == NULL))
    {
        return;
    }

    call = rvCCConnectionGetCall(x);

    if (call != NULL)
    {
        RvCCCallMgr*    callMgr = rvCCCallGetCallMgr(call);

        /*Set first call's state*/
        rvCCCallSetState(call, RV_CCCALLSTATE_TRANSFER_INIT);
        rvCCConnectionSetTransferLine(x, party);
        rvCCConnectionSetTransferLine(party, x);

        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallSetTransferParties:: Set first call=%p, conn=%p, Line=%d",
            call, x, rvCCConnectionGetLineId(x)));

        /*Set second call's state*/
        if ((call = rvCCConnectionGetCall(party)) == NULL)
        {
            call = rvCCCallMgrCreateCall(callMgr);
            rvCCCallAddParty(call, party);
        }

        rvCCCallSetState(call, RV_CCCALLSTATE_TRANSFER_INIT);

        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallSetTransferParties:: Set second call=%p, party=%p, Line=%d",
            call, party, rvCCConnectionGetLineId(party)));
    }
}

/*Removes a party from the call */
RvBool rvCCCallRemoveParty(
                RvCCCall*           call,
                RvCCConnection*     party)
{
    RvBool rc = RV_OK;

    if ((call== NULL) || (party == NULL))
    {
        return RV_FALSE;
    }

    rvPtrListRemove(&call->connections,party);
    rvCCConnectionSetCall(party, NULL);

    /* Check if it was really deleted */
    if(rvListSize(&call->connections) == call->connNum-1)
    {
        call->connNum--;
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallRemoveParty:: Remove Connection from Call=%p, Number of Connections now=%u, conn=%p, Line=%d",
            call, call->connNum, party, rvCCConnectionGetLineId(party)));
        rc = RV_TRUE;
    }
    else
    {
        RvLogError(ippLogSource,
            (ippLogSource,"rvCCCallRemoveParty:: Removing Connection from Call=%p was not done! Number of Connections=%u, conn=%p, Line=%d",
            call, call->connNum, party, rvCCConnectionGetLineId(party)));
        rc = RV_FALSE;
    }

    return rc;
}

/* This function copies Connections from src to dest so that MDM connections
   will be first on the list and network connections are last. the order matters
   since in disconnecting we want media to be disconnected before signaling does*/
static void copyConnectionsList(
                RvPtrList*      dest,
                RvPtrList*      src)
{
    RvPtrListIter i;

    /*Copy MDM Connections first*/
    for(i=rvListBegin(src); i!=rvListEnd(src); i=rvListIterNext(i))
    {
        RvCCConnection* conn = (RvCCConnection *)RvPtrListIterData(i);
        if (rvCCConnectionGetType(conn) != RV_CCCONNTYPE_MDM)
            continue;

        rvPtrListPushBack(dest, RvPtrListIterData(i));
    }

    /* Now copy network Connections*/
    for(i=rvListBegin(src); i!=rvListEnd(src); i=rvListIterNext(i))
    {
        RvCCConnection* conn = (RvCCConnection *)RvPtrListIterData(i);
        if (rvCCConnectionGetType(conn) == RV_CCCONNTYPE_MDM)
            continue;

        rvPtrListPushBack(dest, RvPtrListIterData(i));
    }
}

/*Drop all parties from call*/
void rvCCCallDrop(
                RvCCCall*       call,
                RvCCEventCause  reason)
{
    RvCCConnection *c;
    RvPtrListIter   i;
    RvPtrList       tmpList;

    /* We save the connection in the static array, because calling
       disconnect may remove the party from the call and the vector (when calling
       ReleasedCB) so the vector is corrupted Linked list may be better solution */
    if (call == NULL)
    {
        return;
    }

    RvLogInfo(ippLogSource, (ippLogSource,"rvCCCallDrop:: Starting Call Drop, call=%p", call));

    rvPtrListConstruct(&tmpList, call->connections.allocator);
    copyConnectionsList(&tmpList, &call->connections);

    /* Send disconnect to all connections*/
    for(i=rvListBegin(&tmpList); i!=rvListEnd(&tmpList); i=rvListIterNext(i))
    {
        c = (RvCCConnection*)RvPtrListIterData(i);

        RvLogInfo(ippLogSource, (ippLogSource,"rvCCCallDrop:: Disconnecting conn=%p, Type=%s, Line=%d",
            c, rvCCTextConnectionType(rvCCConnectionGetType(c)), rvCCConnectionGetLineId(c)));
        rvCCConnectionDisconnect(c , reason);
    }

    rvPtrListDestruct( &tmpList);
}


/***************************************************************************
 * rvCCCallTransfer
 * ------------------------------------------------------------------------
 * General: This function start the transfer process.
 *          It looks for the parties that participates within the transfer
 *          process and send it to transferInit process.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   call        - call 1 of the transfer.
 *          controlTerm - mdm connection of line 2.
 *          otherCall   - call 2 of the transfer. In case of blind transfer,
 *                        this value is NULL since there is no other connected
 *                        call in blind/semi transfer.
 *          isLocal     - is it local or remote?
 ***************************************************************************/
static void rvCCCallTransfer(
                RvCCCall*       call,
                RvCCTerminal*   controlTerm,
                RvCCCall*       otherCall,
                RvBool          isLocal)
{
    RvPtrListIter       i;
    RvCCTerminal*       term;
    RvCCConnection*     conn;
    RvCCConnection*     party1 = NULL;
    RvCCConnection*     party2 = NULL;

    if (call == NULL)
    {
        return;
    }

    /* In case of Attended or Semi-Attended Transfer, otherCall must exist, since there is another call with 'C' */
    if ((otherCall == NULL) && (call->transferType != RV_CCCALL_TRANSFER_BLIND))
    {
        RvLogError(ippLogSource,
            (ippLogSource,"rvCCCallTransfer failed: Second call is NULL in Attended or Semi-Attended Transfer, call=%p", call));
        return;
    }

    for(i=rvListBegin(&call->connections); i!=rvListEnd(&call->connections); i=rvListIterNext(i))
    {
        conn = (RvCCConnection *)RvPtrListIterData(i);
        term = rvCCConnectionGetTerminal(conn);

        if(term != controlTerm)
        {
            party1 = conn;
        }
    }

    if (rvCCCallGetTransferType(call) != RV_CCCALL_TRANSFER_BLIND)
    {
        /*lint -e{613}  otherCall won't be NULL if we are in here */
        for(i=rvListBegin(&otherCall->connections); i!=rvListEnd(&otherCall->connections); i=rvListIterNext(i))
        {
            conn = (RvCCConnection *)RvPtrListIterData(i);
            term = rvCCConnectionGetTerminal(conn);
            if(term != controlTerm)
            {
                party2 = conn;
            }
        }
    }

    /* Attended or Semi-Attended Transfer */
    if (party2 != NULL)
    {
    if (isLocal)
    {
        rvCCCallRemoveParty(otherCall, party2);
        rvCCCallAddParty(call, party2);
    }

        /*Party2 belongs to the originator call, and should end up connected to party1*/
        rvCCConnectionTransferInit(party2);
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallTransfer:: Starting Attended or Semi-Attended Transfer for calls %p and %p",
            call, otherCall));
    }
    /* Blind Transfer */
    else
    {
        rvCCConnectionTransferInit(party1);
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallTransfer:: Starting Blind Transfer for call=%p", call));
    }
}

/***************************************************************************
 * rvCCCallTransferDisconnecting
 * ------------------------------------------------------------------------
 * General: This function disconnecting the mdm connections when the transfer
 *          process is completed.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   call        - call 1 of the transfer.
 *          controlTerm - mdm connection of line 2.
 *          otherCall   - call 2 of the transfer. In case of blind transfer,
 *                        this value is NULL since there is no other connected
 *                        call in blind/semi transfer.
 ***************************************************************************/
static void rvCCCallTransferDisconnecting(
                RvCCCall*       call,
                RvCCTerminal*   controlTerm,
                RvCCCall*       otherCall)
{
    RvPtrListIter   i;
    RvCCTerminal*   term;
    RvCCConnection* conn, *discConn;

    if (call == NULL)
    {
        return;
    }

    /* Look for the connection that started the Transfer so we can disconnect it first*/
    discConn = NULL;
    for(i=rvListBegin(&call->connections); i!=rvListEnd(&call->connections); i=rvListIterNext(i))
    {
        conn = (RvCCConnection *)RvPtrListIterData(i);
        term = rvCCConnectionGetTerminal(conn);

        if (term == controlTerm)
        {
            discConn = conn;
        }
    }

    /* Attended or Semi-Attended Transfer */
    if (call->transferType != RV_CCCALL_TRANSFER_BLIND)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallTransferDisconnecting (Attended or Semi-Attended Transfer) for calls %p and %p",
            call, otherCall));

        if (discConn != NULL)
        {
            rvCCCallSetState(rvCCConnectionGetCall(discConn), RV_CCCALLSTATE_NORMAL);
            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallTransferDisconnecting:: Disconnecting conn=%p, Type=%s, Line=%d",
                discConn, rvCCTextConnectionType(rvCCConnectionGetType(discConn)),
                rvCCConnectionGetLineId(discConn)));
            rvCCConnectionDisconnect(discConn, RV_CCCAUSE_NORMAL);
        }

        /* In case of Full transfer, perform the same process to the otherCall */
        if (otherCall != NULL)
        {
            discConn = NULL;

            /*lint -e{613}  otherCall won't be NULL if we are in here */
            for (i=rvListBegin(&otherCall->connections); i!=rvListEnd(&otherCall->connections); i=rvListIterNext(i))
            {
                conn = (RvCCConnection *)RvPtrListIterData(i);
                term = rvCCConnectionGetTerminal(conn);
                if (term == controlTerm)
                {
                    discConn = conn;
                }
            }
            if (discConn != NULL)
            {
                rvCCCallSetState(rvCCConnectionGetCall(discConn), RV_CCCALLSTATE_NORMAL);
                RvLogInfo(ippLogSource,
                    (ippLogSource,"rvCCCallTransferDisconnecting:: Disconnecting conn=%p, Type=%s, Line=%d",
                    discConn, rvCCTextConnectionType(rvCCConnectionGetType(discConn)),
                    rvCCConnectionGetLineId(discConn)));
                rvCCConnectionDisconnect(discConn, RV_CCCAUSE_NORMAL);
                rvCCConnectionSetState(discConn, RV_CCCONNSTATE_DISCONNECTED);
            }
        }
    }
    /* Blind Transfer */
    else
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallTransferDisconnecting (Blind Transfer) for calls %p and %p",
            call, otherCall));

        /* Disconnect the line so that terminal will be idle when Transfer is complete.*/
        if (discConn!=NULL)
        {
			rvCCConnectionDisconnect(discConn, RV_CCCAUSE_NORMAL); 
        }
    }
}

#ifndef RV_MTF_N_LINES
/* Find both parties of Conference and disconnect mixing media */
static void dropConference(RvCCCall* call)
{
    RvCCConnection* conn, *conn1=NULL, *conn2 = NULL;
    RvCCTerminal*   term;
    RvPtrListIter   i;

    if (call == NULL)
    {
        return;
    }

    for(i=rvListBegin(&call->connections); i!=rvListEnd(&call->connections); i=rvListIterNext(i))
    {
        conn = (RvCCConnection *)RvPtrListIterData(i);
        term = rvCCConnectionGetTerminal(conn);

        if(term == call->conferenceControl)
        {
            if (conn1 == NULL)
            {
                conn1 = conn;
                RvLogDebug(ippLogSource,
                    (ippLogSource,"dropConference:: Found conn1 = %p", conn1));
            }
            else
            {
                if (conn2 == NULL)
                {
                    conn2 = conn;
                    RvLogDebug(ippLogSource,
                        (ippLogSource,"dropConference:: Found conn2 = %p", conn2));
                }
                else
                {
                    break;
                }
            }
        }
    }

    /* This will disconnect the RTP terms belonging to different mdm connections
       (opposite of joinConference) both pointing to the same Physical term (controller term) */
    if ((conn1 != NULL) && (conn2 != NULL))
        rvCCConnectionLeaveConference(conn1, conn2);
}
#endif /* RV_MTF_N_LINES */

/* A party has left the conference, inform other participants
   (other connections with the same termination)
   Note: actually only the conference controller terminations
   know about the conference */
static RvBool rvCCCallConferenceLeft(RvCCConnection* x)
{
    RvCCCall*       call;
    RvCCTerminal*   term;
    RvCCConnection* conn, *confLine = NULL;
    int             confLines = 0;
    RvPtrListIter   i;
	RvPtrList		tmpList;
	
#ifdef RV_MTF_N_LINES
	RvCCTerminal *controlTerm = rvCCConnectionGetTerminal(x);
	RvPtrList	 connectionsList;
#endif /* RV_MTF_N_LINES */

    call = rvCCConnectionGetCall(x);

    if(call == NULL)
    {
        return RV_TRUE;
    }

#ifndef RV_MTF_N_LINES
    dropConference(call);

    term = rvCCConnectionGetTerminal(x);

    /* The user who performed  the Conference ended the conference -
        put other connection in the terminal in "hold" state before disconnecting them */
    if(term == call->conferenceControl)
    {
        RvLogDebug(ippLogSource,
            (ippLogSource,"rvCCCallConferenceLeft() - Conference initiator (%p) left the Conference, Line=%d, disconnection all parties...",
            x, rvCCConnectionGetLineId(x)));

        /* To prevent crash of iterator functions as result of list element deleting
           while in loop we work with stored list copy */
        rvPtrListConstruct( &tmpList, call->connections.allocator);
        copyConnectionsList(&tmpList, &call->connections);

        /* send disconnect to all connections*/
        for(i=rvListBegin(&tmpList); i!=rvListEnd(&tmpList); i=rvListIterNext(i))
        {
            conn = (RvCCConnection *)RvPtrListIterData(i);
            rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_HELD);
            rvCCConnectionDisconnect(conn,RV_CCCAUSE_NORMAL);
        }

        rvPtrListDestruct( &tmpList);
    }
	
#else
	
	/* To prevent crash of iterator functions as result of list element deleting while in loop we work with stored list copy */
	rvPtrListConstructCopy( &tmpList, &call->connections, call->connections.allocator);
	
	/* Construct a list of the mdm connections of the call of this input x connection */
	rvPtrListConstruct(&connectionsList, call->connections.allocator);
	
	
	for(i=rvListBegin(&tmpList); i!=rvListEnd(&tmpList); i=rvListIterNext(i))
	{
		conn = (RvCCConnection *)RvPtrListIterData(i);
		term = rvCCConnectionGetTerminal(conn);
		
		if(term==controlTerm && conn!=x)
		{
			rvPtrListPushBack(&connectionsList, conn);
		}
	}
	
	if(controlTerm==call->conferenceControl)
	{
		rvCCConnectionLeaveConference(x, connectionsList);						
		
		/* send disconnect to all connections*/
		for(i=rvListBegin(&tmpList); i!=rvListEnd(&tmpList); i=rvListIterNext(i))
		{
			conn = (RvCCConnection *)RvPtrListIterData(i);
			rvCCConnectionSetTermState(conn, RV_CCTERMCONSTATE_HELD);
			rvCCConnectionDisconnect(conn,RV_CCCAUSE_NORMAL);
		}	
		
		rvPtrListDestruct(&connectionsList);
		rvPtrListDestruct( &tmpList);
	}
	
#endif /* RV_MTF_N_LINES */
    /* A remote user ended the conference - disconnect it and its remote party */
    else
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallConferenceLeft:: One of remote parties (%p) left the Conference, Line=%d, disconnecting it...",
            x, rvCCConnectionGetLineId(x)));

        confLine = rvCCConnectionGetConnectParty(x);
        rvCCConnectionDisconnect(x, RV_CCCAUSE_NORMAL);

        if ((confLine) != NULL)
        {
            rvCCConnectionSetTermState(confLine, RV_CCTERMCONSTATE_HELD);
            rvCCConnectionDisconnect(confLine, RV_CCCAUSE_NORMAL);
        }

        /* Count how many connections are left in this call */
        for(i=rvListBegin(&call->connections); i!=rvListEnd(&call->connections);
            i=rvListIterNext(i))
        {
            conn = (RvCCConnection *)RvPtrListIterData(i);
            term = rvCCConnectionGetTerminal(conn);

            if ((term == call->conferenceControl) && (conn != confLine))
            {
                confLines++;
            }
        }

        RvLogDebug(ippLogSource,
                (ippLogSource,"rvCCCallConferenceLeft:: %u connections are left in call %p",
                call->connNum, call));

        /* If there is only one line left in the conference,
            it means that the call is not Conference call anymore */
        if (confLines <= 1)
        {
            rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);
        }
    }

    return RV_TRUE;
}

/* Conference is canceled before it was completed (meaning one call was established
   and a second call is in process). This can happen as a result of either:
   1. First call was ended (remote side disconnected), in this case call is no longer
      in a Conference state.
   2. Second call was ended before other side answered (while dialing or ringing),
      in this case call should stay in CONFERENCE_INIT state so the user can start
      a new call and complete the Conference.*/
static void rvCCCallConferenceCanceled(RvCCConnection* x)
{
    RvCCCall*       call;
    RvCCTerminal*   term;
    RvCCConnection* party;

    if (x == NULL)
    {
        return;
    }

    call = rvCCConnectionGetCall(x);
    term = rvCCConnectionGetTerminal(x);
    party = rvCCConnectionGetConnectParty(x);

    if (party != NULL)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallConferenceCanceled:: Disconnecting one party, conn=%p, Line=%d, Type=%s, call=%p",
            x, rvCCConnectionGetLineId(x), rvCCTextConnectionType(x->type), call));
        rvCCConnectionDisconnect(party, RV_CCCAUSE_NORMAL);
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallConferenceCanceled:: Disconnecting second party, conn=%p, Line=%d, Type=%s, call=%p",
        x, rvCCConnectionGetLineId(x), rvCCTextConnectionType(x->type), call));

    rvCCConnectionDisconnect(x, RV_CCCAUSE_NORMAL);

    /*First call disconnected while setting up the second call*/
    if ((x->termState == RV_CCTERMCONSTATE_HELD) && (call->conferenceControl != term))
    {
        rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);
    }

}

/*This function removes all connections of the call, except for the connection and its party.
  It is used when the call is switched from Conference state to Normal state.
  parties removed are probably not successful calls*/
void rvCCCallRemoveConferenceParties(RvCCConnection* x)
{
    RvCCCall*           call;
    RvCCConnection*     party;
    RvCCConnection*     conn;
    RvPtrListIter       i;
    RvCCConnection*     connections[6];
    int                 j, n=0;

    if (x == NULL)
    {
        return;
    }

    call = rvCCConnectionGetCall(x);
    party = rvCCConnectionGetConnectParty(x);

    RvLogDebug(ippLogSource,
        (ippLogSource,"rvCCCallRemoveConferenceParties:: call=%p, conn=%p, party=%p",
        call, x, party));

    for (i=rvListBegin(&call->connections); i!=rvListEnd(&call->connections);
            i=rvListIterNext(i))
    {
        conn = (RvCCConnection *)RvPtrListIterData(i);
        if ((conn != party)  && (conn != x))
        {
            connections[n++] = conn;
        }
    }

    for (j=0 ; j<n ; j++)
    {
        /*lint -e{644}   connections is just fine in here */
        conn = connections[j];
        rvCCCallRemoveParty(call, conn);
        rvCCConnectionSetConnectParty(conn, NULL);
    }
}

/*One of the sides disconnected while setting a Transfer call (meaning one call
  was established and a second call is in process):
  1. First call was ended (remote side disconnected), in this case Transfer is
     canceled - Change state of the 2 calls that participate the Transfer to Normal.
  2. Second call was ended before other side answered (while dialing or ringing),
     in this case call should stay in TRANSFER_INIT state so the user can start
     a new call and complete the Transfer.*/
void rvCCCallTransferCanceled(RvCCConnection* x)
{
    RvCCCall*           call;
    RvCCConnection*     transferLine;
    RvCCConnection*     party;

    if (x == NULL)
    {
        return;
    }

    call = rvCCConnectionGetCall(x);
    transferLine = rvCCConnectionGetTransferLine(x);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallTransferCanceled:: Cancelling Transfer for call=%p, conn=%p, Line=%d",
        call, x, rvCCConnectionGetLineId(x)));

    /*Second call disconnected*/
    if (rvCCConnectionGetTermState(x) != RV_CCTERMCONSTATE_HELD)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallTransferCanceled:: Second call is disconnected, nothing to do here, call=%p, termConnState=%s, conn=%p, Line=%d",
            call, rvCCTextTermConnState(rvCCConnectionGetTermState(x)), x,
            rvCCConnectionGetLineId(x)));
        return;
    }

    /* Check if this is not the only connection in the call */
    /* In this case it is not really a transfer cancel */
    if(rvCCCallGetConnNum(call) == 1)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallTransferCanceled:: Only 1 connection in the call, nothing to do here, call=%p, conn=%p, Line=%d",
            call, x, rvCCConnectionGetLineId(x)));

        return;
    }

    /* Now we can safely cancel Transfer*/
    rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);

    if ((rvCCConnectionGetType(x) == RV_CCCONNTYPE_NETWORK) ||
        (transferLine == NULL) )
    {
        party = rvCCConnectionGetConnectParty(x);
        transferLine = rvCCConnectionGetTransferLine(party);
    }

    if (transferLine != NULL)
    {
        call = rvCCConnectionGetCall(transferLine);
        rvCCCallSetState(call, RV_CCCALLSTATE_NORMAL);
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallTransferCanceled:: Transfer is cancelled for call=%p, conn=%p, Line=%d",
        call, x, rvCCConnectionGetLineId(x)));
}

static RvCCCall* rvCCCallConstructA(
                RvCCCall*   call,
                RvAlloc*    a)
{
    rvPtrListConstruct(&call->connections, a);
    RvMutexConstruct( IppLogMgr(), &call->lock);
    call->connNum = 0;
    call->state = RV_CCCALLSTATE_NORMAL;
    call->transferType = RV_CCCALL_TRANSFER_NONE;
    call->conferenceControl = NULL;
    call->lockCnt = 0;
    call->destructionCandidate = RV_FALSE;

    RvLogInfo(ippLogSource,(ippLogSource,"Constructed New Call %p", call));

    return call;
}

static void rvCCCallDestruct(RvCCCall* call)
{
    if (call == NULL)
    {
        return;
    }

    rvPtrListDestruct(&call->connections);
    RvMutexDestruct(&call->lock, IppLogMgr());

    RvLogInfo(ippLogSource,(ippLogSource,"Destructed Call %p", call));
}

void rvCCCallSetOriginAddress(
                RvCCCall*   call,
                char*       address)
{
    if (call == NULL)
    {
        return;
    }

    strncpy(call->originAddress, address, sizeof(call->originAddress)-1);
    call->originAddress[sizeof(call->originAddress)-1] = '\0';

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallSetOriginAddress: %s for call %p", call->originAddress, call));
}


/*===============================================================================*/
/*======================= C A L L   C A L L B A C K S ===========================*/
/*===============================================================================*/

void rvCCCallTransferInProcessCB(RvCCConnection* conn)
{
    RvSdpMsg*           origMedia;
    RvCCConnection*     destConn;

    if (conn == NULL)
    {
        return;
    }

    origMedia = (RvSdpMsg*)rvCCConnectionGetMedia(conn);
    destConn = rvCCConnectionGetConnectParty(conn);

    if (destConn != NULL)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallTransferInProcessCB:: for connections %p and %p", conn, destConn));
        rvCCConnectionSetConnectParty(destConn, conn);
        rvCCConnectionTransferOffered(destConn, origMedia);
    }
}

/* This function is called by Network connection (conn) after setting up a second call
   with the final destination. It takes the MDM connection of the old call and
   put it in the new call.
   conn & destConn are the connections of the old call, newConn & newDestConn belongs
   to the new call*/
void rvCCCallTransferConnectedCB(
                RvCCConnection*     conn,
                RvCCConnection*     newConn)
{
    RvCCConnection*     destConn;
    RvSdpMsg*           newMedia ;
    RvCCCall*           call;
    RvCCConnection*     newDestConn;

    if (conn == NULL)
    {
        return;
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallTransferConnectedCB:: Starting Replacement process of MDM connection... conn=%p, Line=%d",
        conn, rvCCConnectionGetLineId(conn)));

    destConn = rvCCConnectionGetConnectParty(conn);
    newDestConn = destConn;

    if (destConn != NULL)
    {
        rvCCCallRemoveParty(rvCCConnectionGetCall(destConn), destConn);

        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallTransferConnectedCB:: Restarting Media for conn=%p, Line=%d",
            newDestConn, rvCCConnectionGetLineId(newDestConn)));

        /* Let's offer all codecs we have */
        rvCCConnectionRestartMedia(newDestConn);

        newMedia = (RvSdpMsg*)rvCCConnectionGetMedia(newDestConn);
        call = rvCCConnectionGetCall(newConn);
        rvCCCallAddParty(call, newDestConn);

        /*Detach old Network connection from its MDM connection, since it moves to the new call*/
        rvCCConnectionSetConnectParty(conn, NULL);
        rvCCConnectionSetConnectParty(newConn, newDestConn);
        rvCCConnectionSetConnectParty(newDestConn, newConn);

        /* Store Network connection of the 1st call in the MDM connection.
           In case something goes wrong with B->C call,
           the MDM connection can be returned to the 1st A->B call
           using this stored Network connection. */
        rvCCConnectionSetTransferLine(rvCCConnectionGetConnectParty(newConn), conn);
        rvCCConnectionSetTransferLine(conn, rvCCConnectionGetConnectParty(newConn));

        rvCCConnectionSetRemoteMedia(newConn, newMedia);

        /* Move the destConn terminal state from HELD state (as was with A) to TALKING (with C)*/
        rvCCConnectionSetTermState(destConn, RV_CCTERMCONSTATE_TALKING);

    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallTransferConnectedCB:: Replacement process of MDM connection ended successfully for conn=%p, Line=%d",
        conn, rvCCConnectionGetLineId(conn)));
}

/***************************************************************************
 * rvCCCallTransferCompletedCB
 * ------------------------------------------------------------------------
 * General: This function is called when the transfer process is completed.
 *          If the transfer process completed successfully, it is needed to
 *          finish the transfer process and to disconnect the connections.
 *          If the transfer process is completed with a failure, it is needed
 *          to go back to the lines status BEFORE the transfer process.
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   conn            - network connection
 *          isSuccessfully  - Was Transfer process completed successfully or not.
  ***************************************************************************/
void rvCCCallTransferCompletedCB(
                RvCCConnection*     conn,
                RvBool              isSuccessfully)
{
    RvCCConnection *x;

    if (conn == NULL)
    {
        return;
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallTransferCompletedCB:: Starting Transfer Completed Process... conn=%p, Line=%d",
         conn, rvCCConnectionGetLineId(conn)));

    x = rvCCConnectionGetConnectParty(conn);

    if (x != NULL)
    {
        /* Transfer process completed successfully- disconnect both lines*/
        if (isSuccessfully == RV_TRUE)
        {
            RvCCCall *transferLineCall = NULL;

            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallTransferCompletedCB:: Transfer Was Successful for conn=%p, Line=%d",
                conn, rvCCConnectionGetLineId(conn)));

            if (rvCCConnectionGetTransferLine(x) != NULL)
                transferLineCall = rvCCConnectionGetCall(rvCCConnectionGetTransferLine(x));

            if(x->conferenceFlag == 0)
                rvCCCallTransferDisconnecting(rvCCConnectionGetCall(x), rvCCConnectionGetTerminal(x),transferLineCall);
        }
        /* Transfer process was not completed successfully.
        It is needed to go back to the status before starting the Transfer process,
        meaning, A will be connected with both B and C: on Hold with B, active with C*/
        else
        {
            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallTransferCompletedCB:: Transfer Was Not Successful for conn=%p, Line=%d",
                conn, rvCCConnectionGetLineId(conn)));

            rvCCCallClearTransferParties(x, rvCCConnectionGetTransferLine(x));

            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallTransferCompletedCB:: Putting On Hold to Restore Media for conn=%p, Line=%d",
                conn, rvCCConnectionGetLineId(conn)));

            /* Send Hold to B (though A and B are in Hold at this point, this is
               sent again to B, since B's media is set to C, and due to the "MDM connection
               replacement", it is easier to change B's media by sending Re-Invite)*/
                rvCCConnectionTermHold(x->curParty);
                rvCCConnectionTermSetHoldIndicator(x, RV_TRUE);

        }
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallTransferCompletedCB:: Transfer Completed Process Ended for conn=%p, Line=%d",
        conn, rvCCConnectionGetLineId(conn)));
}




/* The remote side is alerting */
void rvCCCallAlerting(
                IN RvCCConnection*  x,
                IN RvCCEventCause   reason)
{
    RvCCConnection* origin;

    if (x == NULL)
    {
        return;
    }

    origin = rvCCConnectionGetConnectParty(x);

    RvLogDebug(ippLogSource,
        (ippLogSource,"rvCCCallAlerting:: for connections %p and %p, reason=%s",
        x, origin, rvCCTextCause(reason)));

    /* the reason can be incoming call, call waiting, transfer, etc */
    rvCCConnectionRingback(origin, reason);
}

/* Both parties are connected */
void rvCCCallConnected(
                IN RvCCConnection*  x,
                IN RvCCEventCause   reason)
{
    if (x == NULL)
    {
        return;
    }

    RvLogDebug(ippLogSource,
        (ippLogSource,"rvCCCallConnected:: for conn=%p, reason=%s",
        x, rvCCTextCause(reason)));

    /*Incoming call*/
    if (reason == RV_CCCAUSE_INCOMING_CALL)
    {
        RvCCConnection* origin = rvCCConnectionGetConnectParty(x);
        rvCCConnectionCallAnswered(origin, NULL);
    }
    /*Outgoing call*/
    else
    {
        rvCCConnectionCallAnsweredCB(x);
}
}

void rvCCCallDisconnectedRemote(
                IN RvCCConnection*  x,
                IN RvCCEventCause   reason)
{
    RvCCCall*       call;

    if (x == NULL)
    {
        return;
    }

    RvLogDebug(ippLogSource,
        (ippLogSource,"rvCCCallDisconnectedRemote:: for conn=%p, reason=%s",
        x, rvCCTextCause(reason)));

    call = rvCCConnectionGetCall(x);

    if (call != NULL)
    {
        /*One of the parties of a conference call disconnected */
        if (rvCCCallGetState(call) == RV_CCCALLSTATE_CONFERENCE_COMPLETED)
        {
            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallDisconnectedRemote:: One party in the Conference disconnected, conn=%p, Line=%d, call=%p, reason=%s",
                x, rvCCConnectionGetLineId(x), call, rvCCTextCause(reason)));

            rvCCCallConferenceLeft(x);
            return;
        }

        /*Disconnecting second party of conference call before it was completed*/
        else if (rvCCCallGetState(call) == RV_CCCALLSTATE_CONFERENCE_INIT)
        {
            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallDisconnectedRemote:: Second call is disconnected before Conference is completed, conn=%p, Line=%d, call=%p, reason=%s",
                x, rvCCConnectionGetLineId(x), call, rvCCTextCause(reason)));
            rvCCCallConferenceCanceled(x);
            return;
        }

        else if (reason == RV_CCCAUSE_TRANSFER)
        {
            RvCCCall *transferLineCall = NULL;

            if (rvCCConnectionGetTransferLine(x) != NULL)
            {
                transferLineCall = rvCCConnectionGetCall(rvCCConnectionGetTransferLine(x));
            }

            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallDisconnectedRemote:: Starting Transfer process, conn=%p, Line=%d, call=%p, transferLineCall=%p",
                x, rvCCConnectionGetLineId(x), call, transferLineCall));
            rvCCCallTransfer(call, rvCCConnectionGetTerminal(x), transferLineCall, RV_FALSE);

            return;

        }
        else
        {
            if (rvCCCallGetState(call) == RV_CCCALLSTATE_TRANSFER_INIT)
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource,"rvCCCallDisconnectedRemote:: Cancelling Transfer, second call is disconnected, conn=%p, Line=%d, call=%p",
                    x, rvCCConnectionGetLineId(x), call));
                rvCCCallTransferCanceled(x);
            }
            /*No return, continue to rvCCCallDrop*/
        }

        /*Normal call, disconnect all parties*/
        rvCCCallDrop(call, reason);

    }
}


RvBool rvCCCallProcessIncomingCB(
                RvCCConnection*     x,
                RvCCEventCause      reason)
{
    RvBool result = RV_TRUE; /* By default, handle the incoming call normally */

    if (x == NULL)
    {
        return result;
    }

    RV_UNUSED_ARG(reason);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallProcessIncomingCB:: New incoming call, check if we need to forward it first, conn=%p, Line=%d",
        x, rvCCConnectionGetLineId(x)));

    /* In the following cases we continue to handle the incoming call normally: */
    /* 1. Failed to forward the call
       2. CFNR case
       3. CFW is not actived */

    result = rvCCCfwProcessIncomingCall(x);

    return result;
}


void rvCCCallRejected(
                IN RvCCConnection*  x,
                IN RvCCEventCause   reason)
{
    RvCCConnection* party;

    if (x == NULL)
    {
        return;
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallRejected:: Call is rejected, conn=%p, Line=%d",
        x, rvCCConnectionGetLineId(x)));

    party = rvCCConnectionGetConnectParty(x);

    if (party != NULL)
    {
        rvCCConnectionReject(party, reason);
    }
}

RvBool rvCCCallModifyMediaCB(
                RvCCConnection*         x,
                RvMdmMediaStreamInfo*   streamDescr)
{
    RvCCConnection* party   = NULL;
    RvBool          status  = RV_FALSE;

    if (x == NULL)
    {
        return status;
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallModifyMediaCB:: Modifying Media during a call, conn=%p, Line=%d",
        x, rvCCConnectionGetLineId(x)));

    rvCCTextPrintMedia(x, streamDescr, "rvCCCallModifyMediaCB", RV_LOGLEVEL_DEBUG);

    party = rvCCConnectionGetConnectParty(x);

    /* If media modification is trigerred by local party (outgoing re-invite)
       then both MDM and SIP handling is required.
       If media modification is trigerred by remote party (incoming re-invite or
       provisional messages (180,183) then only MDM handling is required
       (and then party = mdm cconnection). */
    if (rvCCConnectionGetType(x) == RV_CCCONNTYPE_MDM)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallModifyMediaCB:: Modifying Media in Local party, conn=%p, Line=%d",
            x, rvCCConnectionGetLineId(x)));

        status = rvCCConnectionModifyMedia(x, streamDescr);
        if (status != RV_TRUE)
        {
            RvLogError(ippLogSource,
                (ippLogSource,"rvCCCallModifyMediaCB:: Modify Media failed for Conn=%p, Line=%d, stream=%p",
                x, rvCCConnectionGetLineId(x), streamDescr));
            return status;
        }
    }

    party = rvCCConnectionGetConnectParty(x);

    if (party != NULL)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallModifyMediaCB:: Modifying Media for conn=%p, Line=%d, Type=%s",
            party, rvCCConnectionGetLineId(party), rvCCTextConnectionType(party->type)));
        status = rvCCConnectionModifyMedia(party, streamDescr);
    }

    return status;
}

void rvCCCallModifyMediaDoneCB(
                RvCCConnection*             x,
                RvBool                      status,
                RvMdmMediaStreamInfo*       mediaStream,
                RvMdmTermReasonModifyMedia  reason)
{
    RvCCConnection* party   = NULL;

    if (x == NULL)
    {
        return;
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallModifyMediaCB:: Modifying Media Done for conn=%p, Line=%d, Type=%s",
        x, rvCCConnectionGetLineId(x), rvCCTextConnectionType(x->type)));

    party = rvCCConnectionGetConnectParty(x);
    if (party != NULL)
    {
        rvCCConnectionModifyMediaDone(party, status, mediaStream, reason);

    }
}

RvBool rvCCCallHold(
                RvCCConnection*     x,
                RvCCEventCause      reason)
{
    RvCCCall*           call;
    RvCCConnection*     party;
    RvPtrListIter       i;
    RvBool              res = RV_TRUE;

    if (x == NULL)
    {
        return res;
    }

    call = rvCCConnectionGetCall(x);
    if (call == NULL)
    {
        return res;
    }

    /*If this is a conference call, and local user pressed on Hold, put all other parties
      of the call on Hold*/
    if ((call->state == RV_CCCALLSTATE_CONFERENCE_COMPLETED) &&
        (reason == RV_CCCAUSE_LOCAL_HOLD))
    {
        for(i = rvListBegin(&call->connections); i != rvListEnd(&call->connections);
            i = rvListIterNext(i))
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource,"rvCCCallHold:: Starting Call Hold of all parties during Conference for conn=%p, Line=%d",
                    x, rvCCConnectionGetLineId(x)));

                party = (RvCCConnection *)RvPtrListIterData(i);
                if (rvCCConnectionGetType(party) == RV_CCCONNTYPE_NETWORK)
                {
                    RvLogInfo(ippLogSource,
                        (ippLogSource,"rvCCCallHold:: Putting remote party (%p) on Hold for conn=%p, Line=%d",
                        party, x, rvCCConnectionGetLineId(x)));

                    if (rvCCConnectionTermRemoteHold(party) == RV_FALSE)
                    {
                        RvLogError(ippLogSource,
                            (ippLogSource,"rvCCCallHold::  Putting remote party (%p) on Hold failed for conn=%p, Line=%d",
                            party, x, rvCCConnectionGetLineId(x)));
                        res = RV_FALSE;
                    }
                }
                else if (party != x)
                {
                    /* x is already on Hold*/
                    RvLogInfo(ippLogSource,
                        (ippLogSource,"rvCCCallHold:: Putting local party on Hold for conn=%p, Line=%d",
                        party, rvCCConnectionGetLineId(party)));

                    if (rvCCConnectionTermHold(party) == RV_FALSE)
                    {
                        RvLogError(ippLogSource,
                            (ippLogSource,"rvCCCallHold::  Putting local party on Hold failed for conn=%p, Line=%d",
                            x, rvCCConnectionGetLineId(x)));
                        res = RV_FALSE;
                    }
                }
            }
    }
    /*All other cases, put only the other party on Hold*/
    else
    {
        party = rvCCConnectionGetConnectParty(x);
        if (party != NULL)
        {
            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallHold:: Putting remote party (%p) on Hold for conn=%p, Line=%d",
                party, x, rvCCConnectionGetLineId(x)));
            res = rvCCConnectionTermRemoteHold(party);
        }
        else
        {
            RvLogError(ippLogSource,
                (ippLogSource,"rvCCCallHold::  Putting remote party on Hold failed, party is NULL for conn=%p, Line=%d",
                x, rvCCConnectionGetLineId(x)));
            res = RV_FALSE;
        }
    }

    return res;

}

void rvCCCallTalking(
                RvCCConnection*     x,
				RvMdmMediaStreamInfo* streamDescr,
                RvCCEventCause      reason)
{

    RvCCCall*           call;
    RvCCConnection*     party;
    RvPtrListIter       i;

    if (x == NULL)
    {
        return;
    }

    call = rvCCConnectionGetCall(x);
    /*If this is a conference call, and local user pressed on Unhold, put all other parties
      of the call on a Talking state*/
    if ((call->state == RV_CCCALLSTATE_CONFERENCE_COMPLETED) &&
        (reason != RV_CCCAUSE_REMOTE_HOLD))
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallTalking:: Starting Call Unhold of all parties during Conference for conn=%p, Line=%d",
            x, rvCCConnectionGetLineId(x)));

        for (i = rvListBegin(&call->connections); i != rvListEnd(&call->connections);
             i = rvListIterNext(i))
        {
            party = (RvCCConnection *)RvPtrListIterData(i);
            if (rvCCConnectionGetType(party) == RV_CCCONNTYPE_NETWORK)
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource,"rvCCCallTalking:: Unholding remote party (%p) for conn=%p, Line=%d",
                    party, x, rvCCConnectionGetLineId(x)));
                rvCCConnectionTermRemoteUnhold(party);
            }
            else if (party != x)
            {
                /* x is already talking*/
                RvLogInfo(ippLogSource,
                    (ippLogSource,"rvCCCallTalking:: Unholding local party for conn=%p, Line=%d",
                    party, rvCCConnectionGetLineId(party)));
                rvCCConnectionTermUnhold(party, NULL);
            }
        }
    }
    else
    {
        party = rvCCConnectionGetConnectParty(x);
        if (party)
        {
            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallTalking:: Unholding remote party for conn=%p, Line=%d",
                party, rvCCConnectionGetLineId(party)));
			if (streamDescr != NULL)
			{
				/* If a streamDescr is supplied set the media in the Network and MDM connections before
				   sending an Unhold request. Some applications may change the media during Unhold 
				   process. */
				const RvMdmStreamDescriptor*  descr = rvMdmMediaStreamInfoGetStreamDescriptor(streamDescr);
				if (rvMdmStreamDescriptorIsLocalDescriptorSet(descr) == rvTrue) 
				{
					const RvSdpMsg*         localSdp = rvMdmStreamDescriptorGetLocalDescriptor(descr, 0);
					rvCCConnectionSetLocalMedia(x, (RvSdpMsg*)localSdp);
					/* In the party connection the local media is stored as remote media. This is true for SIP,
					need to be verified for H323 connection */	   
					rvCCConnectionSetRemoteMedia(party, (RvSdpMsg*)localSdp);
				}	
			}

            rvCCConnectionTermRemoteUnhold(party);
        }
    }
}

/* This function is used for normal call only */
void rvCCCallDtmfPressed(
                IN RvCCConnection*      x,
                IN RvDtmfParameters*    dtmfParam)
{

    RvCCConnection* party;

    if (x == NULL)
    {
        return;
    }

    party = rvCCConnectionGetConnectParty(x);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallDtmfPressed:: Send DTMF (digit=%c) to party=%p, Line=%d for conn=%p, Line=%d",
        dtmfParam->digit, party, rvCCConnectionGetLineId(party), x, rvCCConnectionGetLineId(x)));

    rvCCConnectionTermPlayDtmf(party, dtmfParam);
}

/*This event is sent by the connection to inform the call it's been released,
the function will check if this is the last connection, if yes it will release
the call.
Returns false if the call was released*/
RvBool rvCCCallPartyReleased(IN RvCCConnection* x)
{
    RvCCCall* call;

    call = rvCCConnectionGetCall(x);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallPartyReleased:: Connection is about to be released, call=%p, conn=%p, Line=%d",
        call, x, rvCCConnectionGetLineId(x)));

    if(call==NULL)
        return RV_TRUE;

    rvCCCallRemoveParty(call, x);

    if (rvListSize(&call->connections) == 0)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallPartyReleased:: No Connections left, Releasing call=%p", call));

        rvCCCallTerminatedCB(x, call);
        rvCCCallMgrReleaseCall(call->callMgr, call);
        return RV_FALSE;
    }

    return RV_TRUE;
}

#ifndef RV_MTF_N_LINES

/* The controller has joined the conference, inform
   the other parties (with the same termination) to connect */
RvBool rvCCCallConferenceJoinedCB(RvCCConnection* x)
{
    RvCCCall*       call;
    RvPtrListIter   i;
    RvCCTerminal*   term, *controlTerm;
    RvCCConnection* conn, *party;
    RvPtrList       tmpList;

    if (x == NULL)
    {
        return RV_FALSE;
    }

    call = rvCCConnectionGetCall(x);
    if (call == NULL)
    {
        return RV_FALSE;
    }

    controlTerm = rvCCConnectionGetTerminal(x);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallConferenceJoinedCB:: Completing Conference for conn=%p, Line=%d, Terminal=%s",
        x, rvCCConnectionGetLineId(x), rvCCTerminalGetId(controlTerm)));

    /* To prevent crash of iterator functions as result of list element deleting while in loop we work with stored list copy */
    rvPtrListConstructCopy( &tmpList, &call->connections, call->connections.allocator);

    for(i = rvListBegin(&tmpList); i != rvListEnd(&tmpList); i = rvListIterNext(i))
    {
        conn = (RvCCConnection *)RvPtrListIterData(i);
        term = rvCCConnectionGetTerminal(conn);

        if ((term == controlTerm) && (conn != x))
        {
            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallConferenceJoinedCB:: Joining local party of first call, conn=%p, Line=%d, Terminal=%s",
                conn, rvCCConnectionGetLineId(conn), rvCCTerminalGetId(controlTerm)));

            rvCCConnectionJoinConference(conn, x);
            party = rvCCConnectionGetConnectParty(conn);
            if (party != NULL)
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource,"rvCCCallConferenceJoinedCB:: Joining remote party (%p) of first call, conn=%p, Line=%d, Terminal=%s",
                    party, x, rvCCConnectionGetLineId(x), rvCCTerminalGetId(controlTerm)));

                rvCCConnectionTermUnhold(party, NULL);
            }
        }
    }

    rvPtrListDestruct( &tmpList);

    rvCCCallSetState(call, RV_CCCALLSTATE_CONFERENCE_COMPLETED);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallConferenceJoinedCB:: Conference is Completed successfully for conn=%p, Line=%d, Terminal=%s",
         x, rvCCConnectionGetLineId(x), rvCCTerminalGetId(controlTerm)));

    return RV_TRUE;
}
#else

RvBool rvCCCallConferenceJoinedCB(RvCCConnection* x) 
{
	RvCCCall* call = rvCCConnectionGetCall(x);
	RvPtrListIter i;
	RvCCTerminal* term,* controlTerm = rvCCConnectionGetTerminal(x);
	RvCCConnection* conn, *party;
	RvPtrList    tmpList;
	RvPtrList	conferenceMdmConnectionsList;
	
	/* To prevent crash of iterator functions as result of list element deleting while in loop we work with stored list copy */
	rvPtrListConstructCopy( &tmpList, &call->connections, call->connections.allocator);
	
	/* Construct a list of the mdm connections of the call of this input x connection */
	rvPtrListConstruct(&conferenceMdmConnectionsList, call->connections.allocator);
	
	
	for(i=rvListBegin(&tmpList); i!=rvListEnd(&tmpList); i=rvListIterNext(i))
	{
		conn = (RvCCConnection *)RvPtrListIterData(i);
		term = rvCCConnectionGetTerminal(conn);
		
		if(term==controlTerm && conn!=x)
		{
			rvPtrListPushBack(&conferenceMdmConnectionsList, conn);
		}
	}
	
	rvCCConnectionJoinConference(x, conferenceMdmConnectionsList);
	
	for(i=rvListBegin(&conferenceMdmConnectionsList); i!=rvListEnd(&conferenceMdmConnectionsList); i=rvListIterNext(i))
	{
		conn = (RvCCConnection *)RvPtrListIterData(i);
		party = rvCCConnectionGetConnectParty(conn);
		rvCCConnectionTermUnhold(party); /* Unhold the protocol specific connection */
	}
	
	rvPtrListDestruct(&conferenceMdmConnectionsList);
	rvPtrListDestruct(&tmpList);
	
	rvCCCallSetState(call, RV_CCCALLSTATE_CONFERENCE_COMPLETED);
	
	return rvTrue;
}

#endif /* RV_MTF_N_LINES */

RvBool rvCCCallMediaUpdatedCB(
                RvCCConnection*     conn,
                RvSdpMsg*           inMedia)
{
    RvCCConnection*     party;

    if (conn == NULL)
    {
        return RV_FALSE;
    }

    party = rvCCConnectionGetConnectParty(conn);
    if (party != NULL)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallMediaUpdatedCB:: Updating remote party media for conn=%p, Line=%d",
             conn, rvCCConnectionGetLineId(conn)));

        return rvCCConnectionSetRemoteMedia(party, inMedia);
    }

    return RV_TRUE;
}

void rvCCCallTerminatedCB(
                RvCCConnection*     conn,
                RvCCCall*           call)

{
    RvCCConnection* party;

    if (conn == NULL)
    {
        return;
    }
    party   = rvCCConnectionGetConnectParty(conn);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallTerminatedCB:: About to release the call, release its connections first... conn=%p, Line=%d",
        conn, rvCCConnectionGetLineId(conn)));

    if (call == NULL)
    {
        if (party != NULL)
        {
            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallTerminatedCB:: Call is already released, releasing party (%p) for conn=%p, Line=%d",
                 party, conn, rvCCConnectionGetLineId(conn)));
            rvCCConnectionTerminate(party);
        }
    }

    else /*If call exists, terminate all other parties*/
    {
        RvPtrListIter   i;
        RvPtrList       tmpList;

        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallTerminatedCB:: releasing party (%p), conn=%p, Line=%d",
             party, conn, rvCCConnectionGetLineId(conn)));

        rvCCConnectionTerminate(party);

        /* To prevent crash of iterator functions as result of list element deleting
           while in loop we work with stored list */
        rvPtrListConstructCopy( &tmpList, &call->connections, call->connections.allocator);

        for(i=rvListBegin(&tmpList); i!=rvListEnd(&tmpList); i=rvListIterNext(i))
        {
            party = (RvCCConnection *)RvPtrListIterData(i);
            if (party != conn)
            {
                RvLogInfo(ippLogSource,
                    (ippLogSource,"rvCCCallTerminatedCB:: releasing party (%p), conn=%p, Line=%d",
                    party, conn, rvCCConnectionGetLineId(conn)));
                rvCCConnectionTerminate(party);
            }
        }

        rvPtrListDestruct( &tmpList);
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallTerminatedCB:: Call was released successfully for conn=%p, Line=%d",
         conn, rvCCConnectionGetLineId(conn)));
}

/*This function can be used to pass events from network connection to MDM connection*/
void rvCCCallSendUserEventCB(
                RvCCConnection*     x,
                RvCCTerminalEvent   event,
                RvCCEventCause*     reason)
{
    RvCCConnection* party;
    RvBool stillAlive;

    if (x == NULL)
    {
        return;
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallSendUserEventCB:: Sending user event for conn=%p, Line=%d, event=%s, reason=%s",
         x, rvCCConnectionGetLineId(x), rvCCTextEvent(event), rvCCTextCause(*reason)));

    party = rvCCConnectionGetConnectParty(x);

    if ((party != NULL) && (rvCCConnectionGetType(party) == RV_CCCONNTYPE_MDM))
    {
        rvCCConnectionProcessTermEvent(party, event, &stillAlive, *reason);
    }
}

/*===============================================================================*/
/*==================== L O C K   F U N C T I O N S ==============================*/
/*===============================================================================*/

/* Lock the call */
void rvCCCallLock(RvCCCall* call)
{
    RvLogDebug(ippLogSource,
        (ippLogSource,"rvCCCallLock:: Locking call=%p", call));

    RvMutexLock(&call->lock,IppLogMgr());
    call->lockCnt++;
}

/* Unlock the call */
void rvCCCallUnlock(RvCCCall* call)
{
    RvLogDebug(ippLogSource,
        (ippLogSource,"rvCCCallLock:: Unlocking call=%p", call));

    RvMutexUnlock(&call->lock,IppLogMgr());
    call->lockCnt--;

    /* That's it, call was marked as released and all holders unlocked the call,
       we can finally truly destroy it */
    if ((call->lockCnt == 0) && (call->destructionCandidate == RV_TRUE))
    {
        rvCCCallDestruct(call);
        rvMtfAllocatorDealloc(call, sizeof(RvCCCall));
    }
}


/*===============================================================================*/
/*==================== C A L L  M G R   F U N C T I O N S =======================*/
/*===============================================================================*/
void rvCCCallMgrConstructA(
                RvCCCallMgr*    x,
                RvAlloc*        a)
{
    rvPtrListConstruct(&x->calls, a);
    RvMutexConstruct( IppLogMgr(), &x->mutex);
}

void rvCCCallMgrDestruct(RvCCCallMgr* x)
{
    rvPtrListDestruct(&x->calls);
    RvMutexDestruct(&x->mutex, IppLogMgr());
}

RvCCCall* rvCCCallMgrCreateCall(RvCCCallMgr* x)
{
    RvCCCall* newCall = NULL;

    rvMtfAllocatorAlloc(sizeof(RvCCCall), (void**)&newCall);
    rvCCCallConstructA(newCall,prvDefaultAlloc);
    rvPtrListPushBack(&x->calls, newCall);
    newCall->callMgr = x;

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallMgrCreateCall:: New call (%p) was constructed, callMgr=%p",
        newCall, x));

    return newCall;
}

void rvCCCallMgrReleaseCall(
                RvCCCallMgr*    x,
                RvCCCall*       call)
{
    rvPtrListRemove(&x->calls, call);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallMgrReleaseCall:: Call (%p) was released, callMgr=%p",
         call, x));

    /* First we wait until all other threads unlock the call*/
    rvCCCallLock(call);

    /* If call->lockCnt > 1, it means we already locked the call previously. If this is the case,
       we don't destruct mutex here, only mark the call as "logically destructed" and it will be physically
       destructed later on when call->lockCnt is zero. */
    if (call->lockCnt > 1)
    {
        /* This flag only marks the call as "needs to be destructed" */
        call->destructionCandidate = RV_TRUE;
        rvCCCallUnlock(call);
    }
    /* If call->lockCnt=1, it means the call is not locked in any other place but here, so we can safely
       destroy it */
    else
    {
        /* We must unlock the call before destroying mutex*/
        rvCCCallUnlock(call);
        /* Destroy the call physically*/
        rvCCCallDestruct(call);
    rvMtfAllocatorDealloc(call, sizeof(RvCCCall));
    }
}

/*Moves connection from callSource to callDest, and remove callSource*/
void rvCCCallMgrMoveConnection(
                RvCCCallMgr*    x,
                RvCCCall*       callSource,
                RvCCCall*       callDest,
                RvCCConnection* conn)
{
    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallMgrMoveConnection:: About to move connection (%p) from call (%p) to call (%p), Line=%d",
         conn, callSource, callDest, rvCCConnectionGetLineId(conn)));

    rvCCCallRemoveParty(callSource, conn);
    if (rvListSize(&callSource->connections) == 0)
    {
        RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallMgrMoveConnection:: Releasing Call (%p), no connections are left",
             callSource));
        /*Release call only if no connections are left*/
        rvCCCallMgrReleaseCall(x, callSource);
    }

    rvCCCallAddParty(callDest, conn);
}

/* Transfer-Replaces feature */
RvBool rvCCCallMgrReplaceConnByLocal(
                IN RvCCCallMgr*         x,
                IN RvCCConnection*      conn,
                IN char*                address,
                IN char*                data,
                OUT RvCCConnection**    oldParty)
{
    RvCCCall*           newCall;
    RvCCCall*           oldCall;
    RvCCConnection*     party;
    RvPtrListRevIter    i;
    RvPtrListIter       j;

    if (conn == NULL)
    {
        return RV_FALSE;
    }

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallMgrReplaceConnByLocal:: About to replace connections (conn=%p), address=%s, to=%s",
         conn, address, data));

    newCall = rvCCConnectionGetCall(conn);
    for(i = rvPtrListBegin(&x->calls); i != rvPtrListEnd(&x->calls);
        i = rvPtrListIterNext(i))
    {
        oldCall = (RvCCCall *)rvPtrListIterData(i);
        if (strcmp(oldCall->originAddress, address))
            continue;

        for(j = rvListBegin(&oldCall->connections); j != rvListEnd(&oldCall->connections);
            j = rvListIterNext(j))
        {
            RvCCConnection* oldPartyTmp;

            party = (RvCCConnection *)RvPtrListIterData(j);
            if (party->type != RV_CCCONNTYPE_MDM)
                continue;

            /*Check if this is the matching connection from the original call*/
            if (rvCCConnectionIsTransferedConn(party, data) == RV_FALSE)
                continue;

            oldPartyTmp = party->curParty;

            rvCCCallMgrMoveConnection(x, oldCall, newCall, party);

            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallMgrReplaceConnByLocal:: New party=%p for conn=%p, Line=%d",
                 conn, party, rvCCConnectionGetLineId(party)));

            rvCCConnectionSetConnectParty(party, conn);
            rvCCConnectionSetConnectParty(conn, party);

            RvLogInfo(ippLogSource,
                (ippLogSource,"rvCCCallMgrReplaceConnByLocal:: Old party=%p of conn=%p, Line=%d",
                 oldPartyTmp, party, rvCCConnectionGetLineId(party)));

            *oldParty = oldPartyTmp;
            return RV_TRUE;
        }
    }

     RvLogInfo(ippLogSource,
            (ippLogSource,"rvCCCallMgrReplaceConnByLocal:: Old call/party was Not found, connections were not replaced (conn=%p)", conn));

    *oldParty = NULL;
    return RV_FALSE;
}


/* Transfer-Replaces feature */
/***************************************************************************
 * rvCCCallMgrReplaceConn
 * ------------------------------------------------------------------------
 * General: Moves the MDM connection from the existing call to the new call.
 *          In addition, it handles the replacement of connection.
 * Return Value: Returns RV_Status.
 * ------------------------------------------------------------------------
 * Arguments:
 * input: x             - Pointer to call manger structure.
 *        call1Conn     - Pointer to connection of call1
 *        call2Conn     - Pointer to connection of call2
 * output: None
 ***************************************************************************/
int rvCCCallMgrReplaceConn(
                RvCCCallMgr*    x,
                RvCCConnection* call1Conn,
                RvCCConnection* call2Conn)
{
    RvCCCall*       oldCall;
    RvCCCall*       newCall;
    RvCCConnection* MDMConn = rvCCConnectionGetConnectParty(call1Conn);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallMgrReplaceConn:: Moving MDM connection (%p), Line=%d, from party=%p to party=%p",
         MDMConn, rvCCConnectionGetLineId(MDMConn), call1Conn, call2Conn));

    oldCall = rvCCConnectionGetCall(call1Conn);
    newCall = rvCCConnectionGetCall(call2Conn);

    rvCCCallMgrMoveConnection(x, oldCall, newCall, MDMConn);

    rvCCConnectionSetConnectParty(call2Conn, MDMConn);
    rvCCConnectionSetConnectParty(MDMConn, call2Conn);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallMgrReplaceConn:: Moved MDM connection (%p), Line=%d successfully",
         MDMConn, rvCCConnectionGetLineId(MDMConn)));

    return (0); /* Rv_Success */
}



/******************************************************************************
*  RvCCCallConferenceSendDtmfByConn
*  ----------------------------
*  General :        send dtmf to all parties in conference
*
*  Return Value:    None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          conn            current connection.
*       .          digit           digit from user
*
*
*
*
*  Output          None.
*
******************************************************************************/
void RvCCCallConferenceSendDtmfByConn(
                IN RvCCConnection*  conn,
                IN RvChar           digit)
{
    RvUint16            i = 0;
    RvCCCall*           call = NULL;
    RvCCConnection*     x;
    RvDtmfParameters    dtmfParam;
	unsigned int     	maxConnections;

    RvLogInfo(ippLogSource,
        (ippLogSource,"RvCCCallConferenceSendDtmfByConn:: Sending DMTF (digit=%c) to all Conference parties for conn=%p, Line=%d",
         digit, conn, rvCCConnectionGetLineId(conn)));

    rvDtmfParametersInit(&dtmfParam);
    dtmfParam.digit = digit;

    if (conn != NULL)
    {
        call = rvCCConnectionGetCall(conn);
		maxConnections = rvCCTerminalGetNumberOfLines(rvCCConnectionGetTerminal(conn));

        while (i < maxConnections)
        {
            x = call->conferenceControl->connections[i++];
            if (rvCCConnectionGetState(x) == RV_CCCONNSTATE_CONNECTED)
            {
                rvCCCallDtmfPressed(x, &dtmfParam);
            }
        }
    }
}

/******************************************************************************
*  rvCCCallHandleOutOfBandDTMF
*  ----------------------------
*  General :        choose if to send DTMF signal to one party or more(conf)
*  Return Value:    None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          conn            current connection.
*                  digit           digit from user
*                  duration        duration to "play" a signal
*
*
*  Output          None.
******************************************************************************/
void rvCCCallHandleOutOfBandDTMF(
                IN RvCCConnection*  conn,
                IN RvChar           digit,
                int                 duration)
{
    RvCCTerminal*       t;
    RvDtmfParameters    dtmfParam;

    t = rvCCConnectionGetTerminal(conn);

    RvLogInfo(ippLogSource,
        (ippLogSource,"rvCCCallHandleOutOfBandDTMF:: digit=%c, duration=%d, conn=%p, Line=%d",
        digit, duration, conn, rvCCConnectionGetLineId(conn)));

    rvDtmfParametersInit(&dtmfParam);
    dtmfParam.digit = digit;
    dtmfParam.duration = duration;

    if (rvCCTerminalMdmIsOutOfBandDtmfEnabled(t))
    {
        RvCCCall* call = rvCCConnectionGetCall(conn);
        if (call != NULL)
        {
            if (rvCCCallGetState(call) == RV_CCCALLSTATE_CONFERENCE_COMPLETED)
                RvCCCallConferenceSendDtmfByConn(conn, digit);
            else
                rvCCCallDtmfPressed(conn, &dtmfParam);
        }
    }
}
/****************************************************************************************
*   rvCCCallAddEventParam
*   ----------------------
*  General :      Add an event to  RvMdmParameterList  
*  Return Value:  None  
*
*  ----------------------------------------------------------------------------
*  Arguments:    
*  Input:       list       - Argument list    
*               paramName  - parameter in the list
*               paramValue - parameter value
*
*  Output          None.
*****************************************************************************************/

void rvCCCallAddEventParam(
							RvMdmParameterList*     list,
							char*                   paramName,
						    char*                   paramValue)
{
    RvMdmPackageItem    pkgItem;
	
    rvMdmPackageItemConstruct(&pkgItem, "", paramName);
    rvMdmParameterListOr(list, &pkgItem, paramValue);
    rvMdmPackageItemDestruct(&pkgItem);
}
/****************************************************************************************
*   rvCCCallSendOnhookToMdmStateMachine
*   -----------------------------------
*  General :      Send an ONHOOK event directly to the MDM state machine, bypassing the
*                 event queue.
*                 This proc may be called when a user application is not able to send
*                 ONHOOK by itself. The MTF should send it in order to complete a call.
*                 Sending this event via the event queue will delay its handling, which 
*                 may cause synchronization problems.
*  Return Value:  None  
*
*  ----------------------------------------------------------------------------
*  Arguments:    
*  Input:       conn       - The call connection   
*
*  Output          None.
*****************************************************************************************/
void rvCCCallSendOnhookToMdmStateMachine( RvCCConnection*     conn )
{
	RvCCConnection*     mdmConn = conn;
	RvMdmParameterList  paramsList;
	RvCCTerminal*		t;
	RvCCTerminalMdm*	term;
	RvMdmTerm*			mdmTerm;

	if (rvCCConnectionGetType(conn) != RV_CCCONNTYPE_MDM)
	{
		mdmConn = rvCCConnectionGetConnectParty(conn);
	}
	
	if (mdmConn != NULL)
	{
		t = rvCCConnectionGetTerminal(mdmConn);
		term = rvCCTerminalMdmGetImpl(t);
		mdmTerm = rvCCTerminalMdmGetMdmTerm(term);

		rvMdmParameterListConstruct(&paramsList);

		rvCCCallAddEventParam(&paramsList, "keyid", "kh");
		rvMdmTermProcessObsEvent(mdmTerm,"kf","ku", NULL, &paramsList);

		rvMdmParameterListDestruct(&paramsList);
		
		RvLogDebug(ippLogSource,
			(ippLogSource, "rvCCCallSendOnhookToMdmStateMachine: sent Onhook event for mdmConn %p", mdmConn));

	}
}






















