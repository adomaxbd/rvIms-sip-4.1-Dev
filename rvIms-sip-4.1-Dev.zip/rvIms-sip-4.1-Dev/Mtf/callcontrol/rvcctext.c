/******************************************************************************
Filename:    rvcctext.c
Description: Maps states and events id to text
*******************************************************************************
                Copyright (c) 2001 RADVISION
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make changes
without obligation to notify any person of such revisions or changes.
******************************************************************************/
#define LOGSRC  LOGSRC_CALLCONTROL
#include "ipp_inc_std.h"
#include "rvcctext.h"
#include "rvlog.h"


/********************************************************************************************
 *                                rvcctext.c
 *
 * This module is responsible for changing various IPP enumerations to strings.
 *
 *
 ********************************************************************************************/

//#if (RV_LOGMASK != RV_LOGLEVEL_NONE)

/******************************************************************************
*  rvCCTextCause
*  ----------------------------
*  General :      Returns a string representing the Event cause
*
*  Return Value:  constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          id                  RvCCEventCause
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextCause(IN RvCCEventCause id)
{
    switch(id)
    {
        case RV_CCCAUSE_INCOMING_CALL:          return "INCOMING_CALL";
        case RV_CCCAUSE_OUTGOING_CALL:          return "OUTGOING_CALL";
        case RV_CCCAUSE_CALL_WAITING:           return "CALL_WAITING";
        case RV_CCCAUSE_BUSY:                   return "BUSY";
        case RV_CCCAUSE_NOT_FOUND:              return "NOT_FOUND";
        case RV_CCCAUSE_REORDER_TONE:           return "REORDER_TONE";
        case RV_CCCAUSE_TRANSFER:               return "TRANSFER";
        case RV_CCCAUSE_UNHOLD:                 return "UNHOLD";
        case RV_CCCAUSE_CALL_CANCELLED:         return "CALL_CANCELLED";
         case RV_CCCAUSE_LOCAL_HOLD:            return "LOCAL_HOLD";
        case RV_CCCAUSE_REMOTE_HOLD:            return "REMOTE_HOLD";
        case RV_CCCAUSE_NEW_CALL:               return "NEW_CALL";
        case RV_CCCAUSE_NORMAL:                 return "NORMAL";
        case RV_CCCAUSE_RESOURCES_NOT_AVAILABLE:return "RESOURCES_NOT_AVAILABLE";
        case RV_CCCAUSE_MEDIA_NOT_SUPPORTED:    return "MEDIA_NOT_SUPPORTED";
        case RV_CCCAUSE_EVENT_BEGIN:            return "EVENT_BEGIN";
        case RV_CCCAUSE_EVENT_END:              return "EVENT_END";
        case RV_CCCAUSE_OPERATION_SUCCEEDED:    return "OPERATION_SUCCEEDED";
        case RV_CCCAUSE_OPERATION_FAILED:       return "OPERATION_FAILED";
        case RV_CCCAUSE_AUTH_FAIL:              return "AUTH_FAIL";
		case RV_CCCAUSE_BAD_REQUEST:            return "BAD_REQUEST";
		case RV_CCCAUSE_SECURITY_REQUIRED:		return "SECURITY_REQUIRED";
		
        case RV_CCCAUSE_UNKNOWN:
        default:                                return "UNKNOWN";
    }
}


/******************************************************************************
*  rvCCTextEvent
*  ----------------------------
*  General :       Returns a string representing the TerminalEvent
*
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          id                 Terminal Event
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextEvent(IN RvCCTerminalEvent id)
{
    switch(id)
    {
        case RV_CCTERMEVENT_NONE:               return "NONE";
        case RV_CCTERMEVENT_GW_ACTIVE:          return "GW_ACTIVE";
        case RV_CCTERMEVENT_OFFHOOK:            return "OFFHOOK";
        case RV_CCTERMEVENT_DIALTONE:           return "DIALTONE";
        case RV_CCTERMEVENT_DIGITS:             return "DIGITS";
        case RV_CCTERMEVENT_DIGIT_END:          return "DIGIT_END";
        case RV_CCTERMEVENT_DIALCOMPLETED:      return "DIALCOMPLETED";
        case RV_CCTERMEVENT_MAKECALL:           return "MAKECALL";
        case RV_CCTERMEVENT_RINGBACK:           return "RINGBACK";
        case RV_CCTERMEVENT_RINGING:            return "RINGING";
        case RV_CCTERMEVENT_CALLANSWERED:       return "CALLANSWERED";
        case RV_CCTERMEVENT_ONHOOK:             return "ONHOOK";
        case RV_CCTERMEVENT_HOLD:               return "HOLD";
        case RV_CCTERMEVENT_MUTE:               return "MUTE";
        case RV_CCTERMEVENT_HOLDKEY:            return "HOLDKEY";
        case RV_CCTERMEVENT_UNHOLD:             return "UNHOLD";
        case RV_CCTERMEVENT_CONFERENCE:         return "CONFERENCE";
        case RV_CCTERMEVENT_TRANSFER:           return "TRANSFER";
        case RV_CCTERMEVENT_BLIND_TRANSFER:     return "BLIND_TRANSFER";
        case RV_CCTERMEVENT_LINE:               return "LINE";
        case RV_CCTERMEVENT_LINEOTHER:          return "LINEOTHER";
        case RV_CCTERMEVENT_HEADSET:            return "HEADSET";
        case RV_CCTERMEVENT_HANDSFREE:          return "HANDSFREE";
        case RV_CCTERMEVENT_AUDIOHANDSET:       return "AUDIOHANDSET";
        case RV_CCTERMEVENT_AUDIOHANDSFREE:     return "AUDIOHANDSFREE";
        case RV_CCTERMEVENT_FAILGENERAL:        return "FAILGENERAL";
        case RV_CCTERMEVENT_MEDIAOK:            return "MEDIAOK";
        case RV_CCTERMEVENT_MEDIAFAIL:          return "MEDIAFAIL";
        case RV_CCTERMEVENT_DISCONNECTING:      return "DISCONNECTING";
        case RV_CCTERMEVENT_DISCONNECTED:       return "DISCONNECTED";
        case RV_CCTERMEVENT_INCOMINGCALL:       return "INCOMINGCALL";
        case RV_CCTERMEVENT_REJECTCALL:         return "REJECTCALL";
        case RV_CCTERMEVENT_TRANSFER_INIT:      return "TRANSFER_INIT";
        case RV_CCTERMEVENT_TRANSFER_OFFERED:   return "TRANSFER_OFFERED";
        case RV_CCTERMEVENT_REMOTE_DISCONNECTED:return "REMOTE_DISCONNECTED";
        case RV_CCTERMEVENT_ONHOOK_OTHER:       return "ONHOOK_OTHER";
        case RV_CCTERMEVENT_REJECT_KEY:         return "REJECT_KEY";
        case RV_CCTERMEVENT_MEDIANOTACCEPTED:   return "MEDIA_NOT_ACCEPTED";
        case RV_CCTERMEVENT_MODIFYMEDIA:        return "MODIFYMEDIA";
		case RV_CCTERMEVENT_MODIFYMEDIA_BY_UPDATE: return "MODIFYMEDIA_BY_UPDATE";
        case RV_CCTERMEVENT_MODIFYMEDIA_DONE:   return "MODIFYMEDIA_DONE";
        case RV_CCTERMEVENT_REDIAL:             return "REDIAL";
        case RV_CCTERMEVENT_CFW:                return "CFW";
        case RV_CCTERMEVENT_USER:               return "USER";

        case RV_CCTERMEVENT_UNKNOWN:
        default:                                return "UNKNOWN";
    }
}


/******************************************************************************
*  rvCCTextConnState
*  ----------------------------
*  General :       Returns a string representing the ConnState
*
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          id                 Connection State
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextConnState(IN RvCCConnState id)
{
    switch(id)
    {
        case RV_CCCONNSTATE_IDLE:               return "IDLE";
        case RV_CCCONNSTATE_INITIATED:          return "INITIATED";
        case RV_CCCONNSTATE_DIALING:            return "DIALING";
        case RV_CCCONNSTATE_ADDRESS_ANALYZE:    return "ADDRESS_ANALYZE";
        case RV_CCCONNSTATE_INPROCESS:          return "INPROCESS";
        case RV_CCCONNSTATE_CALL_DELIVERED:     return "CALL_DELIVERED";
        case RV_CCCONNSTATE_OFFERED:            return "OFFERED";
        case RV_CCCONNSTATE_ALERTING:           return "ALERTING";
        case RV_CCCONNSTATE_DISCONNECTED:       return "DISCONNECTED";
        case RV_CCCONNSTATE_CONNECTED:          return "CONNECTED";
        case RV_CCCONNSTATE_FAILED:             return "FAILED";
        case RV_CCCONNSTATE_TRANSFER_INIT:      return "TRANSFER_INIT";
        case RV_CCCONNSTATE_TRANSFER_INPROCESS: return "TRANSFER_INPROCESS";
        case RV_CCCONNSTATE_TRANSFER_DELIVERED: return "TRANSFER_DELIVERED";
        case RV_CCCONNSTATE_TRANSFER_OFFERED:   return "TRANSFER_OFFERED";
        case RV_CCCONNSTATE_TRANSFER_ALERTING:  return "TRANSFER_ALERTING";
        case RV_CCCONNSTATE_REJECTED:           return "REJECTED";
        case RV_CCCONNSTATE_ALERTING_REJECTED:  return "ALERTING_REJECTED";
        case RV_CCCONNSTATE_USER:               return "USER";
		case RV_CCCONNSTATE_TERMINATED:         return "TERMINATED";

        case RV_CCCONNSTATE_UNKNOWN:
        default:                                return "UNKNOWN";
    }
}

/******************************************************************************
*  rvCCTextTermConnState
*  ----------------------------
*  General :       Returns a string representing the TermConnState
*
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          id                 Terminal ConnectionState
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextTermConnState(IN RvCCTermConnState id)
{
    switch(id)
    {
        case RV_CCTERMCONSTATE_IDLE:                    return "IDLE";
        case RV_CCTERMCONSTATE_RINGING:                 return "RINGING";
        case RV_CCTERMCONSTATE_TALKING:                 return "TALKING";
        case RV_CCTERMCONSTATE_HELD:                    return "HELD";
        case RV_CCTERMCONSTATE_REMOTE_HELD:             return "REMOTE_HELD";
        case RV_CCTERMCONSTATE_BRIDGED:                 return "BRIDGED";
        case RV_CCTERMCONSTATE_DROPPED:                 return "DROPPED";
        case RV_CCTERMCONSTATE_MUTE:                    return "MUTE";
        case RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD:  return "REMOTE_HELD_LOCAL_HELD";

        default:                                        return "UNKNOWN STATE";
    }
}

/******************************************************************************
*  rvCCTextCallState
*  ----------------------------
*  General :       Returns a string representing the Call state
*
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          id                 Call State
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextCallState(IN RvCCCallState id)
{
    switch(id)
    {
        case RV_CCCALLSTATE_NORMAL:                 return "NORMAL";
        case RV_CCCALLSTATE_CONFERENCE_INIT:        return "CONFERENCE_INIT";
        case RV_CCCALLSTATE_CONFERENCE_COMPLETED:   return "CONFERENCE_COMPLETED";
        case RV_CCCALLSTATE_TRANSFER_INIT:          return "TRANSFER_INIT";
        default:                                    return "UNKNOWN STATE";
    }
}

/******************************************************************************
*  rvCCTextTermType
*  ----------------------------
*  General :       Returns a string representing the Terminal type
*
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          id                 Terminal Type
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextTermType(IN RvCCTerminalType id)
{
    switch (id)
    {
        case RV_CCTERMINALTYPE_UNKNOWN:     return "UNKNOWN";
        case RV_CCTERMINALTYPE_EPHEMERAL:   return "EPHEMERAL";
        case RV_CCTERMINALTYPE_ANALOG:      return "ANALOG";
        case RV_CCTERMINALTYPE_UI:          return "USER INTERFACE";
        case RV_CCTERMINALTYPE_AT:          return "AUDIO";
#ifdef RV_MTF_VIDEO
        case RV_CCTERMINALTYPE_VT:          return "VIDEO";
#endif
        default:                            return "UNKNOWN TERM TYPE";
    }
}

/******************************************************************************
*  rvCCTextConnectionType
*  ----------------------------
*  General :       Returns a string representing the Terminal type
*
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          id                 Terminal Type
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextConnectionType(IN RvCCConnType id)
{
    switch (id)
    {
        case RV_CCCONNTYPE_MDM:         return "MDM";
        case RV_CCCONNTYPE_NETWORK:     return "SIGNALING";
        default:                        return "UNKNOWN CONNECTION TYPE";
    }
}

/******************************************************************************
*  rvCCTextMediaState
*  ----------------------------
*  General :       Returns a string representing the MediaState
*
*  Return Value:   constant string
*
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          id                 Media State
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextMediaState(IN RvCCMediaState state)
{
    switch(state)
    {
    case RV_CCMEDIASTATE_NONE:          return "NONE";
    case RV_CCMEDIASTATE_CREATING:      return "CREATING";
    case RV_CCMEDIASTATE_CREATED:       return "CREATED";
    case RV_CCMEDIASTATE_CONNECTED:     return "CONNECTED";
    case RV_CCMEDIASTATE_DISCONNECTED:  return "DISCONNECTED";
    case RV_CCMEDIASTATE_NOTSUPPORTED:  return "NOTSUPPORTED";
    case RV_CCMEDIASTATE_MODIFYING:     return "MODIFYING";
	case RV_CCMEDIASTATE_MODIFYING_BEFORE_CONNECTED:
		                                return "MODIFYING BEFORE CONNECTED";
    case RV_CCMEDIASTATE_FAILED:        return "FAILED";
    default:                            return "UNKNOWN MEDIA STATE";
    }
}

/******************************************************************************
*  rvCCTextModifyMediaReason
*  ----------------------------
*  General :       Returns a string representing the Reason of Modify Media
*
*  Return Value:   constant string
*
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          id                 Modify Media Reason
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextModifyMediaReason(IN RvMdmTermReasonModifyMedia id)
{
    switch(id)
    {
        case RV_MDMTERMREASON_UNKNOWN:          return "UNKNOWN";
        case RV_MDMTERMREASON_SUCCESS:          return "SUCCESS";
        case RV_MDMTERMREASON_IN_PROCESS:       return "IN_PROGRESS";
        case RV_MDMTERMREASON_REMOTE_REJECTED:  return "REMOTE_REJECTED";
        case RV_MDMTERMREASON_LOCAL_FAILED:     return "LOCAL_FAILED";
        default:                                return "UNKNOWN MODIFY MEDIA REASON";
    }
}

/******************************************************************************
*  rvCCTextTerminalAudioType
*  ----------------------------
*  General :       Returns a string representing the terminal Audio Type
*  Return Value:   constant string
*
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          atType                 Audio Terminal Type
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextTerminalAudioType(IN RvCCTerminalAudioType atType)
{
    switch (atType)
    {
    case RV_CCTERMAUDIO_HANDSET:    return "Handset";
    case RV_CCTERMAUDIO_HEADSET:    return "Headset";
    case RV_CCTERMAUDIO_HANDSFREE:  return "Handsfree";
    case RV_CCTERMAUDIO_NONE:       return "None";
    default:                        return "Unknown";
    }
}

/******************************************************************************
*  rvCCTextConnTransferState
*  ----------------------------
*  General :       Returns a string representing the connection Transfer State
*  Return Value:   constant string
*
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          transState                 connection Transfer State
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextConnTransferState(IN RvCCConnTransferState transState)
{
    switch (transState)
    {
        case RV_CCCONNSTATE_TRANSFER_IDLE:          return "IDLE";
        case RV_CCCONNSTATE_TRANSFERROR_1ST_CALL:   return "TRANSFERROR_1ST_CALL";
        case RV_CCCONNSTATE_TRANSFERROR_2ND_CALL:   return "TRANSFERROR_2ND_CALL";
        case RV_CCCONNSTATE_TRANSFEREE:             return "TRANSFEREE";
        case RV_CCCONNSTATE_TRANSFERER:             return "TRANSFERER";
        default:                                    return "Unknown";
    }
}

/******************************************************************************
*  rvCCTextCfwType
*  ----------------------------
*  General :       Returns a string representing the Call Forward type
*  Return Value:   constant string
*
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          type                 Call Forward type
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextCfwType(IN RvIppCfwType type)
{
    switch (type)
    {
    case RV_IPP_CFW_TYPE_UNCONDITIONAL:     return "UNCONDITIONAL";
    case RV_IPP_CFW_TYPE_BUSY:              return "BUSY";
    case RV_IPP_CFW_TYPE_NO_REPLY:          return "NO_REPLY";
    case RV_IPP_CFW_TYPE_NONE:              return "NONE";
    default:                                return "Unknown";
    }

}

/******************************************************************************
*  rvCCTextCfwState
*  ----------------------------
*  General :       Returns a string representing the Call Forward state
*  Return Value:   constant string
*
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          state                 Call Forward state
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextCfwState(IN RvCCCfwState state)
{
    switch (state)
    {
    case RV_IPP_CFW_STATE_DEACTIVATED:          return "DEACTIVATED";
    case RV_IPP_CFW_STATE_ACTIVATE_START:       return "ACTIVATE_START";
    case RV_IPP_CFW_STATE_ACTIVATE_COMPLETED:   return "ACTIVATE_COMPLETED";
    case RV_IPP_CFW_STATE_NUM:                  return "STATE_NUM";
    default:                                    return "Unknown";
    }
}

/******************************************************************************
*  rvCCTextCfwReason
*  ----------------------------
*  General :       Returns a string representing the Call Forward reason
*  Return Value:   constant string
*
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          reason                 Call Forward reason
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextCfwReason(IN RvIppCfwReturnReasons reason)
{
    switch (reason)
    {
    case RV_IPP_CFW_SUCCESS:                return "SUCCESS";
    case RV_IPP_CFW_INVALID_DEACTIVATION:   return "INVALID_DEACTIVATION";
    case RV_IPP_CFW_INVALID_PARAM:          return "INVALID_PARAM";
    case RV_IPP_CFW_ADDRESS_NOT_FOUND:      return "ADDRESS_NOT_FOUND";
    case RV_IPP_CFW_NOT_ALLOWED:            return "NOT_ALLOWED";
    case RV_IPP_CFW_CANCELLED_BY_USER:      return "CANCELLED_BY_USER";
    default:                                return "Unknown";
    }
}

/******************************************************************************
*  rvMtfTextSignalType
*  ----------------------------
*  General :       Returns a string representing the signal type
*
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          signal                 signal type
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvMtfTextSignalType(IN RvMtfSignalType  signal)
{
    switch(signal)
    {
	case RV_MTF_SIGNAL_DIALTONE:					return "DIALTONE";
		case RV_MTF_SIGNAL_RINGBACK:				return "RINGBACK";
		case RV_MTF_SIGNAL_RINGING:					return "RINGING";
		case RV_MTF_SIGNAL_CALLWAITING_CALLER:		return "CALLWAITING_CALLER";
		case RV_MTF_SIGNAL_CALLWAITING_CALLEE:		return "CALLWAITING_CALLEE";
		case RV_MTF_SIGNAL_BUSY:					return "BUSY";
		case RV_MTF_SIGNAL_WARNING:					return "WARNING";
		case RV_MTF_SIGNAL_DIGIT:					return "DIGIT";
		case RV_MTF_SIGNAL_IND_LINE:				return "IND_LINE";
		case RV_MTF_SIGNAL_IND_HOLD:				return "IND_HOLD";
		case RV_MTF_SIGNAL_IND_MUTE:				return "IND_MUTE";
		case RV_MTF_SIGNAL_IND_HANDSFREE:			return "IND_HANDSFREE";
		case RV_MTF_SIGNAL_IND_HEADSET:				return "IND_HEADSET";
        default:									return "UNKNOWN";
    }
}

/******************************************************************************
*  rvMtfTextSignalState
*  ----------------------------
*  General :       Returns a string representing the signal state
*
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          state                 signal state
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvMtfTextSignalState(IN RvMtfSignalState  state)
{
    switch(state)
    {
		case RV_MTF_SIGNAL_STATE_ON:				return "ON";
		case RV_MTF_SIGNAL_STATE_OFF:				return "OFF";
		case RV_MTF_SIGNAL_STATE_BLINK:				return "BLINK";
		case RV_MTF_SIGNAL_STATE_FAST_BLINK:		return "FAST_BLINK";
        default:									return "UNKNOWN";
    }
}

//#endif /* (RV_LOGMASK != RV_LOGLEVEL_NONE) */
/******************************************************************************
*  rvCCTextStreamMode
*  ----------------------------
*  General :       Returns a string representing the stream mode
*  Return Value:   constant string
*
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          mode                 stream mode
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextStreamMode(IN RvMdmStreamMode mode)
{
#if (RV_LOGMASK != RV_LOGLEVEL_NONE)
    switch (mode)
    {
    case RV_MDMSTREAMMODE_NOTSET:          return "NOT_SET";
    case RV_MDMSTREAMMODE_INACTIVE:        return "INACTIVE";
    case RV_MDMSTREAMMODE_SENDONLY:        return "SEND_ONLY";
    case RV_MDMSTREAMMODE_RECVONLY:        return "RECV_ONLY";
    case RV_MDMSTREAMMODE_SENDRECV:        return "SEND_RECV";
    case RV_MDMSTREAMMODE_LOOPBACK:        return "LOOP_BACK";
    default:                                return "Unknown";
    }
#else
	return "Unknown";
#endif /* (RV_LOGMASK != RV_LOGLEVEL_NONE) */

}

/******************************************************************************
*  rvMtfTextTerminalState
*  ----------------------------
*  General :       Returns a string representing the terminal state
*
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          state                 terminal state
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvMtfTextTerminalState(IN RvMtfTerminationState  state)
{
	switch (state)
    {
		case RV_CCTERMINAL_IDLE_STATE:				return "IDLE";
		case RV_CCTERMINAL_CFW_ACTIVATING_STATE:    return "CFW_ACTIVATING";
		case RV_CCTERMINAL_ERROR_STATE:				return "ERROR";
		default:									return "Unknown";
    }
}

/******************************************************************************
*  rvMtfTextOfferAnswerState
*  ----------------------------
*  General :       Returns a string representing the offer/answer state
*
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          state                 offer/answer state
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvMtfTextOfferAnswerState(IN RvMtfOfferAnswerState  state)
{
	switch (state)
    {
		case RV_MTF_OFFERANSWER_OFFER_NONE:				return "NONE";
		case RV_MTF_OFFERANSWER_OFFER_BUILDING:			return "OFFER_BUILDING";
		case RV_MTF_OFFERANSWER_OFFER_SENT:				return "OFFER_SENT";
		case RV_MTF_OFFERANSWER_OFFER_RECEIVED:			return "OFFER_RECEIVED";
		case RV_MTF_OFFERANSWER_OFFER_ANSWERED:			return "OFFER_ANSWERED";
		case RV_MTF_OFFERANSWER_NUM_OF_STATES:			return "NUM_OF_STATES";

		default:									return "Unknown";
    }
}

/******************************************************************************
*  rvCCTextCallStateReason
*  -------------------------------
*  General :       Returns a string representing the call state changed reason
*
*  Return Value:   constant string
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          reason                 call state changed reason
*       .
*
*  Output          None.
*
*
*
******************************************************************************/
RVAPI const RvChar* rvCCTextCallStateReason(IN RvMtfCallStateReason  reason)
{
	switch (reason)
	{
		case RV_MTF_CALL_STATE_REASON_TIME_OUT:                    return "TIME_OUT";
		case RV_MTF_CALL_STATE_REASON_UNREACHABLE:                 return "UNREACHABLE";
		case RV_MTF_CALL_STATE_REASON_LOCAL_DISCONNECT:            return "LOCAL_DISCONNECT";
		case RV_MTF_CALL_STATE_REASON_REMOTE_DISCONNECTED:         return "REMOTE_DISCONNECTED";
		case RV_MTF_CALL_STATE_REASON_LOCAL_INVITING:              return "LOCAL_INVITING";
		case RV_MTF_CALL_STATE_REASON_REMOTE_INVITING:             return "REMOTE_INVITING"; 
		case RV_MTF_CALL_STATE_REASON_REFER_SENT:                  return "REFER_SENT";
		case RV_MTF_CALL_STATE_REASON_REFER_RECEIVED:              return "REFER_RECEIVED";
		case RV_MTF_CALL_STATE_REASON_REFER_NOTIFY_SENT:           return "REFER_NOTIFY_SENT";
		case RV_MTF_CALL_STATE_REASON_REFER_NOTIFY_RECEIVED:       return "REFER_NOTIFY_RECEIVED";
		case RV_MTF_CALL_STATE_REASON_CALL_ACCEPTED:               return "CALL_ACCEPTED";
		case RV_MTF_CALL_STATE_REASON_ACK_SENT:                    return "ACK_SENT";
		case RV_MTF_CALL_STATE_REASON_ACK_RECEIVED:                return "ACK_RECEIVED";
		case RV_MTF_CALL_STATE_REASON_REDIRECTED:                  return "REDIRECTED";
		case RV_MTF_CALL_STATE_REASON_LOCAL_REJECTED:              return "LOCAL_REJECTED";
		case RV_MTF_CALL_STATE_REASON_REQUEST_FAILURE:             return "REQUEST_FAILURE";
		case RV_MTF_CALL_STATE_REASON_SERVER_FAILURE:              return "SERVER_FAILURE";
		case RV_MTF_CALL_STATE_REASON_GLOBAL_FAILURE:              return "GLOBAL_FAILURE";
		case RV_MTF_CALL_STATE_REASON_OPERATION_FAILED:            return "OPERATION_FAILED";
		case RV_MTF_CALL_STATE_REASON_CALL_TERMINATED:             return "CALL_TERMINATED";
		case RV_MTF_CALL_STATE_REASON_AUTHENTICATION_FAILURE:      return "AUTHENTICATION_FAILURE";
		case RV_MTF_CALL_STATE_REASON_LOCAL_CANCELLING:           return "LOCAL_CANCELLING";
		case RV_MTF_CALL_STATE_REASON_REMOTE_CANCELED:             return "REMOTE_CANCELED";
		case RV_MTF_CALL_STATE_REASON_CALL_CONNECTED:              return "CALL_CONNECTED";
		case RV_MTF_CALL_STATE_REASON_PROVISIONAL_RESP_RECEIVED:   return "PROVISIONAL_RESP_RECEIVED";
		case RV_MTF_CALL_STATE_REASON_REFER_REPLACES_RECEIVED:     return "REFER_REPLACES_RECEIVED";
		case RV_MTF_CALL_STATE_REASON_INVITING_REPLACES_RECEIVED:  return "INVITING_REPLACES_RECEIVED";
		case RV_MTF_CALL_STATE_REASON_DISCONNECT_LOCAL_REJECT:     return "DISCONNECT_LOCAL_REJECT";
		case RV_MTF_CALL_STATE_REASON_DISCONNECT_REMOTE_REJECT:    return "DISCONNECT_REMOTE_REJECT";
		case RV_MTF_CALL_STATE_REASON_NETWORK_ERROR:               return "NETWORK_ERROR";
		case RV_MTF_CALL_STATE_REASON_SERVER_UNAVAILABLE:          return "SERVER_UNAVAILABLE";
		case RV_MTF_CALL_STATE_REASON_GIVE_UP_DNS:                 return "GIVE_UP_DNS";
		case RV_MTF_CALL_STATE_REASON_CONTINUE_DNS:                return "CONTINUE_DNS";
		case RV_MTF_CALL_STATE_REASON_REMOTE_BUSY:                 return "REMOTE_BUSY";
		case RV_MTF_CALL_STATE_REASON_CALL_DISCONNECTED:           return "CALL_DISCONNECTED";
		case RV_MTF_CALL_STATE_REASON_CALL_REMOTE_REJECTED:        return "REMOTE_REJECTED";
		case RV_MTF_CALL_STATE_REASON_CALL_SETUP:                  return "CALL_SETUP";
		case RV_MTF_CALL_STATE_REASON_CALL_CONFERENCE:             return "CALL_CONFERENCE";
		case RV_MTF_CALL_STATE_REASON_OFFERING_CREATE:             return "OFFERING_CREATE";
		case RV_MTF_CALL_STATE_REASON_OFFERING_INVITE:             return "OFFERING_INVITE";
		case RV_MTF_CALL_STATE_REASON_OFFERING_JOIN:               return "OFFERING_JOIN";
		case RV_MTF_CALL_STATE_REASON_CAPS_NEGOTIATION:            return "CAPS_NEGOTIATION";
		case RV_MTF_CALL_STATE_REASON_SUPPL_SERVICE:               return "SUPPL_SERVICE";
		case RV_MTF_CALL_STATE_REASON_INCOMPLETE_ADDRESS:          return "INCOMPLETE_ADDRESS";
		case RV_MTF_CALL_STATE_REASON_TRANSFER_FORWARDED:          return "TRANSFER_FORWARDED";
		case RV_MTF_CALL_STATE_REASON_TRANSFER_TO_MC:              return "TRANSFER_TO_MC";
		case RV_MTF_CALL_STATE_REASON_TRANSFER_TO_GK:              return "TRANSFER_TO_GK";
		case RV_MTF_CALL_STATE_REASON_REMOTE_NO_REPLY:             return "REMOTE_NO_REPLY";
		case RV_MTF_CALL_STATE_REASON_RELEASE_COMPLETE_RECEIVED:   return "RELEASE_COMPLETE_RECEIVED";
		case RV_MTF_CALL_STATE_REASON_OUT_OF_RESOURCES:            return "OUT_OF_RESOURCES";
		case RV_MTF_CALL_STATE_REASON_NORMAL:                      return "NORMAL";
		case RV_MTF_CALL_STATE_REASON_UNKNOWN: 
		default:                                                   return "Unknown";

	}
}


	    








































