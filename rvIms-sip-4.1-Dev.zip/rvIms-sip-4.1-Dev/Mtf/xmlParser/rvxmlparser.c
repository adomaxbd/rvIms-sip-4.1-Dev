/***********************************************************************
Filename   : rvxmlparser.c
Description: 
************************************************************************
        Copyright (c) 2005 RADVISION Inc. and RADVISION Ltd.
************************************************************************
NOTICE:
This document contains information that is confidential and proprietary
to RADVISION Inc. and RADVISION Ltd.. No part of this document may be
reproduced in any form whatsoever without written prior approval by
RADVISION Inc. or RADVISION Ltd..

RADVISION Inc. and RADVISION Ltd. reserve the right to revise this
publication and make changes without obligation to notify any person of
such revisions or changes.
***********************************************************************/

#include "rvstdio.h"
#include "rvxmlparser.h"
#include "_rvxmlparsertypes.h"
#include "rvmemory.h"      
#include "rvcbase.h"  


/* The following parse option is reserved for internal use */
#define RVXMLPARSER_OPTION_DTD			0x00002000 /* If RVXMLPARSER_OPTION_DOCTYPE set, then parse whatever is in data member ('[...]'). */
#define RVXMLPARSER_OPTION_DTD_ONLY		0x00004000 /* If RVXMLPARSER_OPTION_DOCTYPE|RVXMLPARSER_OPTION_DTD set, then parse only '&lt;!DOCTYPE [*]&gt;' */

typedef enum RvXmNodeTypeEnum
{
	RVXMLPARSER_NODE_TYPE_NULL,			 /*An undifferentiated entity. */
	RVXMLPARSER_NODE_TYPE_DOCUMENT,		 /*A document tree's absolute root. */
	RVXMLPARSER_NODE_TYPE_ELEMENT,		 /*E.g. '&lt;...&gt;'  */
	RVXMLPARSER_NODE_TYPE_PCDATA,		 /*E.g. '&gt;...&lt;'  */
	RVXMLPARSER_NODE_TYPE_CDATA,		 /*E.g. '&lt;![CDATA[...]]&gt;' */
	RVXMLPARSER_NODE_TYPE_COMMENT,		 /*E.g. '&lt;!--...--&gt;' */
	RVXMLPARSER_NODE_TYPE_PI,			 /*E.g. '&lt;?...?&gt;' */
	RVXMLPARSER_NODE_TYPE_INCLUDE,		 /*E.g. '&lt;![INCLUDE[...]]&gt;' */
	RVXMLPARSER_NODE_TYPE_DOCTYPE,		 /*E.g. '&lt;!DOCTYPE ...&gt;'.  */
	RVXMLPARSER_NODE_TYPE_DTD_ENTITY,	 /*E.g. '&lt;!ENTITY ...&gt;'.  */
	RVXMLPARSER_NODE_TYPE_DTD_ATTLIST,	 /*E.g. '&lt;!ATTLIST ...&gt;'.  */
	RVXMLPARSER_NODE_TYPE_DTD_ELEMENT,	 /*E.g. '&lt;!ELEMENT ...&gt;'.  */
	RVXMLPARSER_NODE_TYPE_DTD_NOTATION	 /*E.g. '&lt;!NOTATION ...&gt;'.  */
} RvXmlNodeType; 


struct RvXmlNodeStruct
{
	RvChar*		name;				/* Pointer to element name. */
	RvUint32	name_size;			/* Length of element name. */
	RvXmlNodeType	type;				/* Node type; see RvXmlNodeStruct. */
	RvChar*		value;				/* Pointer to any associated string data */
	RvUint32	value_size;			/* Length of element data. */
}; 



/*******************************   Parser utilities. ************************************************/
#define _T(x) x
#define NextState(X)    	(X)++ 

static RvBool RvXmlParserChartypeSymbol(RvChar c) /* Character is alphanumeric, -or- '_', -or- ':', -or- '-', -or- '.'. */
{ return (isalnum(c)||c=='_'||c==':'||c=='-'||c=='.'); }
static RvBool RvXmlParserChartypeSpace(RvChar c) /* Character is greater than 0 or character is less than exclamation. */
{ return (c>0 && c<'!'); }
static RvBool RvXmlParserChartypeEnter(RvChar c) /* Character is '&lt;'. */
{ return (c==_T('<')); }
static RvBool RvXmlParserChartypeLeave(RvChar c) /* Character is '&gt;'. */
{ return (c==_T('>')); }
static RvBool RvXmlParserChartypeClose(RvChar c) /* Character is '/'. */
{ return (c==_T('/')); }
static RvBool RvXmlParserChartypeEquals(RvChar c) /* Character is '='. */
{ return (c==_T('=')); }
static RvBool RvXmlParserChartypeSpecial(RvChar c) /* Character is '!'. */
{ return (c==_T('!')); }
static RvBool RvXmlParserChartypePi(RvChar c) /* Character is '?'. */
{ return (c==_T('?')); }
static RvBool RvXmlParserChartypeDash(RvChar c) /* Character is '-'. */
{ return (c==_T('-')); }
static RvBool RvXmlParserChartypeQuote(RvChar c) /* Character is &quot;&lsquo;&quot; -or- &lsquo;&quot;&lsquo;. */
{ return (c==_T('"')||c==_T('\'')); }
static RvBool RvXmlParserChartypeLbracket(RvChar c) /* Character is '['. */
{ return (c==_T('[')); }
static RvBool RvXmlParserChartypeRbracket(RvChar c) /* Character is ']'. */
{ return (c==_T(']')); }
/*******************************************************************************
 * RvXmlParserStrwtrim
 * Trim leading and trailing whitespace. 
 * INPUT: s - Pointer to pointer to string.
 *        len - Specifies the length of *s in bytes and returns its new length.
 * RETURNS: Success.
 * NOTE: *s is modified to point to the first non-white character in the string.
 */
static  RvBool RvXmlParserStrwtrim(RvChar** s, RvUint32* len)
{
	RvChar* pse = NULL;
	if(!s || !*s) return RV_FALSE;
	pse = *s + (*len);
	while(*s < pse && RvXmlParserChartypeSpace(**s)) /* Find first non-white character. */
		NextState(*s); /* As long as we hit whitespace, increment the string pointer. */
	for(; *s < --pse;) /* As long as we hit whitespace, decrement. */
	{
		if(!RvXmlParserChartypeSpace(*pse))
		{
			*len = pse + 1 - *s;
			break;
		}
	}
	return RV_TRUE;
}

#define SKIPWS()			{ while(RvXmlParserChartypeSpace(*s)) NextState(s); if(*s==0) return s; }
#define OPTSET(OPT)			( optmsk & OPT )
#define PUSHNODE(TYPE)		{ cursor = RvXmlParserAppendNodeToStack(hParser, TYPE, s); if(!cursor) return s; } 
#define POPNODE()			{ cursor = RvXmlParserPopNodeFromStack(hParser); rvFireEvent(hParser, cursor, eEndTag); }
#define APPENDATTR()		{ a = RvXmlParserAppendAttribute(hParser, cursor); if(!a) return s;}
#define SCANFOR(X)			{ while(*s!=0 && !(X)) NextState(s); if(*s==0) return s; }
#define SCANWHILE(X)		{ while((X)) NextState(s); if(*s==0) return s; }
#define ENDSEG()			{ ch = *s; NextState(s); if(*s==0) return s; }
#define SETLEN()			( cursor->value_size = s - cursor->value )
#define ENDSEGDAT()			{ ch = *s; SETLEN(); NextState(s); if(*s==0) return s; } 
#define ENDSEGNAM(S)		{ ch = *s; S->name_size = s - S->name; NextState(s); if(*s==0) return s; } 
#define ENDSEGATT(S)		{ ch = *s; S->value_size = s - S->value; NextState(s); if(*s==0) return s; }

/***************************************************************************************************
 * Handler setter implementation
 *
 */

/********************************************************************************************
 * RvXmlParserSetStartElementHandler
 * Sets handler for start elements.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *           handler - Pointer to an RvXmlParserStartElementHandler function implementation.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */
RVAPI void  RVCALLCONV RvXmlParserSetStartElementHandler(IN RvXmlParserHandle hParser, IN RvXmlParserStartElementHandler handler)
{
	if (hParser) {
		RVXMLPARSER(hParser)->StartElementFn = handler;
	}
}

/********************************************************************************************
 * RvXmlParserSetEndElementHandler
 * Sets handler for end elements.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *			 handler - Pointer to an RvXmlParserEndElementHandler function implementation.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */
RVAPI void  RVCALLCONV RvXmlParserSetEndElementHandler(IN RvXmlParserHandle hParser, IN RvXmlParserEndElementHandler handler)
{
	if (hParser) {
		RVXMLPARSER(hParser)->EndElementFn = handler;
	}
}

/********************************************************************************************
 * RvXmlParserSetElementHandler
 * Sets handlers for both start and end elements.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *           start - Pointer to an RvXmlParserStartElementHandler function implementation.
 *			 end - Pointer to an RvXmlParserEndElementHandler function implementation.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */
RVAPI void  RVCALLCONV RvXmlParserSetElementHandler(IN RvXmlParserHandle hParser, IN RvXmlParserStartElementHandler start, IN RvXmlParserEndElementHandler end)
{
	RvXmlParserSetStartElementHandler(hParser, start);
	RvXmlParserSetEndElementHandler(hParser, end);
}

/********************************************************************************************
 * RvXmlParserSetCharacterDataHandler
 * Sets the RvXmlParserCharacterDataHandler handler.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *			 handler - Pointer to an RvXmlParserCharacterDataHandler function implementation.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
 */
RVAPI void  RVCALLCONV RvXmlParserSetCharacterDataHandler(IN RvXmlParserHandle hParser, IN RvXmlParserCharacterDataHandler handler)
{
	if (hParser) {
		RVXMLPARSER(hParser)->CharacterDataFn = handler;
	}

}

/********************************************************************************************
 * RvXmlParserSetCommentHandler
 * Sets the RvXmlParserCommentHandler handler.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *			 handler - Pointer to an RvXmlParserCommentHandler function implementation.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
 */
RVAPI void  RVCALLCONV RvXmlParserSetCommentHandler(IN RvXmlParserHandle hParser, IN RvXmlParserCommentHandler handler)
{
	if (hParser) {
		RVXMLPARSER(hParser)->CommentFn = handler;
	}
}

/********************************************************************************************
 * RvXmlParserSetStartDoctypeDeclHandler
 * Sets handlers for both the start and end of the declaration.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *           handler - Pointer to an RvXmlParserStartDoctypeDeclHandler function implementation.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */
RVAPI void  RVCALLCONV RvXmlParserSetStartDoctypeDeclHandler(IN RvXmlParserHandle hParser, IN RvXmlParserStartDoctypeDeclHandler handler)
{
	if (hParser) {
		RVXMLPARSER(hParser)->StartDoctypeFn = handler;
	}
}

/********************************************************************************************
 * RvXmlParserSetEndDoctypeDeclHandler
 * Sets a handler for the end of the declaration.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *			 handler - Pointer to an RvXmlParserEndDoctypeDeclHandler function implementation.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */
RVAPI void  RVCALLCONV RvXmlParserSetEndDoctypeDeclHandler(IN RvXmlParserHandle hParser, IN RvXmlParserEndDoctypeDeclHandler handler)
{
	if (hParser) {
		RVXMLPARSER(hParser)->EndDoctypeFn = handler;
	}
}

/********************************************************************************************
 * RvXmlParserSetDoctypeDeclHandler
 * Sets handlers for both the start and end of the declaration.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *           start - Pointer to an RvXmlParserStartDoctypeDeclHandler function implementation.
 *			 end - Pointer to an RvXmlParserEndDoctypeDeclHandler function implementation.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */
RVAPI void  RVCALLCONV RvXmlParserSetDoctypeDeclHandler(IN RvXmlParserHandle hParser, 
											 IN RvXmlParserStartDoctypeDeclHandler start, IN RvXmlParserEndDoctypeDeclHandler end)
{
	RvXmlParserSetStartDoctypeDeclHandler(hParser,start);
	RvXmlParserSetEndDoctypeDeclHandler(hParser, end);
}

/********************************************************************************************
 * RvXmlParserSetXmlErrorHandler
 * Sets a handler that will be called for all errors.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *           handler - Pointer to an RvXmlParserXmlErrorHandler function implementation.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */
RVAPI void  RVCALLCONV RvXmlParserSetXmlErrorHandler(IN RvXmlParserHandle hParser, IN RvXmlParserXmlErrorHandler handler)
{
	if (hParser) {
		RVXMLPARSER(hParser)->ErrorHandlerFn = handler;
	}
}

/********************************************************************************************
 * Set function for RvXmlParserSetProcessingInstructionHandler handler
 */
/********************************************************************************************
 * RvXmlParserSetProcessingInstructionHandler
 * Sets the RvXmlParserProcessingInstructionHandler handler implementation.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *			 handler - Pointer to an RvXmlParserProcessingInstructionHandler function implementation.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
 */
RVAPI void  RVCALLCONV RvXmlParserSetProcessingInstructionHandler(IN RvXmlParserHandle hParser, 
													   IN RvXmlParserProcessingInstructionHandler handler)
{
	if (hParser) {
		RVXMLPARSER(hParser)->ProcessingInstructionFn = handler;
	}
}

/********************************************************************************************
 * RvXmlParserSetCallbackHandlers
 * Sets all callback handlers.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *           pCallBacks - Pointer to an RvXmlParserCallBacks structure.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */
RVAPI void  RVCALLCONV RvXmlParserSetCallbackHandlers(IN RvXmlParserHandle hParser, 
											 IN RvXmlParserCallBacks* pCallBacks)
{
	if (hParser && pCallBacks) {
		RvXmlParser* p = RVXMLPARSER(hParser);
		p->StartElementFn = pCallBacks->StartElementFn;
		p->EndElementFn = pCallBacks->EndElementFn;
		p->CharacterDataFn = pCallBacks->CharacterDataFn;
		p->CommentFn = pCallBacks->CommentFn;
		p->StartDoctypeFn = pCallBacks->StartDoctypeFn;
		p->EndDoctypeFn = pCallBacks->EndDoctypeFn;
		p->ErrorHandlerFn = pCallBacks->ErrorHandlerFn;
		p->ProcessingInstructionFn = pCallBacks->ProcessingInstructionFn;
		p->ElementDeclFn = pCallBacks->ElementDeclFn;
	}
}



#ifdef RVXML_WITH_VALIDATION

/********************************************************************************************
 * RvXmlParserSetValidationFlag
 * Sets validation flag.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *           doValidation - validation flag either RV_FALSE (no validation) or RV_TRUE (do validation).
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */
RVAPI void  RVCALLCONV RvXmlParserSetValidationFlag(IN RvXmlParserHandle hParser, 
									 IN RvBool doValidation)
{
	if (hParser) {
		RVXMLPARSER(hParser)->doValidation = doValidation;
	}
}

/********************************************************************************************
 * RvXmlParserGetValidationFlag
 * Gets current validation flag.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 * RETURNS  : - current validation flag.
 *			 - Synchronous.		
  */
RVAPI RvBool RVCALLCONV RvXmlParserGetValidationFlag(IN RvXmlParserHandle hParser)
{
	if (hParser) {
		return RVXMLPARSER(hParser)->doValidation;
	}
	return RV_FALSE;
}

#endif /*#ifdef RVXML_WITH_VALIDATION*/

/********************************************************************************************
 * RvXmlParserSetUserData
 * Sets user data pointer.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *           userData - Pointer to the user data object associated with the parser. 
 *			 This argument is opaque to the parser and the parser does not own this data.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */
RVAPI void  RVCALLCONV RvXmlParserSetUserData(	IN RvXmlParserHandle hParser,
									IN void* userData)
{
	if (hParser) {
		RVXMLPARSER(hParser)->userData = userData;
	}
}

/********************************************************************************************
 * RvXmlParserGetUserData
 * Gets a pointer to the current user data associated with the parser.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 * RETURNS  : - Pointer to the current user data object. This data is opaque to the parser and the caller
 *			    should know the relevant data semantics and be able to cast this pointer appropriately.
 *			 - Synchronous.	
  */
RVAPI void*  RVCALLCONV RvXmlParserGetUserData( IN RvXmlParserHandle hParser)
{
	if (hParser) {
		return RVXMLPARSER(hParser)->userData;
	}
	return NULL;
}


/********************************************************************************************
 * RvXmlParserDestruct
 * Destroys an XML Parser object and released the resources owned by the parser instance.
 * INPUT: hParser - A valid parser handle obtained by calling RvXmlParserConstruct.
 * NOTE: - The handle is no longer usable after calling this function. Its usage after calling
 *		   this function will produce unpredicted results.
 *		 - Calling this function doesn't modifiy or release user data associated with the parser using .
 *		 - Synchronous.	
 */
void RVCALLCONV RvXmlParserDestruct(IN RvXmlParserHandle hParser)
{
    if (hParser != NULL) 
    {
		RvLogInfo(RVXMLPARSER(hParser)->pLogSrc ,(RVXMLPARSER(hParser)->pLogSrc ,
                            "RvXmlParser[%x] - destructed", (void*)hParser));
		if(RVXMLPARSER(hParser)->attributeSpace) {
			RvMemoryFree((void*)RVXMLPARSER(hParser)->attributeSpace, NULL);
		}
		if(RVXMLPARSER(hParser)->nodeStack) {
			RvMemoryFree((void*)RVXMLPARSER(hParser)->nodeStack, NULL);
		}
		RvMemoryFree((void*)RVXMLPARSER(hParser),NULL);
    }
	RvCBaseEnd();
}

/********************************************************************************************
 * RvXmlParserConstruct
 * Constructs an XML Parser object and returns an RvXmlParserHandle. Must be called before any other parser API.
 * INPUT   : parserCfg - Pointer to an RvXmlParserCfg owned by the caller and prefilled with data. 
 * RETURNS : A Handle to the XML parser instance upon success and NULL upon failure. 
 * NOTE    : - The object returned by this function is valid XML parser handle used in other XML parser APIs.
 *			   If the application requires parsing of multiple XML documents it is required to 
 *			   to create a parser instance for each one by calling this function.
 *			 - The Caller owns the returning parser handle.
 *			 - The Caller should free the handle and resources owned by it by calling
 *			   RvXmlParserDestruct.
 *			 - Synchronous.		
 */
RvXmlParserHandle RVCALLCONV RvXmlParserConstruct(IN RvXmlParserCfg* parserCfg)
{
	RvUint32 maxAttributesNum = 0; 
	RvUint32 maxStackDepth = 0;
    RvXmlParser* hParser = NULL;
	if (parserCfg) 
	{
		maxAttributesNum = parserCfg->maxAttributesNum; 
		maxStackDepth = parserCfg->maxStackDepth;
	}
	if (RvCBaseInit() != RV_OK) 
	{
		return NULL;
	}
    
    if (RV_OK != RvMemoryAlloc(NULL,sizeof(RvXmlParser),NULL, (void**) &hParser))
    {
		RvLogError(parserCfg->pLogSrc,(parserCfg->pLogSrc,
                  "RvXmlParserConstruct - the RvXmlParser allocation failed"));
        return NULL;
    } 
	
	memset(hParser, 0, sizeof(RvXmlParser));
	hParser->maxStackDepth = maxStackDepth + 1;
	hParser->maxAttributesNum = maxAttributesNum;
	hParser->pLogSrc = parserCfg->pLogSrc;
	hParser->pLogMgr = parserCfg->pLogMgr;

	if (RV_OK != RvMemoryAlloc(NULL, sizeof(RvXmlNodeStruct) * hParser->maxStackDepth, NULL, (void**) &(hParser->nodeStack)))
	{
		/* Error: node stack allocation failed */ 
		RvLogError(parserCfg->pLogSrc,(parserCfg->pLogSrc,
                  "RvXmlParserConstruct - the RvXmlParser node stack allocation failed"));
		RvXmlParserDestruct((RvXmlParserHandle)hParser);
		return NULL;
    } else {
		memset(hParser->nodeStack, 0, sizeof(RvXmlNodeStruct) * hParser->maxStackDepth);
	}
	
	/* allocating Attribute space */
	if (RV_OK != RvMemoryAlloc(NULL, sizeof(RvXmlAttributeStruct) * hParser->maxAttributesNum, 
		NULL, (void**) &(hParser->attributeSpace)))
    {
		/* Error: attribute space allocation failed */
		RvLogError(parserCfg->pLogSrc,(parserCfg->pLogSrc,
                  "RvXmlParserConstruct - the RvXmlParser attribute space allocation failed"));
		RvXmlParserDestruct((RvXmlParserHandle)hParser);
        return NULL;
    } else {
		memset(hParser->attributeSpace, 0, sizeof(RvXmlAttributeStruct) * hParser->maxAttributesNum);
    }
	hParser->AttributesNum = 0;
	hParser->stackDepth = 0;
	RvLogInfo(parserCfg->pLogSrc ,(parserCfg->pLogSrc ,
                            "RvXmlParser[%x] - successfuly contructed", (void*)hParser));
    return (RvXmlParserHandle) hParser;
}

/********************************************************************************************
 * RvXmlParserReset
 * Resets an XML Parser object internal state.
 * INPUT: hParser - A valid parser handle obtained by calling RvXmlParserConstruct.
 * NOTE: - This function doesn't modifiy or release user application data associated with the parser instance,
 *		   by calling RvXmlParserSetUserData.
 *		 - Synchronous.	
 */
RVAPI  void RVCALLCONV RvXmlParserReset(RvXmlParserHandle hParser)
{
	if( !hParser ) return;
	if(RVXMLPARSER(hParser)->nodeStack) { 
		memset(RVXMLPARSER(hParser)->nodeStack, 0, 
					sizeof(RvXmlNodeStruct) * RVXMLPARSER(hParser)->maxStackDepth);
	}
	if (RVXMLPARSER(hParser)->attributeSpace ) {
		memset(RVXMLPARSER(hParser)->attributeSpace, 0, 
					sizeof(RvXmlAttributeStruct) * RVXMLPARSER(hParser)->maxAttributesNum);
	}
	RVXMLPARSER(hParser)->AttributesNum = 0;
	RVXMLPARSER(hParser)->stackDepth = 0;
}

/********************************************************************************************
 * RvXmlParserFullReset
 * Resets an XML Parser object internal state including callback functions.
 * INPUT: hParser - A valid parser handle.
 *		 - Synchronous.	
 */
void RVCALLCONV RvXmlParserFullReset(RvXmlParserHandle hParser)
{
	RvXmlParser* p = RVXMLPARSER(hParser);
	if( !p ) return;
	p->CharacterDataFn = NULL;
	/*Callback functions pointers.*/
	p->StartElementFn = NULL;
	p->EndElementFn = NULL;
	p->CharacterDataFn = NULL;	
	p->CommentFn = NULL;
	p->StartDoctypeFn = NULL;
	p->EndDoctypeFn = NULL;
	p->ErrorHandlerFn = NULL;
	p->ProcessingInstructionFn = NULL;
	p->ElementDeclFn = NULL;
	p->inUse = 0;
	p->userData = NULL;
#ifdef RVXML_WITH_VALIDATION
	p->validatorObj = NULL; 
	p->doValidation = RV_FALSE;
#endif
	RvXmlParserReset(hParser);
}

RvBool RVCALLCONV RvXmlIsParserInUse(RvXmlParserHandle hParser)
{
	return ( RVXMLPARSER(hParser)->inUse != 0); 
}

void RVCALLCONV RvXmlSetParserInUse(RvXmlParserHandle hParser) 
{
	RVXMLPARSER(hParser)->inUse = 1;
}

void RVCALLCONV RvXmlSetParserFree(RvXmlParserHandle hParser) 
{
	RVXMLPARSER(hParser)->inUse = 0;
}



typedef enum RvXmlTagTypeEnum 
{
	eBeginTag = 0,
	eEndTag = 1

} RvXmlTagType;

/*******************************************************************************************
 * rvFireEvent
 * Auxiliary private utility function. 
 */
static void rvFireEvent(RvXmlParser* hParser, RvXmlNodeStruct* cursor, RvXmlTagType tagtype)
{
	switch(cursor->type)
	{
	case    RVXMLPARSER_NODE_TYPE_ELEMENT:           /*E.g. '&lt;...&gt;'  */
		{
			switch(tagtype)
			{
			case eBeginTag: 
				{
					if (hParser->StartElementFn != NULL) 
					{
						hParser->StartElementFn(hParser->userData, cursor->name, cursor->name_size, 
							hParser->attributeSpace, hParser->AttributesNum);
						hParser->AttributesNum = 0;
					}
					break;
				}
			case eEndTag:
				{
					if (hParser->EndElementFn != NULL) 
					{
						hParser->EndElementFn(hParser->userData, cursor->name, cursor->name_size);
					}
					break;
				}
			} /* End of switch(tagtype) */
			break;
		} /* case    RVXMLPARSER_NODE_TYPE_ELEMENT:  */
	case    RVXMLPARSER_NODE_TYPE_PCDATA:            /*E.g. '&gt;...&lt;'  */
		{
			if (hParser->CharacterDataFn != NULL) 
			{
				hParser->CharacterDataFn(hParser->userData, cursor->value, cursor->value_size);
			}
			break;
		}
	case    RVXMLPARSER_NODE_TYPE_COMMENT:           /*E.g. '&lt;!--...--&gt;' */
		{
			if (hParser->CommentFn != NULL) 
					{
						hParser->CommentFn(hParser->userData, cursor->value, cursor->value_size);
					}
			break;
		}
	case    RVXMLPARSER_NODE_TYPE_DOCTYPE:           /*E.g. '&lt;!DOCTYPE ...&gt;'.  */	
		{
			switch(tagtype)
			{
			case eBeginTag: 
				{
					if (hParser->StartDoctypeFn != NULL) 
					{	
						if(hParser->AttributesNum) {
							hParser->StartDoctypeFn(hParser->userData, hParser->attributeSpace, hParser->AttributesNum);
							hParser->AttributesNum = 0;
						} else {
							hParser->StartDoctypeFn(hParser->userData, NULL, 0);
						}
					}
					break;
				}
			case eEndTag:
				{
					if (hParser->EndDoctypeFn != NULL) 
					{
						hParser->EndDoctypeFn(hParser->userData, cursor->value, cursor->value_size);
					}
					break;
				}
			} /* End of switch(tagtype) */
			break;	
		} /* case    RVXMLPARSER_NODE_TYPE_DOCTYPE: */
	case    RVXMLPARSER_NODE_TYPE_PI:                /*E.g. '&lt;?...?&gt;' */
		{
			switch(tagtype)
			{
			case eEndTag:
				{
					if (hParser->ProcessingInstructionFn!= NULL) 
					{
						hParser->ProcessingInstructionFn(hParser->userData, cursor->name, cursor->name_size, 
							hParser->attributeSpace, hParser->AttributesNum);
						hParser->AttributesNum = 0;
					}
					break;
				};
			default:
				break;
			} /* End of switch(tagtype) */
			break;
		}
#ifdef RVXML_WITH_VALIDATION
	case RVXMLPARSER_NODE_TYPE_DTD_ELEMENT:       /*E.g. '&lt;!ELEMENT ...&gt;'.  */
		{
			if (hParser->ElementDeclFn != NULL) 
			{
					hParser->ElementDeclFn(hParser->userData, cursor->name, cursor->name_size,
											cursor->value, cursor->value_size);
			}
		}
	case    RVXMLPARSER_NODE_TYPE_DTD_ENTITY:        /*E.g. '&lt;!ENTITY ...&gt;'.  */
	case    RVXMLPARSER_NODE_TYPE_DTD_ATTLIST:       /*E.g. '&lt;!ATTLIST ...&gt;'.  */
	case    RVXMLPARSER_NODE_TYPE_DTD_NOTATION:       /*E.g. '&lt;!NOTATION ...&gt;'.  */
#endif /* #ifdef RVXML_WITH_VALIDATION */

/* for future use */	
	case    RVXMLPARSER_NODE_TYPE_CDATA:             /*E.g. '&lt;![CDATA[...]]&gt;' */
	case    RVXMLPARSER_NODE_TYPE_DOCUMENT:          /*A document tree's absolute root. */	
	
	case    RVXMLPARSER_NODE_TYPE_INCLUDE:           /*E.g. '&lt;![INCLUDE[...]]&gt;' */
	case    RVXMLPARSER_NODE_TYPE_NULL:              /*An undifferentiated entity. */
	default:
		{
			break;
		}
	} /* End of switch(cursor->type) */
}


static RvXmlNodeStruct*  RvXmlParserPopNodeFromStack (RvXmlParser* hParser)
{
	RvXmlNodeStruct* node = 0;
	if(hParser && hParser->stackDepth ) {
		hParser->stackDepth--;
		node = &hParser->nodeStack[hParser->stackDepth];
	}
	return node;
}


static RvXmlNodeStruct* RvXmlParserAppendNodeToStack(RvXmlParser* hParser, RvXmlNodeType type, RvChar* s)
{
	RvXmlNodeStruct* p = NULL;

	if(hParser && hParser->nodeStack) 
	{
		if( hParser->stackDepth < (hParser->maxStackDepth - 1)) 
		{
			p = &hParser->nodeStack[hParser->stackDepth];
			hParser->stackDepth++;
			memset(p, 0, sizeof(RvXmlNodeStruct));
			memset(hParser->attributeSpace, 0, sizeof(RvXmlAttributeStruct) * hParser->maxAttributesNum);
			hParser->AttributesNum = 0;
			if(p) {
				p->type = type; /* Set the desired type. */
			}
		} else {
			/* node stack overflow */
			hParser->ErrorHandlerFn(hParser->userData, RVXMLPARSER_ERROR_NODE_STACK_OVERFLOW,s);
		}
	} 
	return p;
}


RvXmlAttributeStruct* RvXmlParserNewAttribute(RvXmlParser* hParser)
{
	RvXmlAttributeStruct* a = NULL;

	if( hParser == NULL ) return a;

	if ( (hParser->attributeSpace == NULL) || 
		(hParser->AttributesNum >= hParser->maxAttributesNum)) {
		return a;
	} else {
		a = hParser->attributeSpace + hParser->AttributesNum;
		hParser->AttributesNum++;
	}
	return a;
}

static RvXmlAttributeStruct* RvXmlParserAppendAttribute(RvXmlParser* hParser, RvXmlNodeStruct* node)
{
	RvXmlAttributeStruct* a = NULL;
	if ( (hParser == NULL) || ( node == NULL)) return a;
	a = RvXmlParserNewAttribute(hParser);
	if ( a == NULL) 
	{
		hParser->ErrorHandlerFn(hParser->userData, RVXMLPARSER_ERROR_ATTRIBUTE_SPACE_OVERFLOW, node->name);
	}
	return a;
}


/********************************************************************************************
 * Parse
 * Auxiliary private function parsing the given xml string.
 * INPUT: hParser - pointer to parser object.
 *        s - Pointer to XML-formatted null-terminated string.
 *        parent - pointer to RvXmlNodeStruct (used only in case of recursive parsing)
 *        optmsk - Parse options mask.
 * RETURNS: current position or NULL. 
  */
static RvChar* Parse(IN RvXmlParser* hParser, IN RvChar*  s, RvXmlNodeStruct* parent, IN RvUint32 optmsk)
{
	RvChar ch = 0; 
	RvXmlNodeStruct* cursor = NULL;
	RvChar* mark = NULL;
	RvXmlAttributeStruct* a = NULL;
	RvUint32 bd = 1; 
	RvXmlNodeType e;
	RvBool qq;

	if( hParser == NULL ) return s; 
    if(!s ) return s;
	
    cursor = parent; 
	mark = s; 
	
    while(*s!=0)
	{
LOC_SEARCH: 
		SCANFOR(RvXmlParserChartypeEnter(*s)); 
		if(RvXmlParserChartypeEnter(*s))
		{
			NextState(s);
LOC_CLASSIFY: 
			if(RvXmlParserChartypePi(*s)) 
			{
				NextState(s);
				if(RvXmlParserChartypeSymbol(*s) && OPTSET(RVXMLPARSER_OPTION_PI))
				{
					mark = s;
					SCANFOR(RvXmlParserChartypePi(*s)); 
					s = mark;
					PUSHNODE(RVXMLPARSER_NODE_TYPE_PI); 
					goto LOC_ELEMENT; 
				}
				else 
				{
					SCANFOR(RvXmlParserChartypeLeave(*s)); 
					NextState(s);
					mark = 0;
					continue;
				}
			}
			else if(RvXmlParserChartypeSpecial(*s)) 
			{
				NextState(s);
				if(RvXmlParserChartypeDash(*s)) 
				{
					NextState(s);
					if(OPTSET(RVXMLPARSER_OPTION_COMMENTS) && RvXmlParserChartypeDash(*s)) 
					{
						NextState(s);
						PUSHNODE(RVXMLPARSER_NODE_TYPE_COMMENT); 
						cursor->value = s; 
						while(*s!=0 && *(s+1) && *(s+2) && !((RvXmlParserChartypeDash(*s) && RvXmlParserChartypeDash(*(s+1))) && RvXmlParserChartypeLeave(*(s+2)))) NextState(s); 
						if(*s==0) return s;
						SETLEN(); 
						if(OPTSET(RVXMLPARSER_OPTION_TRIM_COMMENT)) 
						{
							RvXmlParserStrwtrim(&cursor->value,&(cursor->value_size));
						}
						s += 2; 
						POPNODE(); 
						goto LOC_LEAVE; 
					}
					else
					{
						while(*s!=0 && *(s+1)!=0 && *(s+2)!=0 && !((RvXmlParserChartypeDash(*s) && RvXmlParserChartypeDash(*(s+1))) && RvXmlParserChartypeLeave(*(s+2)))) NextState(s); 
						if(*s==0) return s;
						s += 2;
						goto LOC_LEAVE; 
					}
				}
				else if(RvXmlParserChartypeLbracket(*s)) 
				{
					NextState(s);
					if(*s==_T('I')) 
					{
						NextState(s);
						if(*s==_T('N')) 
						{
							NextState(s);
							if(*s==_T('C')) 
							{
								NextState(s);
								if(*s==_T('L')) 
								{
									NextState(s);
									if(*s==_T('U')) 
									{
										NextState(s);
										if(*s==_T('D')) 
										{
											NextState(s);
											if(*s==_T('E')) 
											{
												NextState(s);
												if(RvXmlParserChartypeLbracket(*s)) 
												{
													NextState(s);
													if(OPTSET(RVXMLPARSER_NODE_TYPE_CDATA))
													{
														PUSHNODE(RVXMLPARSER_NODE_TYPE_INCLUDE); 
														cursor->value = s; 
														while(!(RvXmlParserChartypeRbracket(*s) && RvXmlParserChartypeRbracket(*(s+1)) && RvXmlParserChartypeLeave(*(s+2)))) ++s; 
														if(RvXmlParserChartypeRbracket(*s))
														{
															SETLEN(); 
															NextState(s);
															if(OPTSET(RVXMLPARSER_OPTION_TRIM_CDATA)) 
															{
																RvXmlParserStrwtrim(&cursor->value, &(cursor->value_size));
															}
														}
														POPNODE(); 
													}
													else 
													{
														while(*s!=0 && *(s+1)!=0 && *(s+2)!=0 && !(RvXmlParserChartypeRbracket(*s) && RvXmlParserChartypeRbracket(*(s+1)) && RvXmlParserChartypeLeave(*(s+2)))) NextState(s); 
														NextState(s);
													}
													NextState(s); 
													goto LOC_LEAVE; 
												}
											}
										}
									}
								}
							}
						}
					}
					else if(*s==_T('C')) 
					{
						NextState(s);
						if(*s==_T('D')) 
						{
							NextState(s);
							if(*s==_T('A')) 
							{
								NextState(s);
								if(*s==_T('T')) 
								{
									NextState(s);
									if(*s==_T('A')) 
									{
										NextState(s);
										if(RvXmlParserChartypeLbracket(*s)) 
										{
											NextState(s);
											if(OPTSET(RVXMLPARSER_OPTION_CDATA))
											{
												PUSHNODE(RVXMLPARSER_NODE_TYPE_CDATA); 
												cursor->value = s; 
												while(*s!=0 && *(s+1)!=0 && *(s+2)!=0 && !(RvXmlParserChartypeRbracket(*s) && RvXmlParserChartypeRbracket(*(s+1)) && RvXmlParserChartypeLeave(*(s+2)))) NextState(s); 
												if(*(s+2)==0) return s; 
												if(RvXmlParserChartypeRbracket(*s))
												{
													SETLEN(); 
													NextState(s);
													if(OPTSET(RVXMLPARSER_OPTION_TRIM_CDATA)) 
													{
														RvXmlParserStrwtrim(&cursor->value,&(cursor->value_size));
													}
												}
												POPNODE(); 
											}
											else 
											{
												while(*s!=0 && *(s+1)!=0 && *(s+2)!=0 && !(RvXmlParserChartypeRbracket(*s) && RvXmlParserChartypeRbracket(*(s+1)) && RvXmlParserChartypeLeave(*(s+2)))) NextState(s); 
												NextState(s);
											}
											NextState(s); 
											goto LOC_LEAVE; 
										}
									}
								}
							}
						}
					}
					continue; 
				}
				else if(*s==_T('D')) 
				{
					NextState(s);
					if(*s==_T('O')) 
					{
						NextState(s);
						if(*s==_T('C')) 
						{
							NextState(s);
							if(*s==_T('T')) 
							{
								NextState(s);
								if(*s==_T('Y')) 
								{
									NextState(s);
									if(*s==_T('P')) 
									{
										NextState(s);
										if(*s==_T('E')) 
										{
											NextState(s);
											SKIPWS(); 
											a = 0;
											if(OPTSET(RVXMLPARSER_OPTION_DOCTYPE))
											{
												PUSHNODE(RVXMLPARSER_NODE_TYPE_DOCTYPE); 
												APPENDATTR();  
												a->value = a->name = s; 
											}
											SCANWHILE(RvXmlParserChartypeSymbol(*s)); 
											if(OPTSET(RVXMLPARSER_OPTION_DOCTYPE))
												a->name_size = a->value_size = s - a->value; 
											ENDSEG(); 
											if(RvXmlParserChartypeSpace(ch)) SKIPWS(); 
LOC_DOCTYPE_SYMBOL:
											if(RvXmlParserChartypeSymbol(*s))
											{
												mark = s;
												SCANWHILE(RvXmlParserChartypeSymbol(*s)); 
												if(OPTSET(RVXMLPARSER_OPTION_DOCTYPE))
												{
													APPENDATTR();  
													a->value = a->name = mark;
													a->value_size = a->name_size = s - mark; 
												}
												NextState(s);
												SKIPWS();
											}
											if(RvXmlParserChartypeQuote(*s)) 
											{
LOC_DOCTYPE_QUOTE:
												ch = *s;
												NextState(s);
												mark = s;
												while(*s!=0 && *s != ch) NextState(s);
												if(*s!=0)
												{
													if(OPTSET(RVXMLPARSER_OPTION_DOCTYPE))
													{
														APPENDATTR();  
														a->value = mark;
														a->value_size = s - mark; 
													}
													NextState(s);
													SKIPWS(); 
													if(RvXmlParserChartypeQuote(*s)) goto LOC_DOCTYPE_QUOTE; 
													else if(RvXmlParserChartypeSymbol(*s)) goto LOC_DOCTYPE_SYMBOL; 
												}
											}
											if(RvXmlParserChartypeLbracket(*s)) 
											{
												rvFireEvent(hParser,cursor,eBeginTag); /* fire start of doctype */
												NextState(s); 
												if(OPTSET(RVXMLPARSER_OPTION_DOCTYPE)) cursor->value = s; 
												bd = 1; 
												while(*s!=0) /* Loop till we're out of all brackets. */
												{
													if(RvXmlParserChartypeRbracket(*s)) --bd;
													else if(RvXmlParserChartypeLbracket(*s)) ++bd;
													if(bd == 0) break;
													NextState(s);
												}
												/* Note: 's' now points to end of DTD, i.e.: ']'. */
												if(OPTSET(RVXMLPARSER_OPTION_DOCTYPE))
												{
													
													SETLEN(); 
													if(OPTSET(RVXMLPARSER_OPTION_DTD)||OPTSET(RVXMLPARSER_OPTION_DTD_ONLY))
													{
														if(OPTSET(RVXMLPARSER_OPTION_DTD))
														{
															RvChar svch = *s;
															{
																RvChar* ret_val = NULL;
																*s = 0; 
																ret_val = Parse(hParser,cursor->value,cursor,optmsk); 
															}
															*s = svch;
														}
														if(OPTSET(RVXMLPARSER_OPTION_DTD_ONLY)) {
															POPNODE();
															return (s+1);
														}
													}
													else if(OPTSET(RVXMLPARSER_OPTION_TRIM_DOCTYPE)) 
													{
														RvXmlParserStrwtrim(&cursor->value, &(cursor->value_size));
													}
													NextState(s); 
													POPNODE(); 
												}
												SCANFOR(RvXmlParserChartypeLeave(*s));
												continue;
											}
											
											POPNODE(); 
											continue;
										}
									}
								}
							}
						}
					}
				}
				else if(RvXmlParserChartypeSymbol(*s)) 
				{
					mark = s;
					SCANWHILE(RvXmlParserChartypeSymbol(*s));
					ENDSEG(); 
					e = RVXMLPARSER_NODE_TYPE_DTD_ENTITY;
					{
						const RvUint32 dtdilen = (s - 1) - mark;
						if(strncmp(mark,_T("ATTLIST"),RvMax((7*sizeof(RvChar)),dtdilen))==0) e = RVXMLPARSER_NODE_TYPE_DTD_ATTLIST;
						else if(strncmp(mark,_T("ELEMENT"),RvMax((7*sizeof(RvChar)),dtdilen))==0) e = RVXMLPARSER_NODE_TYPE_DTD_ELEMENT;
						else if(strncmp(mark,_T("NOTATION"),RvMax((8*sizeof(RvChar)),dtdilen))==0) e = RVXMLPARSER_NODE_TYPE_DTD_NOTATION;
					}
					PUSHNODE(e); 
					if(*s!=0 && RvXmlParserChartypeSpace(ch))
					{
						SKIPWS(); 
						if(RvXmlParserChartypeSymbol(*s) || *s==_T('%'))
						{
							mark = s;
							if(*s==_T('%')) 
							{
								
								cursor->name = mark; 
								NextState(s);
								if(RvXmlParserChartypeSpace(*s))
								{
									SKIPWS(); 
								}
							}
							else
							{
								cursor->name = s;
							}
							SCANWHILE(RvXmlParserChartypeSymbol(*s));
							cursor->name_size = s - cursor->name;
							ENDSEG(); 
							if(RvXmlParserChartypeSpace(ch))
							{
								SKIPWS(); 
								if(e == RVXMLPARSER_NODE_TYPE_DTD_ENTITY) 
								{
									cursor->value = s; 
									qq = RV_FALSE;
									while(*s != 0) 
									{
										if(!qq && RvXmlParserChartypeQuote(*s)){ ch = *s; qq = RV_TRUE; }
										else if(qq && *s == ch) qq = RV_FALSE;
										else if(!qq && RvXmlParserChartypeLeave(*s)) 
										{
											SETLEN(); 
											NextState(s);
											if(OPTSET(RVXMLPARSER_OPTION_TRIM_ENTITY))
											{
												RvXmlParserStrwtrim(&cursor->value,&(cursor->value_size));
											}
											POPNODE();
											goto LOC_SEARCH;
										}
										NextState(s);
									}
									if(OPTSET(RVXMLPARSER_OPTION_TRIM_ENTITY))
									{
										RvXmlParserStrwtrim(&cursor->value, &(cursor->value_size));
									}
								}
								else
								{
									cursor->value = s;
									SCANFOR(RvXmlParserChartypeLeave(*s)); 
									SETLEN(); 
									NextState(s);
									if(OPTSET(RVXMLPARSER_OPTION_TRIM_ENTITY))
									{
										RvXmlParserStrwtrim(&cursor->value, &(cursor->value_size));
									}
									POPNODE();
									goto LOC_SEARCH;
								}
							}
						}
					}
					POPNODE();
				}
			}
			else if(RvXmlParserChartypeSymbol(*s)) 
			{
				cursor = RvXmlParserAppendNodeToStack(hParser, RVXMLPARSER_NODE_TYPE_ELEMENT, s); if(!cursor) return s;
LOC_ELEMENT: 
				cursor->name = s;
				SCANWHILE(RvXmlParserChartypeSymbol(*s)); 
				cursor->name_size = s - cursor->name; 
				ENDSEG(); 
				if
					(
					*s!=0 &&
					(
					RvXmlParserChartypeClose(ch) 
					
					
					)
					)
				{
					SCANFOR(RvXmlParserChartypeLeave(*s)); 
					POPNODE(); 
					continue;
				}
				else if(*s!=0 && !RvXmlParserChartypeSpace(ch))
				{
					rvFireEvent(hParser, cursor, eBeginTag);
					goto LOC_PCDATA; 
				}
				else if(*s!=0 && RvXmlParserChartypeSpace(ch))
				{
					SKIPWS(); 
LOC_ATTRIBUTE:
					if(RvXmlParserChartypeSymbol(*s)) 
					{
						RvXmlAttributeStruct* a = NULL; 
						APPENDATTR(); 
						a->name = s; 
						SCANWHILE(RvXmlParserChartypeSymbol(*s)); 
						ENDSEGNAM(a);
						if(*s!=0 && RvXmlParserChartypeSpace(ch)) SKIPWS(); 
						if(*s!=0 && (RvXmlParserChartypeEquals(ch) || RvXmlParserChartypeEquals(*s))) 
						{
							if(RvXmlParserChartypeEquals(*s)) NextState(s);
							SKIPWS(); 
							if(RvXmlParserChartypeQuote(*s)) 
							{
								ch = *s; 
								NextState(s); 
								a->value = s; 
								SCANFOR(*s == ch); 
								ENDSEGATT(a);
								
								if(OPTSET(RVXMLPARSER_OPTION_TRIM_ATTRIBUTE)) 
								{
									RvXmlParserStrwtrim(&a->value,&(a->value_size));
								}
								if(RvXmlParserChartypeLeave(*s))
								{ 
									rvFireEvent(hParser, cursor, eBeginTag);
									NextState(s); 
									goto LOC_PCDATA; 
								}
								else if(RvXmlParserChartypeClose(*s))
								{
									NextState(s);
									POPNODE();
									SKIPWS(); 
									if(RvXmlParserChartypeLeave(*s)) NextState(s);
									goto LOC_PCDATA;
								}
								if(RvXmlParserChartypeSpace(*s)) 
								{
									SKIPWS(); 
									goto LOC_ATTRIBUTE; 
								}
							}
						}
						if(RvXmlParserChartypeSymbol(*s)) goto LOC_ATTRIBUTE;
						else if(*s!=0 && cursor->type == RVXMLPARSER_NODE_TYPE_PI)
						{
							SCANFOR(RvXmlParserChartypePi(*s)); 
							SKIPWS(); 
							if(RvXmlParserChartypePi(*s)) NextState(s);
							SKIPWS(); 
							if(RvXmlParserChartypeLeave(*s)) NextState(s);
							POPNODE();
							goto LOC_PCDATA;
						}
					}
				}
LOC_LEAVE:
				if(RvXmlParserChartypeLeave(*s)) 
				{
					rvFireEvent(hParser, cursor, eBeginTag);
					NextState(s); 
LOC_PCDATA: 
					mark = s; 
					SKIPWS(); 
					if(RvXmlParserChartypeEnter(*s)) 
					{
						if(RvXmlParserChartypeClose(*(s+1))) 
						{
							SCANFOR(RvXmlParserChartypeLeave(*s)); 
							POPNODE(); 
							continue; 
						}
						else goto LOC_SEARCH; 
					}
					
					s = mark; 
					PUSHNODE(RVXMLPARSER_NODE_TYPE_PCDATA); 
					cursor->value = s; 
					SCANFOR(RvXmlParserChartypeEnter(*s)); 
					ENDSEGDAT();
					if(OPTSET(RVXMLPARSER_OPTION_TRIM_PCDATA)) 
					{
						RvXmlParserStrwtrim(&cursor->value,&(cursor->value_size));
					}
					POPNODE(); 
					
					if(RvXmlParserChartypeEnter(ch)) 
					{
						if(RvXmlParserChartypeClose(*s)) 
						{
							POPNODE();
							cursor->name = s+1;
							cursor->type = RVXMLPARSER_NODE_TYPE_ELEMENT;
							SCANFOR(RvXmlParserChartypeLeave(*s)); 
							ENDSEGDAT();
							 
							goto LOC_PCDATA;
						}
						else if(RvXmlParserChartypeSpecial(*s)) goto LOC_CLASSIFY; 
						else if(*s) goto LOC_CLASSIFY;
						else return s;
					}
				}
				
				else if(RvXmlParserChartypeClose(*s)) 
				{
					NextState(s);
					if(RvXmlParserChartypeLeave(*s)) 
					{
						POPNODE(); 
						NextState(s);
						continue;
					}
				}
			}
			
			else if(RvXmlParserChartypeClose(*s)) 
			{
							cursor->name = s+1;
							cursor->type = RVXMLPARSER_NODE_TYPE_ELEMENT;
				SCANFOR(RvXmlParserChartypeLeave(*s)); 
				ENDSEGDAT();
				POPNODE(); 
				continue;
			}
		}
	}
	return s;
}

/********************************************************************************************
 * RvXmlParse
 * Static single-pass in-place parsing of the given xml string.
 * INPUT: hParser - Pointer to a valid parser object instance created with RvXmlParserConstruc.
 *        xmlString - Pointer to XML-formatted null-terminated string.
 *        optmsk - Parse options mask.
 * RETURNS: RV_OK if the parsing is successfull, , or RV_XMLPARSER_ERROR_XML_NOT_VALID otherwise. 
 * NOTE    : - The Caller owns all arguments. 
 *			 - If errors are encountered during parsing the error handlers are called during the parsing procedure.
 *			 - Synchronous.		
  */
RVAPI RvStatus RVCALLCONV RvXmlParse(IN RvXmlParserHandle hParser, IN RvChar* s, IN RvUint32 optmsk)
{
	RvChar* rb = NULL;
	RvStatus rv = RV_XMLPARSER_ERROR_XML_NOT_VALID;
	
	if (hParser == NULL) return RV_ERROR_NULLPTR;

#ifdef RVXML_WITH_VALIDATION
	if ( RVXMLPARSER(hParser)->doValidation 
		&& RVXMLPARSER(hParser)->validatorObj 
		&& (RVXMLPARSER(hParser)->validatorObj->ValidateXmlFn(hParser, s) == RV_FALSE)) 
	{
		return rv;
	}
#endif

	RvLogInfo(RVXMLPARSER(hParser)->pLogSrc ,(RVXMLPARSER(hParser)->pLogSrc ,
                            "RvXmlParser - start parsing"));
	rb = Parse(RVXMLPARSER(hParser), (RvChar*) s, 0, optmsk);
	if (	( rb[0] == '\0' ) 
			||	(RVXMLPARSER(hParser)->stackDepth == 0) ) {
			rv = RV_OK;
	}
	RvLogInfo(RVXMLPARSER(hParser)->pLogSrc ,(RVXMLPARSER(hParser)->pLogSrc ,
                            "RvXmlParser - end parsing"));
	return rv;
}



/********************************************************************************************
 * RvXmlParserSetDtdElementDeclHandler
 * Sets an RvXmlParserDtdElementDeclHandler handler for dtd elements.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *			 handler - Pointer to an RvXmlParserDtdElementDeclHandler function implementation.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */

RVAPI void  RVCALLCONV RvXmlParserSetDtdElementDeclHandler(IN RvXmlParserHandle hParser, IN RvXmlParserDtdElementDeclHandler handler)
{
	if (hParser) 
	{
		RVXMLPARSER(hParser)->ElementDeclFn = handler;
	}
}

#ifdef RVXML_WITH_VALIDATION
/********************************************************************************************
 * GetXmlValidator
 * Retrieves the current validator handle associated with the parser.
 * INPUT   : hParser - A valid validator handle.
 * RETURNS  : - current validation object.
 *			 - Synchronous.	
  */
RVAPI RvXmlValidatorHandle RVCALLCONV GetXmlValidator(IN RvXmlParserHandle hParser)
{
	if (hParser) 
	{
		return (RvXmlValidatorHandle) (RVXMLPARSER(hParser)->validatorObj);
	}
	return NULL;
}


/********************************************************************************************
 * RvXmlParserSetXmlValidator
 * Associates and XML validator with the parser.
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *			 validatorObj - A handle to a an RvXmlValidator instance.
 * NOTE    : - The caller owns hParser.
 *			 - The parser does not own the validator.
 *			 - Synchronous.		
  */

RVAPI void  RVCALLCONV RvXmlParserSetXmlValidator(IN RvXmlParserHandle hParser, IN RvXmlValidatorHandle validatorObj)
{
	if (hParser) {
		RVXMLPARSER(hParser)->validatorObj = (RvXmlValidator*) validatorObj;
	}
}

/********************************************************************************************
 * RvXmlValidate  
 * A public function called by an application using RvXmlParser to validate a NULL terminated
 * XML formatted string according to the RvXmlValidator based validator plug-in implementation. 
 * INPUT   : hParser - A valid parser handle obtained by calling RvXmlParserConstruct. 
 *			 xml - Pointer to XML-formatted null-terminated string.
 * RETURNS : RvBool - Boolean - RV_TRUE if the document is valid, RV_FALSE if the document contains an
 *			 error.
 * NOTE    : - The caller owns all arguments.
 *			 - Synchronous.		
  */
RVAPI RvBool RVCALLCONV RvXmlValidate(IN RvXmlParserHandle hParser, IN IN RvChar* s)
{
	if(hParser && RVXMLPARSER(hParser)->validatorObj && RVXMLPARSER(hParser)->validatorObj->ValidateXmlFn)
	{
		return RVXMLPARSER(hParser)->validatorObj->ValidateXmlFn(hParser , s);
	}
	return RV_FALSE;
}

#endif /*RVXML_WITH_VALIDATION*/



