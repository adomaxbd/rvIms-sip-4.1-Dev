/***********************************************************************
Filename   : rvxmlparsermanager.c
Description: 
************************************************************************
        Copyright (c) 2005 RADVISION Inc. and RADVISION Ltd.
************************************************************************
NOTICE:
This document contains information that is confidential and proprietary
to RADVISION Inc. and RADVISION Ltd.. No part of this document may be
reproduced in any form whatsoever without written prior approval by
RADVISION Inc. or RADVISION Ltd..

RADVISION Inc. and RADVISION Ltd. reserve the right to revise this
publication and make changes without obligation to notify any person of
such revisions or changes.
***********************************************************************/

#include "rvxmlparsermanager.h"
#include "_rvxmlparsertypes.h"
#include "rvmemory.h"      
#include "rvcbase.h" 
#include "rvtypes.h" 

#include <string.h>

/*********************************************************************** 
 * RvXmlParserMgr is a manager, which is designed to allocate, free and 
 * managed a pool of RvXmlParser instances. 
 ***********************************************************************/
typedef struct RvXmlParserMgr RvXmlParserMgr;

struct RvXmlParserMgr
{
	/*Pointer to a valid log manager.*/
    RvLogMgr*           pLogMgr;
	/* register number from the log manager.*/
    RvLogSource*        pLogSrc;     
	/* Array representing the number of parser instances for each type.*/
	RvUint32			poolSize[RVXMLPARSER_MAX_PARSER_TYPES];
	/* Pointer array to the pool.*/
	RvXmlParserHandle*	pool[RVXMLPARSER_MAX_PARSER_TYPES];
};


#define RVXMLPARSERMGR( x ) ((RvXmlParserMgr*) x )


/***************************************************************************
 * RvXMLParserFreeParserPool
 * ------------------------------------------------------------------------
 * General: Frees a pool of parser objects of type eParserType.
 * Return Value: None.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:		eParserType - parser type
 *				pMgr  - pointer to the parser manager.
 ***************************************************************************/

void RVCALLCONV RvXMLParserFreeParserPool(	RvXmlParserType eParserType, 
								RvXmlParserMgr* pMgr)
{
	if(pMgr)
	{
		RvXmlParserHandle* pPool = pMgr->pool[eParserType];
		RvUint32 i = 0;
		if(pPool != NULL) {
			for (i = 0; i < pMgr->poolSize[eParserType]; i++ )
			{
				RvXmlParserHandle p = pPool[i];
				RvXmlParserDestruct(p);
			}
			RvMemoryFree((void*)pPool, NULL);
		}
	}
}


/***************************************************************************
 * RvXmlParserAllocParserPool
 * ------------------------------------------------------------------------
 * General: Allocates a pool of parser objects of type eParserType.
 * Return Value: RvStatus  - return status RV_OK upon success and various error codes upon error.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:		eParserType - parser type
 *				pMgr  - Pointer to the parser manager.
 *				pCfg  - Pointer to a parser manager configuration structure.
 ***************************************************************************/
RvStatus RVCALLCONV RvXmlParserAllocParserPool(RvXmlParserType eParserType, 
												RvXmlParserMgr		*pMgr,
												RvXmlParserMgrCfg   *pCfg )
{
	RvStatus rvs = RV_OK;
	RvUint32 numOfParsers = pMgr->poolSize[eParserType];
	RvUint32 i = 0;

	if(numOfParsers) { 
		RvUint32 poolSize = sizeof(RvXmlParserHandle) * numOfParsers;
		RvXmlParserHandle* pv; 
		if (RV_OK != RvMemoryAlloc(NULL, poolSize, pCfg->pLogMgr, (void**)&(pv)))
		{
			RvLogError(pMgr->pLogSrc,(pMgr->pLogSrc,
                  "RvXmlParserAllocParserPool - the RvXmlParser pool allocation failed"));
			return RV_ERROR_OUTOFRESOURCES;
		}
		pMgr->pool[eParserType] = pv;
		memset((void*)pv, 0, poolSize);
		
		/*Allocate the actual parsers.*/
		for(i = 0; i < numOfParsers; i++)
		{
			RvXmlParserCfg* parserCfg = &(pCfg->parserCfg[eParserType]);
			parserCfg->pLogSrc = pMgr->pLogSrc;
			parserCfg->pLogMgr = pMgr->pLogMgr;
			*(pMgr->pool[eParserType] + i) = RvXmlParserConstruct(parserCfg);
			if( *(pMgr->pool[eParserType] + i) == NULL ) {
				/*Verify that resources were available for the allocation.
				  If not then leave with the appropriate error code.*/
				rvs = RV_ERROR_OUTOFRESOURCES;
				break;
			}
		}
	}
	return rvs;
}



/***************************************************************************
 * RvXmlParserFindFirstAvailableParser
 * ------------------------------------------------------------------------
 * General: Finds first available parser object.
 * Return Value: RvXmlParserHandle or NULL if not found
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:		pMgr  - pointer to the parser manager.
 *				eParserType - parser type
 ***************************************************************************/

RvXmlParserHandle RVCALLCONV RvXmlParserFindFirstAvailableParser(IN RvXmlParserMgr* pMgr,
																 RvXmlParserType eParserType)
{	RvXmlParserHandle p = NULL;
	RvUint32 poolSize = pMgr->poolSize[eParserType]; 
	if (poolSize) 
	{
		RvUint32 i = 0;
		for (i = 0; i < poolSize; i++) {
			p = pMgr->pool[eParserType][i]; 
			if (!RvXmlIsParserInUse(p)) 
				{
					RvXmlSetParserInUse(p);
					return p;
				}
		}
		p = NULL;
	}
	return p;
}

/***************************************************************************
 * RvXmlParserNumberAvailable
 * ------------------------------------------------------------------------
 * General: Gets the number of available parser instances of type eParserType
 *			in the current parser pool.
 * Return Value: RvUint32 - Number of available parser instances of type eParserType
 *			in the current parser pool.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hParserMgr - Handle to the parser manager retrieved from a successful call to 
 *			  RvXmlParserMgrConstruct.
 *			  eParserType - parser type
 ***************************************************************************/
RVAPI RvUint32 RVCALLCONV RvXmlParserNumberAvailable(IN RvXmlParserMgrHandle hParserMgr,
													 IN	RvXmlParserType eParserType)
{	
	RvXmlParserMgr* pMgr = RVXMLPARSERMGR(hParserMgr);
	RvXmlParserHandle p = NULL;
	RvUint32 numAvailable = 0;
	RvUint32 poolSize = 0;
	if(pMgr != NULL) {
		poolSize = pMgr->poolSize[eParserType]; 
	}
	if (poolSize) 
	{
		RvUint32 i = 0;
		for (i = 0; i < poolSize; i++) 
		{
			p = pMgr->pool[eParserType][i]; 
			if (!RvXmlIsParserInUse(p)) 
			{
				numAvailable++;
			}
		}
	}
	return numAvailable;
}


/***************************************************************************
 * RvXmlParserMgrDestruct
 * ------------------------------------------------------------------------
 * General: Destroys the parser manager instance and frees all resources owned by it.
 * Return Value: None.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hParserMgr - Handle to the parser manager retrieved from a successful call to 
 *			  RvXmlParserMgrConstruct.
 ***************************************************************************/
RVAPI void RVCALLCONV RvXmlParserMgrDestruct(IN RvXmlParserMgrHandle hParserMgr)
{
    if (hParserMgr != NULL) 
    {
		RvXmlParserMgr* pMgr = RVXMLPARSERMGR(hParserMgr);
		RvLogInfo(pMgr->pLogSrc ,(pMgr->pLogSrc ,
                            "RvXmlParserMgr - destruction"));
		RvXMLParserFreeParserPool(RVXMLPARSER_TYPE_LOW_MEM,pMgr);
		RvXMLParserFreeParserPool(RVXMLPARSER_TYPE_MEDIUM_MEM,pMgr);
		RvXMLParserFreeParserPool(RVXMLPARSER_TYPE_HIGH_MEM,pMgr);
        /* Not your log source to destruct!
		RvLogSourceDestruct(pMgr->pLogSrc);*/
		RvMemoryFree((void*)pMgr,NULL);
    }
	RvCBaseEnd();
}


/***************************************************************************
 * RvXmlParserMgrConstruct
 * ------------------------------------------------------------------------
 * General: Construct a parser manager instance and allocate all related 
 *			resources.
 * Return Value: RvStatus  - return status RV_OK upon success and various error codes upon error.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:		sizeOfCfg - Disregarded.
 *				pCfg  - Pointer to a valid RvXmlParserMgrCfg instance with relevant configuration parameters.
 *				phParserMgr - Pointer to an uninitialized parser manager handle. Which will be
 *				initialized after a successful call to this function.
 * Output:		phParserMgr  - Pointer to an initialized parser manager handle.
 * Disposition: Synchronous.
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV RvXmlParserMgrConstruct(	IN RvInt32 sizeOfCfg,
												    IN RvXmlParserMgrCfg* pCfg,
						                            OUT RvXmlParserMgrHandle* phParserMgr)
{
	RvXmlParserMgr* pMgr = NULL;
	RvStatus crv = RV_OK;

	RV_UNUSED_ARG(sizeOfCfg);

	if (pCfg == NULL)
    {
		RvLogError(pCfg->pLogSrc,(pCfg->pLogSrc,
                  "RvXmlParserMgrConstruct - the RvXmlParserMgrHandle is NULL"));
        return RV_ERROR_UNKNOWN;
    }

	/*initialize the common core modules*/
    crv = RvCBaseInit();
    if (crv != RV_OK)
    {
		RvLogError(pCfg->pLogSrc,(pCfg->pLogSrc,
                  "RvXmlParserMgrConstruct - the RvCBaseInit() failed"));
        return RV_ERROR_UNKNOWN;
    }

	/* allocating the struct that holds the parser manager information */
    if (RV_OK != RvMemoryAlloc(NULL,sizeof(RvXmlParserMgr),pCfg->pLogMgr,(void**)&pMgr))
    {
		RvLogError(pCfg->pLogSrc,(pCfg->pLogSrc,
                  "RvXmlParserMgrConstruct - the RvXmlParserMgr memory allocation failed"));
        RvCBaseEnd();
        return RV_ERROR_UNKNOWN;
    }
	memset(pMgr, 0, sizeof(RvXmlParserMgr));

	pMgr->poolSize[RVXMLPARSER_TYPE_LOW_MEM] = pCfg->numOfLowMemParsers;
	pMgr->poolSize[RVXMLPARSER_TYPE_MEDIUM_MEM] = pCfg->numOfMediumMemParsers;
	pMgr->poolSize[RVXMLPARSER_TYPE_HIGH_MEM] = pCfg->numOfHighMemParsers;
	
	pMgr->pLogMgr = pCfg->pLogMgr;
	pMgr->pLogSrc = pCfg->pLogSrc;

	/* allocating the LOW_MEM Parsers pool */
	crv = RvXmlParserAllocParserPool(RVXMLPARSER_TYPE_LOW_MEM, pMgr, pCfg);
	if(crv != RV_OK ) 
	{
			RvXmlParserMgrDestruct((RvXmlParserMgrHandle)pMgr);
			RvCBaseEnd();
			return crv;
	}

	/* allocating the MEDIUM_MEM Parsers pool */
	crv = RvXmlParserAllocParserPool(RVXMLPARSER_TYPE_MEDIUM_MEM, pMgr, pCfg);
	if(crv != RV_OK ) 
	{
			RvXmlParserMgrDestruct((RvXmlParserMgrHandle)pMgr);
			RvCBaseEnd();
			return RV_ERROR_UNKNOWN;
	}
	/* allocating the HIGH_MEM Parsers pool */
	crv = RvXmlParserAllocParserPool(RVXMLPARSER_TYPE_HIGH_MEM, pMgr, pCfg);
	if(crv != RV_OK ) 
	{
			RvXmlParserMgrDestruct((RvXmlParserMgrHandle)pMgr);
			RvCBaseEnd();
			return RV_ERROR_UNKNOWN;
	}
	

    *phParserMgr = (RvXmlParserMgrHandle)pMgr;

	RvLogInfo(pMgr->pLogSrc ,(pMgr->pLogSrc ,
                            "RvXmlParserMgr - successfully initiated"))

    return RV_OK;
}


/***************************************************************************
 * RvXmlParserGetParserHandle
 * ------------------------------------------------------------------------
 * General: Gets a handle to a specific parser instance. 
 * Return Value: RvStatus  - return status RV_OK upon success and various error codes upon error.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:	  hParserMgr - Handle to the parser manager retrieved from a successful call to 
 *			  RvXmlParserMgrConstruct.
 *			  eParserType - parser type.
 *			  phParser - Pointer to an uninitialized parser handle. Which will be
 *			  initialized after a successful call to this function.	  
 * Output:	  phParser  - initialized parser instance handle.
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV RvXmlParserGetParserHandle( IN RvXmlParserMgrHandle hParserMgr,
													  IN RvXmlParserType eParserType,
													  OUT RvXmlParserHandle* hParser)
{

	RvXmlParserMgr* pMgr = RVXMLPARSERMGR(hParserMgr);
	*hParser = RvXmlParserFindFirstAvailableParser(pMgr, eParserType);
	if(*hParser == NULL) 
	{
		RvLogError(pMgr->pLogSrc,(pMgr->pLogSrc,
                  "RvXmlParserMgrConstruct - available RvXmlParser object not found"));
		return RV_ERROR_NOT_FOUND;
	} 
	return RV_OK;
}


/***************************************************************************
 * RvXmlParserReleaseParserHandle
 * ------------------------------------------------------------------------
 * General: Releases a give parser instance within the pool and renders it available again
 *			for future use within the life-time scope of the manager instance.
 * Return Value: RvStatus  - return status RV_OK upon success and various error codes upon error.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:	  hParserMgr - Handle to the parser manager retrieved from a successful call to 
 *			  RvXmlParserMgrConstruct.
 *			  hParser - Handle to a parser instance retrieved by a successful call to RvXmlParserGetParserHandle.
 ***************************************************************************/
RVAPI RvStatus RVCALLCONV RvXmlParserReleaseParserHandle( IN RvXmlParserMgrHandle hParserMgr,
														  IN RvXmlParserHandle hParser)
{
	RV_UNUSED_ARG(hParserMgr);
	RvXmlSetParserFree(hParser); 
	RvXmlParserFullReset(hParser);
	return RV_OK;
}



