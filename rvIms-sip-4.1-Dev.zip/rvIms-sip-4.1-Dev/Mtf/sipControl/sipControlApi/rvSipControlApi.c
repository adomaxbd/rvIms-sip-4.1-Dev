/******************************************************************************
Filename   : rvSipControlApi.c
Description: Sip Control Extension APIs
******************************************************************************
                Copyright (c) 2004 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_SIPCONTROL
#include "ipp_inc_std.h"
#include "rvSipControlApi.h"
#include "sipControlInt.h"
#include "sipphone.h"
#include "rvMdmControlApi.h"
#include "rvccterminalmdm.h"
#include "rvccconnsip.h"
#include "mtfBaseInt.h"
#include "ippthread.h"

RvAlloc* prvDefaultAlloc = NULL;
extern RvIppSipExtClbks     sipExtClbksDeprecated;
static RvSize_t				initialAlloc;

/******************************************************************************
*  checkForMemoryLeaks()
*  --------------------------------
*  General :        Prints a list of memory allocations that have not been released
*                   by the moment of printing. Also indicates whether memory leaks
*					were found.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          None.
*
*  Output:         none.
******************************************************************************/
static void checkForMemoryLeaks(void)
{

    RvMemoryInfo memInfo;
    RvUint32     actualLeak = 0;
	RvUint32     sizeofRvLogMgr = sizeof(RvLogMgr);
	RvUint32	 sizeofRvSemaphore;
	
	sizeofRvSemaphore = sizeof(RvSemaphore);

    RvMemoryGetInfo(NULL, NULL, &memInfo);
    actualLeak = (RvUint32)(memInfo.bytes_requested_byuser - initialAlloc);
    if (actualLeak > 0)
    {
		if (actualLeak == sizeofRvLogMgr)
		{
			RvLogInfo(ippLogSource,(ippLogSource, ":-) No Memeory Leaks were found (*) "));
			RvLogInfo(ippLogSource,(ippLogSource, "(*) %d Bytes are still captured by the Logger", actualLeak));
		}

#if (RV_OS_TYPE != RV_OS_TYPE_WINCE) && (RV_OS_TYPE != RV_OS_TYPE_WIN32)

		/* Actually correct "if" condition, should be as follows:
		#if RV_SELECT_SYNC_REMOVAL && RV_SELECT_TYPE != RV_SELECT_EPOLL && RV_SELECT_TYPE != RV_SELECT_KQUEUE
		But since these defines of common core are not visible here we just asking about OS .

		In this case, the syncSem semaphore for  "MTF_LOG" thread will be deallocated later on, upon thread exit.
		As currently we write MemoryLeak information into the MTF_LOG, the thread is still running.
		Don't declare it as MemoryLeak. It it released through calling RvThreadDestruct() from IppLogEnd().
		*/
		else if (actualLeak == sizeofRvLogMgr + sizeofRvSemaphore)
		{
			RvLogInfo(ippLogSource,(ippLogSource, ":-) No Memeory Leaks were found (*) "));
			RvLogInfo(ippLogSource,(ippLogSource, "(*) %d Bytes are still captured by the Logger", sizeofRvLogMgr));
			RvLogInfo(ippLogSource,(ippLogSource, "(*) %d Bytes are still captured by the syncSem of MTF_LOG thread", sizeofRvSemaphore));
		}
		else
		{
			RvLogWarning(ippLogSource,(ippLogSource, ":-( MEMORY LEAK ALERT !!! %d bytes (*)", actualLeak - sizeofRvLogMgr - sizeofRvSemaphore));
			RvLogWarning(ippLogSource,(ippLogSource, "(*) not including %d bytes captured by the Logger",sizeofRvLogMgr));
			RvLogWarning(ippLogSource,(ippLogSource, "(*) not including %d bytes captured by the syncSem of MTF_LOG thread",sizeofRvSemaphore));
		}
#else
		else
		{
			RvLogWarning(ippLogSource,(ippLogSource, ":-( MEMORY LEAK ALERT !!! %d bytes (*)", actualLeak - sizeofRvLogMgr));
			RvLogWarning(ippLogSource,(ippLogSource, "(*) not including %d bytes captured by the Logger",sizeofRvLogMgr));
		}
#endif

        /* This function will print all deallocated memory to log file (MtfLog.txt). To see the prints
           compile in Debug mode and turn on log level DEBUG in Memory module of Common Core (IppLogOptions)
           Note: log will always show unreleased memory in ipplog.c, since obviously LogMgr cannot
           be released at this point...

           In order to trace the allocating sequence of an un-released memory:
           1. perform the leaking scenario
           2. get the printDbg output
           3. add the following lines in the end of proc RvMemoryAllocDbg()
             {
                if (*resultptr == (void*)0x00E20C80) <------   The unreleased address from the log, add "0x"
                {
                    int a = 1;       <-------   place a breakpoint here
                }
            }
          4. perform the scenario again
          5. the proc will break once an allocation is made for the requested address
        */
        RvMemoryPrintDbg(NULL, IppLogMgr());
    }
    else
    {
        RvLogInfo(ippLogSource,(ippLogSource, "No Memory Leaks were found :-) "));
    }
/*    RvAssert(initialAlloc == memInfo.bytes_requested_total);*/
}

/**********************************************************************************
                    S I P   A D A P T O R   A P I
**********************************************************************************/

/*****************************************************************************
 * rvIppSipInitConfig() 
 *****************************************************************************/
RVAPI RvBool RVCALLCONV rvIppSipInitConfig(
    OUT RvMtfSipPhoneCfg*    cfg)
{
	RvBool rc;
    RvLogEnter(ippLogSource,(ippLogSource, "rvIppSipInitConfig(cfg=%p)", cfg));

    if (cfg != NULL)
    {
        /* Cleanup before we start putting any default values */
        memset(cfg, 0, sizeof(*cfg));

        cfg->autoRegister           = RV_TRUE;
        cfg->debugLevel             = 2;/*RV_LOGLEVEL_ERROR|RV_LOGLEVEL_WARNING|RV_LOGLEVEL_INFO3*/
        cfg->dialToneDuration       = 30000;
        cfg->localAddress           = NULL;
		cfg->numberOfLines			= 2;
        cfg->maxCallLegs            = 5;
        cfg->maxRegClients          = 5;
        cfg->outboundProxyAddress   = NULL;
        cfg->outboundProxyPort      = RVSIPCTRL_DEFAULT_PORT;
#ifdef RV_SIP_IMS_ON
		strcpy(cfg->imsSipPhoneCfg.PAccessNetworkInfo,"");
        cfg->imsSipPhoneCfg.ipsecPortC   = RVSIPCTRL_DEFAULT_PORT + 3;
        cfg->imsSipPhoneCfg.ipsecPortS   = RVSIPCTRL_DEFAULT_PORT + 5;
		cfg->disableAkaAuthentication = RV_TRUE;
		cfg->imsSipPhoneCfg.disableSecAgree = RV_TRUE;
        cfg->imsSipPhoneCfg.ipsecSpiRangeStart   = 256;
        cfg->imsSipPhoneCfg.ipsecSpiRangeEnd   = 65535;
#endif
        cfg->password               = NULL;
        cfg->priority               = RV_THREAD_PRIORITY_DEFAULT;
        cfg->referTimeout           = RV_DEFAULT_REFER_TIMEOUT;
        cfg->userDomain             = NULL;
		cfg->displayName            = NULL;
        cfg->registrarAddress       = NULL;
        cfg->registrarPort          = 5060;
#ifdef RV_SIP_IMS_ON
        cfg->registrationExpire     = 600000;   /*seconds, default for IMS */
#else
		cfg->registrationExpire     = 3600;     /*seconds, default is defined in RFC 3261 */
#endif
        cfg->unregistrationExpire   = 20;       /*seconds */
		cfg->maxAuthenticateRetries = 4;
		cfg->removeOldAuthHeaders   = RV_FALSE;
        cfg->stackTcpPort           = 5060;
        cfg->stackUdpPort           = 5060;
        cfg->tcpEnabled             = RV_TRUE;
        cfg->transportType          = RVSIP_TRANSPORT_UDP;
        cfg->username               = NULL;
        cfg->logOptions             = NULL;
        cfg->callWaitingReply       = RV_REPLY_QUEUED;
		cfg->disableCallWaiting     = RV_FALSE;
		cfg->persistentRegisterEnabled = RV_FALSE;
		cfg->persistentRegisterRetryInterval = 30;    /* seconds */
		cfg->registerCompleteTimeout         = 10;    /* seconds */
        cfg->watchdogTimeout        = 0;
        cfg->outOfBandDtmf          = RV_FALSE;
        cfg->sdpStackCfg.disableSdpLogs = RV_FALSE;
        cfg->sdpStackCfg.logManagerPtr = IppLogMgr();
        cfg->connectMediaOn180      = RV_FALSE;
		cfg->sessionTimerRefreshByUpdate = RV_FALSE;
		cfg->addUserAgentHeader     = RV_FALSE;
		cfg->manufacturerId         = NULL;
		cfg->productId              = NULL;
		cfg->productVersion         = NULL;
		cfg->sendOldHoldFormat      = RV_FALSE;
		cfg->addUpdateSupport       = RV_FALSE;
		cfg->updateRetryAfterTimeout   = (RvUint8)UNDEFINED;  
		cfg->callerUpdateResendTimeout = (RvUint16)UNDEFINED; 
    	cfg->calleeUpdateResendTimeout = (RvUint16)UNDEFINED;  
		cfg->autoAnswer				= RV_FALSE;
		cfg->autoDisconnect			= RV_FALSE;
		cfg->digitMapPtr            = NULL;
		cfg->acceptCallWhenUserNotFound = RV_FALSE;
		cfg->outgoingCallNoAnswerTimeout      = 180000;   /* Sip default for the provisionalTimer 
		                                                     parameter (DEFAULT_PROVISIONAL_TIMER)  */
		
		cfg->outgoingRequestNoResponseTimeout = 32000;    /* SIP default value for Timer B
			                                                (DEFAULT_T1 * 64)   */
//		cfg->mapAddresses               = RV_TRUE;
		cfg->defaultProtocolType        = RV_MTF_PROTOCOL_SIP;
		cfg->cfwCallCfg.cfwCallBacks.activateCompleted = NULL;
		cfg->cfwCallCfg.cfwCallBacks.deactivateCompleted = NULL;
        rc = RV_TRUE;
    }
    else
    {
        RvLogError(ippLogSource,(ippLogSource, "cfg is NULL"));
        rc = RV_FALSE;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipInitConfig()=%d", rc));
    return rc;
}

/******************************************************************************
*  rvIppSipSystemInit
******************************************************************************/
RVAPI void RVCALLCONV rvIppSipSystemInit(void)
{
/* NOTE!!!!!!!!!!
    Do not add log here. log is not started yet */
	
    RvMemoryInfo    memInfo;
    RvStatus        status = RV_OK;
	
    status = RvCBaseInit();
    if (status != RV_OK)
        return;
	
    RvMemoryGetInfo(NULL, NULL, &memInfo);
    initialAlloc = memInfo.bytes_requested_byuser;
	
    /* Do not use cache Allocator if we are not compiled with RV_MTF_USE_CACHE_ALLOCATOR */
#ifndef RV_MTF_USE_CACHE_ALLOCATOR
	
    prvDefaultAlloc  = rvAllocGetDefaultAllocator();
	
#else
	
    if ( RV_FALSE == rvMtfAllocatorInit() )
    {
        /* failed to init mtf allocator */
        return;
    }
	
    prvDefaultAlloc  = rvMtfAllocatorGet();
	
#endif /* RV_MTF_USE_CACHE_ALLOCATOR */
	
    /*Reset structure of user callbacks*/
    memset(&sipExtClbksDeprecated, 0, sizeof(RvIppSipExtClbks));
}

/******************************************************************************
*  rvIppSipSystemEnd
******************************************************************************/
RVAPI void RVCALLCONV rvIppSipSystemEnd(void)
{
	
#ifdef RV_MTF_USE_CACHE_ALLOCATOR
    rvMtfAllocatorFinish();
#endif /* RV_MTF_USE_CACHE_ALLOCATOR */

	
    RvSdpMgrDestruct();
	
    checkForMemoryLeaks();
	
    /* Logger is initialized by user application and destructed here */
    IppLogEnd();
	
    RvCBaseEnd();
}

/******************************************************************************
*  rvIppSipRegisterExtClbks
******************************************************************************/
RVAPI void RVCALLCONV rvIppSipRegisterExtClbks(IN RvIppSipExtClbks* clbks)
{
    RvLogEnter(ippLogSource,(ippLogSource, "rvIppSipRegisterExtClbks(clbks=%p)", clbks));

    if (clbks != NULL)
    {
        sipExtClbksDeprecated.postCallLegCreatedIncomingF = clbks->postCallLegCreatedIncomingF;      
        sipExtClbksDeprecated.postCallLegCreatedOutgoingF = clbks->postCallLegCreatedOutgoingF;   
        sipExtClbksDeprecated.postMsgReceivedF = clbks->postMsgReceivedF;        
        sipExtClbksDeprecated.postMsgToSendF = clbks->postMsgToSendF;       
        sipExtClbksDeprecated.preCallLegCreatedIncomingF = clbks->preCallLegCreatedIncomingF;    
        sipExtClbksDeprecated.preCallLegCreatedOutgoingF = clbks->preCallLegCreatedOutgoingF;     
        sipExtClbksDeprecated.preMsgReceivedF = clbks->preMsgReceivedF;      
        sipExtClbksDeprecated.preMsgToSendF = clbks->preMsgToSendF;      
        sipExtClbksDeprecated.PreRegClientStateChangedF = clbks->PreRegClientStateChangedF;        
        sipExtClbksDeprecated.preStateChangedF = clbks->preStateChangedF;
		sipExtClbksDeprecated.postStateChangedF = clbks->postStateChangedF;
		sipExtClbksDeprecated.transmitterRegExpResolutionNeededF = clbks->transmitterRegExpResolutionNeededF;    
        sipExtClbksDeprecated.registerStackEventsF = clbks->registerStackEventsF;       
        sipExtClbksDeprecated.stackConfigF = clbks->stackConfigF; 
        sipExtClbksDeprecated.userData = clbks->userData;
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipRegisterExtClbks()"));
}




/******************************************************************************
*  rvIppSipClearExtClbks
******************************************************************************/
RVAPI void rvIppSipClearExtClbks(void)
{
    RvLogEnter(ippLogSource,(ippLogSource,"rvIppSipClearExtClbks()"));

    /*Reset structure of user callbacks*/
    memset(&sipExtClbksDeprecated, 0, sizeof(RvIppSipExtClbks));

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipClearExtClbks()"));
}



/******************************************************************************
*  rvIppSipControlGetRegistrarAddress
******************************************************************************/
RVAPI void RVCALLCONV rvIppSipControlGetRegistrarAddress(
    IN  RvIppSipControlHandle   sipMgrHndl,
    OUT RvChar*                 registrarAddress,
    IN  RvSize_t                registrarAddressLen)
{
    RvSipControl* sipMgr = (RvSipControl*)sipMgrHndl;

    RvLogEnter(ippLogSource,(ippLogSource,"rvIppSipControlGetRegistrarAddress(sipMgr=%p,addr=%p,len=%d)",
        sipMgr, registrarAddress, registrarAddressLen));

    if ((rvSipControlGetRegistrarAddress(sipMgr) != NULL) && strcmp(rvSipControlGetRegistrarAddress(sipMgr), ""))
    {
        RvSnprintf(registrarAddress, registrarAddressLen, "%s:%d", rvSipControlGetRegistrarAddress(sipMgr), rvSipControlGetRegistrarPort(sipMgr));
        registrarAddress[registrarAddressLen-1] = '\0';
    }
    else
    {
        registrarAddress[0] = '\0';
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipControlGetRegistrarAddress()=%s", registrarAddress));
}

/******************************************************************************
*  rvIppSipControlGetUserDomain
******************************************************************************/
RVAPI void RVCALLCONV rvIppSipControlGetUserDomain(
    IN  RvIppSipControlHandle   sipMgrHndl,
    OUT RvChar*                 userDomain,
    IN  RvSize_t                userDomainLen)
{
    RvSipControl* sipMgr = (RvSipControl*)sipMgrHndl;

	RvLogEnter(ippLogSource,(ippLogSource,"rvIppSipControlGetUserDomain(sipMgr=%p,domain=%p,len=%d)",
        sipMgr, userDomain, userDomainLen));

    if ((sipMgr->userDomain != NULL) && (strcmp(sipMgr->userDomain, "")))
    {
        strncpy(userDomain, sipMgr->userDomain, userDomainLen);
        userDomain[userDomainLen-1] = '\0';
    }
    else
    {
        /*userDomain[0] = '\0';*/
        strcpy(userDomain, "mydomain.com");
    }

	RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipControlGetUserDomain()=%s", userDomain));

}

/******************************************************************************
*  rvIppSipControlGetOutboundProxyAddress
******************************************************************************/
RVAPI void RVCALLCONV rvIppSipControlGetOutboundProxyAddress(
    IN  RvIppSipControlHandle   sipMgrHndl,
    OUT RvChar*                 outboundProxyAddress,
    IN  RvSize_t                outboundProxyAddressLen)
{
    RvSipControl* sipMgr = (RvSipControl*)sipMgrHndl;

    RvLogEnter(ippLogSource,(ippLogSource,"rvIppSipControlGetOutboundProxyAddress(sipMgr=%p,proxy=%p,len=%d)",
        sipMgr, outboundProxyAddress, outboundProxyAddressLen));

    if (rvSipControlGetOutboundProxyAddress(sipMgr) != NULL)
    {
        strncpy(outboundProxyAddress, rvSipControlGetOutboundProxyAddress(sipMgr), outboundProxyAddressLen);
        outboundProxyAddress[outboundProxyAddressLen-1] = '\0';
    }
    else
    {
        outboundProxyAddress[0] = '\0';
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipControlGetOutboundProxyAddress()=%s", outboundProxyAddress));
}

/******************************************************************************
*  rvIppSipControlGetExtUserData
******************************************************************************/
RVAPI void* RVCALLCONV rvIppSipControlGetExtUserData(IN RvIppSipControlHandle sipMgrHndl)
{

    RV_UNUSED_ARG(sipMgrHndl);

    RvLogEnter(ippLogSource,(ippLogSource,"rvIppSipControlGetExtUserData()"));
    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipControlGetExtUserData()=%p",
        sipExtClbksDeprecated.userData));

   return (sipExtClbksDeprecated.userData);
}

/******************************************************************************
*  rvIppSipControlGetTransportType
******************************************************************************/
RVAPI RvSipTransport RVCALLCONV rvIppSipControlGetTransportType(
    IN RvIppSipControlHandle    sipMgrHndl)
{
    RvSipControl* sipMgr = (RvSipControl*)sipMgrHndl;
    RvSipTransport rc;

    RvLogEnter(ippLogSource,(ippLogSource,"rvIppSipControlGetTransportType(sipMgr=%p)",
        sipMgr));

    rc = rvSipControlGetTransportType(sipMgr);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipControlGetTransportType()=%d", rc));

    return rc;
}

/******************************************************************************
*  rvIppSipControlMsgSetSdpBody
******************************************************************************/
RVAPI RvBool RVCALLCONV rvIppSipControlMsgSetSdpBody(
    IN RvSipMsgHandle   hMsg,
    IN const RvSdpMsg*  sdpMsg)
{
    RvBool rc;
    RvLogEnter(ippLogSource,(ippLogSource,"rvIppSipControlMsgSetSdpBody(msg=%p,sdp=%p)",
        hMsg, sdpMsg));

    rc = !rvSipControlMsgSetBody(hMsg, sdpMsg);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipControlMsgSetSdpBody()=%d", rc));

    return rc;
}

/******************************************************************************
*  rvIppSipControlGetStackCallbacks()
******************************************************************************/
RVAPI RvIppSipStackCallbacks* RVCALLCONV rvIppSipControlGetStackCallbacks(
    IN RvIppSipControlHandle sipMgrHndl)
{
    RvIppSipStackCallbacks *rc;
    RvSipControl* sipMgr = (RvSipControl*)sipMgrHndl;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppSipControlGetStackCallbacks(sipMgr=%p)",
        sipMgr));

    rc = &sipMgr->stackCallbacks;

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipControlGetStackCallbacks()=%p", rc));
    return rc;
}

/******************************************************************************
*  rvIppSipControlGetStackHandle
******************************************************************************/
RVAPI RvSipStackHandle RVCALLCONV rvIppSipControlGetStackHandle(
    IN RvIppSipControlHandle sipMgrHndl)
{
    RvSipStackHandle rc;
    RvSipControl* sipMgr = (RvSipControl*)sipMgrHndl;

    RvLogEnter(ippLogSource,(ippLogSource, "rvIppSipControlGetStackHandle(sipMgr=%p)", sipMgr));

    rc = rvSipControlGetStackHandle(sipMgr);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipControlGetStackHandle()=%p", rc));
    return rc;
}

/******************************************************************************
*  rvIppSipControlGetMdmTerminal (DEPRECATED)
******************************************************************************/
RVAPI RvIppTerminalHandle RVCALLCONV rvIppSipControlGetMdmTerminal(
    IN RvSipAppCallLegHandle   hAppCallLeg)
{
    RvCCConnection* c = (RvCCConnection*)hAppCallLeg;
    RvCCConnSip* sconn = NULL;
    RvCCTerminal* st = NULL;
    RvCCTerminalSip* sTerm = NULL;
    RvCCTerminal* t = NULL;

    RvLogEnter(ippLogSource,(ippLogSource,"rvIppSipControlGetMdmTerminal(appLeg=%p)", hAppCallLeg));

    /* Dive through all the ugly pointers until we get what we need */
    if (c != NULL)
    {
        if ((sconn = rvCCConnSipGetIns(c)) != NULL)
        {
            if ((st = rvCCConnSipGetTerminal(c)) != NULL)
            {
                if ((sTerm = rvCCTerminalSipGetImpl(st)) != NULL)
                {
                    t = rvCCTerminalSipGetMdmTerminal(sTerm);
                }
            }
        }
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipControlGetMdmTerminal()=%p", t));

    return (RvIppTerminalHandle)t;

}

/******************************************************************************
*  rvIppSipControlGetCallLeg
******************************************************************************/
RVAPI RvSipCallLegHandle RVCALLCONV rvIppSipControlGetCallLeg(
    IN RvIppConnectionHandle   connHndl)
{
    RvCCConnection* c = (RvCCConnection*)connHndl;
    RvCCConnSip* conn = NULL;

    RvLogEnter(ippLogSource,(ippLogSource,"rvIppSipControlGetCallLeg(connHndl=%p)", connHndl));

    conn = rvCCConnSipGetIns(c);

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipControlGetCallLeg()=%p", conn->callLegHndl));

    return conn->callLegHndl;

}


/******************************************************************************
*  rvIppSipConnGetMdmTerminal
******************************************************************************/
RVAPI RvIppTerminalHandle RVCALLCONV rvIppSipConnGetMdmTerminal(
    IN RvIppConnectionHandle          connHndl)
{
    RvCCConnection* c = (RvCCConnection*)connHndl;
    RvCCConnSip* sconn = NULL;
    RvCCTerminal* st = NULL;
    RvCCTerminalSip* sTerm = NULL;
    RvCCTerminal* t = NULL;

    RvLogEnter(ippLogSource,(ippLogSource,"rvIppSipConnGetMdmTerminal(connHndl=%p)", connHndl));

    /* Dive through all the ugly pointers until we get what we need */
    if (connHndl != NULL)
    {
        if ((sconn = rvCCConnSipGetIns(c)) != NULL)
        {
            if ((st = rvCCConnSipGetTerminal(c)) != NULL)
            {
                if ((sTerm = rvCCTerminalSipGetImpl(st)) != NULL)
                {
                    t = rvCCTerminalSipGetMdmTerminal(sTerm);
                }
            }
        }
    }

    RvLogLeave(ippLogSource,(ippLogSource, "rvIppSipConnGetMdmTerminal()=%p", t));

    return (RvIppTerminalHandle)t;

}

