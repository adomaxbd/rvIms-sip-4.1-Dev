/******************************************************************************
Filename   : rvSipControlInt.c
Description: Sip Control Internal Extension APIs
******************************************************************************
                Copyright (c) 2004 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_SIPCONTROL
#include "ipp_inc_std.h"
#include "mtfBaseInt.h"
#include "rvMtfExtControlApi.h"
#include "rvSipControlApi.h"
#include "sipControlInt.h"
#include "rvccprovidermdm.h"
#include "sipphone.h"
#include "sipMgr.h"
#include "sipRegClient.h"

#ifdef RV_CFLAG_TLS
#include "sipTls.h"
#endif


/*===============================================================================*/
/*===============  G L O B A L		D E C L A R A T I O N S		=================*/
/*===============================================================================*/

RvIppSipExtClbks				sipExtClbksDeprecated;
extern RvMtfSipControlClbks		sipExtClbks;
extern RvMtfBaseMgr*			g_mtfMgr;

static RvMtfAppHandle getMtfApplicationHandle();
static void stackConfigValidate(RvSipStackCfg* pStackCfgOld, RvSipStackCfg* pStackCfgNew);
static void checkStateChanged(IN RvSipCallLegState origState, IN const RvChar* funcName, IN RvSipCallLegHandle hCallLeg);


/*===============================================================================*/
/*=============== S I P     S T A C K       E X T E N S I O N S =================*/
/*===============================================================================*/

/******************************************************************************
*  rvIppSipExtStackConfigCB
*  -------------------------
*  General :        Calls user callback for changing stack configuration, and
*                   validating the changed parameters.
*                   Parameters with illegal or unsupported values will be ignored
*                   or changed back to the original value.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          pStackCfg              pointer of stack configuration structure
*
*  Output:         none.
******************************************************************************/
void rvIppSipExtStackConfigCB(RvSipStackCfg* pStackCfg)
{

    RvSipStackCfg stackCfg;

    /*Copy config structure to a local variable before sending to user*/
    memcpy(&stackCfg, pStackCfg, sizeof(RvSipStackCfg));

	/* Try the deprecated callback first */
	if (sipExtClbksDeprecated.stackConfigF != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvIppSipStackConfigCB() - before user callback (pStackCfg=%p)", pStackCfg));

		/*Call user callback*/
		sipExtClbksDeprecated.stackConfigF(&stackCfg);

		stackConfigValidate(pStackCfg, &stackCfg);

		RvLogDebug(ippLogSource,(ippLogSource, "RvIppSipStackConfigCB() - after user callback"));
	}
	else if (sipExtClbks.stackConfigCB != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfChangeSipStackConfigEv() - before user callback (pStackCfg=%p)", pStackCfg));

		/*Call user callback*/
		sipExtClbks.stackConfigCB(&stackCfg);

		stackConfigValidate(pStackCfg, &stackCfg);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfChangeSipStackConfigEv() - after user callback"));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtStackConfigCB() - application did not register this callback"));
	}
}

/******************************************************************************
*  rvIppSipExtRegisterStackEventsCB
*  ---------------------------------
*  General :        Calls user callback for registering stack events that IPP TK
*                   doesn't listen on.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgr	               pointer to SipControl structure
*                  stackHandle              stack handle
*
*  Output:         none.
******************************************************************************/
void rvIppSipExtRegisterStackEventsCB(RvSipControl*  sipMgr, RvSipStackHandle stackHandle)
{
	/* Try the deprecated callback first */
    if (sipExtClbksDeprecated.registerStackEventsF != NULL)
    {
        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipRegisterStackEventsCB() - before user callback (sipMgr=%p)", stackHandle));

        /*Call user callback*/
        sipExtClbksDeprecated.registerStackEventsF((RvIppSipControlHandle)sipMgr);

        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipRegisterStackEventsCB() - after user callback"));
    }
	else if (sipExtClbks.registerStackEventsCB != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegisterSipStackEventsEv() - before user callback (mtfMgr=%p)", g_mtfMgr));

		/*Call user callback*/
		sipExtClbks.registerStackEventsCB(stackHandle, &sipMgr->stackCallbacks);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegisterSipStackEventsEv() - after user callback"));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtRegisterStackEventsCB() - application did not register this callback"));
	}
}

/******************************************************************************
*  rvIppSipExtPreCallLegCreatedIncomingCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipCallLegCreatedEvHandler event
*                   is received from the stack, before it is processed by IPP TK.
*
*  Return Value:   True - if event should be processed by IPP TK
*                  False - if event should be ignored by IPP TK
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*                  hCallLeg                handle of call leg
*                  phAppCallLeg            handle of application
*
*  Output:         none.
******************************************************************************/
RvBool rvIppSipExtPreCallLegCreatedIncomingCB(
    IN  RvIppSipControlHandle   sipMgrHndl,
    IN  RvSipCallLegHandle      hCallLeg,
    OUT RvSipAppCallLegHandle   *phAppCallLeg)
{
	RvSipCallLegState	state;
    RvBool res = RV_TRUE;

	RvSipCallLegDirection direction;

	RvSipCallLegGetDirection(hCallLeg, &direction);

	/*Store call-leg state*/
	RvSipCallLegGetCurrentState(hCallLeg, &state);

	/* Try the deprecated callback first */
    if (sipExtClbksDeprecated.preCallLegCreatedIncomingF != NULL)
    {
        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPreCallLegCreatedIncomingCB() - before user callback (sipMgr=%p,leg=%p,userData=%p)",
            sipMgrHndl, hCallLeg, sipExtClbksDeprecated.userData));

        /*Call user callback*/
        res = sipExtClbksDeprecated.preCallLegCreatedIncomingF(sipMgrHndl, hCallLeg, phAppCallLeg,
            sipExtClbksDeprecated.userData);

        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPreCallLegCreatedIncomingCB() - after user callback (appLeg=%p, res=%d)", *phAppCallLeg, res));
    }
	/* This user callback (PreCallLegCreatedIncomingCB) should be called for incoming calls only,
	   while the SIP callback (CallLegCreated) is called for both incoming and outgoing.
	   We don't block it in sipMgr.c to keep backward compatibility.*/
	if (direction == RVSIP_CALL_LEG_DIRECTION_INCOMING)
	{
		if (sipExtClbks.preCallLegCreatedIncomingCB != NULL)
		{
			RvMtfAppHandle userData = (RvMtfAppHandle)getMtfApplicationHandle();
			RvMtfMsgProcessType	type;

			RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPreCallCreatedIncomingEv() - before user callback (hCallLeg = %p, user data=%p)",
				hCallLeg, userData));

			/*Call user callback*/
			type = sipExtClbks.preCallLegCreatedIncomingCB(hCallLeg, userData);

			res = ((type == RV_MTF_DONT_IGNORE) ? RV_TRUE : RV_FALSE);

			RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPreCallCreatedIncomingEv() - after user callback (type=%d)", type));
		}
		else
		{
			RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtPreCallLegCreatedIncomingCB() - application did not register this callback"));
		}
	}
	/*Check if call-leg state was changed by user*/
    checkStateChanged(state, "rvIppSipExtPreCallLegCreatedIncomingCB", hCallLeg);

    return res;
}

/******************************************************************************
*  rvIppSipExtPostCallLegCreatedIncomingCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipCallLegCreatedEvHandler event
*                   is received from the stack, after it is processed by IPP TK.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*                  hCallLeg                handle of call leg
*                  phAppCallLeg            handle of application
*
*  Output:         none.
******************************************************************************/
void rvIppSipExtPostCallLegCreatedIncomingCB(
    IN RvIppSipControlHandle    sipMgrHndl,
    IN RvSipCallLegHandle       hCallLeg,
    IN RvIppConnectionHandle    hConn)
{
	RvSipCallLegState	state;


	/*Store call-leg state*/
    RvSipCallLegGetCurrentState(hCallLeg, &state);

		/* Try the deprecated callback first */
    if (sipExtClbksDeprecated.postCallLegCreatedIncomingF != NULL)
    {
        void*	userData = sipExtClbksDeprecated.userData;

        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPostCallLegCreatedIncomingCB() - before user callback (sipMgr=%p,leg=%p,conn=%p,userData=%p)",
            sipMgrHndl, hCallLeg, hConn, userData));

        /*Call user callback*/
        sipExtClbksDeprecated.postCallLegCreatedIncomingF(sipMgrHndl, hCallLeg, hConn, userData);

        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPostCallLegCreatedIncomingCB() - after user callback"));
    }
	else if (sipExtClbks.postCallLegCreatedIncomingCB != NULL)
	{
		RvMtfConnAppHandle userData = NULL;

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPostCallCreatedIncomingEv() - before user callback (hCallLeg=%p, user data=%p)",
			hCallLeg, userData));

		/*Call user callback. We don't pass Connection yet in the callback since we have only SIP connection,
		  and we are passing the MDM connection to user callbacks.*/
		sipExtClbks.postCallLegCreatedIncomingCB(hCallLeg, &userData);

		/* Set user data in the connection. */
		rvMtfConnectionSetAppHandle(hConn, userData);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPostCallCreatedIncomingEv() - after user callback"));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtPostCallLegCreatedIncomingCB() - application did not register this callback"));
	}

	/*Check if call-leg state was changed by user*/
    checkStateChanged(state, "rvIppSipExtPostCallLegCreatedIncomingCB", hCallLeg);
}

/******************************************************************************
*  rvIppSipExtPreCallLegCreatedOutgoingCB
*  ---------------------------------
*  General :        Calls user callback to be called before sending out Invite
*                   message - after call-leg was created, and before setting
*                   parameters to the Invite message.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*                  hCallLeg                handle of call leg
*                  phAppCallLeg            handle of application
*
*  Output:         none.
******************************************************************************/
void rvIppSipExtPreCallLegCreatedOutgoingCB(
    IN RvIppSipControlHandle    sipMgrHndl,
    IN RvIppConnectionHandle    hConn,
    IN RvSipCallLegHandle       hCallLeg,
    IN RvChar*                  to,
    IN RvChar*                  from)
{
	RvCCConnection*		conn = (RvCCConnection *)hConn;
	RvSipCallLegState	state;
	void*				userData;

	/*Store call-leg state*/
	RvSipCallLegGetCurrentState (hCallLeg, &state);

	/* try the deprecated callback first */
    if (sipExtClbksDeprecated.preCallLegCreatedOutgoingF != NULL)
    {
        userData = sipExtClbksDeprecated.userData;

        if (conn != NULL)
        {
            userData = conn->userData;
        }

        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPreCallLegCreatedOutgoingCB() - before user callback (sipMgr=%p,call-leg=%p,to=%s,from=%s,userData=%p)",
            sipMgrHndl, hCallLeg ,to, from, userData));

        /*Call user callback*/
        sipExtClbksDeprecated.preCallLegCreatedOutgoingF(sipMgrHndl, hCallLeg, to, from, userData);

        RvLogDebug(ippLogSource, (ippLogSource, "RvIppSipPreCallLegCreatedOutgoingCB() - after user callback (to=%s,from=%s)", to, from));

    }

	else if (sipExtClbks.preCallLegCreatedOutgoingCB != NULL)
	{
		RvCCConnection* mdmConn = conn->curParty;
		RvIppConnectionHandle hMdmConn = NULL;

		if (mdmConn != NULL)
		{
			/* Get user data from connection */
			hMdmConn = (RvIppConnectionHandle)mdmConn;
			userData = mdmConn->userData;
		}
		else
		{
			hMdmConn = NULL;
			userData = NULL;
		}

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPreCallCreatedOutgoingEv() - before user callback (hCallLeg=%p, hMdmConn=%p, to=%s, from=%s, user data=%p)",
			hCallLeg, hMdmConn, to, from, userData));

		/*Call user callback*/
		sipExtClbks.preCallLegCreatedOutgoingCB(hCallLeg, hMdmConn, to, from, (RvMtfConnAppHandle*)userData);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPreCallCreatedOutgoingEv() - after user callback (to=%s,from=%s)", to, from));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtPreCallLegCreatedOutgoingCB() - application did not register this callback"));
	}

	/*Check if call-leg state was changed by user*/
    checkStateChanged(state, "rvIppSipExtPreCallLegCreatedOutgoingCB", hCallLeg);

}

/******************************************************************************
*  rvIppSipExtPostCallLegCreatedOutgoingCB
*  ---------------------------------
*  General :        Calls user callback to be called before sending out Invite
*                   message - after setting parameters to the Invite message,
*                   and before calling RvSipCallLegMake() to send out the message.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*
*  Output:         none.
******************************************************************************/
void rvIppSipExtPostCallLegCreatedOutgoingCB(
    IN RvIppSipControlHandle    sipMgrHndl,
    IN RvIppConnectionHandle    hConn,
    IN RvSipCallLegHandle       hCallLeg)
{
	RvCCConnection*		conn = (RvCCConnection *)hConn;
	RvSipCallLegState	state;
	void*				userData;

	/*Store call-leg state*/
    RvSipCallLegGetCurrentState(hCallLeg, &state);

    if (sipExtClbksDeprecated.postCallLegCreatedOutgoingF != NULL)
    {
        userData = sipExtClbksDeprecated.userData;

        if (conn != NULL)
        {
			userData = conn->userData;
        }

        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPostCallLegCreatedOutgoingCB() - before user callback (sipMgr=%p,call-leg=%p,userData=%p)",
            sipMgrHndl, hCallLeg, userData));

        /*Call user callback*/
        sipExtClbksDeprecated.postCallLegCreatedOutgoingF(sipMgrHndl, hCallLeg, userData);

        RvLogDebug(ippLogSource, (ippLogSource, "RvIppSipPostCallLegCreatedOutgoingCB() - after user callback"));

    }
	else if (sipExtClbks.postCallLegCreatedOutgoingCB != NULL)
	{
		RvCCConnection* mdmConn = conn->curParty;
		RvIppConnectionHandle hMdmConn = NULL;

		if (mdmConn != NULL)
		{
			/* Get user data from connection */
			hMdmConn = (RvIppConnectionHandle)mdmConn;
			userData = mdmConn->userData;
		}
		else
		{
			hMdmConn = NULL;
			userData = NULL;
		}

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPostCallCreatedOutgoingEv() - before user callback (hCallLeg=%p, hMdmConn=%p, user data=%p)",
			hCallLeg, hMdmConn, userData));

		/*Call user callback*/
		sipExtClbks.postCallLegCreatedOutgoingCB(hCallLeg, hMdmConn, (RvMtfConnAppHandle)userData);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPostCallCreatedOutgoingEv() - after user callback"));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtPostCallLegCreatedOutgoingCB() - application did not register this callback"));
	}

	/*Check if call-leg state was changed by user*/
    checkStateChanged(state, "rvIppSipExtPostCallLegCreatedOutgoingCB", hCallLeg);
}

/******************************************************************************
*  rvIppSipExtPreStateChangedCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipCallLegCreatedEvHandler event
*                   is received from the stack, before it is processed by IPP TK.
*
*  Return Value:   True - if event should be processed by IPP TK
*                  False - if event should be ignored by IPP TK
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*                  hCallLeg                handle of call leg
*                  phAppCallLeg            handle of application
*
*  Output:         none.
******************************************************************************/
RvBool rvIppSipExtPreStateChangedCB(
    IN RvIppSipControlHandle            sipMgrHndl,
    IN RvSipCallLegHandle               hCallLeg,
    IN RvSipAppCallLegHandle            hAppCallLeg,
    IN RvSipCallLegState                eState,
    IN RvSipCallLegStateChangeReason    eReason)
{
	RvCCConnection*			conn = (RvCCConnection *)hAppCallLeg;
	RvSipCallLegState		newState;
    RvBool					res = RV_TRUE;
	void*					userData;

    if (sipExtClbksDeprecated.preStateChangedF != NULL)
    {
        userData = sipExtClbksDeprecated.userData;

        if (conn != NULL)
        {
            userData = conn->userData;
        }

        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPreStateChangedCB() - before user callback (sipMgr=%p,leg=%p,conn=%p,eState=%s,eReason=%d,userData=%p)",
            sipMgrHndl, hCallLeg, hAppCallLeg, rvSipControlGetCallLegStateName(eState), eReason,
            userData));

        /*Call user callback*/
        res = sipExtClbksDeprecated.preStateChangedF(sipMgrHndl, hCallLeg, (RvIppConnectionHandle)conn,
            eState, eReason, userData);

        /*Check call-leg state after user callback*/
        RvSipCallLegGetCurrentState(hCallLeg, &newState);

        RvLogDebug(ippLogSource, (ippLogSource, "RvIppSipPreStateChangedCB() - after user callback (res=%d)", res));
    }
	else if (sipExtClbks.preStateChangedCB != NULL)
	{
		RvCCConnection* mdmConn = NULL;
		RvIppConnectionHandle hMdmConn = NULL;
		RvMtfMsgProcessType	type;

		userData = NULL;

		/* When call disconnecting, conn or mdmConn are already released.*/
		if ((conn != NULL))
		{
			mdmConn = conn->curParty;
			if (mdmConn != NULL)
			{
				/* Get user data from connection */
				hMdmConn = (RvIppConnectionHandle)mdmConn;
				userData = mdmConn->userData;
			}
		}

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPreCallLegStateChangedEv() - before user callback (hCallLeg=%p, hMdmConn=%p, eState=%s,eReason=%d, user data=%p)",
			hCallLeg, hMdmConn, rvSipControlGetCallLegStateName(eState), eReason, userData));

		/*Call user callback*/
		type = sipExtClbks.preStateChangedCB(hCallLeg, hMdmConn, (RvMtfConnAppHandle)userData, eState, eReason);

		res = ((type == RV_MTF_DONT_IGNORE) ? RV_TRUE : RV_FALSE);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPreCallLegStateChangedEv() - after user callback (res=%d)", type));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtPreStateChangedCB() - application did not register this callback"));
	}

	/*Check if call-leg state was changed by user*/
    checkStateChanged(eState, "rvIppSipExtPreStateChangedCB", hCallLeg);

    return res;
}

/******************************************************************************
*  rvIppSipExtPostStateChangedCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipCallLegStateChangedEvHandler event
*                   is received from the stack, after it is processed by MTF.
*                   Note: if eState = RVSIP_CALL_LEG_STATE_DISCONNECTED or RVSIP_CALL_LEG_STATE_TERMINATED,
*                   hAppCallLeg is not valid anymore.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*                  hCallLeg                handle of call leg
*                  phAppCallLeg            handle of application
*
*  Output:         none.
******************************************************************************/
void rvIppSipExtPostStateChangedCB(RvIppSipControlHandle                sipMgrHndl,
                                   RvSipCallLegHandle                   hCallLeg,
                                   IN  RvSipAppCallLegHandle            hAppCallLeg,
                                   IN  RvSipCallLegState                eState,
                                   IN  RvSipCallLegStateChangeReason    eReason)
{
	RvCCConnection*		conn = (RvCCConnection *)hAppCallLeg;
	void*				userData;

    if (sipExtClbksDeprecated.postStateChangedF != NULL)
	{
        userData = sipExtClbksDeprecated.userData;

        /* When eState = RVSIP_CALL_LEG_STATE_DISCONNECTED conn is not valid, in this case we will pass NULL as
           connection */
        if ((conn != NULL)  && (eState != RVSIP_CALL_LEG_STATE_DISCONNECTED))
        {
            userData = conn->userData;
        }
        else
        {
            conn = NULL;
        }


        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPostStateChangedCB() - before user callback (sipMgr=%p,leg=%p,appLeg=%p,eState=%s,eReason=%d,userData=%p)",
            sipMgrHndl, hCallLeg, hAppCallLeg, rvSipControlGetCallLegStateName(eState), eReason,
            userData));

        /*Call user callback*/
        sipExtClbksDeprecated.postStateChangedF(sipMgrHndl, hCallLeg, (RvIppConnectionHandle)conn, eState, eReason,
            userData);

        RvLogDebug(ippLogSource, (ippLogSource, "RvIppSipPostStateChangedCB() - after user callback"));
    }

	else if (sipExtClbks.postStateChangedCB != NULL)
	{
		RvCCConnection* mdmConn = NULL;
		RvIppConnectionHandle hMdmConn = NULL;
		RvSipCallLegState	newState;

		userData = NULL;

		/*Check call-leg state after user callback*/
		RvSipCallLegGetCurrentState (hCallLeg, &newState);

		/* When call disconnecting, conn or mdmConn are already released.*/
		if ((conn != NULL) &&
			(eState   != RVSIP_CALL_LEG_STATE_DISCONNECTED)	&&
			(newState != RVSIP_CALL_LEG_STATE_DISCONNECTED) &&
			(newState != RVSIP_CALL_LEG_STATE_DISCONNECTING)&&
			(newState != RVSIP_CALL_LEG_STATE_CANCELLED)	&&
			(eState   != RVSIP_CALL_LEG_STATE_CANCELLED)    &&
			(newState != RVSIP_CALL_LEG_STATE_TERMINATED)	&&
			(eState   != RVSIP_CALL_LEG_STATE_TERMINATED))
		{
			mdmConn = conn->curParty;
			if (mdmConn != NULL)
			{
				/* Get user data from connection */
				hMdmConn = (RvIppConnectionHandle)mdmConn;
				userData = mdmConn->userData;
			}
		}

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPostCallLegStateChangedEv() - before user callback (hCallLeg=%p, hMdmConn=%p, eState=%s,eReason=%d, user data=%p)",
			hCallLeg, hMdmConn, rvSipControlGetCallLegStateName(eState), eReason, (RvMtfConnAppHandle)userData));

		/*Call user callback*/
		sipExtClbks.postStateChangedCB(hCallLeg, hMdmConn, (RvMtfConnAppHandle)userData, eState, eReason);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPostCallLegStateChangedEv() - after user callback"));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtPostStateChangedCB() - application did not register this callback"));
	}

	/*Check if call-leg state was changed by user*/
    checkStateChanged(eState, "rvIppSipExtPostStateChangedCB", hCallLeg);

}

/******************************************************************************
*  rvIppSipExtPreMsgToSendCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipCallLegMsgToSendEvHandler event
*                   is received from the stack, before it is processed by MTF.
*                   First it calls the deprecated callback, if not registered it calls the
*					regular one.
*
*  Return Value:   True, if event should be processed by MTF, False, if should be ignored.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*                  hCallLeg                handle of call leg
*                  phAppCallLeg            handle of application
*				   hMsg					   handle to message to send
*
*  Output:         none.
******************************************************************************/
RvBool rvIppSipExtPreMsgToSendCB(
    IN RvIppSipControlHandle    sipMgrHndl,
    IN RvSipCallLegHandle       hCallLeg,
    IN RvSipAppCallLegHandle    hAppCallLeg,
    IN RvSipMsgHandle           hMsg)
{
	RvBool res = RV_TRUE;

    if (sipExtClbksDeprecated.preMsgToSendF != NULL)
    {
		RvCCConnection* conn = (RvCCConnection *)hAppCallLeg;
		void* userData = sipExtClbksDeprecated.userData;
        RvSipCallLegState state;

        if (conn != NULL)
        {
			userData = conn->userData;
        }

        /*Store call-leg original state*/
        RvSipCallLegGetCurrentState(hCallLeg, &state);

        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPreMsgToSendCB() - before user callback (sipMgr=%p,leg=%p,conn=%p,hMsg=%p,userData=%p)",
            sipMgrHndl, hCallLeg, conn, hMsg, userData));

        /*Call user callback*/
        res = sipExtClbksDeprecated.preMsgToSendF(sipMgrHndl, hCallLeg, (RvIppConnectionHandle)conn,
            hMsg, userData);

        RvLogDebug(ippLogSource, (ippLogSource, "RvIppSipPreMsgToSendCB() - after user callback (res=%d)", res));

        /*Check if call-leg state was changed by user*/
        checkStateChanged(state, "rvIppSipExtPreMsgToSendCB", hCallLeg);
    }
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtPreMsgToSendCB() - application did not register this callback"));
	}

    return res;
}

/******************************************************************************
*  rvIppSipExtPostMsgToSendCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipCallLegMsgToSendEvHandler event
*                   is received from the stack, after it is processed by MTF.
*                   First it calls the deprecated callback, if not registered it calls the
*					regular one.
*
*  Return Value:   None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*                  hCallLeg                handle of call leg
*                  phAppCallLeg            handle of application
*				   hMsg					   handle to message to send
*
*  Output:         none.
******************************************************************************/
void rvIppSipExtPostMsgToSendCB(
						IN  RvIppSipControlHandle       sipMgrHndl,
                        IN  RvSipCallLegHandle          hCallLeg,
                        IN  RvSipAppCallLegHandle		hAppCallLeg,
                        IN  RvSipMsgHandle				hMsg)
{
	RvCCConnection*		conn = (RvCCConnection *)hAppCallLeg;
	RvSipCallLegState	state;
	void*				userData = NULL;

	/*Store call-leg original state*/
    RvSipCallLegGetCurrentState(hCallLeg, &state);

    if (sipExtClbksDeprecated.postMsgToSendF != NULL)
    {
        userData = sipExtClbksDeprecated.userData;

        if (conn != NULL)
        {
			userData = conn->userData;
        }

        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPostMsgToSendCB() - before user callback (sipMgr=%p,leg=%p,conn=%p,hMsg=%p,userData=%p)",
            sipMgrHndl, hCallLeg, conn, hMsg, userData));

        /*Call user callback*/
        sipExtClbksDeprecated.postMsgToSendF(sipMgrHndl, hCallLeg, (RvIppConnectionHandle)conn,
            hMsg, userData);

        RvLogDebug(ippLogSource, (ippLogSource, "RvIppSipPostMsgToSendCB() - after user callback"));

    }
	else if (sipExtClbks.postMsgToSendCB != NULL)
	{
		RvCCConnection* mdmConn = NULL;
		RvIppConnectionHandle hMdmConn = NULL;

		if (conn != NULL)
		{
			mdmConn = rvCCConnectionGetConnectParty(conn);	
		
			if (mdmConn != NULL) 
			{
				/* Get user data from connection */
				hMdmConn = (RvIppConnectionHandle)mdmConn;
				userData = mdmConn->userData;
			}
		}

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfMsgToSendEv() - before user callback (hCallLeg=%p, hMdmConn=%p, hMsg=%p, user data=%p)",
			hCallLeg, hMdmConn, hMsg, userData));

		/*Call user callback*/
		sipExtClbks.postMsgToSendCB(hCallLeg, hMdmConn, (RvMtfConnAppHandle)userData, hMsg);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfMsgToSendEv() - after user callback"));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtPostMsgToSendCB() - application did not register this callback"));
	}

	/*Check if call-leg state was changed by user*/
    checkStateChanged(state, "rvIppSipExtPostMsgToSendCB", hCallLeg);
}

/******************************************************************************
*  RvIppSipExtPreRegClientStateChangedCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipRegClientStateChangedEvHandler event
*                   is received from the stack, before it is processed by MTF.
*                   First it calls the deprecated callback, if not registered it calls the
*					regular one.
*
*  Return Value:   True, if event should be processed by MTF, False, if should be ignored.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*                  hRegClient              handle of reg-client object
*                  mdmTerminalHndl         handle of terminal associated with reg-client
*				   eState				   state of reg-client object
*				   eReason				   reason for reg-client state
*
*  Output:         none.
******************************************************************************/
RvBool RvIppSipExtPreRegClientStateChangedCB(
				RvIppSipControlHandle           sipMgrHndl,
				RvSipRegClientHandle            hRegClient,
				RvIppTerminalHandle             mdmTerminalHndl,
				RvSipRegClientState             eState,
				RvSipRegClientStateChangeReason eReason)
{
    RvBool res = RV_TRUE;

	/* Try the deprecated callback first */
    if (sipExtClbksDeprecated.PreRegClientStateChangedF != NULL)
    {
        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPreRegClientStateChangedCB() - before user callback (sipMgr=%p,hRegClient=%p,mdmTerminalHndl=%p,eState=%s,eReason=%d,userData=%p)",
            sipMgrHndl, hRegClient, mdmTerminalHndl, getRegClientStateName(eState), eReason,
            sipExtClbksDeprecated.userData));

        res = sipExtClbksDeprecated.PreRegClientStateChangedF(sipMgrHndl, hRegClient, mdmTerminalHndl, eState, eReason,
            sipExtClbksDeprecated.userData);

        RvLogDebug(ippLogSource, (ippLogSource, "RvIppSipPreRegClientStateChangedCB() - after user callback (res=%d)", res));
    }
	else if (sipExtClbks.regClientStateChangedCB != NULL)
	{
		void* userData;
		RvMtfMsgProcessType	type;

		rvMtfTerminationGetAppHandle(mdmTerminalHndl, (void*)&userData);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegClientStateChangedEv() - before user callback (hRegClient=%p, mdmTerminalHndl=%p, eState=%s, eReason=%d, user data=%p)",
			hRegClient, mdmTerminalHndl, getRegClientStateName(eState), eReason, userData));

		/*Call user callback*/
		type = sipExtClbks.regClientStateChangedCB(hRegClient, mdmTerminalHndl, (RvMtfTerminalAppHandle)userData, eState, eReason);

		res = ((type == RV_MTF_DONT_IGNORE) ? RV_TRUE : RV_FALSE);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegClientStateChangedEv() - after user callback (res=%d)", type));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvIppSipExtPreRegClientStateChangedCB() - application did not register this callback"));
	}

    return res;
}
/******************************************************************************
*  RvIppSipExtRegClientCreatedCB
*  ---------------------------------
*  General :        Calls user callback to be called after a reg client object 
*                   has been built by the MTF.
*
*  Return Value:   True, if event should be processed by MTF, False, if should be ignored.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:           hRegClient              handle of reg-client object
*  
*
*  Output:         none.
******************************************************************************/
RvBool RvIppSipExtRegClientCreatedCB(
				RvSipRegClientHandle            hRegClient)
{
	RvStatus rv = RV_OK;

	if (sipExtClbks.regClientCreatedCB != NULL)
	{

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegClientCreatedEv() - before user callback (hRegClient=%p)",
			hRegClient));

		/*Call user callback*/
		rv = sipExtClbks.regClientCreatedCB(hRegClient);
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegClientCreatedEv() - after user callback (rv=%d)", rv));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvIppSipExtRegClientCreatedCB() - application did not register this callback"));
	}

    return (rv == RV_OK);
}
/******************************************************************************
*  RvIppSipExtRegClientMsgReceivedCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipRegClientMsgReceivedEv
*                   event is received from the stack                
*
*  Return Value:	RV_OK on success, error code otherwise
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:			hRegClient -  The sip stack register-client handle
*					hRegClient -  The application handle for this register-client.
*					hMsg -        Handle to the received message.
*
*  Output:			none.
******************************************************************************/
RvStatus RvIppSipExtRegClientMsgReceivedCB(	IN  RvSipRegClientHandle          hRegClient,
											IN  RvSipAppRegClientHandle       hAppRegClient,
											IN  RvSipMsgHandle                hMsg)
{
	RvStatus res =		RV_OK;
	RvCCTerminal*       xTerm;
	RvCCTerminalSip*    term;
	RvCCTerminal*       mdmTerm;
	void*				userData;

	if(!hAppRegClient)
	{
		return RV_ERROR_INVALID_HANDLE;
	}

	xTerm   = (RvCCTerminal*)hAppRegClient;
	term    = rvCCTerminalSipGetImpl(xTerm);

	if (term == NULL)
	{
		return RV_ERROR_NULLPTR;
	}
	
	mdmTerm = rvCCTerminalSipGetMdmTerminal(term);

	if (mdmTerm == NULL)
	{
		return RV_ERROR_NULLPTR;
	}

	rvMtfTerminationGetAppHandle((RvIppTerminalHandle)mdmTerm, (void*)&userData);

	if (sipExtClbks.regClientMsgReceivedCB != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegClientMsgReceivedEv() - before user callback (hRegClient=%p, mdmTerm=%p, userData=%p, hMsg=%p)",
			hRegClient, mdmTerm, userData, hMsg));

		/*Call user callback*/
		res = sipExtClbks.regClientMsgReceivedCB(hRegClient, (RvIppTerminalHandle)mdmTerm, (RvMtfTerminalAppHandle)userData, hMsg);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegClientMsgReceivedEv() - after user callback (res=%d)", res));
	}
    return res;
}

/******************************************************************************
*  RvIppSipExtRegClientMsgToSendCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipRegClientMsgReceivedEv
*                   event is received from the stack                
*
*  Return Value:	RV_OK on success, error code otherwise
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:			hRegClient -  The sip stack register-client handle
*					hRegClient -  The application handle for this register-client.
*					hMsg -        Handle to the outgoing message.
*
*  Output:			none.
******************************************************************************/
RvStatus RvIppSipExtRegClientMsgToSendCB(	IN  RvSipRegClientHandle          hRegClient,
											IN  RvSipAppRegClientHandle       hAppRegClient,
											IN  RvSipMsgHandle                hMsg)
{
	RvStatus res =		RV_OK;
	RvCCTerminal*       xTerm;
	RvCCTerminalSip*    term;
	RvCCTerminal*       mdmTerm;
	void*				userData;

	if(!hAppRegClient)
	{
		return RV_ERROR_INVALID_HANDLE;
	}

	xTerm   = (RvCCTerminal*)hAppRegClient;
	term    = rvCCTerminalSipGetImpl(xTerm);

	if (term == NULL)
	{
		return RV_ERROR_NULLPTR;
	}
	mdmTerm = rvCCTerminalSipGetMdmTerminal(term);

	if (mdmTerm == NULL)
	{
		return RV_ERROR_NULLPTR;
	}

	rvMtfTerminationGetAppHandle((RvIppTerminalHandle)mdmTerm, (void*)&userData);

	if (sipExtClbks.regClientMsgToSendCB != NULL)
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegClientMsgToSendEv() - before user callback (hRegClient=%p, mdmTerm=%p, userData=%p, hMsg=%p)",
			hRegClient, mdmTerm, userData, hMsg));

		/*Call user callback*/
		res = sipExtClbks.regClientMsgToSendCB(hRegClient, (RvIppTerminalHandle)mdmTerm, (RvMtfTerminalAppHandle)userData, hMsg);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegClientMsgToSendEv() - after user callback"));
	}

	return res;
}

/******************************************************************************
*  rvIppSipExtPreMsgReceivedCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipCallLegMsgReceivedEvHandler event
*                   is received from the stack, before it is processed by MTF.
*                   First it calls the deprecated callback, if not registered it calls the
*					regular one.
*
*  Return Value:   according to values of RvMtfMsgProcessType.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*                  hCallLeg	               handle of call-leg object
*                  hAppCallLeg		       handle of call-leg application handle (SIP connection)
*				   hMsg					   handle of message received
*
*  Output:         none.
******************************************************************************/
RvMtfMsgProcessType rvIppSipExtPreMsgReceivedCB(
    IN RvIppSipControlHandle    sipMgrHndl,
    IN RvSipCallLegHandle       hCallLeg,
    IN RvSipAppCallLegHandle    hAppCallLeg,
    IN RvSipMsgHandle           hMsg)
{
	RvCCConnection* conn = (RvCCConnection *)hAppCallLeg;
	void* userData;
	RvMtfMsgProcessType res = RV_MTF_DONT_IGNORE;
    RvSipCallLegState state;

	/*Store call-leg original state*/
    RvSipCallLegGetCurrentState(hCallLeg, &state);

    if (sipExtClbksDeprecated.preMsgReceivedF != NULL)
    {
        userData = sipExtClbksDeprecated.userData;

        if (conn != NULL)
        {
			userData = conn->userData;
        }

        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPreMsgReceivedCB() - before user callback (sipMgr=%p,leg=%p,conn=%p,hMsg=%p,userData=%p)",
            sipMgrHndl, hCallLeg, conn, hMsg, userData));

        /*Call user callback*/
        res = sipExtClbksDeprecated.preMsgReceivedF(sipMgrHndl, hCallLeg, (RvIppConnectionHandle)conn,
            hMsg, userData);

        RvLogDebug(ippLogSource, (ippLogSource, "RvIppSipPreMsgReceivedCB() - after user callback (res=%d)", res));
    }
	else if (sipExtClbks.preMsgReceivedCB != NULL)
	{
		RvCCConnection* mdmConn = NULL;
		RvIppConnectionHandle hMdmConn = NULL;

		if ((mdmConn != NULL) && (conn != NULL))
		{
			/* Get MDM connection. */
			mdmConn = conn->curParty;
			/* Get user data from connection */
			hMdmConn = (RvIppConnectionHandle)mdmConn;
			userData = mdmConn->userData;
		}
		else
		{
			hMdmConn = NULL;
			userData = NULL;
		}

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPreMsgReceivedEv() - before user callback (hCallLeg=%p, hMdmConn=%p, hMsg=%p, user data=%p)",
			hCallLeg, hMdmConn, hMsg, userData));

		/*Call user callback*/
		res = sipExtClbks.preMsgReceivedCB(hCallLeg, hMdmConn, (RvMtfConnAppHandle)userData, hMsg);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPreMsgReceivedEv() - after user callback (res=%d)", res));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtPreMsgReceivedCB() - application did not register this callback"));
	}

	/*Check if call-leg state was changed by user*/
    checkStateChanged(state, "rvIppSipExtPreMsgReceivedCB", hCallLeg);

    return res;
}

/******************************************************************************
*  rvIppSipExtPostMsgReceivedCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipCallLegMsgReceivedEvHandler event
*                   is received from the stack, after it is processed by MTF.
*                   First it calls the deprecated callback, if not registered it calls the
*					regular one.
*
*  Return Value:   None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*                  hCallLeg	               handle of call-leg object
*                  hAppCallLeg		       handle of call-leg application handle (SIP connection)
*				   hMsg					   handle of message received
*
*  Output:         none.
******************************************************************************/
void rvIppSipExtPostMsgReceivedCB(
    IN RvIppSipControlHandle    sipMgrHndl,
    IN RvSipCallLegHandle       hCallLeg,
    IN RvSipAppCallLegHandle    hAppCallLeg,
    IN RvSipMsgHandle           hMsg)
{
	RvCCConnection* conn = (RvCCConnection *)hAppCallLeg;
	void* userData = sipExtClbksDeprecated.userData;
    RvSipCallLegState state;

	/*Store call-leg original state*/
    RvSipCallLegGetCurrentState(hCallLeg, &state);

    if (sipExtClbksDeprecated.postMsgReceivedF != NULL)
    {
        userData = sipExtClbksDeprecated.userData;

        if (conn != NULL)
        {
			userData = conn->userData;
        }

        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipPostMsgReceivedCB() - before user callback (sipMgr=%p,leg=%p,conn=%p,hMsg=%p,userData=%p)",
            sipMgrHndl, hCallLeg, conn, hMsg, userData));

        /*Call user callback*/
        sipExtClbksDeprecated.postMsgReceivedF(sipMgrHndl, hCallLeg, (RvIppConnectionHandle)conn,
            hMsg, userData);

        RvLogDebug(ippLogSource, (ippLogSource, "RvIppSipPostMsgReceivedCB() - after user callback"));

    }
	else if (sipExtClbks.postMsgReceivedCB != NULL)
	{
		RvCCConnection* mdmConn = NULL;
		RvIppConnectionHandle hMdmConn = NULL;

		if ((mdmConn != NULL) && (conn != NULL))
		{
			/* Get MDM connection. */
			mdmConn = conn->curParty;
			/* Get user data from connection */
			hMdmConn = (RvIppConnectionHandle)mdmConn;
			userData = mdmConn->userData;
		}
		else
		{
			hMdmConn = NULL;
			userData = NULL;
		}

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPostMsgReceivedEv() - before user callback (hCallLeg=%p, hMdmConn=%p, hMsg=%p, user data=%p)",
			hCallLeg, hMdmConn, hMsg, userData));

		/*Call user callback*/
		sipExtClbks.postMsgReceivedCB(hCallLeg, hMdmConn, (RvMtfConnAppHandle)userData, hMsg);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfPostMsgReceivedEv() - after user callback"));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "rvIppSipExtPostMsgReceivedCB() - application did not register this callback"));
	}

	/*Check if call-leg state was changed by user*/
    checkStateChanged(state, "rvIppSipExtPostMsgReceivedCB", hCallLeg);
}


/******************************************************************************
*  rvIppSipExtPostMsgReceivedCB
*  ---------------------------------
*  General :        Calls user callback to be called when RvSipTransmitterRegExpResolutionNeededEvHandler event
*                   is received from the stack, after it is processed by MTF.
*                   First it calls the deprecated callback, if not registered it calls the
*					regular one.
*
*  Return Value:   None.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          sipMgrHndl              handle of SipControl object
*                  hTrxMgr	               handle of transmitter manager
*                  pAppTrxMgr		       handle of transmitter manager application handle
*				   hTrx					   handle of transmitter object
*				   hAppTrx				   handle of transmitter application handle
*				   pRegExpParams		   pointer to structure with regular expression to be resolved
*
*  Output:         none.
******************************************************************************/
RvStatus RvIppSipExtRegExpResolutionNeededCB(
                IN RvIppSipControlHandle                        sipMgrHndl,
                IN  RvSipTransmitterMgrHandle                   hTrxMgr,
                IN  void*                                       pAppTrxMgr,
                IN  RvSipTransmitterHandle                      hTrx,
                IN  RvSipAppTransmitterHandle                   hAppTrx,
                INOUT RvSipTransmitterRegExpResolutionParams*   pRegExpParams)
{
    RvCCConnection* conn = (RvCCConnection *)hAppTrx;
    void* userData = sipExtClbksDeprecated.userData;
	RvStatus rv = RV_OK;

    if (conn != NULL)
    {
        userData = conn->userData;
    }

    if (sipExtClbksDeprecated.transmitterRegExpResolutionNeededF != NULL)
    {
        RvLogDebug(ippLogSource, (ippLogSource,
            "RvIppSipExtRegExpResolutionNeededCB() - before user callback (sipMgr=%p,hTrxMgr=%p,pAppTrxMgr=%p,hTrx=%p,hAppTrx=%p,pRegExpParams=%p, userData=%p)",
					sipMgrHndl, hTrxMgr, pAppTrxMgr, hTrx, hAppTrx, pRegExpParams, userData));

        rv = sipExtClbksDeprecated.transmitterRegExpResolutionNeededF(sipMgrHndl, hTrxMgr, pAppTrxMgr, hTrx, (RvIppConnectionHandle)conn, pRegExpParams,
            sipExtClbksDeprecated.userData);

        RvLogDebug(ippLogSource, (ippLogSource, "RvIppSipExtRegExpResolutionNeededCB() - after user callback (res=%d)", rv));
    }
	else if (sipExtClbks.regExpResolutionNeededCB != NULL)
	{

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegExpResolutionNeededEv() - before user callback (hTrxMgr=%p,hTrx=%p,pRegExpParams=%p)",
			hTrxMgr, hTrx, pRegExpParams));

		/*Call user callback*/
		rv = sipExtClbks.regExpResolutionNeededCB(hTrxMgr, hTrx, pRegExpParams);

		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfRegExpResolutionNeededEv() - after user callback (res=%d)", rv));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvIppSipExtRegExpResolutionNeededCB() - application did not register this callback"));
	}

	return rv;

}

/*-----------------------------------------------------------------------*/
/*                      SUBSCRIPTION    CALLBACKS                        */              
/*-----------------------------------------------------------------------*/
/***************************************************************************
 * RvMtfSubsStateChangedCB
 * -----------------------
 * General: Calls user callback to inform about a Subscription State Change
 *          
 * Arguments:
 * Input:     hSubs    - The sip stack subscription handle
 *            hAppSubs - The application handle for this subscription.
 *            eState   - The new subscription state.
 *            eReason  - The reason for the state change.
 *
 * Return Value:     RV_OK on success, error code otherwise
 ***************************************************************************/
RvStatus  RvMtfSubsStateChangedCB(
								  IN  RvSipSubsHandle            hSubs,
								  IN  RvSipAppSubsHandle         hAppSubs,
								  IN  RvSipSubsState             eState,
								  IN  RvSipSubsStateChangeReason eReason)
{
	RvStatus rv = RV_OK;
	if (sipExtClbks.subsClbks.subsStateChangedCB != NULL)
	{
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsStateChangedEv() - before user callback (hSubs=%p,hAppSubs=%p,eState=%d, eReason=%d)",
			hAppSubs, hAppSubs, eState, eReason));
		
		/*Call user callback*/
		rv = sipExtClbks.subsClbks.subsStateChangedCB(hSubs, hAppSubs, eState, eReason);
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsStateChangedEv() - after user callback (res=%d)", rv));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsStateChangedEv() - application did not register this callback"));
	}
	
	return rv;
}

/***************************************************************************
 * RvMtfSubsSubscriptionExpiredCB
 * ------------------------------
 * General: This callback is invoked whenever the MTF is informed about
 *          a Subscription expiration 
 *          
 * Arguments:
 * Input:     hSubs    - The sip stack subscription handle
 *            hAppSubs - The application handle for this subscription.
 *
 * Return Value:     RV_OK on success, error code otherwise
 ***************************************************************************/
RvStatus  RvMtfSubsSubscriptionExpiredCB(
						IN  RvSipSubsHandle            hSubs,
						IN  RvSipAppSubsHandle         hAppSubs)
{
	RvStatus rv = RV_OK;

	if (sipExtClbks.subsClbks.subsSubscriptionExpiredCB != NULL)
	{
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsSubscriptionExpiredEv() - before user callback (hSubs=%p,hAppSubs=%p)",
			hAppSubs, hAppSubs));
		
		/*Call user callback*/
		rv = sipExtClbks.subsClbks.subsSubscriptionExpiredCB(hSubs, hAppSubs);
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsSubscriptionExpiredEv() - after user callback (res=%d)", rv));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsSubscriptionExpiredEv() - application did not register this callback"));
	}
	
	return rv;
}

/***************************************************************************
 * RvMtfSubsExpirationAlertCB 
 * --------------------------
 * General: This callback is invoked whenever the MTF is alerted that
 *          a Subscription is about to expire
 * Arguments:
 * Input:     hSubs    - The sip stack subscription handle
 *            hAppSubs - The application handle for this subscription.
 *
 * Return Value:     RV_OK on success, error code otherwise
 ***************************************************************************/
RvStatus  RvMtfSubsExpirationAlertCB(
						IN  RvSipSubsHandle            hSubs,
						IN  RvSipAppSubsHandle         hAppSubs)
{
	RvStatus rv = RV_OK;
	
	if (sipExtClbks.subsClbks.subsExpirationAlertCB != NULL)
	{
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsExpirationAlertEv() - before user callback (hSubs=%p,hAppSubs=%p)",
			hAppSubs, hAppSubs));
		
		/*Call user callback*/
		rv = sipExtClbks.subsClbks.subsExpirationAlertCB(hSubs, hAppSubs);
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsExpirationAlertEv() - after user callback (res=%d)", rv));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsExpirationAlertEv() - application did not register this callback"));
	}
	
	return rv;
}

/****************************************************************************
 * RvMtfSubsNotifyCB
 * -----------------
 * General:
 *	Indicates the status of a NOTIFY. The NOTIFY status will include the
 *	received NOTIFY message, and its related notification object
 *	handle. 
 *
 *
 * Arguments:
 * Input:   hSubs            - The SIP Stack subscription handle.
 *          hAppSubs         - The application handle for this subscription.
 *          hNotification    - The SIP Stack notification object handle.
 *          hAppNotification - hAppNotification - The application handle for this notification. (relevant
 *                             only for a notifier subscription, which set the hAppNotification
 *                             in RvSipSubsCreateNotify().
 *          eNotifyStatus    - The status of the notification object.
 *          eNotifyReason    - The reason for the indicated status.
 *          hNotifyMsg       - The received message (NOTIFY request).
 *
 * Return Value:     RV_OK on success, error code otherwise
 ****************************************************************************/
RvStatus  RvMtfSubsNotifyCB(
					IN  RvSipSubsHandle			hSubs,
				    IN  RvSipAppSubsHandle		hAppSubs,
					IN  RvSipNotifyHandle		hNotification,
					IN  RvSipAppNotifyHandle	hAppNotification,
					IN  RvSipSubsNotifyStatus	eNotifyStatus,
					IN  RvSipSubsNotifyReason	eNotifyReason,
					IN  RvSipMsgHandle			hNotifyMsg)

{
	RvStatus rv = RV_OK;
	
	if (sipExtClbks.subsClbks.subsNotifyCB != NULL)
	{
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsNotifyEv() - before user callback (hSubs=%p,hAppSubs=%p, hNotification=%p, hAppNotification=%p, eNotifyStatus=%d, eNotifyReason=%d)",
			hAppSubs, hAppSubs, hNotification, hAppNotification, eNotifyStatus, eNotifyReason));
		
		/*Call user callback*/
		rv = sipExtClbks.subsClbks.subsNotifyCB(hSubs, hAppSubs, hNotification, hAppNotification,
			                                    eNotifyStatus, eNotifyReason, hNotifyMsg);
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsNotifyEv() - after user callback (res=%d)", rv));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsNotifyEv() - application did not register this callback"));
	}
	
	return rv;
}

/*******************************************************************************
 * RvMtfSubsCreatedDueToForkingCB
 * ------------------------------
 * General:
 *	Notifies the application of the creation of a forked subscription. A forked
 *  subscription is created as the result of the arrival of a NOTIFY message
 *  that was sent in response to a forked SUBSCRIBE request. For information
 *  about forking determination criteria, see sections 3.3.3 and 4.4.9 of
 *  RFC 3265.
 *
 *
 * Arguments:
 * Input:   hSubs       - The handle to the created forked Subscription.
 *          pExpires    - A pointer to the expiration value of the subscription
 *                        This value should be set in seconds. If the value was
 *                        not determined, it will be set to -1.
 *                        The value cannot be determined if it was not set in
 *                        the original Subscription. In this case,
 *                        the application should supply the value to limit
 *                        the life cycle of the forked subscription.
 *                        The RvSipSubsUpdateSubscriptionTimer() function can
 *                        be also used for this purpose. On expiration,
 *                        the expiration callback will be called for the forked
 *                        subscription.
 * Output:  pExpires    - A pointer to the memory where the application can set
 *                        the expiration value.
 *          phAppSubs   - The handle that the application sets
 *                        for the subscription.
 *          pRejectStatus-If Application decides to terminate this Subscription
 *                        it should set the pointer to point to positive
 *                        integer, representing Error Code. In this case Stack
 *                        will respond to the NOTIFY with error code and
 *                        will free Subscription object and
 *                        all the Subscription related resources.
 *
 * Return Value:     RV_OK on success, error code otherwise
 ******************************************************************************/
RvStatus  RvMtfSubsCreatedDueToForkingCB(
						IN        RvSipSubsHandle    hSubs,
						INOUT     RvInt32            *pExpires,
						OUT       RvSipAppSubsHandle *phAppSubs,
                        OUT       RvUint16           *pRejectStatus)

{
	RvStatus rv = RV_OK;
	
	if (sipExtClbks.subsClbks.subsCreatedDueToForkingCB != NULL)
	{
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsCreatedDueToForkingEv() - before user callback (hSubs=%p,*pExpires=%d, *phAppSubs=%p, *pRejectStatus=%d)",
			hSubs, *pExpires, *phAppSubs, *pRejectStatus));
		
		/*Call user callback*/
		rv = sipExtClbks.subsClbks.subsCreatedDueToForkingCB(hSubs, pExpires, phAppSubs, pRejectStatus);
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsCreatedDueToForkingEv() - after user callback (res=%d)", rv));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsCreatedDueToForkingEv() - application did not register this callback"));
	}
	
	return rv;
}
/*******************************************************************************
* RvMtfSubsMsgToSendEv
* --------------------
* General:
*	Notifies the application that an outgoing SUBCRIBE message or NOTIFY
*  response (which is related to its components) is about to be sent.
* Arguments:
* Input:     hSubs -      The sip stack subscription handle
*            hAppSubs -   The application handle for this subscription.
*            hNotify -    The notify object handle (relevant only for notify message)
*            hAppNotify - The application notify object handle (relevant only for notify message)
*            hMsg -       Handle to the outgoing message.
*
* Return Value: RvStatus. Returning RV_ERROR_XXX will cease the sending of
 *                         the message.
 ******************************************************************************/
RvStatus  RvMtfSubsMsgToSendCB(
					IN    RvSipSubsHandle      hSubs,
					IN    RvSipAppSubsHandle   hAppSubs,
					IN    RvSipNotifyHandle    hNotify,
					IN    RvSipAppNotifyHandle hAppNotify,
					IN    RvSipMsgHandle       hMsg)
									
{
	RvStatus rv = RV_OK;
	
	if (sipExtClbks.subsClbks.subsMsgToSendCB != NULL)
	{
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsMsgToSendEv() - before user callback (hSubs=%p,hAppSubs=%p hNotify=%p, hAppNotify=%p, hMsg=%p)",
			hAppSubs, hAppSubs, hNotify, hAppNotify, hMsg));
		
		/*Call user callback*/
		rv = sipExtClbks.subsClbks.subsMsgToSendCB(hSubs, hAppSubs, hNotify, hAppNotify, hMsg);
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsMsgToSendEv() - after user callback (res=%d)", rv));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsMsgToSendEv() - application did not register this callback"));
	}
	
	return rv;
}

/***************************************************************************
 * RvMtfSubsMsgReceivedEv (RvMtfSipExtPkg)
 * ------------------------------------------------------------------------
 * General:
 * Notifies the application that an incoming NOTIFY message or SUBSCRIBE
 * response (which is related to its components) was received.
 *
 * Arguments:
 * Input:     hSubs -      The sip stack subscription handle
 *            hAppSubs -   The application handle for this subscription.
 *            hNotify -    The notify object handle (relevant only for notify message)
 *            hAppNotify - The application notify object handle (relevant only for notify message)
 *            hMsg -       Handle to the incoming message.
 * Return Value: One of the following:
 *				 - RV_MTF_IGNORE_BY_STACK �
 *				   This value indicates to both the SIP Stack and the MTF
 *				   to ignore the message. 
 *				 - RV_MTF_IGNORE_BY_MTF �
 *				   This value indicates to the MTF to ignore the message,
 *				   but the SIP Stack will still process it.
 *				 - RV_MTF_DONT_IGNORE �
 *				   This value indicates to both the SIP Stack and the MTF
 *				   to process the message.
 ******************************************************************************/
RvMtfMsgProcessType RvMtfSubsMsgReceivedCB(
							IN  RvSipSubsHandle      hSubs,
							IN  RvSipAppSubsHandle   hAppSubs,
							IN  RvSipNotifyHandle    hNotify,
							IN  RvSipAppNotifyHandle hAppNotify,
                            IN  RvSipMsgHandle       hMsg)
							   
{
	RvMtfMsgProcessType rv = RV_MTF_DONT_IGNORE;
	
	if (sipExtClbks.subsClbks.subsMsgReceivedCB != NULL)
	{
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsMsgReceivedEv() - before user callback (hSubs=%p,hAppSubs=%p hNotify=%p, hAppNotify=%p, hMsg=%p)",
			hAppSubs, hAppSubs, hNotify, hAppNotify, hMsg));
		
		/*Call user callback*/
		rv = sipExtClbks.subsClbks.subsMsgReceivedCB(hSubs, hAppSubs, hNotify, hAppNotify, hMsg);
		
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsMsgReceivedEv() - after user callback (res=%d)", rv));
	}
	else
	{
		RvLogDebug(ippLogSource,(ippLogSource, "RvMtfSubsMsgReceivedEv() - application did not register this callback"));
	}
	
	return rv;
}
/*-----------------------------------------------------------------------
                    U T I L I T Y       F U N C T I O N S
 ------------------------------------------------------------------------*/

/******************************************************************************
*  getMtfApplicationHandle()
*  ---------------------------------
*  General : This function returns application data associated with MTF instance.
*
*  Return Value:   pointer to application data associated with MTF instance.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:			None
*
*  Output:         none.
******************************************************************************/
static RvMtfAppHandle getMtfApplicationHandle()
{
	RvCCProvider* p = rvCCBasePhoneGetMdmProvider();
	RvMtfBaseMgr* mtfMgr = rvGetMtfMgrByTermMgr(rvCCProviderMdmGetTermMgr(p));

	return mtfMgr->userData;

}

/******************************************************************************
*  checkStateChanged()
*  ---------------------------------
*  General : This function checks whether call-leg state changed or not.
*
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:			origState		-      original state
*					funcName		-	   function name (used for printing log)
*					hCallLeg		-	   handle to call-leg
*
*  Output:         none.
******************************************************************************/
static void checkStateChanged(
    IN RvSipCallLegState    origState,
    IN const RvChar*        funcName,
    IN RvSipCallLegHandle   hCallLeg)
{
    RvSipCallLegState newState;

    /*Check if user had changed call-leg state*/
    RvSipCallLegGetCurrentState(hCallLeg, &newState);

    if (origState != newState)
    {
        RvLogInfo(ippLogSource, (ippLogSource,
            "%s - State Changed: Call-Leg = %p OrigState = %s NewState = %s",
            funcName, hCallLeg, rvSipControlGetCallLegStateName(origState),
            rvSipControlGetCallLegStateName(newState)));
    }
}

/******************************************************************************
*  isStrEmpty
*  ---------------------------------
*  General : This function checks if string is empty or NULL.
*
*                   .
*
*  Return Value:   True is empty, False if not.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          str	- string to check
*
*  Output:         none.
******************************************************************************/
static RvBool isStrEmpty(char* str)
{
    if ((str == NULL) || (!strcmp(str, "")))
        return RV_TRUE;

    return RV_FALSE;
}


/******************************************************************************
*  isDifferentStr
*  ---------------------------------
*  General : This function checks whether oldStr is different from newStr, and if so,
*			 sets outStr to the value of newStr.
*
*  Return Value:   True if different, False if not.
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          oldStr	- old string
*				   newStr	- new string
*
*  Output:         outStr - output string
******************************************************************************/
static RvBool isDifferentStr(char* oldStr, char* newStr, char* outStr)
{
    if (isStrEmpty(oldStr)) {
        if (isStrEmpty(newStr)) {
            return RV_FALSE;
        }
        else {
            strcpy(outStr, newStr);
            return RV_TRUE;
        }
    }

    else if (!isStrEmpty(oldStr)) {
        if (isStrEmpty(newStr)) {
            strcpy(outStr, "None");
            return RV_TRUE;
        }
        else if (strcmp(oldStr, newStr)) {
            strcpy(outStr, newStr);
            return RV_TRUE;
        }
    }

    return RV_FALSE;
}


/******************************************************************************
*  stackConfigValidate
*  ---------------------------------
*  General :        This function validates the stack configuration changed by the user.
*                   It checks for logical validation only, illegal values will be checked
*                   by the stack.
*                   The allowed parameters are copied from pStackCfgNew to pStackCfgOld and
*                   thus override the default values, while blocked parameters are not copied
*                   at all.
*
*  Return Value:   None
*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          pStackCfgOld - IPP TK default configuration
*                  pStackCfgNew - User configuration
*
*  Output:         pStackCfgOld - will include user values for allowed parameters
*                                 and default values for blocked parameters.
******************************************************************************/
static void stackConfigValidate(RvSipStackCfg* pStackCfgOld, RvSipStackCfg* pStackCfgNew)
{
#define RV_IPP_SIP_ADDRESS_LEN          48
#define RV_IPP_MIN_CALL_LEGS             1
#define RV_IPP_MIN_TRANSACTIONS         10
#define RV_IPP_MIN_REG_CLIENTS           2
#define RV_IPP_MIN_MSG_NUM_PAGES        10
#define RV_IPP_MIN_MSG_PAGE_SIZE       512
#define RV_IPP_MIN_GENERAL_NUM_PAGES     5
#define RV_IPP_MIN_GENERAL_PAGE_SIZE   512
#define RV_IPP_MIN_SENDRECV_BUF_SIZE  1024

    char newVal[RV_LONG_STR_SZ];
	RvChar          tempList[128] = {""};
	RvBool          addComma = RV_FALSE;

    RvLogInfo(ippLogSource,(ippLogSource, "Checking User Configuration..."));

    /*Checking Compilation Flags*/
    /*--------------------------*/
#ifdef EXPRESS_EXTRA_LEAN
    RvLogInfo(ippLogSource,(ippLogSource, "stackConfigValidate - EXPRESS_EXTRA_LEAN = on"));
#endif
#ifdef RV_IPV6
    RvLogInfo(ippLogSource,(ippLogSource, "stackConfigValidate - RV_IPV6 = on"));
#endif
#ifdef RV_DNS_ENHANCED_FEATURES_SUPPORT
    RvLogInfo(ippLogSource,(ippLogSource, "stackConfigValidate - RV_DNS_ENHANCED_FEATURES_SUPPORT = on"));
#endif
#ifdef RV_TLS_ON
    RvLogInfo(ippLogSource,(ippLogSource, "stackConfigValidate - RV_TLS_ON = on"));
#endif
#ifdef RV_NOTHREADS
    RvLogInfo(ippLogSource,(ippLogSource, "stackConfigValidate - RV_NOTHREADS = on"));
#endif

    /*Checking Configuration Parameters*/
    /*---------------------------------*/

    /* The max callLeg number must not be lower than RV_IPP_MIN_CALL_LEGS */

    if (pStackCfgNew->maxCallLegs < RV_IPP_MIN_CALL_LEGS)
    {
        RvLogInfo(ippLogSource,(ippLogSource, "stackConfigValidate - maxCallLegs is set to minimum: %d", RV_IPP_MIN_CALL_LEGS));
        pStackCfgOld->maxCallLegs = RV_IPP_MIN_CALL_LEGS;
    }
    else if (pStackCfgOld->maxCallLegs != pStackCfgNew->maxCallLegs)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - maxCallLegs = %d", pStackCfgNew->maxCallLegs));
        pStackCfgOld->maxCallLegs = pStackCfgNew->maxCallLegs;
    }

    if (pStackCfgOld->maxTransactions != pStackCfgNew->maxTransactions)
    {
        if (pStackCfgNew->maxTransactions < RV_IPP_MIN_TRANSACTIONS)
        {
            pStackCfgOld->maxTransactions = RV_IPP_MIN_TRANSACTIONS;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - maxTransactions is set to minimum: %d", RV_IPP_MIN_TRANSACTIONS));
        }
        else
        {
            pStackCfgOld->maxTransactions = pStackCfgNew->maxTransactions;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - maxTransactions = %d", pStackCfgNew->maxTransactions));
        }
    }

    if (pStackCfgOld->maxRegClients != pStackCfgNew->maxRegClients)
    {
        if (pStackCfgNew->maxRegClients < RV_IPP_MIN_REG_CLIENTS)
        {
            pStackCfgOld->maxRegClients = RV_IPP_MIN_REG_CLIENTS;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - maxRegClients is set to minimum: %d", RV_IPP_MIN_REG_CLIENTS));
        }
        else
        {
            pStackCfgOld->maxRegClients = pStackCfgNew->maxRegClients;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - maxRegClients = %d", pStackCfgNew->maxRegClients));
        }
    }

    if (pStackCfgOld->messagePoolNumofPages != pStackCfgNew->messagePoolNumofPages)
    {
        if (pStackCfgNew->messagePoolNumofPages < RV_IPP_MIN_MSG_NUM_PAGES)
        {
            pStackCfgOld->messagePoolNumofPages = RV_IPP_MIN_MSG_NUM_PAGES;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - messagePoolNumofPages is set to minimum: %d", RV_IPP_MIN_MSG_NUM_PAGES));
        }
        else
        {
            pStackCfgOld->messagePoolNumofPages = pStackCfgNew->messagePoolNumofPages;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - messagePoolNumofPages = %d", pStackCfgNew->messagePoolNumofPages));
        }
    }

    if (pStackCfgOld->messagePoolPageSize != pStackCfgNew->messagePoolPageSize)
    {
        if (pStackCfgNew->messagePoolPageSize < RV_IPP_MIN_MSG_PAGE_SIZE)
        {
            pStackCfgOld->messagePoolPageSize = RV_IPP_MIN_MSG_PAGE_SIZE;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - messagePoolPageSize is set to minimum: %d", RV_IPP_MIN_MSG_PAGE_SIZE));
        }
        else
        {
            pStackCfgOld->messagePoolPageSize = pStackCfgNew->messagePoolPageSize;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - messagePoolPageSize = %d", pStackCfgNew->messagePoolPageSize));
        }
    }

    if (pStackCfgOld->generalPoolNumofPages != pStackCfgNew->generalPoolNumofPages)
    {
        if (pStackCfgNew->generalPoolNumofPages < RV_IPP_MIN_GENERAL_NUM_PAGES)
        {
            pStackCfgOld->generalPoolNumofPages = RV_IPP_MIN_GENERAL_NUM_PAGES;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - generalPoolNumofPages is set to minimum: %d", RV_IPP_MIN_GENERAL_NUM_PAGES));
        }
        else
        {
            pStackCfgOld->generalPoolNumofPages = pStackCfgNew->generalPoolNumofPages;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - generalPoolNumofPages = %d", pStackCfgNew->generalPoolNumofPages));
        }
    }

    if (pStackCfgOld->generalPoolPageSize != pStackCfgNew->generalPoolPageSize)
    {
        if (pStackCfgNew->generalPoolPageSize < RV_IPP_MIN_GENERAL_PAGE_SIZE)
        {
            pStackCfgOld->generalPoolPageSize = RV_IPP_MIN_GENERAL_PAGE_SIZE;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - generalPoolPageSize is set to minimum: %d", RV_IPP_MIN_GENERAL_PAGE_SIZE));
        }
        else
        {
            pStackCfgOld->generalPoolPageSize = pStackCfgNew->generalPoolPageSize;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - generalPoolPageSize = %d", pStackCfgNew->generalPoolPageSize));
        }
    }

    if (pStackCfgOld->tcpEnabled != pStackCfgNew->tcpEnabled)
    {
        pStackCfgOld->tcpEnabled = pStackCfgNew->tcpEnabled;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - tcpEnabled = %d", pStackCfgNew->tcpEnabled));
    }

    if (pStackCfgOld->maxConnections != pStackCfgNew->maxConnections)
    {
        pStackCfgOld->maxConnections = pStackCfgNew->maxConnections;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - maxConnections = %d", pStackCfgNew->maxConnections));
    }

    if (pStackCfgOld->ePersistencyLevel != pStackCfgNew->ePersistencyLevel)
    {
        pStackCfgOld->ePersistencyLevel = pStackCfgNew->ePersistencyLevel;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - ePersistencyLevel = %d", pStackCfgNew->ePersistencyLevel));
    }

    if (pStackCfgOld->serverConnectionTimeout != pStackCfgNew->serverConnectionTimeout)
    {
        pStackCfgOld->serverConnectionTimeout = pStackCfgNew->serverConnectionTimeout;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - serverConnectionTimeout = %d", pStackCfgNew->serverConnectionTimeout));
    }

    /*if (isDifferentStr(pStackCfgOld->outboundProxyIpAddress, pStackCfgNew->outboundProxyIpAddress, newVal)) {
        RvSnprintf(logstr, sizeof(logstr), "stackConfigValidate - outboundProxyIpAddress = %s", newVal);
        RvLogInfo(ippLogSource,(ippLogSource,logstr));

        strncpy(pStackCfgOld->outboundProxyIpAddress, pStackCfgNew->outboundProxyIpAddress, RV_IPP_SIP_ADDRESS_LEN);
        pStackCfgOld->outboundProxyIpAddress[RV_IPP_SIP_ADDRESS_LEN-1]='\0';
    }*/

    if (isDifferentStr(pStackCfgOld->outboundProxyHostName, pStackCfgNew->outboundProxyHostName, newVal))
    {
        pStackCfgOld->outboundProxyHostName = pStackCfgNew->outboundProxyHostName;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - outboundProxyHostName = %s", newVal));
    }

    /*if (pStackCfgOld->outboundProxyPort != pStackCfgNew->outboundProxyPort) {
        RvSnprintf(logstr, sizeof(logstr), "stackConfigValidate - outboundProxyPort = %d",pStackCfgNew->outboundProxyPort);
        RvLogInfo(ippLogSource,(ippLogSource,logstr));

        pStackCfgOld->outboundProxyPort = pStackCfgNew->outboundProxyPort;
    }*/

    if (pStackCfgOld->eOutboundProxyTransport != pStackCfgNew->eOutboundProxyTransport)
    {
        pStackCfgOld->eOutboundProxyTransport = pStackCfgNew->eOutboundProxyTransport;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - eOutboundProxyTransport = %d", pStackCfgNew->eOutboundProxyTransport));
    }

    if (pStackCfgOld->sendReceiveBufferSize != pStackCfgNew->sendReceiveBufferSize)
    {
        if (pStackCfgNew->sendReceiveBufferSize < RV_IPP_MIN_SENDRECV_BUF_SIZE)
        {
            pStackCfgOld->sendReceiveBufferSize = RV_IPP_MIN_SENDRECV_BUF_SIZE;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - sendReceiveBufferSize is set to minimum: %d", RV_IPP_MIN_SENDRECV_BUF_SIZE));
        }
        else
        {
            pStackCfgOld->sendReceiveBufferSize = pStackCfgNew->sendReceiveBufferSize;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - sendReceiveBufferSize = %d", pStackCfgNew->sendReceiveBufferSize));
        }
    }

    if (pStackCfgOld->bUseRportParamInVia != pStackCfgNew->bUseRportParamInVia)
    {
        pStackCfgOld->bUseRportParamInVia = pStackCfgNew->bUseRportParamInVia;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - bUseRportParamInVia = %d", pStackCfgNew->bUseRportParamInVia));
    }

    if (pStackCfgOld->processingQueueSize != pStackCfgNew->processingQueueSize)
    {
        pStackCfgOld->processingQueueSize = pStackCfgNew->processingQueueSize;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - processingQueueSize = %d", pStackCfgNew->processingQueueSize));
    }

    if (pStackCfgOld->numOfReadBuffers != pStackCfgNew->numOfReadBuffers)
    {
        pStackCfgOld->numOfReadBuffers = pStackCfgNew->numOfReadBuffers;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - numOfReadBuffers = %d", pStackCfgNew->numOfReadBuffers));
    }

    if (pStackCfgOld->retransmissionT1 != pStackCfgNew->retransmissionT1)
    {
        pStackCfgOld->retransmissionT1 = pStackCfgNew->retransmissionT1;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - retransmissionT1 = %d", pStackCfgNew->retransmissionT1));
    }

    if (pStackCfgOld->retransmissionT2 != pStackCfgNew->retransmissionT2)
    {
        pStackCfgOld->retransmissionT2 = pStackCfgNew->retransmissionT2;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - retransmissionT2 = %d", pStackCfgNew->retransmissionT2));
    }

    if (pStackCfgOld->generalLingerTimer != pStackCfgNew->generalLingerTimer)
    {
        pStackCfgOld->generalLingerTimer = pStackCfgNew->generalLingerTimer;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - generalLingerTimer = %d", pStackCfgNew->generalLingerTimer));
    }

    if (pStackCfgOld->inviteLingerTimer != pStackCfgNew->inviteLingerTimer)
    {
        pStackCfgOld->inviteLingerTimer = pStackCfgNew->inviteLingerTimer;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - inviteLingerTimer = %d", pStackCfgNew->inviteLingerTimer));
    }

    if (pStackCfgOld->provisionalTimer != pStackCfgNew->provisionalTimer)
    {
        pStackCfgOld->provisionalTimer = pStackCfgNew->provisionalTimer;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - provisionalTimer = %d", pStackCfgNew->provisionalTimer));
    }

    if (pStackCfgOld->retransmissionT4 != pStackCfgNew->retransmissionT4)
    {
        pStackCfgOld->retransmissionT4 = pStackCfgNew->retransmissionT4;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - retransmissionT4 = %d", pStackCfgNew->retransmissionT4));
    }

    if (pStackCfgOld->cancelGeneralNoResponseTimer != pStackCfgNew->cancelGeneralNoResponseTimer)
    {
        pStackCfgOld->cancelGeneralNoResponseTimer = pStackCfgNew->cancelGeneralNoResponseTimer;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - cancelGeneralNoResponseTimer = %d", pStackCfgNew->cancelGeneralNoResponseTimer));
    }

    if (pStackCfgOld->cancelInviteNoResponseTimer != pStackCfgNew->cancelInviteNoResponseTimer)
    {
        pStackCfgOld->cancelInviteNoResponseTimer = pStackCfgNew->cancelInviteNoResponseTimer;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - cancelInviteNoResponseTimer = %d", pStackCfgNew->cancelInviteNoResponseTimer));
    }

    if (pStackCfgOld->generalRequestTimeoutTimer != pStackCfgNew->generalRequestTimeoutTimer)
    {
        pStackCfgOld->generalRequestTimeoutTimer = pStackCfgNew->generalRequestTimeoutTimer;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - generalRequestTimeoutTimer = %d", pStackCfgNew->generalRequestTimeoutTimer));
    }

    if (pStackCfgOld->maxElementsInSingleDnsList != pStackCfgNew->maxElementsInSingleDnsList)
    {
        pStackCfgOld->maxElementsInSingleDnsList = pStackCfgNew->maxElementsInSingleDnsList;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - maxElementsInSingleDnsList = %d", pStackCfgNew->maxElementsInSingleDnsList));
    }

    if (pStackCfgOld->maxSubscriptions != pStackCfgNew->maxSubscriptions)
    {
        pStackCfgOld->maxSubscriptions = pStackCfgNew->maxSubscriptions;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - maxSubscriptions = %d", pStackCfgNew->maxSubscriptions));
    }

    if (pStackCfgOld->subsAlertTimer != pStackCfgNew->subsAlertTimer)
    {
        pStackCfgOld->subsAlertTimer = pStackCfgNew->subsAlertTimer;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - subsAlertTimer = %d", pStackCfgNew->subsAlertTimer));
    }

    if (pStackCfgOld->subsNoNotifyTimer != pStackCfgNew->subsNoNotifyTimer)
    {
        pStackCfgOld->subsNoNotifyTimer = pStackCfgNew->subsNoNotifyTimer;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - subsNoNotifyTimer = %d", pStackCfgNew->subsNoNotifyTimer));
    }

    if (pStackCfgOld->subsAutoRefresh != pStackCfgNew->subsAutoRefresh)
    {
        pStackCfgOld->subsAutoRefresh = pStackCfgNew->subsAutoRefresh;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - subsAutoRefresh = %d", pStackCfgNew->subsAutoRefresh));
    }

    if (pStackCfgOld->processingTaskPriority != pStackCfgNew->processingTaskPriority)
    {
        pStackCfgOld->processingTaskPriority = pStackCfgNew->processingTaskPriority;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - processingTaskPriority = %d", pStackCfgNew->processingTaskPriority));
    }

    if (pStackCfgOld->numOfDnsDomains != pStackCfgNew->numOfDnsDomains)
    {
        RvUint16 index = 0;
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - numOfDnsDomains = %d", pStackCfgNew->numOfDnsDomains));

        for (index = 0; index < pStackCfgNew->numOfDnsDomains; index++ )
        {
            RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - Dns Domain[%d] = %s",index,pStackCfgNew->pDnsDomains[index]));
        }

        pStackCfgOld->numOfDnsDomains   = pStackCfgNew->numOfDnsDomains;
        pStackCfgOld->pDnsDomains       = pStackCfgNew->pDnsDomains;
    }

    if (pStackCfgOld->numOfDnsServers != pStackCfgNew->numOfDnsServers)
    {
        RvUint16 index = 0;
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - numOfDnsServers = %d",pStackCfgNew->numOfDnsServers));

        for (index = 0; index < pStackCfgNew->numOfDnsServers; index++ )
        {
            RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - Dns Server[%d] = %s",index,pStackCfgNew->pDnsServers[index].strIP ));
        }

        pStackCfgOld->numOfDnsServers = pStackCfgNew->numOfDnsServers;
        pStackCfgOld->pDnsServers     = pStackCfgNew->pDnsServers;
    }

    if (pStackCfgOld->sessionExpires != pStackCfgNew->sessionExpires)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - sessionExpires = %d",pStackCfgNew->sessionExpires));

        pStackCfgOld->sessionExpires    = pStackCfgNew->sessionExpires;
    }


    if (pStackCfgOld->minSE != pStackCfgNew->minSE)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - minSE = %d",pStackCfgNew->minSE));

        pStackCfgOld->minSE = pStackCfgNew->minSE;
    }

/*   Merge both config supportedExtensionLists */

	if (pStackCfgOld->supportedExtensionList == NULL)
	{
		RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate:: supportedExtensionList must be initialized by calling proc"));
	}
	else
	{
		strcpy(tempList, pStackCfgOld->supportedExtensionList);
		addComma = RV_TRUE;
	
		if ((pStackCfgNew->supportedExtensionList != NULL) &&
			(strcmp(pStackCfgOld->supportedExtensionList, pStackCfgNew->supportedExtensionList)))
		{
			if (addComma == RV_TRUE)
			{
				strcat(tempList, ",");
			}
			strcat(tempList, pStackCfgNew->supportedExtensionList);		
		}
	}

	strcpy(pStackCfgOld->supportedExtensionList,tempList); 

    if (pStackCfgOld->localUdpAddresses != pStackCfgNew->localUdpAddresses)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - localUdpAddresses = %d",pStackCfgNew->localUdpAddresses));

        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - first UDP address = %s",pStackCfgNew->localUdpAddresses[0]));

        pStackCfgOld->localUdpAddresses = pStackCfgNew->localUdpAddresses;
    }

    if (pStackCfgOld->localUdpPorts != pStackCfgNew->localUdpPorts)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - localUdpPorts = %d",pStackCfgNew->localUdpPorts));

        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - first UDP port = %s",pStackCfgNew->localUdpPorts[0]));

        pStackCfgOld->localUdpPorts = pStackCfgNew->localUdpPorts;
    }

    if (pStackCfgOld->localTcpAddresses != pStackCfgNew->localTcpAddresses)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - localTcpAddresses = %d",pStackCfgNew->localTcpAddresses));

        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - first TCP address = %s",pStackCfgNew->localTcpAddresses[0]));

        pStackCfgOld->localTcpAddresses = pStackCfgNew->localTcpAddresses;
    }

    if (pStackCfgOld->localTcpPorts != pStackCfgNew->localTcpPorts)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - localTcpPorts = %d",pStackCfgNew->localTcpPorts));

        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - first TCP port = %s",pStackCfgNew->localTcpPorts[0]));

        pStackCfgOld->localTcpPorts = pStackCfgNew->localTcpPorts;
    }

    if(pStackCfgOld->bDisableMerging != pStackCfgNew->bDisableMerging)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - bDisableMerging = %d",pStackCfgNew->bDisableMerging));
        pStackCfgOld->bDisableMerging     = pStackCfgNew->bDisableMerging;
    }

    /* For Tel-URI*/
    if (isDifferentStr(pStackCfgOld->strDialPlanSuffix, pStackCfgNew->strDialPlanSuffix, newVal))
    {
        pStackCfgOld->strDialPlanSuffix = pStackCfgNew->strDialPlanSuffix;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - strDialPlanSuffix = %s", newVal));
    }

    if(pStackCfgOld->pfnPrintLogEntryEvHandler != pStackCfgNew->pfnPrintLogEntryEvHandler)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - pfnPrintLogEntryEvHandler = %p",pStackCfgNew->pfnPrintLogEntryEvHandler));
        pStackCfgOld->pfnPrintLogEntryEvHandler     = pStackCfgNew->pfnPrintLogEntryEvHandler;
    }

	if(pStackCfgOld->rejectUnsupportedExtensions != pStackCfgNew->rejectUnsupportedExtensions)
    {
        RvLogInfo(ippLogSource,(ippLogSource,"stackConfigValidate - rejectUnsupportedExtensions = %d",pStackCfgNew->pfnPrintLogEntryEvHandler));
        pStackCfgOld->rejectUnsupportedExtensions     = pStackCfgNew->rejectUnsupportedExtensions;
    }

#ifdef RV_CFLAG_TLS
    if (rvIppTlsStackConfigValidate(pStackCfgOld, pStackCfgNew) != RV_OK)
    {
        RvLogWarning(ippLogSource,(ippLogSource, "TlsStackConfig: parameters were setting to deafult"));
    }
#endif

#ifdef RV_SIP_IMS_ON

    if (pStackCfgOld->maxSecAgrees != pStackCfgNew->maxSecAgrees)
    {
        
            pStackCfgOld->maxSecAgrees = pStackCfgNew->maxSecAgrees;
            RvLogInfo(ippLogSource, (ippLogSource,
                "stackConfigValidate - maxSecAgrees = %d", pStackCfgNew->maxSecAgrees));
    }

	if (pStackCfgOld->maxSecurityObjects != pStackCfgNew->maxSecurityObjects)
    {
        
		pStackCfgOld->maxSecurityObjects = pStackCfgNew->maxSecurityObjects;
		RvLogInfo(ippLogSource, (ippLogSource,
			"stackConfigValidate - maxSecurityObjects = %d", pStackCfgNew->maxSecurityObjects));
    }
   
#endif

	if (pStackCfgOld->defaultLogFilters != pStackCfgNew->defaultLogFilters)
    {
        
		pStackCfgOld->defaultLogFilters = pStackCfgNew->defaultLogFilters;
		RvLogInfo(ippLogSource, (ippLogSource,
			"stackConfigValidate - defaultLogFilters = %d", pStackCfgNew->defaultLogFilters));
    }

#ifdef RV_MTF_SIMPLE_ON
	if (pStackCfgOld->maxPubClients != pStackCfgNew->maxPubClients)
    {
        pStackCfgOld->maxPubClients = pStackCfgNew->maxPubClients;
        RvLogInfo(ippLogSource, (ippLogSource,
            "stackConfigValidate - maxPubClients = %d", pStackCfgNew->maxPubClients));
    }
	
#endif

    RvLogInfo(ippLogSource,(ippLogSource, "Checking User Configuration Done. All Other Parameters Are Ignored."));
}



