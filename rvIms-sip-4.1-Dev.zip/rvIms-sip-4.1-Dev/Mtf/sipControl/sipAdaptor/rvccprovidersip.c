/******************************************************************************
Filename   : rvccprovidersip.c
Description: Implements Sip Provider Object
******************************************************************************
                Copyright (c) 2001 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_SIPCONTROL
#include "ipp_inc_std.h"
#include "ippmisc.h"

#include "RvSipCSeqHeader.h"
#include "RvSipOtherHeader.h"
#include "RvSipHeader.h"
#include "rvccprovidersip.h"
#include "rvccterminalsip.h"
#include "rvccconnsip.h"
#ifdef RV_MTF_VIDEO
#include "rvccconnsipvideo.h"
#endif
#include "rvccapi.h"
#include "rvmdm.h"
#include "rvccconnmdm.h"
#include "rvcccall.h"
#include "rvsdpmedia.h"
#include "rvsdpenc.h"
#include "CallLegObject.h"
#include "RvSipCallLegTypes.h"
#include "rvMtfPhone.h"
#include "MsgTypes.h"

#ifdef RV_SIP_IMS_ON
#include "rvAkaAuth.h"
#endif
/*Globals*/

extern HRPOOL   g_appPool;
extern RvSipControl* g_sipControl;
RvCCProvider* g_sipProvider;
typedef RvVectorIter(RvMdmMediaStreamInfo) RvMdmMediaStreamInfoVectorIter;
rvDeclareFindIf(RvVectorIter, RvMdmMediaStreamInfo)

extern int Psip_IsHandleInviteWithReferby(RvSipCallLegHandle hCallLeg);
extern int PSip_SetFinalResponseCode(RvSipMsgHandle  hMsg, unsigned int statuscode);



/*===============================================================================*/
/*================== I N T E R N A L    F U N C T I O N S   =====================*/
/*===============================================================================*/
static RV_Status handleOfferingState(RvCCConnection* c, RvSipCallLegHandle hCallLeg,
                                    RvCCTerminalEvent*  event,
                                    RvSipCallLegStateChangeReason reason);

static RvBool HandleReferDecline( RvCCConnection* c);

static void rvInitConnFuncs(RvCCProviderSip* x)
{
    RvCCConnectionFuncs* funcs = &x->connFuncs;

    memset(funcs, 0, sizeof(RvCCConnectionFuncs));
    funcs->acceptF = rvCCConnSipAccept;
    funcs->rejectF = rvCCConnSipReject;
    funcs->ringbackF = rvCCConnSipRingback;
    funcs->disconnectF = rvCCConnSipDisconnecting;
    funcs->getMediaF = rvCCConnSipGetMedia;
    funcs->getMediaCapsF = rvCCConnSipGetMediaCaps;
    funcs->makeCallF = rvCCConnSipMakeCall;
    funcs->callAnsweredF = rvCCConnSipCallAnswered;
    funcs->createMediaF = rvCCConnSipCreateMedia;
    funcs->setRemoteMediaF = rvCCConnSipSetRemoteMedia;
    funcs->remoteHoldF = rvCCConnSipRemoteHold;
    funcs->remoteUnholdF = rvCCConnSipRemoteUnhold;
    funcs->holdF = rvCCConnSipHold;
    funcs->unholdF = rvCCConnSipUnhold;
    funcs->getCallerIdF = rvCCConnSipGetCallerId;
    funcs->getCallerNameF = rvCCConnSipGetCallerName;
    funcs->getCallerAddressF = rvCCConnSipGetCallerAddress;
    funcs->getCallerNumberF = rvCCConnSipGetCallerNumber;
    funcs->transferInitF = rvCCConnSipTransferInit;
    funcs->transferInProgressF = rvCCConnSipTransferInProgress;
    funcs->playDtmfF = rvCCConnSipPlayDtmf;
    funcs->terminateF = rvCCConnSipTerminate;
	funcs->releaseF = rvCCConnSipRelease;
    funcs->modifyMediaF         = rvCCConnSipModifyMedia;
    funcs->modifyMediaDoneF     = rvCCConnSipModifyMediaDone;
    funcs->processTermEventF = rvCCConnSipProcessEvent;
    funcs->forwardCallF =       rvCCConnSipForwardCall;
	funcs->getProtocolIdF = rvCCConnSipGetProtocolId;
	funcs->getRemoteDisplayNameF = rvCCConnSipGetRemoteDisplayName;
	funcs->getRemotePhoneNumberF = rvCCConnSipGetRemotePhoneNumber;
	funcs->getRemoteUriF		 = rvCCConnSipGetRemoteUri;
}

static void rvInitConnCallbacks(RvCCProviderSip* x)
{
    RvCCConnectionClbks* clbks = &x->connClbks;

    memset(clbks, 0, sizeof(RvCCConnectionClbks));
    clbks->initiatedCB =        rvCCConnSipInitiatedCB;
    clbks->callDeliveredCB =    rvCCConnSipCallDeliveredCB;
    clbks->offeredCB =          rvCCConnSipOfferedCB;
    clbks->transferInitCB =     rvCCConnSipTransferInitCB;
    clbks->transferOfferedCB =  rvCCConnSipTransferOfferedCB;
    clbks->mediaCreatedCB =     rvCCConnSipMediaCreatedCB;

    clbks->mediaUpdatedCB =     rvCCCallMediaUpdatedCB;
    clbks->mediaModifiedCB      =   rvCCCallModifyMediaCB;
    clbks->mediaModifiedDoneCB  =   rvCCCallModifyMediaDoneCB;

    /*those will be registered by application:*/
    /*clbks->addressAnalyzeCB */
    /*clbks->inProcessCB */
}

static void handleConnectedState(RvCCConnection* c, RvSipCallLegHandle hCallLeg,
                                RvCCTerminalEvent*  event, RvCCEventCause* cause)
{
    RvCCConnection* transferLine;

    RV_UNUSED_ARG(hCallLeg);

    if (rvCCConnSipIsRejectCall(c))
    {
        /*Can't reject the call at this stage, can only disconnect*/
        *event = RV_CCTERMEVENT_DISCONNECTING;
        *cause = RV_CCCAUSE_MEDIA_NOT_SUPPORTED;
    }
    else
    {
        *event = RV_CCTERMEVENT_CALLANSWERED;
        *cause = RV_CCCAUSE_OUTGOING_CALL;

        /* Find a better place if you can to reset transferLine on B */
        transferLine = rvCCConnectionGetTransferLine(rvCCConnectionGetConnectParty(c));
        if (transferLine != NULL)
        {
           /* transferLine is set on A and B while calling to C.
              on A: transferLine is SIP connection of B and has a connect Party,
              on B: transferLine does NOT have Connect Party because it was moved
                    out from B-A call to B-C call.
            */
            RvCCConnection *cParty = rvCCConnectionGetConnectParty(transferLine);
            if (cParty == NULL)
            {
                /* This is EP B. The B-C call is connected, the transferLine can be removed.*/
/* crash on B during blind transfer                rvCCConnectionSetTransferLine(cParty, NULL);*/
                rvCCConnectionSetTransferLine(c, NULL);
            }
        }

    }
}

static void handleAcceptedState(RvCCConnection* c, RvSipCallLegHandle hCallLeg)
{
    if (rvCCConnSipIsRejectCall(c))
    {
        /*SDP is not valid or not supported*/
        rvSipControlReject(hCallLeg, RV_SIPCTRL_STATUS_NOTACCEPTABLE);
    }
}

/***************************************************************************
 * isHoldUnholdMsg
 * ------------------------------------------------------------------------
 * General:  Check if an SDP message contains indication for hold or if the
 *           connection is in a held state therefore it should be set unhold.
 *
 * Return Value: RV_OK - any of states is identified
 * ------------------------------------------------------------------------
 * Arguments:
 * input   : c  - a pointer to the connection staructure
 *           sdpMsg - a pointer to an SDP of a modify request message
 ***************************************************************************/
static RvBool isHoldUnholdMsg(RvCCConnection* c, RvSdpMsg* sdpMsg)
{
	RvBool  rv = RV_FALSE;

	if (rvCCConnMdmIsReInviteForHold(c, sdpMsg))
	{
		rv = RV_TRUE;
	}
	else
	{
		/* Get the MDM connection as an MDM proc is about to be called */
		RvCCConnection* party = rvCCConnectionGetConnectParty(c);
		rv =  rvCCConnMdmIsReInviteForUnhold(party);
	}

	return rv;
}

/***************************************************************************
 * callLegRemoveAllAuthObjFromList
 * ------------------------------------------------------------------------
 * General:  Remove the old auth-obj from the call-leg list.
 *
 * Return Value: RV_OK - if successful. error code o/w
 * ------------------------------------------------------------------------
 * Arguments:
 * input   : hCallLeg - Handle to the call-leg, holding the auth-obj list.
 ***************************************************************************/
static RvStatus callLegRemoveAllAuthObjFromList(RvSipCallLegHandle hCallLeg)
{
    RvSipAuthObjHandle hAuthobj = NULL;

    RvSipCallLegAuthObjGet(hCallLeg, RVSIP_FIRST_ELEMENT, NULL, &hAuthobj) ;
    while (hAuthobj != NULL)
    {
        RvSipCallLegAuthObjRemove(hCallLeg, hAuthobj);
		RvLogDebug(ippLogSource,(ippLogSource,"callLegRemoveAllAuthObjFromList:: Removing auth header 0x%p from CallLeg 0x%p",
				                  hAuthobj, hCallLeg));
        /* look for the first elemet again since we removed the previous first element */
        RvSipCallLegAuthObjGet(hCallLeg, RVSIP_FIRST_ELEMENT, NULL, &hAuthobj) ;
    }
    return RV_OK;
}

/***************************************************************************
* callLegRemoveOldAuthObjFromList
* ------------------------------------------------------------------------
* General:  Remove the old auth-obj from the call-leg list.
*           There are two types of auth headers: proxy-authenticate and
*           www-authenticate.
*           The last Auth object of each type in the list is the latest, all the
*           other objects are removed.
* Return Value: RV_OK - if successful. error code o/w
* ------------------------------------------------------------------------
* Arguments:
* input   : hCallLeg - Handle to the call-leg, holding the auth-obj list.
***************************************************************************/
static RvStatus callLegRemoveOldAuthObjFromList(RvSipCallLegHandle hCallLeg)
{
    RvSipAuthObjHandle hNextAuthobj    = NULL;
	RvSipAuthObjHandle hCurrentAuthobj = NULL;
	RvSipAuthObjHandle hProxyAuthobj   = NULL;
	RvSipAuthObjHandle hWwwAuthobj     = NULL;
	RvSipAuthenticationHeaderType eAuthHeaderType=RVSIP_AUTH_UNDEFINED_AUTHENTICATION_HEADER;
	RvSipAuthenticationHeaderHandle hAuthHeader=NULL;
	RvBool	isValid = RV_FALSE;

    RvSipCallLegAuthObjGet(hCallLeg, RVSIP_FIRST_ELEMENT, NULL, &hCurrentAuthobj) ;
	RvSipAuthObjGetAuthenticationHeader(hCurrentAuthobj,&hAuthHeader,&isValid);
	eAuthHeaderType = RvSipAuthenticationHeaderGetHeaderType(hAuthHeader);
	if (eAuthHeaderType == RVSIP_AUTH_WWW_AUTHENTICATION_HEADER)
	{
		hWwwAuthobj = hCurrentAuthobj;
	}
	else
	if (eAuthHeaderType == RVSIP_AUTH_PROXY_AUTHENTICATION_HEADER)
	{
		hProxyAuthobj = hCurrentAuthobj;
	}

	/* Loop over all auth objets */
    while (hCurrentAuthobj != NULL)
    {
		RvSipAuthObjHandle hRemoveAuthobj    = NULL;

		RvSipCallLegAuthObjGet(hCallLeg, RVSIP_NEXT_ELEMENT, hCurrentAuthobj, &hNextAuthobj) ;

		if (hNextAuthobj != NULL)
		{
			RvSipAuthObjGetAuthenticationHeader(hNextAuthobj,&hAuthHeader,&isValid);
			eAuthHeaderType = RvSipAuthenticationHeaderGetHeaderType(hAuthHeader);

			if (eAuthHeaderType == RVSIP_AUTH_WWW_AUTHENTICATION_HEADER)
			{
			/* found a www-authenticate header. If we have already found
				a previous one remove it and save a pointer to the new one */

				if (hWwwAuthobj != NULL)
				{
					hRemoveAuthobj =  hWwwAuthobj;
				}
				hWwwAuthobj = hNextAuthobj;
			}
			else
				if (eAuthHeaderType == RVSIP_AUTH_PROXY_AUTHENTICATION_HEADER)
				{
				/* found a proxy-authenticate header. If we have already found
					a previous one remove it and save a pointer to the new one */
					if (hProxyAuthobj != NULL)
					{
						hRemoveAuthobj =  hProxyAuthobj;
					}
					hProxyAuthobj = hNextAuthobj;
				}
				else
				{
					/* shouldn't happen but just in case */
					hRemoveAuthobj = hCurrentAuthobj;
				}
				if (hRemoveAuthobj != NULL)
				{
					/* this is not the last object of its type in the list, remove it */
					RvSipCallLegAuthObjRemove(hCallLeg, hCurrentAuthobj);
					RvLogDebug(ippLogSource,(ippLogSource,"callLegRemoveOldAuthObjFromList:: Removing auth header 0x%p from CallLeg 0x%p",
						hCurrentAuthobj, hCallLeg));
				}
		}
		hCurrentAuthobj = hNextAuthobj;
    }
    return RV_OK;
}


/***************************************************************************
 * needToAuthenticate
 * ------------------------------------------------------------------------
 * General: decide if we need to authenticate the connection
 *
 *
 * Return Value: True - need to authenticate, False - not authenticate.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   authHeader      - Handle the the authorization header
 *          c               - The connection handle
 *
 ***************************************************************************/
RvBool needToAuthenticateConn(
                          IN  RvSipAuthenticationHeaderHandle authHeader,
                          IN  RvCCConnection*                 c)

{
    RvBool              isNeedToAuthenticate    = RV_TRUE;
    RvStatus            status                  = RV_OK;
    char                rcvdNonce[RV_NAME_STR_SZ]   = "";
	RvUint16            authRetries             = 0;
	RvUint32            maxAuthRetries          = 0;

    /* get nonce from recv message */

    status = rvSipControlGetNonceFromAuthHeader(authHeader,rcvdNonce);

    if(status != RV_OK)
    {
        RvLogWarning(ippLogSource,(ippLogSource,"getConnNonceHeader:rvSipControlRegClientGetNonce Failed error %d", status));
        return RV_FALSE;
    }
    else
    {

        /* When the first unauthenticated message is received the stored nonce  */
        /* is NULL. in this case authentication is required.                    */
        /* In the next time there is already a previously stored nonce and we   */
        /* need to compare it to the new one. If the two nonces differ there is */
        /* a real authentication problem and there is no point trying to        */
        /* authenticate any further. There is a mismatch in the user name or    */
        /* password.                                                            */
        isNeedToAuthenticate = !rvSipControlIsSameNonce(rcvdNonce,rvCCConnSipGetNonce(c));
    }

    if (isNeedToAuthenticate==RV_TRUE)
    {
		/* check if there is a limitation for the number of times an authentication attempts can be made */
		if ((maxAuthRetries = rvSipControlGetMaxAuthenticateRetries(g_sipControl)) > 0)
		{
			authRetries = rvCCConnSipGetCallAuthRetriesCount(c);
			if (authRetries < maxAuthRetries)
			{
				rvCCConnSipSetCallAuthRetriesCount(c, (RvUint16)(authRetries + 1));
			}
			else
			{
				/* no more authentication trials are allowed */
				isNeedToAuthenticate = rvFalse;
				RvLogError(ippLogSource,(ippLogSource,"needToAuthenticate: Registration failed: can't send another register msg, num of retries (%d) was exceeded",maxAuthRetries));
			}
		 }
        rvCCConnSipSetNonce(c,rcvdNonce);
    }
    else
    {
        RvLogWarning(ippLogSource,(ippLogSource,"connAuthenticate mismatch user or password"));
    }

	if (isNeedToAuthenticate == RV_FALSE)
	{
		/* Need to reset authorization parameters */
		rvCCProviderSipResetAuthParams(c);
	}

    return isNeedToAuthenticate;
} /* needToAuthenticateConn */

/***************************************************************************
 * rvCCProviderSipResetAuthParams
 * ------------------------------------------------------------------------
 * General: Reset some authorization parameters to get ready for the next
 *          request that may require authorization.
 *          The authorization headers are not cleared in this proc because
 *          it is invoked on failure or success. In case of failure there is
 *          no need to save the old authorization headers so the calling proc will
 *          clear them. In case of success (received OK) there is a need to keep
 *          these headers in order to add them to the next outgoing request.
 *
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   c               - The connection handle
 *          hCallLeg        - Handle to the callLeg
 *
 ***************************************************************************/
void rvCCProviderSipResetAuthParams(RvCCConnection*  c)
{
	if (rvCCConnSipGetCallAuthRetriesCount(c) > 0)
	{
		/* clear the Nonce */
		rvCCConnSipSetNonce(c,"");

		/* reset the CallAuthRetriesCount */
		rvCCConnSipSetCallAuthRetriesCount(c, 0);
	}
}

/***************************************************************************
 * rvCCProviderSipHandleUnauthenticateState
 * ------------------------------------------------------------------------
 * General: This proc is called as a result of an 401/407 unauthorized response
 *          that was received for an outgoing request. If RV_SIP_IMS_ON is set,
 *          it checks what algorithm is used for authentication - AKA or MD5.
 *          If AKA - the authorization header is changed with AKA credentials.
 *          Otherwise the header is not changed as the Sip Stack has already
 *          set it with MD5 values.
 *          The calling proc can choose
 *
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   c          -  A pointer to the connection
 *          hCallLeg   -  The sip stack call-leg handle
 *          sendTheMsg -  Indicationg whether to send the message
 ***************************************************************************/
RvBool rvCCProviderSipHandleUnauthenticateState(
								RvCCConnection*     c,
								RvSipCallLegHandle  hCallLeg,
                            	RvBool              sendTheMsg)
{
    RvCCTerminal*               t                   = rvCCConnSipGetTerminal(c);
    RvCCTerminalSip*            term;
    RvStatus                    rv;
    RvSipAppCallLegHandle       hAppCallLegHandle;
	RvSipMsgHandle              hMsg, outbMsg;
	RvSipHeaderListElemHandle   hListElem;
	RvSipAuthenticationHeaderHandle authHeader;
#ifdef RV_SIP_IMS_ON
	RvBool                      isAkaAlgorithm = RV_FALSE;
#endif

    rv = RvSipCallLegGetAppHandle(hCallLeg,&hAppCallLegHandle);
	if(hAppCallLegHandle == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipHandleUnauthenticateState::Application handle = NULL Call: %p", hCallLeg));
		goto err_exit;
	}

    /* The following 'if' prevents a crash (exception) in   */
    /* cases where the terminal is Null.                    */
    if (t != NULL)
    {
        term = rvCCTerminalSipGetImpl(t);
    }
    else
    {
        RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipHandleUnauthenticateState:: Null terminal"));
        goto err_exit;
    }

    if ((rv = RvSipCallLegGetReceivedMsg((RvSipCallLegHandle)hCallLeg, &hMsg)) != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"fail to get RecvMsg Handle callHandel = %p",hCallLeg));
        goto err_exit;
    }
    else
    {
        /* get the auth header from the receive message*/
        authHeader = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_AUTHENTICATION,
                                             RVSIP_FIRST_HEADER, &hListElem);
        if(authHeader == NULL)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvSipControlGetCallLegNonce::RvSipMsgGetHeaderByType fail"));
            goto err_exit;
        }
	}

	/* Check if there is a change in the nonce field of the authentication header since the last time
	   authentication was required. If there wasn't a change or of the number of authorization re-attempt
	   exceeded the limkt, there is no point in authorizing again */
	if (needToAuthenticateConn(authHeader,c) == RV_FALSE)
	{
		goto err_exit;
	}

	/* If the user has configured the removeOldAuthHeader parameter, do so */
	if (g_sipControl->removeOldAuthHeaders)
	{
		callLegRemoveOldAuthObjFromList(hCallLeg);
	}

	/* Add route headers if needed */
    RvSipCallLegGetOutboundMsg(hCallLeg, &outbMsg);
    rvSipControlSetRouteHeaderInMsg(hCallLeg, (RvCCConnection*)hAppCallLegHandle, outbMsg);


#ifdef RV_SIP_IMS_ON

	/* Check what is the authentication algorithm - MD5 or AKA-MD5.
	   Currently the message has an MD5 authorization header that was built by the Sip Stack.
	   If the algorithm is AKA there is a need to change the authorization header fields.
	*/
	if (!g_sipControl->imsControl.disableAkaAuthentication)
	{
		isAkaAlgorithm = rvAkaAuthIsAkaAlgorithmInAuthHeader(authHeader);

		if (isAkaAlgorithm)
		{
			/* AKA Authentication */
			rv = rvAkaAuthHandleCallLegUnauthState(hCallLeg, term);
			if (rv != RV_OK)
			{
				RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipHandleUnauthenticateState::Failed to AKA Authenticate Call: 0x%p, result=%d, conn=%p", hCallLeg, rv, c));
				return RV_FALSE;
			}
			else
			{
				RvLogInfo(ippLogSource,(ippLogSource,"rvCCProviderSipHandleUnauthenticateState:: AKA Authentication for call leg 0x%p was sent", hCallLeg));
			}
		}
	}
	else
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvCCProviderSipHandleUnauthenticateState:: AKA Authentication is disabled, using MD5 for call leg 0x%p ", hCallLeg));
	}

#endif
	/* Check if the calling proc requested to send the message */
	if (sendTheMsg)
	{
        rv = RvSipCallLegAuthenticate(hCallLeg);
        if (rv != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipHandleUnauthenticateState::Failed to Authenticate Call: 0x%p, result=%d, conn=%p", hCallLeg, rv, c));
			return RV_FALSE;
        }
        else
        {
            RvLogInfo(ippLogSource,(ippLogSource,"rvCCProviderSipHandleUnauthenticateState:: MD5 Authentication for call leg 0x%p was sent", hCallLeg));
		}
	}

    return RV_TRUE;
err_exit:
	/* Clear all the authentication headers that have been added to the callLeg on each
	   authorization attempt. They are not needed anymore. */
	callLegRemoveAllAuthObjFromList(hCallLeg);
	return RV_FALSE;

}


static void handleDisconnectedState(
                                    RvSipCallLegHandle              hCallLeg,
                                    RvSipCallLegStateChangeReason   reason,
                                    RvCCTerminalEvent*              event,
                                    RvCCEventCause*                 cause)
{
    RvSipMsgHandle          phMsg;
    RV_INT16                statusCode = 0;
    switch (reason)
    {
        case RVSIP_CALL_LEG_REASON_REQUEST_FAILURE:
			/* Handle 4xx response. It gets a special attention for the BUSY responses only. */
            RvSipCallLegGetReceivedMsg(hCallLeg,&phMsg);
            if (phMsg!=NULL)
            {
                statusCode = RvSipMsgGetStatusCode(phMsg);
                switch(statusCode)
                {
                    /*busy*/
                    case RV_SIPCTRL_STATUS_TEMPUNAVAIL:/*Unavailable temporarily*/
                    case RV_SIPCTRL_STATUS_BUSYHERE:
                        *event = RV_CCTERMEVENT_DISCONNECTING;
                        *cause = RV_CCCAUSE_BUSY;
                        break;

                    default:
                        *event = RV_CCTERMEVENT_DISCONNECTING;
                        break;
                }
            }
            break;

		case RVSIP_CALL_LEG_REASON_GLOBAL_FAILURE:
			/* Handle 6xx response. */
			*event = RV_CCTERMEVENT_DISCONNECTING;

            RvSipCallLegGetReceivedMsg(hCallLeg,&phMsg);
            if (phMsg != NULL)
            {
                statusCode = RvSipMsgGetStatusCode(phMsg);
                switch(statusCode)
                {
				case RV_SIPCTRL_STATUS_NOTEXISTANYWHERE:
					*cause = RV_CCCAUSE_REORDER_TONE;
					break;
				case RV_SIPCTRL_STATUS_NOTACCEPTABLE:
					*cause = RV_CCCAUSE_MEDIA_NOT_SUPPORTED;
					break;
				case RV_SIPCTRL_STATUS_BUSYEVERYWHERE:
				case RV_SIPCTRL_STATUS_DECLINE:
				default:
					*cause = RV_CCCAUSE_BUSY;
					break;
				}
			}
            break;

        case RVSIP_CALL_LEG_REASON_DISCONNECTED: /*response for bye was received*/
/*      case RVSIP_CALL_LEG_REASON_LOCAL_CANCELLING: */ /*local party canceled*/
            *event = RV_CCTERMEVENT_DISCONNECTED;
            break;

        case RVSIP_CALL_LEG_REASON_LOCAL_DISCONNECTING:/*Local party sent BYE and is waiting for response.*/
            *event = RV_CCTERMEVENT_NONE;
            break;

        case RVSIP_CALL_LEG_REASON_LOCAL_TIME_OUT:
            *event = RV_CCTERMEVENT_DISCONNECTING;
/*          cause = RV_CCCAUSE_CALL_CANCELLED;*/
            break;

        default:
            *event = RV_CCTERMEVENT_DISCONNECTING;
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }
}

RvBool handleModifyMediaReceived(RvCCConnection*    c, RvSdpMsg* sdpMsg)
{
    RvBool callStillAlive;

    RvLogDebug(ippLogSource,(ippLogSource,"<-- handleModifyMediaReceived c(%p)",c));
    /* remove the previous new media (local and remote) and store the new
       remote media in the connection, .
       (in SIP conn the local media is stored in remote descriptor, and vice versa)*/
    rvMdmMediaStreamInfoClearRemote(&c->newMediaStream);
    rvMdmMediaStreamInfoClearLocal(&c->newMediaStream);

    if (sdpMsg != NULL)
        rvCCConnectionAddNewMediaLocalDescr(c, sdpMsg);

    rvCCConnSipProcessEvent(c, RV_CCTERMEVENT_MODIFYMEDIA, &callStillAlive, RV_CCCAUSE_NORMAL);

    RvLogDebug(ippLogSource,(ippLogSource,"--> handleModifyMediaReceived c(%p)",c));
    return RV_TRUE;
}


RvBool rvCCProviderSipHandleReinviteResponse(RvCCConnection*                c,
                            RvSipMsgHandle                  hMsg,
                            RvSipCallLegStateChangeReason   eReason)
{
    RvSdpMsg        sdpMsg;
    RvBool          callStillAlive;
    RvBool           rv;
    RvBool          holdUnhold;
    unsigned int        actlen;
    RvSdpParseStatus    stat=0;
    char    buf[1024];

    /* Check whether this is a response for Hold/Unhold, or for modify media*/
    holdUnhold = (rvCCConnectionGetMediaState(c) != RV_CCMEDIASTATE_MODIFYING);

    /* First, we check if body message is SDP (application/sdp), if not, we ignore it.
       If yes, we get the message body which is SDP as it was sent from the other endpoint, and store it
       in the SIP connection local new media.  */
    if ((rv = rvSipControlIsMediaBody(hMsg)) == RV_TRUE)
    {
		RvSipMsgGetBody(hMsg, buf, 1024, &actlen);

		if (actlen != 0)
		{
			if (rvSdpMsgConstructParseA(&sdpMsg, buf, (int*)&actlen, &stat, prvDefaultAlloc) != NULL)
			{
				rvMdmMediaStreamInfoClearLocal(&c->newMediaStream);
				rvCCConnectionAddNewMediaLocalDescr(c, &sdpMsg);
				rvSdpMsgDestruct(&sdpMsg);
			}
		}
    }

    if (holdUnhold)
		/* TODO: change stream mode according to connection state. See buildHoldUnholdSdpMsg() */
        return rv;

    if (eReason == RVSIP_CALL_LEG_REASON_REMOTE_ACCEPTED)
    {
        rvCCConnSipProcessEvent(c, RV_CCTERMEVENT_MODIFYMEDIA_DONE, &callStillAlive, RV_CCCAUSE_OPERATION_SUCCEEDED);
    }
    else
    {
        rvCCConnSipProcessEvent(c, RV_CCTERMEVENT_MODIFYMEDIA_DONE, &callStillAlive, RV_CCCAUSE_OPERATION_FAILED);

    }

    return RV_TRUE;
}

static void printConfigurationSip(RvMtfSipPhoneCfg* cfg)
{

	RvLogInfo(ippLogSource,(ippLogSource,"*******************************************************"));
    RvLogInfo(ippLogSource,(ippLogSource,"********** MTF SIP CONFIGURATION PARAMETERS: **********"));
	RvLogInfo(ippLogSource,(ippLogSource,"*******************************************************"));
#ifdef RV_SIP_IMS_ON
	RvLogInfo(ippLogSource,(ippLogSource,"********** MTF is compiled with IMS on"));
#endif
#ifdef RV_MTF_VIDEO
	RvLogInfo(ippLogSource,(ippLogSource,"********** MTF is compiled with VIDEO on"));
#endif

#ifdef RV_MTF_SECOND_VIDEO
	RvLogInfo(ippLogSource,(ippLogSource,"********** MTF is compiled with SECOND_VIDEO on"));
#endif

#ifdef RV_MTF_STUN
	RvLogInfo(ippLogSource,(ippLogSource,"********** MTF is compiled with STUN on"));
#endif

#ifdef RV_MTF_USE_CACHE_ALLOCATOR
	RvLogInfo(ippLogSource,(ippLogSource,"********** MTF is compiled with CACHE_ALLOCATOR on"));
#endif

#ifdef RV_MTF_SIMPLE_ON
	RvLogInfo(ippLogSource,(ippLogSource,"********** MTF is compiled with SIMPLE on"));
#endif

#ifdef RV_MTF_H323
	RvLogInfo(ippLogSource,(ippLogSource,"********** MTF is compiled with H.323 on"));
#endif

#if (RV_NET_TYPE & RV_NET_IPV6)
	RvLogInfo(ippLogSource,(ippLogSource,"********** MTF is compiled with IPV6 on"));
#endif

#ifdef RV_CFLAG_TLS
	RvLogInfo(ippLogSource,(ippLogSource,"********** MTF is compiled with TLS on"));
#endif

    RvLogInfo(ippLogSource,(ippLogSource,"********** Local Address			: %s", cfg->localAddress));
    RvLogInfo(ippLogSource,(ippLogSource,"********** Stack UDP Port			: %d", cfg->stackUdpPort));
    RvLogInfo(ippLogSource,(ippLogSource,"********** Stack TCP Port			: %d", cfg->stackTcpPort));
    RvLogInfo(ippLogSource,(ippLogSource,"********** Registrar Address		: %s", cfg->registrarAddress));
    RvLogInfo(ippLogSource,(ippLogSource,"********** Registrar Port			: %d", cfg->registrarPort));
    RvLogInfo(ippLogSource,(ippLogSource,"********** User Domain			: %s", cfg->userDomain));
    RvLogInfo(ippLogSource,(ippLogSource,"********** Outbound Proxy Address	: %s", cfg->outboundProxyAddress));
	RvLogInfo(ippLogSource,(ippLogSource,"********** numberOfLines			: %d", cfg->numberOfLines));
    RvLogInfo(ippLogSource,(ippLogSource,"********** Outbound Proxy Port	: %d", cfg->outboundProxyPort));
    RvLogInfo(ippLogSource,(ippLogSource,"********** Max Call Leg			: %d", cfg->maxCallLegs));
    RvLogInfo(ippLogSource,(ippLogSource,"********** Max Reg Client			: %d", cfg->maxRegClients));
    RvLogInfo(ippLogSource,(ippLogSource,"********** automatic Register		: %d", cfg->autoRegister));
#ifdef RV_SIP_IMS_ON
    RvLogInfo(ippLogSource,(ippLogSource,"********** PAccessNetworkInfo		: %s", cfg->imsSipPhoneCfg.PAccessNetworkInfo));
    RvLogInfo(ippLogSource,(ippLogSource,"********** IPSec PortC			: %d", cfg->imsSipPhoneCfg.ipsecPortC));
    RvLogInfo(ippLogSource,(ippLogSource,"********** IPSec PortS			: %d", cfg->imsSipPhoneCfg.ipsecPortS));
    RvLogInfo(ippLogSource,(ippLogSource,"********** disableAkaAuthentication:%d", cfg->disableAkaAuthentication));
    RvLogInfo(ippLogSource,(ippLogSource,"********** disableSecAgree		: %d", cfg->imsSipPhoneCfg.disableSecAgree));
    RvLogInfo(ippLogSource,(ippLogSource,"********** disableAkaAuthentication:%d", cfg->disableAkaAuthentication));
    RvLogInfo(ippLogSource,(ippLogSource,"********** disableSecAgree		: %d", cfg->imsSipPhoneCfg.disableSecAgree));
    RvLogInfo(ippLogSource,(ippLogSource,"********** IPSec SPI Range start	: %d", cfg->imsSipPhoneCfg.ipsecSpiRangeStart));
    RvLogInfo(ippLogSource,(ippLogSource,"********** IPSec SPI Range end	: %d", cfg->imsSipPhoneCfg.ipsecSpiRangeEnd));
#endif
    RvLogInfo(ippLogSource,(ippLogSource,"********** registrationExpire		: %d sec", cfg->registrationExpire));
    RvLogInfo(ippLogSource,(ippLogSource,"********** unregistrationExpire	: %d sec", cfg->unregistrationExpire));
	RvLogInfo(ippLogSource,(ippLogSource,"********** maxAuthenticateRetries	: %d ", cfg->maxAuthenticateRetries));
	RvLogInfo(ippLogSource,(ippLogSource,"********** removeOldAuthHeaders	: %d ", cfg->removeOldAuthHeaders));
    RvLogInfo(ippLogSource,(ippLogSource,"********** referTimeout			: %d msec", cfg->referTimeout));
    RvLogInfo(ippLogSource,(ippLogSource,"********** watchdogTimeout		: %d sec", cfg->watchdogTimeout));
    RvLogInfo(ippLogSource,(ippLogSource,"********** dialToneDuration		: %d msec", cfg->dialToneDuration));
    RvLogInfo(ippLogSource,(ippLogSource,"********** callWaitingReply		: %d", cfg->callWaitingReply));
	RvLogInfo(ippLogSource,(ippLogSource,"********** disableCallWaiting     : %d", cfg->disableCallWaiting));
	RvLogInfo(ippLogSource,(ippLogSource,"********** persistentRegisterEnabled: %d", cfg->persistentRegisterEnabled));
	RvLogInfo(ippLogSource,(ippLogSource,"********** persistentRegisterRetryInterval: %d", cfg->persistentRegisterRetryInterval));
	RvLogInfo(ippLogSource,(ippLogSource,"********** registerCompleteTimeout: %d", cfg->registerCompleteTimeout));
	RvLogInfo(ippLogSource,(ippLogSource,"********** sendOldHoldFormat      : %d", cfg->sendOldHoldFormat));
	RvLogInfo(ippLogSource,(ippLogSource,"********** addUpdateSupport       : %d", cfg->addUpdateSupport));
	if (cfg->addUpdateSupport == RV_TRUE)
	{
		RvLogInfo(ippLogSource,(ippLogSource,"********** updateRetryAfterTimeout	: %d", cfg->updateRetryAfterTimeout));
		RvLogInfo(ippLogSource,(ippLogSource,"********** callerUpdateResendTime		: %d", cfg->callerUpdateResendTimeout));
		RvLogInfo(ippLogSource,(ippLogSource,"********** calleeUpdateResendTime		: %d", cfg->calleeUpdateResendTimeout));
	}
	RvLogInfo(ippLogSource,(ippLogSource,"********** sesionTimerRefreshByUpdate: %d", cfg->sessionTimerRefreshByUpdate));
	RvLogInfo(ippLogSource,(ippLogSource,"********** sessionTimerMinimumAllowed: %d", cfg->sessionTimerMinimumAllowed));
	RvLogInfo(ippLogSource,(ippLogSource,"********** sessionTimerSessionExpires: %d", cfg->sessionTimerSessionExpires));
	RvLogInfo(ippLogSource,(ippLogSource,"********** connectMediaOn180		: %d", cfg->connectMediaOn180));
	RvLogInfo(ippLogSource,(ippLogSource,"********** autoAnswer				: %d", cfg->autoAnswer));
	RvLogInfo(ippLogSource,(ippLogSource,"********** autoDisconnect			: %d", cfg->autoDisconnect));
	RvLogInfo(ippLogSource,(ippLogSource,"********** addUserAgentHeader     : %d", cfg->addUserAgentHeader));
	RvLogInfo(ippLogSource,(ippLogSource,"********** manufacturerId         : %s", cfg->manufacturerId));
	RvLogInfo(ippLogSource,(ippLogSource,"********** productId              : %s", cfg->productId));
	RvLogInfo(ippLogSource,(ippLogSource,"********** productVersion         : %s", cfg->productVersion));
	RvLogInfo(ippLogSource,(ippLogSource,"********** outgoingRequestNoResponseTimeout: %d", cfg->outgoingRequestNoResponseTimeout));
	RvLogInfo(ippLogSource,(ippLogSource,"********** outgoingCallNoAnswerTimeout	 : %d", cfg->outgoingCallNoAnswerTimeout));
	RvLogInfo(ippLogSource,(ippLogSource,"********** acceptCallWhenUserNotFound	: %d", cfg->acceptCallWhenUserNotFound));

	switch (cfg->transportType)
	{
		case RVSIP_TRANSPORT_TCP:
			RvLogInfo(ippLogSource,(ippLogSource,"********** Transport Type       : TCP"));
		break;

		case RVSIP_TRANSPORT_UDP:
			RvLogInfo(ippLogSource,(ippLogSource,"********** Transport Type       : UDP"));
		break;

		case RVSIP_TRANSPORT_UNDEFINED:
			RvLogInfo(ippLogSource,(ippLogSource,"********** Transport Type       : Undefined"));
			break;
		default:
			RvLogWarning(ippLogSource,(ippLogSource,"********** Transport Type      : not supported (%d)", cfg->transportType));
			break;
    }
    RvLogInfo(ippLogSource,(ippLogSource,"********** Thread Priority        : %d", cfg->priority));
    RvLogInfo(ippLogSource,(ippLogSource,"********** tcpEnabled				: %d", cfg->tcpEnabled));

    RvLogInfo(ippLogSource,(ippLogSource,"********** username				: %s", cfg->username));
    RvLogInfo(ippLogSource,(ippLogSource,"********** password				: %s", cfg->password));
    RvLogInfo(ippLogSource,(ippLogSource,"********** debugLevel				: %d", cfg->debugLevel));
    RvLogInfo(ippLogSource,(ippLogSource,"********** outOfBandDtmf			: %d", cfg->outOfBandDtmf));
	RvLogInfo(ippLogSource,(ippLogSource,"********** Default Protocol Type  : %d", cfg->defaultProtocolType));

#ifdef RV_CFLAG_TLS
    RvLogInfo(ippLogSource,(ippLogSource,"********** TLS PARAMETERS *****************\n"));
    RvLogInfo(ippLogSource,(ippLogSource,"********** stackTlsAddress        : %s", cfg->transportTlsCfg.stackTlsAddress));
    RvLogInfo(ippLogSource,(ippLogSource,"********** stackTlsPort           : %d", cfg->transportTlsCfg.stackTlsPort));
    RvLogInfo(ippLogSource,(ippLogSource,"********** stackNumOfTlsAddresses : %d", cfg->transportTlsCfg.stackNumOfTlsAddresses));
    RvLogInfo(ippLogSource,(ippLogSource,"********** tlsPostConnectAssertFlag: %d", cfg->transportTlsCfg.tlsPostConnectAssertFlag));
    RvLogInfo(ippLogSource,(ippLogSource,"********** tlsMethod              : %d", cfg->transportTlsCfg.tlsMethod));
    RvLogInfo(ippLogSource,(ippLogSource,"********** privateKeyType         : %d", cfg->transportTlsCfg.privateKeyType));
    RvLogInfo(ippLogSource,(ippLogSource,"********** certDepth              : %d", cfg->transportTlsCfg.certDepth));
	RvLogInfo(ippLogSource,(ippLogSource,"********** Registrar Tls Port		: %d", cfg->transportTlsCfg.registrarTlsPort));
#endif

	RvLogInfo(ippLogSource,(ippLogSource,"*****************************************************\r\n"));

}

static void removeAllTerminals(RvCCProvider* p)
{
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(p);
    RvMapIter(RvCharPtr,RvCCTerminalPtr) iter;
    RvCCTerminal** pt;
    RvCCTerminal* t;

    for(iter = rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter != rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter = rvMapIterNext(iter))
    {
        pt = rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(iter);
        t = *pt;
        rvMtfAllocatorDealloc(t, sizeof(RvCCTerminal));
    }

    rvMapClear(&provider->terminals);
}
/*---------------------------------*/
/*
 *  This connection (A->B in callTransfer term) was previously put on hold.
 * We should resume the conversation with B
 * Return true if successfully resume connection else return false
 */
static RvBool HandleReferDecline( RvCCConnection* c)

{
    /*
     *  This connection (A->B in callTransfer term) was previously put on hold.
     * We should resume the conversation with B
     */
    if( (rvCCConnectionGetState(c) !=RV_CCCONNSTATE_DISCONNECTED)&&
        (rvCCConnectionGetTermState(c)==RV_CCTERMCONSTATE_HELD))
    {
        rvCCConnSipUnhold( c, NULL);
        return RV_TRUE;
    }
    else
        return RV_FALSE;
}
/*---------------------------------*/
/***************************************************************************
 * processMessageCode
 * ------------------------------------------------------------------------
 * General: This function processes the message according to the status code,
 *          (such as provisional response).
 *          An event will be sent to SIP Connection state machine if needed.
 *          This code was handled in msgReceived callback (moved from sipProviderMsgReceived_
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          c        -    Connection handle.
 * Output:
 *          event    -    event to be sent to state machine
 *          reason   -    reason to be sent to state machine
 *
 ***************************************************************************/
void processMessageCode(RvSipMsgHandle      phMsg,
                            RvCCConnection*     c,
                            RvCCTerminalEvent*  event,
                            RvCCEventCause*     cause)
{
    RV_INT16                statusCode = 0;

    *event = RV_CCTERMEVENT_NONE;

    statusCode = RvSipMsgGetStatusCode(phMsg);
    RvLogInfo(ippLogSource, (ippLogSource, "processMessageCode statusCode = %d", statusCode));

    switch (statusCode)
    {
        /*Provisional Response*/
    case RV_SIPCTRL_STATUS_TRYING:
        break;

    case RV_SIPCTRL_STATUS_FORWARDED:
        *cause = RV_CCCAUSE_NORMAL;
        break;
        /*No break*/
    case RV_SIPCTRL_STATUS_RINGING:
    case RV_SIPCTRL_STATUS_QUEUED: /*call waiting*/
    case RV_SIPCTRL_STATUS_SESSIONPROGRESS:
        if (statusCode == RV_SIPCTRL_STATUS_QUEUED )
            *cause = RV_CCCAUSE_CALL_WAITING;
        else
            *cause = RV_CCCAUSE_NORMAL;
        if (rvCCConnSipIsRejectCall(c))
        {
            /*SDP is not valid or not supported*/
            /*Can't reject the call at this stage, can only disconnect*/
            *event = RV_CCTERMEVENT_DISCONNECTING;
            *cause = RV_CCCAUSE_MEDIA_NOT_SUPPORTED;
    }
    else
        {   RvCCMediaState mediaState = rvCCConnectionGetMediaState(c);
            /* if we received a Session Progress (183) message with SDP
			   or Ringing (180) while connectMediaOn180 = 1, and media
		       is created/connected - we don't want to apply any ringing signal  */

			if  (!(((mediaState == RV_CCMEDIASTATE_CREATING) ||
				    (mediaState == RV_CCMEDIASTATE_CREATED)  ||
		            (mediaState == RV_CCMEDIASTATE_CONNECTED))
					&&
				   ((statusCode == RV_SIPCTRL_STATUS_SESSIONPROGRESS)||
				    ((statusCode == RV_SIPCTRL_STATUS_RINGING) &&
				     (g_sipControl->connectMediaOn180 == RV_TRUE)))))

            {
           		 *event = RV_CCTERMEVENT_RINGING;
            }
            
            /*zhangcg: 20110615 we don't apply ringing back signal if 183 received*/
            if(statusCode == RV_SIPCTRL_STATUS_SESSIONPROGRESS)
            {
                *event = RV_CCTERMEVENT_NONE;
            }
        }
        break;

    case RV_SIPCTRL_STATUS_DECLINE:
        {
            RvSipCSeqHeaderHandle       hCSeq;
            RvSipMethodType             method = RVSIP_METHOD_UNDEFINED;
            hCSeq = RvSipMsgGetCSeqHeader( phMsg);
            if( hCSeq !=NULL)
                method = RvSipCSeqHeaderGetMethodType( hCSeq);

            switch(method)
            {
                case RVSIP_METHOD_REFER:
                /*
                * We should accomplish a special work if it's decline upon REFER method.
                * Recipient. Call was held. To unhold one.
                * Final-recipient. Network connection is already closed while MDM connection persists. Close the last
                */
                    if(!HandleReferDecline( c))
                    {
                        *event = RV_CCTERMEVENT_REJECTCALL;
                        *cause = RV_CCCAUSE_BUSY;
                    }
                break;
                default:
                    *event = RV_CCTERMEVENT_REJECTCALL;
                    *cause = RV_CCCAUSE_BUSY;
            /*lint -e{788}  all relevant cases are accounted for */
            }
        }
        break;
    case RV_SIPCTRL_STATUS_NOTACCEPTABLE: /*Media not supported*/
        *event = RV_CCTERMEVENT_FAILGENERAL;
        *cause = RV_CCCAUSE_MEDIA_NOT_SUPPORTED;
        break;
    case RV_SIPCTRL_STATUS_MOVEDTEMP:
        break;
    case RV_SIPCTRL_STATUS_MOVEDPERM:
        break;
#ifdef RV_SIP_IMS_ON
	case RV_SIPCTRL_STATUS_EXT_REQUIRED:
		/*No break*/
	case RV_SIPCTRL_STATUS_SEC_AGREE_REQ:
		/* security agreement request received from server */
		*cause = RV_CCCAUSE_SECURITY_REQUIRED;
		*event = RV_CCTERMEVENT_FAILGENERAL;
		break;
#endif

    default:
        if ( (statusCode > RV_SIPCTRL_STATUS_MULTICHOISES) && /* >3xx */
		     /* 401 and 407 responses are not considered as failure */
		     (statusCode != RV_SIPCTRL_STATUS_UNAUTHORIZED) &&
		     (statusCode != RV_SIPCTRL_STATUS_PROXYAUTHREQ))
        {
            *event = RV_CCTERMEVENT_FAILGENERAL;
            *cause = RV_CCCAUSE_REORDER_TONE;
			
        }
    }

    if(statusCode > RV_SIPCTRL_STATUS_BADREQUEST)
    {      
	   PSip_SetFinalResponseCode(phMsg,statusCode);
    }
}

/***************************************************************************
 * handleModifyReceived
 * ------------------------------------------------------------------------
 * General: This function handles a received Re-Invite, and the reply.
 *          The Re-Invite is processed according to the following:
 *          1. Check if SDP body was received -
 *              - If no SDP body: reply with OK + SDP with all capabilities.
 *              - If body is invalid SDP: reply with error BADREQUEST
 *              - If body is valid SDP:
 *                  - Pass SDP to user app (by callback modifyMedia)
 *                  - If Re-Invite is a request for Hold/Unhold:
 *                      - Change indicators and states accordingly
 *          For backwords compatability we check Hold/Unhold in 2 ways:
 *          1. Check if ip address is set to 0.0.0.0 (according to RFC 2543).
 *          2. Check if connection mode is set to Send Only (according to RFC 3261).
 *
 *
 * Return Value: None
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg            - a handle to SIP message
 *          hCall           - call-leg stack handle
 *          hAppCallLeg     - call-leg application handle
 *
 *
 ***************************************************************************/
void rvCCProviderSipHandleReInviteReceived(RvSipMsgHandle          hMsg,
                            RvSipCallLegHandle      hCall,
                            RvSipAppCallLegHandle   hAppCallLeg)
{
    RvCCConnection*     c                   = (RvCCConnection*)hAppCallLeg;
    char                buf[1024];
    unsigned int        actlen;
    RvSdpMsg            sdpMsg;
    RvSdpMsg*           storedSdpMsg;
    RvSdpParseStatus    stat;
    RvSdpOrigin*        sdpMsgOrig              = NULL;
    RvSdpOrigin*        storedSdpMsgOrig        = NULL;
    RvBool              incomingSdpIsInvalid    = RV_FALSE;

    RvLogDebug(ippLogSource,(ippLogSource,"<-- rvCCProviderSipHandleReInviteReceived(hMsg(%p),hCall(%p),hAppCallLeg(%p),c(%p)",hMsg,hCall,hAppCallLeg,c));

    if (rvCCConnectionGetConnectParty(c) == NULL)
    { /* The party is null - Could happen during blind transfer after sending refer to B and waiting until B sends Notify.
		 In this stage the MTF can still receive re-invite or UPDATE but can't handle it. Send OK with no SDP
	 	 so that the request will be replied. */
        RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipHandleReInviteReceived: rvCCConnectionGetConnectParty faild %p", c));
        rvCCConnSipAccept(c, NULL);
		return;
    }

    /* First we check if we have a body, and if body is SDP (application/sdp), if not, we ignore it.*/
    if (((rvSipControlIsMediaBody(hMsg)) == RV_TRUE) &&
        ((RvSipMsgGetBody(hMsg, buf, 1024, &actlen)) == RV_Success))
    {
        /*Process Re-Invite + SDP message*/
        if (rvSdpMsgConstructParseA(&sdpMsg, buf, (int*)&actlen, &stat, prvDefaultAlloc) != NULL)
        {
              /* Get the previously received sdp */
              storedSdpMsg = rvCCConnSipGetMedia(c);
              if (storedSdpMsg != NULL)
              {
                  /* check if the origin version value has changed. If it has not, there is no need
                     to modify the media , just reply OK as before */
                  sdpMsgOrig = (RvSdpOrigin*)rvSdpMsgGetOrigin((RvSdpMsg*)(&sdpMsg));
                  if (sdpMsgOrig != NULL)
                  {
                      storedSdpMsgOrig = rvSdpMsgGetOrigin(storedSdpMsg);
                      if (!strcmp (rvSdpOriginGetVersion(sdpMsgOrig), rvSdpOriginGetVersion(storedSdpMsgOrig)))
                      {
						  /* If the version value has not changed this could be a hold/unhold message which
						     does not comply with the standard. We still want to handle it */
						  if (isHoldUnholdMsg(c, &sdpMsg) == RV_FALSE)
						  {
							  RvLogDebug(ippLogSource,(ippLogSource,
													   "rvCCProviderSipHandleReInviteReceived::No change in sdp version id from prev invite, media not modified for hCall(%p)",
													   hCall));
                            RvSdpMsg* media = rvCCConnectionGetMedia(rvCCConnectionGetConnectParty(c));
                            rvCCConnSipSetRemoteMedia(c, media, RV_TRUE);
							  rvCCConnSipAccept(c, rvCCConnSipGetMediaCaps(c));
							  rvSdpMsgDestruct(&sdpMsg);
							  return;
						  }
                      }
                  }
                  else
                  {
                      /* "v" line is empty or missing */
                      RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipHandleReInviteReceived: invalid sdp (v line is missing) hCall(%p)",hCall));
                      incomingSdpIsInvalid = RV_TRUE;
                  }

            }
            /*Check if SDP includes "m" lines*/
            if (rvSdpMsgGetNumOfMediaDescr(&sdpMsg) != 0)
            {
                /*Send SDP to user application*/
                handleModifyMediaReceived(c, &sdpMsg);
            }
            else
            {
                /* "m" lines are missing*/
                RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipHandleReInviteReceived: invalid sdp (m lines are missing) hCall(%p)",hCall));
                incomingSdpIsInvalid = RV_TRUE;
            }

            rvSdpMsgDestruct(&sdpMsg);
        }
        /* Body is invalid SDP*/
        else
        {
            RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipHandleReInviteReceived: invalid sdp (parsing failed) hCall(%p)",hCall));
            incomingSdpIsInvalid = RV_TRUE;
        }

        if (incomingSdpIsInvalid == RV_TRUE)
        {
			rvCCConnSipReject(c, RV_CCCAUSE_BAD_REQUEST);
        }
   }
       else
   		/*Body is empty or not SDP*/
       {
   		/* Receiving a re-invite msg without SDP means that the MTF is requested to send an offer.
   		   This situation is like a sending re-invite situation.
   		   The newMedia structs of the SIP and MDM connections are filled with the MTF media capabilities.
   		   The same media is attached to the OK response which is sent to the requesting agent.
   		   The agent's media answer will be attached to an ACK message */

   		RvMdmMediaStreamInfo   offeredMedia;
   		RvMdmStreamDescriptor* offerStreamDescr = NULL;
   		RvCCConnection*        party = rvCCConnectionGetConnectParty(c);
           RvSdpMsg               *sdpMsg = rvCCConnSipGetMediaCaps(c);
        /* xuyf, 2011/12/23, add for call transfer as server send invite without sdp, begin */   
        RvSdpMediaDescr     *descrOnsdpMsg;
        int n = rvSdpMsgGetNumOfMediaDescr( sdpMsg);
        int i;
        for(i=0; i < n; i++)
        {
            descrOnsdpMsg  = rvSdpMsgGetMediaDescr( sdpMsg, i);
            rvSdpMediaDescrSetConnectionMode( descrOnsdpMsg, RV_SDPCONNECTMODE_SENDRECV);
        }
        /* xuyf, 2011/12/23, add, end */
        rvMdmMediaStreamInfoConstructA(&offeredMedia, 0, prvDefaultAlloc);

   		offerStreamDescr = rvMdmMediaStreamInfoGetStreamDescriptor(&offeredMedia);

   		rvMdmStreamDescriptorAddRemoteDescriptor(offerStreamDescr, sdpMsg);
   	    rvMdmStreamDescriptorSetMode(offerStreamDescr, RV_MDMSTREAMMODE_SENDRECV);

   		/* set the  current media stream in the new media field of the MDM  and SIP connections
   		   to be delt with when ACK is received */
   		rvCCConnectionSetNewMedia(c, &offeredMedia);
   		/* Since in SIP conn the local media is stored in remote descriptor,
               and vice versa, we need to switch between them before we store it in the MDM conn*/
        rvCCConnSipSwitchLocalAndRemote(&offeredMedia);
   		rvCCConnectionSetNewMedia(party, &offeredMedia);
   		rvCCConnectionSetMediaState(party, RV_CCMEDIASTATE_MODIFYING);

   		rvMdmMediaStreamInfoDestruct(&offeredMedia);

       /*Notify application that an empty Re-Invite was received*/
        RvLogInfo(ippLogSource,(ippLogSource,"rvCCProviderSipHandleReInviteReceived: empty Re-Invite was received, hCall(%p)", hCall));
        rvSipControlCallAccept(hCall, rvCCConnSipGetMediaCaps(c));

    }
}

/***************************************************************************
 * handleRedirectedState
 * ------------------------------------------------------------------------
 * General: This function handles a reply of redirect - initiates a new call
 *          to the new destination.
 *
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg        - a handle to SIP call-leg
 *          c               - pointer to SIP connection
 *
 * Output:  None
 *
 ***************************************************************************/
 static void handleRedirectedState(RvCCConnection*      c,
                                    RvSipCallLegHandle  hCallLeg)
{
    RvSipMsgHandle              hMsg;
    RvSipHeaderListElemHandle   hElement;
    RvSipContactHeaderHandle    hHeader = NULL;
    RvSipAddressHandle          addrHandle = NULL;
    RvChar                     *contactBuffer = NULL;
    RV_UINT32                   bufSize;
    HPAGE                       tmpPage;
    RvStatus                    status;

    /* Get the rcvd REDIRECTED message */
    status = RvSipCallLegGetReceivedMsg(hCallLeg, &hMsg);
    if ((status != RV_Success) || (hMsg == NULL))
        return; /*TBD:  */
    hHeader = RvSipMsgGetHeaderByType(hMsg, RVSIP_HEADERTYPE_CONTACT, RVSIP_FIRST_HEADER,&hElement);
    /* The encode function get tmp page from the pool internally */
    addrHandle = RvSipContactHeaderGetAddrSpec(hHeader);
    RvSipAddrEncode(addrHandle, g_appPool, &tmpPage, &bufSize);
    /*allocate a consecutive buffer*/
    rvMtfAllocatorAlloc(bufSize+1, (void**)&contactBuffer);
    if (contactBuffer == NULL)
    {
        RPOOL_FreePage(g_appPool,tmpPage);  /* Page of the Encode */
        return;
    }
    /* copy the encoded message to an external consecutive buffer*/
    status = RPOOL_CopyToExternal(g_appPool,
        tmpPage,
        0,
        (void*)contactBuffer,
        (RvInt32)bufSize);
    /*terminate the buffer with null*/
    contactBuffer[bufSize] = '\0';

    /* Free the tmp Page that was got in RvSipAddrEncode function */
    RPOOL_FreePage(g_appPool,tmpPage);  /* Page of the Encode */

    rvCCConnSipSetRemoteAddress(c, contactBuffer);

    /* Check if there is a call on hold or in process of transfer which should be updated
       with the new destination */
    rvCCConnectionSetThirdPartyAddress(rvCCConnectionGetConnectParty(c), contactBuffer);

    rvMtfAllocatorDealloc(contactBuffer, bufSize+1);

    status = RvSipCallLegConnect(hCallLeg);
    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"processCallState: STATE_REDIRECTED: RvSipCallLegConnect failed %d", status));
        /* IS IT NEEDED TO SET *event to RV_CCTERMEVENT_DISCONNECTING ??? */
    }
}

 /***************************************************************************
 * handleMsgSendFailure
 * ------------------------------------------------------------------------
 * General: This function handles a failure of sending message - it indicates
 *          the stack to send the message to next address on the list.
 *
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg        - a handle to SIP call-leg
 *          c               - pointer to SIP connection
 *
 * Output:  None
 *
 ***************************************************************************/
 static void handleMsgSendFailure(RvSipCallLegHandle    hCallLeg,
                                  RvCCConnection*       c)
 {
#ifndef RV_DNS_ENHANCED_FEATURES_SUPPORT
    RV_UNUSED_ARG(hCallLeg);
    RV_UNUSED_ARG(c);
#else

    RvStatus rv;

    rv = RvSipProcessInviteFail(hCallLeg, c);

	if(rv == RV_OK)
		return;

    /* Trying to proceed to the other addresses in the DNS list. calling RvSipCallLegDNSContinue()
       will ACK on the 503*/
    rv = RvSipCallLegDNSContinue(hCallLeg, NULL, NULL);
    if (rv != RV_OK)
    {
        RvLogDebug(ippLogSource,(ippLogSource, "No more addresses on DNS list, conn=0x%p", c));
        /* This function will check whether previous call-leg state was disconnected (for example, if we failed to
           send BYE request), and if yes, it will terminate call-leg. If this function is not called we get leak in SIP resources. */
        RvSipCallLegDNSGiveUp(hCallLeg, NULL);
		/* The call to rvCCConnSipNotifyError() should be done last as it may cause a change in the CallLeg
		   state e.g. by disconnecting the call in some cases. */
		rvCCConnSipNotifyError(c);
    }
    else
    {
        /* calling RvSipCallLegDNSReSendRequest() will re send the request but this time on TCP */
        rv = RvSipCallLegDNSReSendRequest(hCallLeg,NULL);
        if (rv != RV_OK)
        {
            rvCCConnSipNotifyError(c);
            RvLogError(ippLogSource,(ippLogSource,"Failed to re send the request on a call"));
        }
    }

#endif /*RV_DNS_ENHANCED_FEATURES_SUPPORT*/
 }


RvStatus RvSipProcessInviteFail(RvSipCallLegHandle    hCallLeg,
	                                 RvCCConnection*       c)
{

	RvStatus rv = RV_OK;
	RvSipTransactionState			  eTranscState = RVSIP_TRANSC_STATE_UNDEFINED;
	RvSipTransactionState			  eLastTranscState = RVSIP_TRANSC_STATE_UNDEFINED;
	RvCCTerminal*                     term=NULL;
	RvCCTerminalSip*                  terminal=NULL;

	CallLeg* pCallLeg = (CallLeg*)hCallLeg;
	
	if(pCallLeg == NULL)
		return RV_ERROR_INVALID_HANDLE;
	
	RvSipTranscHandle hTransc = pCallLeg->hActiveTransc;
	Transaction    *pTransc = (Transaction *)hTransc;
	if(pTransc == NULL)
		return RV_ERROR_INVALID_HANDLE;

	eTranscState = pTransc->eState;
	eLastTranscState = pTransc->eLastState;

	if(eTranscState == RVSIP_TRANSC_STATE_CLIENT_MSG_SEND_FAILURE 
	 	 && eLastTranscState == RVSIP_TRANSC_STATE_CLIENT_INVITE_CALLING)	 	
	 {
		 if (c != NULL)
		 {
			 if ((term = rvCCConnSipGetTerminal(c)) != NULL)
			 {
				if ((terminal = rvCCTerminalSipGetImpl(term)) != NULL)
				 {
					IppTimerStart(&terminal->registerTimer, IPP_TIMER_RESTART_IF_STARTED, 1*1000);
				 }
			 }
		  }
    }
	return rv;
}


/***************************************************************************
 * processCallState
 * ------------------------------------------------------------------------
 * General: This function processes the change in call state.
 *
 *
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg        - a handle to SIP call-leg
 *          c               - pointer to SIP connection
 *          state           - call-leg state
 *          reason          - call-leg reason for state change
 * Output:
 *          event           - event to be sent to Connection state machine
 *          cause           - cause to be sent to Connection state machine
 *
 ***************************************************************************/
void processCallState(  RvSipCallLegHandle              hCallLeg,
                        RvCCConnection*                 c,
                        RvSipCallLegState               state,
                        RvSipCallLegStateChangeReason   reason,
                        RvCCTerminalEvent*              event,
                        RvCCEventCause*                 cause)

{

    switch (state)
    {
    case RVSIP_CALL_LEG_STATE_UNDEFINED:
    case RVSIP_CALL_LEG_STATE_IDLE:
        break;
    case RVSIP_CALL_LEG_STATE_INVITING: /* outgoing call, invite was sent */
        break;
    case RVSIP_CALL_LEG_STATE_UNAUTHENTICATED:
           if (rvCCProviderSipHandleUnauthenticateState(c, hCallLeg, RV_TRUE) == RV_FALSE)
		   {
			   /* Authentication failed for this call. It should be rejected.*/
			   *event = RV_CCTERMEVENT_REJECTCALL;
			   *cause = RV_CCCAUSE_AUTH_FAIL; /* Add to prevent reject for this connection*/
		   }
        break;
    case RVSIP_CALL_LEG_STATE_DISCONNECTING: /* bye was sent, waiting for ok*/
        break;
    case RVSIP_CALL_LEG_STATE_OFFERING: /* incoming call, invite was received*/
            handleOfferingState(c, hCallLeg, event, reason);
        break;
    case RVSIP_CALL_LEG_STATE_ACCEPTED:/*remote party answered and waiting for ack */
            handleAcceptedState(c, hCallLeg);
        break;
    case RVSIP_CALL_LEG_STATE_CONNECTED:/*ack was received, both parties are connected*/
            handleConnectedState(c, hCallLeg, event, cause);
		break;
    case RVSIP_CALL_LEG_STATE_PROCEEDING_TIMEOUT:
            RvSipCallLegCancel(hCallLeg);
        break;
    case RVSIP_CALL_LEG_STATE_REDIRECTED:
            handleRedirectedState(c, hCallLeg);
        break;
    case RVSIP_CALL_LEG_STATE_DISCONNECTED:
            handleDisconnectedState(hCallLeg, reason, event, cause);
        break;
    case RVSIP_CALL_LEG_STATE_MSG_SEND_FAILURE:
        handleMsgSendFailure(hCallLeg, c);
        break;
	case RVSIP_CALL_LEG_STATE_CANCELLING:
		if (reason == RVSIP_CALL_LEG_REASON_LOCAL_CANCELLING)
		{
			*event = RV_CCTERMEVENT_FAILGENERAL;
			*cause = RV_CCCAUSE_CALL_CANCELLED;
		}
		break;

    default:
            *event = RV_CCTERMEVENT_UNKNOWN;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    /*Can be received at any state of the call */
    if (reason == RVSIP_CALL_LEG_REASON_REMOTE_CANCELED)
        *event = RV_CCTERMEVENT_DISCONNECTING;
}

/*===============================================================================*/
/*=========== C A L L B A C K S     I M P L E M E N T A T I O N S ===============*/
/*===============================================================================*/
/* TODO: 1. map events for IP PHONE */
/*       2. get the right connection from connections list - for now we choose the active one*/
void rvCCProviderSipProcessEvent(
    RvSipAppCallLegHandle           hAppCallLeg,
                                RvSipCallLegHandle              hCallLeg,
                                RvSipCallLegState               state,
                                RvSipCallLegStateChangeReason   reason)
{
    RvCCConnection*     c;
    RvSipMsgHandle      phMsg;
    RvCCTerminalEvent   event           = RV_CCTERMEVENT_NONE;
    RvCCEventCause      cause           = RV_CCCAUSE_NORMAL;
    RvCCCall*           call            = NULL;
    RvBool              callStillAlive  = RV_FALSE;

    RvLogEnter(ippLogSource, (ippLogSource,
        "rvCCProviderSipProcessEvent(hAppCallLeg=%p,hCallLeg=%p,state=%s,reason=%s)",
        hAppCallLeg, hCallLeg, rvSipControlGetCallLegStateName(state), rvSipControlGetCallLegStateChangeName(reason)));

	/* hAppCallLeg could be NULL if a request or response has been received for a call that no longer exists.
	   e.g. in case of MTF shutdown while a call is up, where BYE is sent and an OK is received
	   after the call was dropped */
	if (hAppCallLeg == NULL)
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvCCProviderSipProcessEvent: call-leg %x -> hAppCallLeg is NULL", hCallLeg));
        return ;
	}

    c = (RvCCConnection*)hAppCallLeg;
    rvCCConnSipSetCallLegHandle(c, hCallLeg);

    /*Lock call*/
    if ((call = rvCCConnectionGetCall(c)) != NULL)
    {
        rvCCCallLock(call);
        callStillAlive = RV_TRUE;
    }

	if (state == RVSIP_CALL_LEG_STATE_TERMINATED)
	{
        event = RV_CCTERMEVENT_TERMINATED;
	}
    if (RvSipCallLegGetReceivedMsg(hCallLeg, &phMsg) == RV_OK)
    {
        if (phMsg != NULL)
    /* Process message according to the return code*/
            processMessageCode(phMsg, c, &event, &cause);
    }

    /*switch (state) {*/
    if (event != RV_CCTERMEVENT_NONE)
        rvCCConnSipProcessEvent(c, event, &callStillAlive, cause);

    /* Process message according to the call state*/
    processCallState(hCallLeg, c, state, reason, &event, &cause);

    if (event != RV_CCTERMEVENT_NONE)
        rvCCConnSipProcessEvent(c, event, &callStillAlive, cause);

    if (call != NULL)
    {
        rvCCCallUnlock(call);
    }

    RvLogLeave(ippLogSource, (ippLogSource, "rvCCProviderSipProcessEvent()"));
}

void rvCCProviderSipProcessEventModify(
    RvSipAppCallLegHandle           hAppCallLeg,
                                    RvSipCallLegHandle              hCallLeg,
                                    RvSipCallLegModifyState         eModifyState,
                                    RvSipCallLegStateChangeReason   reason)
{
    RvCCConnection* c           = (RvCCConnection*)hAppCallLeg;
    RvSipMsgHandle  hMsg;

    /*Get received SIP message */
    if (RvSipCallLegGetReceivedMsg(hCallLeg, &hMsg) != RV_Success)
        return;

    switch(eModifyState)
    {
    case RVSIP_CALL_LEG_MODIFY_STATE_IDLE:
        if (reason == RVSIP_CALL_LEG_REASON_AUTH_NEEDED)
        {
            RvCCConnection  *c2     = (RvCCConnection *)hAppCallLeg;
            const RvSdpMsg  *sdpMsg = NULL;
			RvBool          rc;


		    rc = rvCCProviderSipHandleUnauthenticateState(c2, hCallLeg, RV_FALSE);
			if (rc == RV_FALSE)
			{
				RvLogError(ippLogSource, (ippLogSource, "rvCCProviderSipProcessEventModify: failed to authenticate modify request for conn %p", c2));
				/* This is the end of the modify process - handle the modify failure */
				rvCCProviderSipHandleReinviteResponse(c, hMsg, reason);
				return;
			}

			/* At this stage the Re-Invite is sent again. We don't want to call proc
		       rvCCProviderSipHandleReinviteResponse now. It should be called only when the
		       modify process is completed successfully or with a failure. We need to wait
			   for the response to this new Re-Invite. Until then modify media is still in process. */

            sdpMsg = rvMdmMediaStreamInfoGetRemoteDescriptor(rvCCConnectionGetNewMedia(c2), 0);
            if (sdpMsg == NULL)
            /* When sdpMsg is Null, the Hold case is handled.
              buildHoldUnholdSdpMsg is already called.
            Therefore, it is not needed to update the sdp msg in the msg,
            but only to call rvSipControlModifyOrRefresh */
            {
                rvSipControlModifyOrRefresh(hCallLeg);
            }
            else
            {
                /* Send Re-invite with the new media*/
                rvSipControlSendModify(hCallLeg, c2, (RvSdpMsg*)sdpMsg);
            }
        }
        break;

		case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_RCVD:
            rvCCProviderSipHandleReInviteReceived(hMsg, hCallLeg, hAppCallLeg);
            break;

        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_RESPONSE_RCVD:
			{
				RvInt16 statuscode = RvSipMsgGetStatusCode(hMsg);

				/* If this is an Unauthorized response don't handle it in this case entry.
				   It will be handled in the following call to rvCCProviderSipProcessEventModify with
				   modify state RVSIP_CALL_LEG_MODIFY_STATE_IDLE */

				if((statuscode != 401) && (statuscode != 407))
				{
					rvCCProviderSipHandleReinviteResponse(c, hMsg, reason);
				}
			}
            break;
        case RVSIP_CALL_LEG_MODIFY_STATE_MSG_SEND_FAILURE:
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_CANCELLING:
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_CANCELLED:
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_PROCEEDING_TIMEOUT:
            RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipProcessEventModify(hAppCallLeg=%p,hCallLeg=%p,eModifyState=%s,reason=%s)"
                ,hAppCallLeg,hCallLeg,rvSipControlGetCallLegModifyStateName(eModifyState),rvSipControlGetCallLegStateChangeName(reason)));

            break;

        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_RESPONSE_SENT:
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_SENT:
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_REMOTE_ACCEPTED:
        case RVSIP_CALL_LEG_MODIFY_STATE_REINVITE_PROCEEDING:

            /* SHOULDN't THESE STATES BE HANDLED? */
            break;
        default:
            break;
    /*lint -e{788}  all relevant cases are accounted for */
    }
}

static RvCCConnection* createNewConnection(RvCCProvider* p)
{
    RvCCCallMgr*    callMgr = rvCCProviderSipGetCallMgr(p);
    RvCCCall*       call    = rvCCCallMgrCreateCall(callMgr);
    RvCCConnection* c       = rvCCProviderSipCreateConnection(p, NULL);/*Terminal will be set later*/

    rvCCCallAddParty(call, c);

    return c;
}

RvSipAppCallLegHandle rvCCProviderSipNewCallLeg(void)
{
    RvCCConnection* c = createNewConnection(g_sipProvider);

    return (RvSipAppCallLegHandle)c;
}

RvStatus rvCCProviderSipSetCallParams(
    RvSipAppCallLegHandle   hAppCallLeg,
                              RvSipCallLegHandle hCallLeg,
                              char* to,
                              char* from,
                              char* contact,
                              char* callerName,
                              char* callerDisplayName)
{
    RvCCConnection* c = (RvCCConnection*)hAppCallLeg;
    RvCCProvider* p = rvCCConnSipGetProvider(c);
    RvCCCall* call = rvCCConnectionGetCall(c);
	RvMdmTermMgr*   termMgr = NULL;
	char*           termId ;
    RvCCTerminal* t;
    RvSipCallLegDirection  eDirection;
    RvStatus status     = RV_OK;
    if (call != NULL)
        rvCCCallLock(c->call);

    RvSipCallLegGetDirection(hCallLeg, &eDirection);
    /* In case of an incoming call get the terminal Id from the "to"  */
    /* parameter. Otherwise, use the caller name                      */
    if (eDirection == RVSIP_CALL_LEG_DIRECTION_INCOMING)
    {
        if ((to != NULL)/* && (to[0] != '\0')*/)
		{
			termMgr  = getMdmTermMgr();
			/* Get the user application mapping for the terminal id */
			termId   = rvMdmTermMgrMapAddressToTermination_(termMgr, to);

            t = rvCCProviderSipFindTerminalById(p, termId);
		}
        else
            t = NULL;
    }
    else
	{
		termMgr  = getMdmTermMgr();
		/* Get the user application mapping for the terminal id */
		termId   = rvMdmTermMgrMapAddressToTermination_(termMgr, callerName);

		t = rvCCProviderSipFindTerminalById(p, termId);
	}

	if (t == NULL)
	{
		RvLogWarning(ippLogSource,(ippLogSource,"rvCCProviderSipSetCallParams: address does not match a terminal"));
		if (call != NULL)
		{
			rvCCCallUnlock(call);
		}
		return RV_ERROR_NOT_FOUND;
	}

    if (to != NULL)
        rvCCConnSipSetRemoteAddress(c, to);
    if (from != NULL)
    {
        rvCCConnSipSetLocalAddress(c, from);
        rvCCCallSetOriginAddress(call, contact);
        rvCCConnSipSetCallerAddress(c, from);
        rvCCConnSipSetCallerName(c, callerName);
        rvCCConnSipSetCallerId(c, callerDisplayName);
		rvCCConnSipSetRemoteUri(c,contact);
    }
    rvCCConnSipSetCallLegHandle(c, hCallLeg);
    rvCCConnSipSetTerminal(c, t);

    if (call != NULL)
    {
        rvCCCallUnlock(call);
	}
    return status;
}
/***************************************************************************
 * rvCCProviderSipProcessIncomingSdp
 * ------------------------------------------------------------------------
 * General: This proc was once called rvCCProviderSipGetMedia.
 *          It handles SDP of an incoming message. It starts the process
 *          of media create/modify by user callbacks.
 *          It assumes that a message is containing an SDP body.
 * Return Value: RV_OK
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg        - Handle to the incoming message.
 *          hAppCallLeg - The application handle for the call-leg.
 *
 ***************************************************************************/
RvBool rvCCProviderSipProcessIncomingSdp(
    RvSipMsgHandle          hMsg,
    RvSipAppCallLegHandle   hAppCallLeg)
{
    RvCCConnection*     c       = (RvCCConnection*)hAppCallLeg;
    RvCCConnSip*        conn    = rvCCConnSipGetIns(c);
    RvSdpParseStatus    stat    = RV_SDPPARSER_STOP_ZERO;
    RvStatus            rv;
    RvSdpMsg            sdp;
    char *              buf = NULL;
    RvInt               strLen;
    RvUint              actlen  =   0;

    char* sdpEnd = NULL;
    char* sdpHeader = NULL;
    MsgMessage* msg = (MsgMessage*)hMsg;

	strLen = (RvInt)RvSipMsgGetStringLength(hMsg, RVSIP_MSG_BODY);

    RvLogInfo(ippLogSource, (ippLogSource,
        "#########RvCCConnSip::rvCCProviderSipProcessIncomingSdp"));

	if (strLen == 0) /* No SDP message was sent */
	{
		RvLogError(ippLogSource,(ippLogSource, "rvCCProviderSipProcessIncomingSdp: No body in message %p, connection %p",hMsg, c));
        return RV_FALSE;
	}

    rvMtfAllocatorAlloc(strLen*sizeof(RvChar), (void**)&buf);
    if (buf == NULL)
    {
        RvLogError(ippLogSource,(ippLogSource, "rvCCProviderSipProcessIncomingSdp: Failed to allocate memory for SDP message %p",hMsg));
        rvCCConnSipSetRejectCall(c, RV_TRUE);
        return RV_FALSE;
    }

    rv = RvSipMsgGetBody(hMsg, buf, (RvUint)strLen, &actlen);
    RvLogInfo(ippLogSource, (ippLogSource,
        "#########RvCCConnSip::RvSipMsgGetBody rv:%d,len:%d,buf:%s",rv,actlen,buf));

    RvLogInfo(ippLogSource, (ippLogSource,
        "#########RvCCConnSip::msg->pBodyObject->hBodyPartsList:%p",msg->pBodyObject->hBodyPartsList));

    /*zxs remove the non-sdp message body */
    if(msg->pBodyObject->hBodyPartsList != NULL && rv == RV_OK && actlen!=0)
    {   
        char* sdpContType = "Content-Type: application/sdp";

        sdpHeader = strstr(buf,sdpContType);
         RvLogInfo(ippLogSource, (ippLogSource,
            "#########RvCCConnSip:sdpHeader:%s",sdpHeader));
       if(sdpHeader != NULL)
        {
             sdpEnd = strstr(sdpHeader,"--ssb");
             if(sdpEnd != NULL)
                sdpHeader[sdpEnd-sdpHeader] = '\0';

             sdpHeader = strstr(sdpHeader, "v=0");

        }
    }

    if(sdpHeader != NULL)
    {
        actlen = strlen(sdpHeader);
    }
    else
        sdpHeader = buf;
    
    RvLogInfo(ippLogSource, (ippLogSource,
        "#########RvCCConnSip::RvSipMsgGetBody rv:%d,len:%d,buf:%s",rv,actlen,sdpHeader));

    if (rv == RV_OK && actlen!=0)
    {
        if ((rvSdpMsgConstructParseA(&sdp, sdpHeader, (int *)&actlen, &stat, conn->alloc)) != NULL)
        {
            if ((rvCCConnSipCreateMedia(c, &sdp)) == RV_CCMEDIASTATE_FAILED)
                rvCCConnSipSetRejectCall(c, RV_TRUE);
			else
			{
				/* There may be cases where this proc is invoked several times before the call is connected.
				   Such a case is receiving UPDATE requests or responses for outgoing UPDATEs during
				   call set up. Some of the media  creations may fail and others may succeed. The last
				   media creation attempt will determine whether the call will be rejected. */
				rvCCConnSipSetRejectCall(c, RV_FALSE);
			}
        }
        else
        {
            RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipProcessIncomingSdp: Parsing SDP message failed, App Call-Leg: %p", hAppCallLeg));
            rvCCConnSipSetRejectCall(c, RV_TRUE);
            rvMtfAllocatorDealloc(buf, strLen*sizeof(RvChar));
            return RV_FALSE;
        }

    rvSdpMsgDestruct(&sdp);
    }

    rvMtfAllocatorDealloc(buf, strLen*sizeof(RvChar));

    return RV_TRUE;
}

/***************************************************************************
 * rvCCProviderSipSetMedia
 * ------------------------------------------------------------------------
 * General: This proc adds SDP body with media cpabilities to a message
 *          if capabilities are already set.
 * Return Value: RV_TRUE - SDP was added to the message, RV_FALSE otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsg        - Handle to the incoming message.
 *          hAppCallLeg - The application handle for the call-leg.
 *
 ***************************************************************************/
RvBool rvCCProviderSipSetMedia(
    RvSipMsgHandle          hMsg,
    RvSipAppCallLegHandle   hAppCallLeg)
{
    RvCCConnection* c = (RvCCConnection*)hAppCallLeg;
    const RvSdpMsg*         sdpMsg;
	RvBool          rc = RV_FALSE;

    sdpMsg = rvCCConnSipGetMediaCaps(c);
    if (sdpMsg != NULL)
    {
        RvStatus rv = rvSipControlMsgSetBody(hMsg, sdpMsg);
        if (rv != RV_OK)
        {
            RvLogError(ippLogSource, (ippLogSource,
                "rvCCProviderSipSetMedia: Setting SDP msg failed, App Call-Leg: %p", hAppCallLeg));
        }
		else
		{
			rc = RV_TRUE;
		}
    }

	return rc;
}

/***************************************************************************
* rvCCProviderSipMsgReceived
* ------------------------------------------------------------------------
* General:     This function handles Provisional Responses only.
*				when Provisional Responses arrives, in some scenarios SIP stack
*				raises both callbacks (MsgReceived and StateChanged) and in other
*              cases only MsgReceived is called.
*				In cases that both callbacks are called, we handle the message in
*              MsgReceived event,and do not handle the message in StateChanged event
*              (we block it by setting NULL to Application handle).
*				Example for case when SIP stack calls both callbacks for Provisional
*              Responses:
*              After Invite is sent, the first provisional response that is received
*              (for example, 100 Trying) will raise the MsgReceived event and then the
*              StateChanged event. The second provisional response that is received
*              (for example, 180 Ringing) will raise the MsgRecieved event only,
*              therefore we must process messages in MsgRecieved event.
*
* Return Value: None
* ------------------------------------------------------------------------
* Arguments:
* Input:   hMsg         -  Handle to SIP message
*          hAppCallLeg  -  Handle to SIP application handle
 ***************************************************************************/
void rvCCProviderSipMsgReceived(
    RvSipMsgHandle          hMsg,
    RvSipAppCallLegHandle   hAppCallLeg)
{
    RvCCConnection*     c;
    RvBool              callStillAlive  = RV_TRUE;
    RvCCCall*           call            = NULL;
    RvCCTerminalEvent   event = RV_CCTERMEVENT_NONE;
    RvCCEventCause      cause = RV_CCCAUSE_NORMAL;
    RV_INT16            statusCode = 0;

    if (hAppCallLeg == NULL)
        return;

    c = (RvCCConnection*)hAppCallLeg;

    statusCode = RvSipMsgGetStatusCode(hMsg);

    /* handle this only if message is provisional response, otherwise, it will be handled
       in StateChanged event */
    if ((statusCode >= RV_SIPCTRL_STATUS_TRYING) &&
        (statusCode < RV_SIPCTRL_STATUS_OK))
    {
        /*Lock call*/
        if (c->call != NULL)
        {
            call = rvCCConnectionGetCall(c);
            rvCCCallLock(c->call);
        }
        else
        {
            callStillAlive = RV_FALSE;
        }

        processMessageCode(hMsg, c, &event, &cause);

        if (event != RV_CCTERMEVENT_NONE)
            rvCCConnSipProcessEvent(c, event, &callStillAlive, cause);

        if (call != NULL)
        {
            rvCCCallUnlock(call);
    }
}
}


/* Transfer-Replaces feature */
/***************************************************************************
 * handleReferredByHeader
 * ------------------------------------------------------------------------
 * General: Handles the Referred-by header in case Replaces header doesn't exist.
 *          It will make the replacement of existing call with the new one as follows:
 *          replaces an existing call with matching origin address, with the new call.
 * Return Value: Returns RV_Status.
 * ------------------------------------------------------------------------
 * Arguments:
 * input: hMsg          - handle to the message
 *        hAppCallLeg   - handle to the application call leg
 * output: None
 ***************************************************************************/
static RV_Status handleReferredByHeader(RvSipMsgHandle hMsg, RvSipAppCallLegHandle hAppCallLeg, RvBool* otherCallFound)
{
    RvCCConnection  *c = (RvCCConnection*)hAppCallLeg;
    RvCCCallMgr     *callMgr = rvCCProviderSipGetCallMgr(g_sipProvider);
    char            address[RV_SIPCTRL_ADDRESS_SIZE];
    char            to[48];
    RvStatus        rc = RV_OK;
    RvCCConnection* connToClose;
    RvCCConnState   connToCloseState = RV_CCCONNSTATE_UNKNOWN;
    RvBool          bShouldCloseConn;
    RvBool          res;

    if (rvSipControlMsgGetReferredAddress(hMsg, address) == RV_FALSE)
    {
        RvLogError(ippLogSource,(ippLogSource,
            "handleReferredByHeader: rvSipControlMsgGetReferredAddress() Failed"));
        return (RV_Failure);
        /* rc = RV_Failure; What has to be done??? */
    }

    rc = rvSipControlGetToAddressByMessage(hMsg, to);
    if (rc != RV_OK)
    {
        RvLogError(ippLogSource, (ippLogSource,
            "handleReferredByHeader: rvSipControlGetToAddressByMessage() Failed"));
        return rc;
    }

	if (c == NULL)
	{
		RvLogError(ippLogSource, (ippLogSource,
			"handleReferredByHeader: Connection is NULL "));
		return RV_ERROR_UNKNOWN;
	}
    res = rvCCCallMgrReplaceConnByLocal(callMgr, c, address, to, &connToClose);
    if (res == RV_FALSE)
    {
        /*  New party was Not found, can't replace connections */
		*otherCallFound = RV_FALSE;
        return RV_ERROR_NOT_FOUND;
    }
	else
	{
		*otherCallFound = RV_TRUE;
	}

    RvLogInfo(ippLogSource, (ippLogSource,
        "SipProvider: Received Invite Referred By: %s, App Call Leg:%p", address, hAppCallLeg));
    /*
     *
     * #28967.
     * We implemented transfer according draft 6.1.Exposing transfer target.
     * Transfered-to EP waits that Transferor close their connection.
     * If it's not a case we MUST close connection ourself.
     * Because we don't treat Replace Header in REFER msg we should find workaround
     * in order to guess what, if any, connection must be dropped.
     */
    if (connToClose !=NULL)
    {
        connToCloseState = rvCCConnectionGetState( connToClose);
        bShouldCloseConn =
            (connToCloseState != RV_CCCONNSTATE_UNKNOWN)&&
            (connToCloseState != RV_CCCONNSTATE_IDLE)&&
            (connToCloseState != RV_CCCONNSTATE_DISCONNECTED);
        if (bShouldCloseConn)
        {
            rvCCConnectionDisconnect(connToClose,RV_CCCAUSE_NORMAL);
        }
        /*
         *  In addition,EP like CISCO put the call with transfered-to EP on Hold.
         * We should Unhold one previously.
         * So we check the terminal state of MDM connection moved (above) to this call.
         */
        if (rvCCConnectionGetTermState(rvCCConnectionGetConnectParty(c)) == RV_CCTERMCONSTATE_REMOTE_HELD)
            rvCCCallTalking(c, NULL, RV_CCCAUSE_UNHOLD);
    }
    return rc;
}


/***************************************************************************
 * handleReplacesHeader
 * ------------------------------------------------------------------------
 * General: Handle the Replaces header, if any.
 *          The replacement of existing call with the new one is based on the Replaces header.
 *          If no matching call is found, it will reject the Invite by sending 481
 *          (Call does not exist). If "early-only" flag exists in the Replaces header,
 *          meaning, the Invite refers to a call that was not established yet,
 *          it will reject the invite with 486 (Busy).
 * Return Value: Returns RV_Status.
 * ------------------------------------------------------------------------
 * Arguments:
 * input: c         - connection
 *        hCallLeg  - handle to the Sip call leg
 * output: None
 ***************************************************************************/
static RV_Status handleReplacesHeader(RvCCConnection *c, RvSipCallLegHandle hCallLeg)
{
    RvCCCallMgr                 *callMgr;
    RV_Status                   rc = RV_Success;
    RvSipCallLegReplacesReason  eReason;
    RvSipCallLegHandle          hMatchedCallLeg;
    RvSipAppCallLegHandle       hAppCallLeg;
    RvSipReplacesHeaderHandle   hReplacesHeader;

    rc |= RvSipCallLegReplacesGetMatchedCallExt(hCallLeg,&eReason, &hMatchedCallLeg);
    if ((eReason == RVSIP_CALL_LEG_REPLACES_REASON_UNDEFINED) || /* no reason specified. */
        (eReason == RVSIP_CALL_LEG_REPLACES_REASON_DIALOG_NOT_FOUND) || /* The matched call-leg was found correctly. */
        (eReason == RVSIP_CALL_LEG_REPLACES_REASON_FOUND_NON_INVITE_DIALOG) || /* found a dialog, with same dialog identifiers,
                                                                        but the dialog was not established with an INVITE request. */
        (eReason == RVSIP_CALL_LEG_REPLACES_REASON_FOUND_TERMINATED_DIALOG) || /* found a dialog in state terminated. */
        (eReason == RVSIP_CALL_LEG_REPLACES_REASON_FOUND_INCOMING_EARLY_DIALOG)) /* found an incoming dialog in an early state (offering),
                                                                            which is not allowed by the replaces draft.*/
    {
        RvLogError(ippLogSource, (ippLogSource, "handleReplacesHeader: eReason=%d", eReason));
        /* 481(RV_SIPCTRL_STATUS_CALLNOTEXIST) response should be sent to the original call leg (hCallLeg)*/
        rvSipControlReject(hCallLeg, RV_SIPCTRL_STATUS_CALLNOTEXIST);
        /* TBD: Check how this is going to influence the other endpoints behavior */
        return RV_ERROR_UNKNOWN;
    }
    else
    {
        /*  found a confirmed dialog, but the replaces header contains 'early-only' parameter,
            so application should reject the request with 486.  */
        if (eReason == RVSIP_CALL_LEG_REPLACES_REASON_FOUND_CONFIRMED_DIALOG)
        {
            RvLogError(ippLogSource, (ippLogSource, "handleReplacesHeader: eReason=early only"));
            rvSipControlReject(hCallLeg, RV_SIPCTRL_STATUS_BUSYHERE);
            return RV_ERROR_UNKNOWN;
        }
    }
    /* Otherwise: eReason == RVSIP_CALL_LEG_REPLACES_REASON_DIALOG_FOUND_OK */

    if ((rc = RvSipCallLegGetReplacesHeader(hCallLeg, &hReplacesHeader)) != RV_Success)
    {
        RvLogError(ippLogSource, (ippLogSource, "handleReplacesHeader: RvSipCallLegGetReplacesHeader Failed"));
        rvSipControlReject(hCallLeg, RV_SIPCTRL_STATUS_CALLNOTEXIST);
        /* TBD: Check how this is going to influence the other endpoints behavior */
        return RV_ERROR_UNKNOWN;
    }
    callMgr = rvCCProviderSipGetCallMgr(g_sipProvider);
    rc = RvSipCallLegGetAppHandle(hMatchedCallLeg, &hAppCallLeg);

    if(hAppCallLeg != NULL)
    {
        if (rvCCCallMgrReplaceConn(callMgr, (RvCCConnection *)hAppCallLeg /* App is the connection itself */, c) != RV_Success)
        {
            RvLogError(ippLogSource, (ippLogSource, "handleReplacesHeader: rvCCCallMgrReplaceConn Failed"));
            rvSipControlReject(hCallLeg, RV_SIPCTRL_STATUS_CALLNOTEXIST);
            rc = RV_ERROR_UNKNOWN;
        }
        /* Eventhough the Reject was done, 'C' should disconnect the call with 'A',
        since this call was created only for replacing it with 'B' */
        rvCCConnectionDisconnect((RvCCConnection *)hAppCallLeg, RV_CCCAUSE_TRANSFER);
    }
    return rc;
}


/***************************************************************************
 * handleOfferingState
 * ------------------------------------------------------------------------
 * General: This function handles the received INVITE.
 *  The procedure of handling Offering State is in the following order:
 *    1. Check if call needs to be rejected - probably due to failure of SDP parsing earlier.
 *       No event is returned.
 *    2. Check if this is a referred Invite - due to Transfer request.
 *    3. Check if we need to send an Authentication request. No event is returned.
 *    4. If all of the above is False, can continue processing an incoming call event
 * Return Value: Returns RV_Status.
 * ------------------------------------------------------------------------
 * Arguments:
 * input: c         - connection
 *        hCallLeg  - handle to the Sip call leg
 *        reason    - the reason the state was changed
 * output:event     - indicates on the next event
 *        cause     - not used for now
 ***************************************************************************/
static RV_Status handleOfferingState(RvCCConnection* c, RvSipCallLegHandle hCallLeg,
                                    RvCCTerminalEvent*  event,
                                    RvSipCallLegStateChangeReason reason)
{
    RvSipMsgHandle              hMsg;
    RvSipOtherHeaderHandle      hHeader;
    RvSipHeaderListElemHandle   hElement;
    char                        strValue[RV_MEDIUM_STR_SZ];
    RvSipCallLegReplacesStatus  statusReplaces = RVSIP_CALL_LEG_REPLACES_UNDEFINED;
    RvUint                      stringLength  = sizeof(strValue);
    RV_Status                   rv = RV_Success;


    if (reason == RVSIP_CALL_LEG_REASON_REMOTE_INVITING_REPLACES)
    {
        /* Meaning, both "Supported: Replaces" and Replaces header exist: "Attended Transfer" */
        *event = RV_CCTERMEVENT_TRANSFER_OFFERED;
        rv = handleReplacesHeader(c, hCallLeg);
		/* if handling replaces header failed the call was already rejected, there is no need to proceed  */
		if (rv != RV_OK)
		{
			*event = RV_CCTERMEVENT_NONE;
		}
    }
    else
    {
        rv = RvSipCallLegGetReceivedMsg(hCallLeg, &hMsg);
        if ((rv != RV_Success) || (hMsg == NULL))
        {
            RvLogError(ippLogSource, (ippLogSource, "handleOfferingState: Failed to get received message"));
            return RV_Failure;
        }
        /* Check if "Supported: Replaces" header exists */
        hHeader =  RvSipMsgGetHeaderByName(hMsg,"Supported", RVSIP_FIRST_HEADER,&hElement);
		while(hHeader != NULL)
		{
			rv = RvSipOtherHeaderGetValue(hHeader,strValue,stringLength,&stringLength);
			if (rv != RV_OK)
			{
				/* We failed to get this value for some reason, maybe we'll have more luck with next one */
				RvLogError(ippLogSource,(ippLogSource,"handleOfferingState: Getting value from Supported header failed, try the next one, call-leg %x", (int)hCallLeg));
				continue;
			}

			if(strcmp(strValue,"replaces") == 0)
			{
				statusReplaces = RVSIP_CALL_LEG_REPLACES_SUPPORTED;
				break;
			}
			hHeader =  RvSipMsgGetHeaderByName(hMsg,"Supported", RVSIP_NEXT_HEADER,&hElement);
			/* Reset string length for next value */
			stringLength = sizeof(strValue);
        }

        if (statusReplaces == RVSIP_CALL_LEG_REPLACES_SUPPORTED)
        {
            /* Meaning, Replaces header doesn't exist: "Blind Transfer" */
            *event = RV_CCTERMEVENT_INCOMINGCALL;
        }
        else
        {
            /* Meaning, both Supported and Replaces headers don't exist */
            RvSipReferredByHeaderHandle hReferredBy = RvSipMsgGetHeaderByType(hMsg,
                                         RVSIP_HEADERTYPE_REFERRED_BY,
                                         RVSIP_FIRST_HEADER,
                                         &hElement);

            if (hReferredBy != NULL && Psip_IsHandleInviteWithReferby(hCallLeg) == 1)
            {
                RV_BOOL otherCallFound = RV_TRUE;

				/* Attended transfer with the OLD implementation(based on up to 1.3.0.5. IPPTK)  */
                *event = RV_CCTERMEVENT_TRANSFER_OFFERED;

                /* Add return code checking in order to solve bug when
                SIP TA sends INVITE with Referred-By Header to an IPP whose call does not exist.
                In the SIP TA, in the "Msg" Tab add Referred-by with <sip:ui035@172.29.49.35> and
                check the "Set headers in outgoing messages" check box.
                If the call leg does not exist, we assume this is an invite for a new call and not
				transfer scenario, despite the presence of Referred-By header. */
                if (handleReferredByHeader(hMsg, (RvSipAppCallLegHandle)c, &otherCallFound) != RV_Success)
                {
					if (otherCallFound == RV_FALSE)
					{
						/* this is invite for a new incoming call */
						*event = RV_CCTERMEVENT_INCOMINGCALL; 
					}
					else
					{
						*event = RV_CCTERMEVENT_REJECTCALL;
						RvLogError(ippLogSource,(ippLogSource,"handleReferredByHeader FAILED. Reject call."));
					}
                }
            }
            else
            {
                /* "Blind Transfer" */
                *event = RV_CCTERMEVENT_INCOMINGCALL;
            }
        }
    }
    return rv;
}

void rvCCProviderSipReferConnected(
    RvSipAppCallLegHandle   hAppCallLeg,
    RvSipAppCallLegHandle   hNewAppCallLeg)
{
    RvCCConnection* conn = (RvCCConnection*)hAppCallLeg;
    RvCCConnection* newConn = (RvCCConnection*)hNewAppCallLeg;

    rvCCCallTransferConnectedCB(conn, newConn);

    rvCCConnectionSetState(conn, RV_CCCONNSTATE_TRANSFER_DELIVERED);

    newConn->state = RV_CCCONNSTATE_CALL_DELIVERED;
}

/***************************************************************************
 * rvCCProviderSipTransferNotified
* ------------------------------------------------------------------------
 * General: This function is called when a notify msg is received or after a REFER
*          timer expired.  A NOTIFY msg is not mandatory so there may be
*          applications that do not send it. In this case when the
*          REFER timers expires we behave as if a NOTIFY has been received.
*
* Return Value: -
* ------------------------------------------------------------------------
* Arguments:
* Input:    hAppCallLeg         - handle of application call leg
***************************************************************************/
void rvCCProviderSipTransferNotified(
    RvSipAppCallLegHandle   hAppCallLeg,
    RvBool                  isNotifyReceived)
{
    RvCCConnection* c       = (RvCCConnection*)hAppCallLeg;
    RvCCConnSip*    conn    = rvCCConnSipGetIns(c);

    RvCCConnection *x = rvCCConnectionGetConnectParty(c);

    RvLogDebug(ippLogSource,(ippLogSource,"<-- rvCCProviderSipTransferNotified hAppCallLeg:%p,isNotifyReceived:%d",hAppCallLeg,isNotifyReceived));
    if (isNotifyReceived == RV_TRUE)
        IppTimerStop(&conn->referTimer);

    rvCCCallTransferCompletedCB(c, RV_TRUE);

    if(x->conferenceFlag == 0)
        RvSipCallLegDisconnect(conn->callLegHndl);

}


/*===============================================================================*/
/*======================= P R O V I D E R   A P I ===============================*/
/*===============================================================================*/
RvCCConnection* rvCCProviderSipCreateConnection(RvCCProvider* p, RvCCTerminal* t)
{
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(p);
    RvCCConnection* c = NULL;
    rvMtfAllocatorAlloc(sizeof(RvCCConnection), (void**)&c);

    rvCCConnSipConstruct(c, p, t, provider->alloc);
    rvCCConnectionSetState(c, RV_CCCONNSTATE_IDLE);

    return c;
}

void rvCCProviderSipConstruct(RvCCProvider* p, RvCCCallMgr* callMgr,
                              RvSipStackHandle stackHandle,
                              RvMtfSipPhoneCfg* cfg, RvAlloc* a)
{
    RvCCProviderSip* provider;
    RvStatus         status     = RV_OK;

    g_sipProvider = p;

    rvMtfAllocatorAlloc(sizeof(RvCCProviderFuncs), (void**)&(p->funcs));

    p->funcs->createConnectionF = rvCCProviderSipCreateConnection;
    rvMtfAllocatorAlloc(sizeof(RvCCProviderSip), (void**)&(p->provider));
    provider = p->provider;

    provider->alloc = a;

    rvMapConstruct(RvCharPtr, RvCCTerminalPtr)(&provider->terminals, a);
    /* Refer Timeout - time to wait for Notify (as response to REFER),
       before terminating call. (Used in Transfer) */
    if (cfg->referTimeout == 0)
        /* if set to 0, override with default timeout*/
        provider->referTimeout = RV_DEFAULT_REFER_TIMEOUT;
    else
        provider->referTimeout = cfg->referTimeout;

    provider->autoRegister = cfg->autoRegister;
    provider->callWaitingReply  = cfg->callWaitingReply;
    provider->watchdogTimeout   = cfg->watchdogTimeout;

    RvMutexConstruct( IppLogMgr(), &provider->mutex);

    RvMutexConstruct( IppLogMgr(), &provider->lock);

    rvInitConnFuncs(provider);
#ifdef RV_MTF_VIDEO
    rvInitConnVideoFuncs(provider);
#endif
    rvInitConnCallbacks(provider);

    rvSipControlConstruct(&provider->sipMgr, stackHandle, cfg);
    if(provider->watchdogTimeout > 0)
    {
        status =rvSipControlWatchDogTimerConstruct((RvCCProvider*)provider);
        if(status!=RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvCCProviderSipConstruct::rvSipControlWatchDogTimerConstruct provider(%p), error = %d",provider,status));
        }
    }

    strncpy(provider->localAddress, cfg->localAddress, sizeof(provider->localAddress)-1);
    provider->localAddress[sizeof(provider->localAddress)-1] = '\0';

#if (RV_NET_TYPE & RV_NET_IPV6)
    IppUtilRemoveScopeIdFromIpv6String((RvChar*)&provider->localAddress);
#endif /* RV_NET_IPV6 */
    provider->callMgr = callMgr;

    rvVectorConstruct(RvMdmMediaStreamInfo)(&provider->streamList, provider->alloc);

	/* Print all configuration parameters to log */
    printConfigurationSip(cfg);

}

void rvCCProviderSipDestruct(RvCCProvider* p)
{
    RvCCProviderSip*    provider= rvCCProviderSipGetImpl(p);

    RvMutexLock(&provider->lock,IppLogMgr());
    RvMutexUnlock(&provider->lock,IppLogMgr());
    RvMutexDestruct( &provider->lock, IppLogMgr());

    rvSipControlDestruct(&provider->sipMgr);


    rvVectorDestruct(RvMdmMediaStreamInfo)(&provider->streamList);
    removeAllTerminals(p);
    rvMapDestruct(&provider->terminals);

    RvMutexLock(&provider->mutex,IppLogMgr());
    RvMutexUnlock(&provider->mutex,IppLogMgr());
    RvMutexDestruct( &provider->mutex, IppLogMgr());

    rvMtfAllocatorDealloc(p->funcs, sizeof(RvCCProviderFuncs));

    rvMtfAllocatorDealloc(provider, sizeof(RvCCProviderSip));

}

void rvCCProviderSipSetMediaCaps(RvCCProvider* x, const RvMdmStreamDescriptor* media) {
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(x);

    /*Set media capabilities */
    provider->mediaCaps = (RvMdmStreamDescriptor*)media;
}

RvMdmStreamId rvCCProviderSipAddEmptyMediaStream(RvCCProviderSip * x)
{
    RvMdmMediaStreamInfo* mediaStream;
    RvMdmStreamId id = 0;
    RvBool found = RV_FALSE;
    int i, streamNum = (int)rvCCProviderSipGetNumOfStreams(x);

    /*Generate stream id - go through the list and find the first empty place*/
    for (i=1 ; i<=streamNum; ++i) {
        RvMdmMediaStreamInfo* media = rvCCProviderSipGetMediaStream(x, i);
        if (media == NULL) {
            found = RV_TRUE;
            id = i;
            break;
        }
    }

    if (!found)
        id = streamNum+1; /*Stream id starts from 1*/

    mediaStream = rvVectorAllocBack(RvMdmMediaStreamInfo)(&x->streamList);
    rvMdmMediaStreamInfoConstructA(mediaStream, id, x->alloc);

    return id;


}

static RvBool matchMediaId(RvMdmMediaStreamInfo *m, void * id)
{
    RvUint32 id_ = *(RvUint32*)id;
    return rvMdmMediaStreamInfoMatchId(m,id_);
}

static RvMdmMediaStreamInfoVectorIter getMediaStream(RvCCProviderSip * x, RvUint32 streamId)
{
    RvMdmMediaStreamInfoVectorIter i = rvFindIf(RvVectorIter, RvMdmMediaStreamInfo)(rvVectorBegin(&x->streamList), rvVectorEnd(&x->streamList),
                                                    matchMediaId, &streamId);
    if(i != rvVectorEnd(&x->streamList))
        return i;
    else
        return NULL;
}

RvMdmMediaStreamInfo * rvCCProviderSipGetMediaStream(RvCCProviderSip * x, RvUint32 streamId)
{
    RvMdmMediaStreamInfoVectorIter i;
    if ((i=getMediaStream(x, streamId))==0)
        return NULL;
    return rvVectorIterData(i);
}

void rvCCProviderSipClearMediaStream(RvCCProviderSip * x, RvUint32 streamId)
{
    RvMdmMediaStreamInfoVectorIter i = getMediaStream(x, streamId);
    RvMdmMediaStreamInfo* media = (RvMdmMediaStreamInfo*)rvPtrVectorIterData(i);

    if (media != NULL) {
        rvMdmMediaStreamInfoDestruct(media);
        rvVectorErase(RvMdmMediaStreamInfo)(&x->streamList, i);
    }

}


/*Those callbacks will be registered by the Application, the rest will be implemented by RvCCCall*/
void rvCCProviderSipRegisterAddressAnalyzeCB(RvCCProvider* x, RvCCConnectionAddressAnalyzeCB addressAnalyzeCB)
{
    RvCCProviderSip* p = rvCCProviderSipGetImpl(x);
    p->connClbks.addressAnalyzeCB = addressAnalyzeCB;

}

void rvCCProviderSipRegisterInProcessCB(RvCCProvider* x, RvCCConnectionInProcessCB inProcessCB)
{
    RvCCProviderSip* p = rvCCProviderSipGetImpl(x);
    p->connClbks.inProcessCB = inProcessCB;
}

static void rvCCProviderSipAddTerminal(RvCCProviderSip* x, RvCCTerminal* t)
{
    RvCCTerminalSip* term = rvCCTerminalSipGetImpl(t);
    char* id = rvCCTerminalSipGetTermId(term);
    rvMapSetValue(RvCharPtr, RvCCTerminalPtr)(&x->terminals, &id, &t);
}

RvCCTerminal* rvCCProviderSipCreateTerminal(RvCCProvider*                   x,
                                     RvCCTerminalType               type,
                                     const char *                   id,
                                     RvMdmTermDefaultProperties*    termProperties)
{
    RvCCProviderSip* provider = x->provider;
    RvCCTerminal* t = NULL;

    /*Create SIP Terminal only for Analog and UI terminations */
    if ((type != RV_CCTERMINALTYPE_ANALOG) && (type != RV_CCTERMINALTYPE_UI))
        return NULL;

    rvMtfAllocatorAlloc(sizeof(RvCCTerminal), (void**)&t);

    rvCCTerminalSipConstruct(t, x, id, termProperties, provider->alloc);

    rvCCProviderSipAddTerminal(provider, t);

    return t;
}

void rvCCProviderSipRemoveTerminal(RvCCProvider* x, RvCCTerminal* t)
{
    RvCCTerminalSip*    term = rvCCTerminalSipGetImpl(t);
    RvCCProviderSip*    provider = rvCCProviderSipGetImpl(x);
    /* id is an intermediate variable that is used in the call to rvMapRemove which expects
       a char** poinetr whilst the terminalId is only char*    */
    char*               id = term->terminalId;

    rvMapRemove(RvCharPtr,RvCCTerminalPtr)(&provider->terminals, &id);
    rvCCTerminalSipDestruct(t);
    rvMtfAllocatorDealloc(t, sizeof(RvCCTerminal));
}

RvCCTerminal* rvSipProviderRegisterTerm(RvCCProvider*                       x,
                                     const char*                    id,
                                     RvCCTerminalType               type,
                                     RvMdmTermDefaultProperties*    termProperties)
{
    /*Create Terminal SIP only for UI and analog terminations*/
    if ((type == RV_CCTERMINALTYPE_UI) ||
        (type == RV_CCTERMINALTYPE_ANALOG))
    {
        return rvCCProviderSipCreateTerminal(x, type, id, termProperties);
    }

    return NULL;
}

void rvSipProviderUnregisterTerm(RvCCProvider*      x,
                                 RvCCTerminal*      t,
                                 RvCCTerminalType   type)
{
    /*Destroy Terminal SIP only for UI and analog terminations*/
    if ((type == RV_CCTERMINALTYPE_UI) || (type == RV_CCTERMINALTYPE_ANALOG))
    {
        rvCCProviderSipRemoveTerminal(x, t);
    }
}

RvCCTerminal* rvCCProviderSipFindTerminalById(RvCCProvider* x, const char* termId)
{
    RvCharPtr id = (char*)termId;
    RvCCProvider* p = (RvCCProvider*)x;
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(p);
    const RvCCTerminalPtr* pt;
    if(termId==NULL)
        return NULL;
    pt = rvMapGetValue(RvCharPtr,RvCCTerminalPtr)(&provider->terminals, &id);
    if(pt==NULL)
        return NULL;
    return *pt;
}

RvCCTerminal* rvCCProviderSipFindTerminalByRegClient(RvCCProvider*          x,
                                                    RvSipRegClientHandle    regClientObject)
{
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(x);
    RvMapIter(RvCharPtr,RvCCTerminalPtr) iter;

    for(iter = rvMapBegin(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter != rvMapEnd(RvCharPtr,RvCCTerminalPtr)(&provider->terminals);
        iter = rvMapIterNext(iter))
    {
        RvCCTerminal** pt = rvMapIterGetValue(RvCharPtr,RvCCTerminalPtr)(iter);
        RvCCTerminal* t = *pt;
        RvCCTerminalSip* term = rvCCTerminalSipGetImpl(t);
        RvSipRegClientHandle objectReg      = rvCCTerminalSipGetRegClientObject(term);

        if (objectReg == regClientObject)
            return *pt;
    }

    return NULL;
}
