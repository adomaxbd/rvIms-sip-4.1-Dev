/******************************************************************************
Filename   : rvccConnSip.c
Description: Implements Sip Connection Object
******************************************************************************
                Copyright (c) 2001 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_SIPCONTROL
#include "ipp_inc_std.h"
#include "rvcctext.h"
#include "sipphone.h"
#include "rvccconnsip.h"
#include "rvccterminalsip.h"
#include "rvsdpmedia.h"
#include "ippmisc.h"
#include "rvccterminalmdm.h"

#define RV_CONNSIP_STREAMID_NONE        0
int     SIP_MINUTE_RESEND =             60*1000;   /*in milliseconds */

extern RvSipControl* g_sipControl;

extern void PSip_getPUriParam(IN RvSipAppCallLegHandle hAppCallLeg);
extern int Psip_RejectDisabledUserIncomingCall(RvCCConnection*     x);

/*LOCAL DECLARATIONS*/
static const RvSdpMsg* getRemoteMedia(RvCCConnection* x);

/*==================================================================================
======================== G E T T E R S  &  S E T T E R S============================
===================================================================================*/
RvCCProviderSip* rvCCConnSipGetProviderImpl(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(conn->provider);
    return provider;
}

void rvCCConnSipSetRemoteAddress(RvCCConnection* x, char* address)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);

    strncpy(conn->remoteAddress, address, sizeof(conn->remoteAddress)-1);
    conn->remoteAddress[sizeof(conn->remoteAddress)-1] = '\0';
}

void rvCCConnSipSetLocalAddress(RvCCConnection* x, char* address)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);

    strncpy(conn->localAddress, address, sizeof(conn->localAddress)-1);
    conn->localAddress[sizeof(conn->localAddress)-1] = '\0';

}

/*===============================================================================*/
/*===================    P R I V A T E    F U N C T I O N S    ==================*/
/*===============================================================================*/
void getPAssociatedUri(RvCCConnection* x)
{
    /* xuyf, add for PAssociateedUri, begin */
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    int nPAssociateedUriEnableFlag = 0;
    char strPAssociatedUriVal[64] ={0};
    char strUserNameVal[64] ={0};
    char *tmpPtr = NULL;
    strncpy(strUserNameVal,conn->localAddress, sizeof(conn->localAddress));
    char* pstrUserName = strtok( strUserNameVal, "@ ");
    printf("@@@ pstrUserName = %s @@@\n",pstrUserName);
    mtfImsGetPAssociatedUriStr(&nPAssociateedUriEnableFlag, pstrUserName,(char*) strPAssociatedUriVal);
    if(nPAssociateedUriEnableFlag == 1 && strPAssociatedUriVal[0] != 0)
    {         
         if((tmpPtr = strstr(conn->localAddress,"@")) != NULL)
         {
            if(strlen(tmpPtr) + strlen(strPAssociatedUriVal) < 64)
            {
                RvCCTerminal*           term      = rvCCConnSipGetTerminal(x);
                RvCCTerminalSip*      sipTerm = rvCCTerminalSipGetImpl(term);
                memset((void *)sipTerm->displayName,0,sizeof(sipTerm->displayName));
                strncpy(sipTerm->displayName,strPAssociatedUriVal, sizeof(strPAssociatedUriVal));
                
                strcat(strPAssociatedUriVal, tmpPtr);
                memset((void *)conn->localAddress,0,sizeof(conn->localAddress));
                strncpy(conn->localAddress,strPAssociatedUriVal, sizeof(strPAssociatedUriVal));                
            }
         }
    }
    /* xuyf, add for PAssociateedUri, end */ 
}

static RvStatus makeCall(RvCCConnection* x)
{
    RvCCProviderSip* provider = rvCCConnSipGetProviderImpl(x);
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvStatus rv;

     getPAssociatedUri(x);
     
    /*start a new sip call*/
    rv = rvSipControlCallMake(&provider->sipMgr, (RvSipAppCallLegHandle)x,
                            conn->remoteAddress, conn->localAddress);

    if (rv != RV_OK)
    {
		RvCCConnSip* conn = rvCCConnSipGetIns(x);

        RvLogError(ippLogSource,(ippLogSource,"makeCall: failed to make call for connection %p error %d, terminating the CallLeg.",x,rv));
		if (conn->callLegHndl == NULL)
		{
			rvCCConnSipProcessEvent(x, RV_CCTERMEVENT_REJECTCALL, NULL, RV_CCCAUSE_RESOURCES_NOT_AVAILABLE);
		}
		else
		{
			rvCCConnSipTerminate(x);
		}
    }

    return rv;
}

/* returns NULL if no match or new connection failed to be created.*/
static RvCCConnection* addressAnalyze(RvCCConnection* x, RvCCEventCause* reason)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvCCConnection* newConn = NULL;
    

    newConn = rvCCConnectionAddressAnalyzeCB(x, conn->remoteAddress,
                                            RV_CCCAUSE_INCOMING_CALL, reason);

    return newConn;

}

/*release connection resources*/
static void releaseConnection(RvCCConnection* x)
{
    RvLogDebug(ippLogSource,(ippLogSource,"<-- releaseConnection conn:%p",x));
/*
 * scenario exist when reference to this object still exists in party object
 * we clean it.
 * I don't yet understand a syncro-threading model here
 */
    if (x->curParty != NULL)
    {
        RvLogDebug(ippLogSource,(ippLogSource,"releaseConnection %p->curParty=NULL",x->curParty));
        rvCCConnectionSetConnectParty(x->curParty, NULL);
        x->curParty = NULL; /* why not rvCCConnectionSetConnectParty(x, NULL); */
    }

    if (x->transferLine != NULL) {
        /*Set other party's Transfer line to NULL too*/
        rvCCConnectionSetTransferLine(x->transferLine, NULL);
        x->transferLine = NULL;
    }

    rvCCConnSipDestruct(x);
	rvMtfAllocatorDealloc(x, sizeof(RvCCConnection));
    RvLogDebug(ippLogSource,(ippLogSource,"--> releaseConnection"));
}

/* Check if the user has enabled the configuration parameter autoDisconnect. */
static RvBool isAutoDisconnectEnabled(RvCCConnection* x)
{
	RvCCConnection* party = rvCCConnectionGetConnectParty(x);

	if (party != NULL)
	{
		RvCCTerminal* term = rvCCConnectionGetTerminal(party);
		RvCCTerminalMdm* t = rvCCTerminalMdmGetImpl(term);
		RvCCProvider* p = rvCCTerminalMdmGetProvider(t);
		RvCCProviderMdm* provider = rvCCProviderMdmGetImpl(p);

		if (provider->autoDisconnect == RV_TRUE)
		{
			return RV_TRUE;
		}
	}
	return RV_FALSE;
}


void rvCCConnSipSwitchLocalAndRemote(RvMdmMediaStreamInfo* media)
{
    RvMdmStreamDescriptor* mediaDescr = rvMdmMediaStreamInfoGetStreamDescriptor(media);
    size_t numLocal = rvMdmStreamDescriptorGetNumLocalDescriptors(mediaDescr);
    size_t numRemote = rvMdmStreamDescriptorGetNumRemoteDescriptors(mediaDescr);
    RvMdmStreamDescriptor tempMedia;
    RvSdpMsg *sdpMsg;
    unsigned int i;

    /* Store in a temporary structure*/
    rvMdmStreamDescriptorConstructCopy(&tempMedia, mediaDescr, prvDefaultAlloc);

    /* Clear remote, move local list to remote, and clear local*/
    rvMdmStreamDescriptorClearRemoteDescriptors(mediaDescr);
    if (rvMdmStreamDescriptorIsLocalDescriptorSet(mediaDescr) == rvTrue) {
        for (i=0 ; i<numLocal ; ++i) {
            sdpMsg = (RvSdpMsg *)rvMdmStreamDescriptorGetLocalDescriptor(mediaDescr, i);
            rvMdmStreamDescriptorAddRemoteDescriptor(mediaDescr, sdpMsg);
        }
        rvMdmStreamDescriptorClearLocalDescriptors(mediaDescr);
    }

    /* Move remote list from temp to local*/
    if (rvMdmStreamDescriptorIsRemoteDescriptorSet(&tempMedia) == rvTrue) {
        for (i=0 ; i<numRemote ; ++i) {
            sdpMsg = (RvSdpMsg *)rvMdmStreamDescriptorGetRemoteDescriptor(&tempMedia, i);
            rvMdmStreamDescriptorAddLocalDescriptor(mediaDescr, sdpMsg);
        }
    }

    rvMdmStreamDescriptorDestruct(&tempMedia);

}

void replaceLocalMedia(RvCCConnection* c, RvMdmMediaStreamInfo* newMedia)
{
        RvCCConnSip* conn = rvCCConnSipGetIns(c);
        RvCCProviderSip* provider = rvCCProviderSipGetImpl(conn->provider);
        RvMdmMediaStreamInfo* oldMedia = rvCCProviderSipGetMediaStream(provider, conn->streamId);
        RvUint32 oldStreamId;

        /* Use the original stream id in the new media */
        oldStreamId = rvMdmMediaStreamInfoGetId(oldMedia);
        rvMdmMediaStreamInfoSetId(newMedia, oldStreamId);

        /* Replace existing local media with the new media stored in connection*/
        /* First, release already allocated memory.*/
        RvMdmMediaStreamInfoDestruct(oldMedia);
        RvMdmMediaStreamInfoConstructCopy(oldMedia, newMedia, prvDefaultAlloc);

}


/***************************************************************************
 * buildHoldUnholdSdpMsg
 * ------------------------------------------------------------------------
 * General: This function builds an SDP msg to be sent in Hold and UnHold
 *          events.
 *          for backwards compatibility we implement Hold in one of two ways:
 *          1. Set ip address to 0.0.0.0 if the configuration parameter
 *             oldHoldFormat is set to true.
 *          2. Set connection mode to Send Only
 *
 * Return Value: RvSdpMsg
 *
 * ------------------------------------------------------------------------
 * Input:   x           - sip connection.
  ***************************************************************************/
static RvSdpMsg* buildHoldUnholdSdpMsg(RvCCConnection* c)
{
    RvCCConnSip*        conn = rvCCConnSipGetIns(c);
    RvCCConnection*     party   = rvCCConnectionGetConnectParty( c);
    RvSdpMsg            *sdpMsgOnSipSide;
    RvSdpMediaDescr     *descrOnSipSide;
    RvSdpMsg            *sdpMsgOnMdmSide;
    RvSdpMediaDescr     *descrOnMdmSide;
    RvSdpConnection     *sdpConnOnSipSide, *sdpConnOnMdmSide, *sdpDescConn;
    RvSize_t            n, i;
    RvSdpConnectionMode connMode;
	RvBool              oldHoldMsgFormat = g_sipControl->sendOldHoldFormat;

    RvLogDebug(ippLogSource,(ippLogSource, "<-- buildHoldUnholdSdpMsg conn:%p",c));
    /*Hold/Unhold ?*/

    if(c->termState == RV_CCTERMCONSTATE_HELD)
    {
        connMode = RV_SDPCONNECTMODE_SENDONLY;
    }
    else if(c->termState == RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD)
    {
        connMode = RV_SDPCONNECTMODE_INACTIVE;
    }
    else
    {
        connMode = RV_SDPCONNECTMODE_SENDRECV;
    }

	/* Find sdp on Mdm side. The MDM media contains  c= lines which may be needed
	   for hold in old format. In the end of the process the MDM and SIP media will be the same.  */
    sdpMsgOnMdmSide = rvCCConnectionGetMedia(party);

	sdpConnOnMdmSide = rvSdpMsgGetConnection(sdpMsgOnMdmSide);

	/* Holding the line */
	if (c->termState == RV_CCTERMCONSTATE_HELD)
	{
        if (sdpConnOnMdmSide != NULL)
        {
            const char* ipAddress =  rvSdpConnectionGetAddress(sdpConnOnMdmSide);

            /* Store only real address for case of reinvite failure due to 401/407 unauthorized response
			   or other rejects, and for unhold handling (storing the real address again in the SDP) */

            if ( (strcmp("0.0.0.0",ipAddress) !=0)&&(strcmp("0:0:0:0:0:0:0:0",ipAddress) !=0) )
            {
                strncpy(conn->sdpAddress, ipAddress, sizeof(conn->sdpAddress)-1);
                conn->sdpAddress[sizeof(conn->sdpAddress)-1] = '\0';
            }

			if (oldHoldMsgFormat)
			{
				/* in old Hold format the conn should be set to 0's */
#if (RV_NET_TYPE == RV_NET_IPV6)
				if (!IppUtilIsIpV4(ipAddress))
				{
					rvSdpConnectionSetAddress(sdpConnOnMdmSide, "0:0:0:0:0:0:0:0");
					rvSdpConnectionSetAddrType(sdpConnOnMdmSide, RV_SDPADDRTYPE_IP6);
				}
				else
#endif
				{
					rvSdpConnectionSetAddress(sdpConnOnMdmSide, "0.0.0.0");
					rvSdpConnectionSetAddrType(sdpConnOnMdmSide, RV_SDPADDRTYPE_IP4);
				}
			}
		}
	}
	/* Unhold */
	else
	{

		if (sdpConnOnMdmSide != NULL)
		{
			rvSdpConnectionSetAddress(sdpConnOnMdmSide, conn->sdpAddress);

#if (RV_NET_TYPE == RV_NET_IPV6)
			if (!IppUtilIsIpV4(conn->sdpAddress))
			{
				rvSdpConnectionSetAddrType(sdpConnOnMdmSide, RV_SDPADDRTYPE_IP6);
			}
			else
#endif
			{
				rvSdpConnectionSetAddrType(sdpConnOnMdmSide, RV_SDPADDRTYPE_IP4);
			}
		}

	}


	/* Loop over the media descroptors and set the connection according to the SDP connection */
    n = rvSdpMsgGetNumOfMediaDescr( sdpMsgOnMdmSide);
    for( i=0; i < n; i++)
    {
        descrOnMdmSide  = rvSdpMsgGetMediaDescr( sdpMsgOnMdmSide, i);

		if ((oldHoldMsgFormat) || (c->termState != RV_CCTERMCONSTATE_HELD))
		{
		/* In old Hold format or in UnHold we need to change the address in the connection of each
			media descriptor (if exists). The SDP connection is copied to the media descriptor connection */

			sdpDescConn = rvSdpMediaDescrGetConnection( descrOnMdmSide);

			if (sdpDescConn != NULL)
			{
				/*
				*   handle connection address
				*/
				rvSdpConnectionCopy(sdpDescConn, sdpConnOnMdmSide);
			}
		}

        /*
        *   handle send mode: sendonly|recvonly etc.
		*   In old Hold format there is no send mode.
        */
	    if (!oldHoldMsgFormat)
		{
			rvSdpMediaDescrSetConnectionMode( descrOnMdmSide, connMode);
		}
    }

    /*
    *   synchronize sdp data on Sip and Mdm side.
    */

	/* the SIP media is stored in Remote side */
    sdpMsgOnSipSide = rvCCConnSipGetMediaRemote(c);

	sdpConnOnSipSide = rvSdpMsgGetConnection(sdpMsgOnSipSide);
	if ((sdpConnOnSipSide != NULL) && (sdpConnOnMdmSide != NULL))
	{
		/*
		*   handle connection address
		*/
		rvSdpConnectionCopy(sdpConnOnSipSide, sdpConnOnMdmSide);
	}
    n = rvSdpMsgGetNumOfMediaDescr( sdpMsgOnMdmSide);
    for( i=0; i < n; i++)
    {
        descrOnSipSide  = rvSdpMsgGetMediaDescr( sdpMsgOnSipSide, i);
        sdpDescConn = rvSdpMediaDescrGetConnection( descrOnSipSide);

		if (sdpDescConn != NULL)
		{
			/*
			*   handle connection address
			*/
			rvSdpConnectionCopy(sdpDescConn, sdpConnOnSipSide);
		}

		/*   In old Hold format there is no send mode. */

		if (!oldHoldMsgFormat)
		{
			rvSdpMediaDescrSetConnectionMode( descrOnSipSide, connMode);
		}
    }

    RvLogDebug(ippLogSource,(ippLogSource, "--> buildHoldUnholdSdpMsg conn:%p",c));

    return sdpMsgOnMdmSide;

}



/*===============================================================================*/
/*===============    C O N N E C T I O N   C A L L B A C K S ====================*/
/*===============================================================================*/

void rvCCConnSipInitiatedCB(RvCCConnection* x)
{
    RV_UNUSED_ARG(x);

}

void rvCCConnSipDialingCB(RvCCConnection* x)
{
    RV_UNUSED_ARG(x);


}

void rvCCConnSipCallDeliveredCB(RvCCConnection* x, RvCCEventCause reason)
{

    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RV_UNUSED_ARG(reason);
    rvSipControlSendRinging(conn->callLegHndl);

}

/***************************************************************************
 * rvCCConnSipTransferInitCB
 * ------------------------------------------------------------------------
 * General: This function starts the transfer process.
 *
 * Return Value: RvCCMediaState (created in case of success, failure otherwise
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   x           - sip connection.
  ***************************************************************************/
RvCCMediaState rvCCConnSipTransferInitCB(RvCCConnection* x)
{

    RvBool              rc;
    RvCCConnSip*        conn        = rvCCConnSipGetIns(x);
    char *              fromAddress =conn->fromAddress;
    RvChar              destAddress[RV_IPP_ADDRESS_SIZE];
    RvCCProviderSip*    provider    = rvCCProviderSipGetImpl(conn->provider);
    RvCCMediaState      mediaState;

    RvLogDebug(ippLogSource,(ippLogSource,"<-- rvCCConnSipTransferInitCB conn:%p",x));
    if (rvCCCallGetTransferType(rvCCConnectionGetCall(x)) != RV_CCCALL_TRANSFER_BLIND)
    {
        /* In this point it is needed to get 2 sip connections:
        Here X is sip conn, party is mdm, transferline of party is the
        mdm of transfer and getparty of this is the 2nd sip conn */
        RvCCConnection  *party = rvCCConnectionGetConnectParty(rvCCConnectionGetTransferLine(rvCCConnectionGetConnectParty(x)));
        RvCCConnSip     *connParty = rvCCConnSipGetIns(party);

        /* The REFER will be sent with Refered-by address actually presented by first call */
        if (!strcmp(fromAddress,""))
        {
        /* fromAddress is Empty string, which means that
        the 1st leg of the transfer was INCOMING call.
        We have to supply "fromAddress" from "party" connection. */
            fromAddress=connParty->fromAddress;
        }

        /* Transfer-Replaces feature */
        rc = rvSipControlRefer(conn->callLegHndl, connParty->callLegHndl, connParty->remoteAddress, fromAddress);
    }
    else /* Case of Blind Transfer */
    {
        memset(destAddress, 0, sizeof(destAddress));
        if (!strcmp(fromAddress,""))
        {
        /* fromAddress is Empty string, which means that
        the 1st leg of the transfer was INCOMING call.
        Here, We have to supply "fromAddress" from the provider since party is null */
            fromAddress=provider->localAddress;
        }
        /* Blind transfer */
        rvCCConnectionGetThirdPartyDestAddress(x, destAddress);
        rc = rvSipControlRefer(conn->callLegHndl, NULL, destAddress, fromAddress);
    }
    if (rc == RV_TRUE)   /* Refer was sent successfully */
    {
        /* start the referTimer */
        IppTimerStart(&conn->referTimer, IPP_TIMER_RESTART_IF_STARTED, 0);
        mediaState = RV_CCMEDIASTATE_CREATED;
        RvLogDebug(ippLogSource, (ippLogSource, "rvCCConnSipTransferInitCB::IppTimerStart refer:%d ", RvInt64ToRvUint32((conn->referTimer).delay/1000000)));
    }
    else /* Failed to send refer */
    {
        /* The transfer process failed. Complete the transfer process. */
        rvCCCallTransferCompletedCB(x, RV_FALSE);
        mediaState = RV_CCMEDIASTATE_FAILED;
    }
    RvLogDebug(ippLogSource,(ippLogSource,"--> rvCCConnSipTransferInitCB mediaState%s",rvCCTextMediaState(mediaState)));
    return mediaState;
}

/***************************************************************************
 * rvCCConnSipTransferOfferedCB
 * ------------------------------------------------------------------------
 * General: This function is called on EP "C"
 *          when the new incoming call comes from "B" and
 *          we believe that it was transferred by "A".
 *
 * Return Value: RvCCMediaState
 *               RV_CCMEDIASTATE_CREATED if the call is transferred by "A"
 *                as part of attended transfer.
 *               RV_CCMEDIASTATE_CREATING - otherwise.
 * ------------------------------------------------------------------------
 * Input:   x           - sip connection.
  ***************************************************************************/
RvCCMediaState rvCCConnSipTransferOfferedCB(RvCCConnection* x)
{
    if (rvCCConnectionGetConnectParty(x) != NULL)
    {
        rvCCCallTransferInProcessCB(x);
        rvCCConnectionSetMediaState(x, RV_CCMEDIASTATE_CREATED);
        return RV_CCMEDIASTATE_CREATED;
    }
    else
    {
         /* The connection has no Connected party:
          *  consider the call like new incoming but not transfered one.
          */
        return RV_CCMEDIASTATE_CREATING; /* may be RV_CCMEDIASTATE_NONE (JUST NOT!!! CREATED)*/
}
}

RvCCMediaState rvCCConnSipOfferedCB(RvCCConnection* x,RvCCEventCause reason)
{
    RV_UNUSED_ARG(x);
    RV_UNUSED_ARG(reason);
    return RV_CCMEDIASTATE_CREATED;
}

void rvCCConnSipMediaCreatedCB(RvCCConnection* x)
{
    RV_UNUSED_ARG(x);
}

/*===============================================================================*/
/*=======================    C O N N E C T I O N   A P I ========================*/
/*===============================================================================*/
static RvCCTerminalEvent connStateMachine(RvCCConnection* conn, RvCCTerminalEvent event,
                                          RvCCEventCause reason, RvBool* stillAlive)
{
    RvCCConnection* otherParty;
    RvCCEventCause  cause;
    RvStatus        status;

    switch(event){

    case RV_CCTERMEVENT_NONE:
    case RV_CCTERMEVENT_UNKNOWN:
    case RV_CCTERMEVENT_OFFHOOK:
    case RV_CCTERMEVENT_ONHOOK:
    case RV_CCTERMEVENT_DIALTONE:
    case RV_CCTERMEVENT_DIGITS:
    case RV_CCTERMEVENT_DIALCOMPLETED:
	 case RV_CCTERMEVENT_DISCONNECTED:
        break;
    case RV_CCTERMEVENT_MAKECALL:
        if (conn->state == RV_CCCONNSTATE_IDLE)
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_OFFERED);
            status = makeCall(conn);
            if (status != RV_OK)
            {
                rvCCConnectionSetState(conn, RV_CCCONNSTATE_FAILED);
                if (status == RV_ERROR_OUTOFRESOURCES)
				{
					rvCCCallRejected(conn, RV_CCCAUSE_RESOURCES_NOT_AVAILABLE);
				}
                else
				{
					rvCCCallRejected(conn, RV_CCCAUSE_BUSY);
                }
            }
        }
        break;
    case RV_CCTERMEVENT_INCOMINGCALL:
        if (conn->state != RV_CCCONNSTATE_IDLE)
            break;

        if ((otherParty = addressAnalyze(conn, &cause)) != NULL)
        {

            //int dwIsReject = Psip_RejectDisabledUserIncomingCall(otherParty);
            
            if(0) //if(dwIsReject == 1)
            {
                rvCCConnSipReject(conn, RV_CCCAUSE_NOT_FOUND);
            }
            else
            {
                RvLogDebug(ippLogSource,(ippLogSource,"connStateMachine %p->curParty=%p",conn,otherParty));
                rvCCConnectionSetConnectParty(conn, otherParty);
                /* The following is added for cfw */
                RvLogDebug(ippLogSource,(ippLogSource,"connStateMachine %p->curParty=%p",otherParty,conn));
                rvCCConnectionSetConnectParty(otherParty, conn);
                /* We have just checked that otherParty != NULL
                      and set ConnectParty, which is curParty to otherParty.
                      Consequently there is no need in the next check...
    
                if (conn->curParty != NULL)
                {
                */
                if (rvCCCallProcessIncomingCB(otherParty, RV_CCCAUSE_INCOMING_CALL) == rvFalse)
                {
                    return RV_CCTERMEVENT_NONE;
                }
                rvCCConnectionSetState(conn, RV_CCCONNSTATE_ADDRESS_ANALYZE);
                    return RV_CCTERMEVENT_MEDIAOK;
                /*}*/
            }
        }
        else /* address or termination not found*/
            rvCCConnSipReject(conn, cause);
        break;

    case RV_CCTERMEVENT_RINGBACK:
        if (conn->state == RV_CCCONNSTATE_IDLE) {/*RV_CCCONNSTATE_INPROCESS or RV_CCCONNSTATE_CALL_DELIVERED?*/
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_CALL_DELIVERED);
            rvCCConnectionCallDeliveredCB(conn, RV_CCCAUSE_OUTGOING_CALL);

            /* Wait for RV_CCTERMEVENT_CALLANSWERED event*/
        }
        break;

    case RV_CCTERMEVENT_RINGING:
        if ((conn->state == RV_CCCONNSTATE_OFFERED) ||
            (conn->state == RV_CCCONNSTATE_ALERTING) ||
            /* in case of blind/semi transfer the conn state of B is call_delivered
            while C is ringing.*/
            (conn->state == RV_CCCONNSTATE_CALL_DELIVERED))
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_ALERTING);
            rvCCCallAlerting(conn, reason);
        }

        break;
    case RV_CCTERMEVENT_CALLANSWERED: /* remote party answered */
        switch (conn->state)
        {
            case RV_CCCONNSTATE_ALERTING: /*for incoming call*/
            case RV_CCCONNSTATE_TRANSFER_ALERTING: /*for incoming call*/
            case RV_CCCONNSTATE_CALL_DELIVERED: /*for outgoing call*/
            case RV_CCCONNSTATE_OFFERED: /*for outgoing call*/
                rvCCConnectionSetState(conn, RV_CCCONNSTATE_CONNECTED);
                rvCCCallConnected(conn, RV_CCCAUSE_INCOMING_CALL);
                break;
            default:
                break;
        /*lint -e{788}  all relevant cases are accounted for */
        }
        break;

    case RV_CCTERMEVENT_TRANSFER_INIT:
        /*if(conn->state==RV_CCCONNSTATE_CONNECTED)*/
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_TRANSFER_INIT);
            conn->mediaState = RV_CCMEDIASTATE_CREATING;
            if(rvCCConnectionTransferInitCB(conn)==RV_CCMEDIASTATE_CREATED)
                return RV_CCTERMEVENT_MEDIAOK;
        }
        break;

    case RV_CCTERMEVENT_TRANSFER_OFFERED:
        if(conn->state==RV_CCCONNSTATE_IDLE)
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_TRANSFER_OFFERED);
            conn->mediaState = RV_CCMEDIASTATE_CREATING;
            if(rvCCConnectionTransferOfferedCB(conn)==RV_CCMEDIASTATE_CREATED)
                return RV_CCTERMEVENT_MEDIAOK;
			/* Handle blindly transferred call without "supported replaces" header*/
            else /* we just discovered that the call is not transferred with consultation.
                    It will be treated as a new incoming call.
                 */
            {
                rvCCConnectionSetState(conn, RV_CCCONNSTATE_IDLE);
                return RV_CCTERMEVENT_INCOMINGCALL;
            }
        }
        break;
	case RV_CCTERMEVENT_REJECTCALL:
    case RV_CCTERMEVENT_FAILGENERAL:
        if (reason != RV_CCCAUSE_AUTH_FAIL)/* we don't want to reject the call if it fail to authenticate*/
		{
			if (isAutoDisconnectEnabled(conn) == RV_TRUE)
			{
				rvCCCallSendOnhookToMdmStateMachine(conn);
			}
            rvCCCallRejected(conn, reason);
		}
        break;

    case RV_CCTERMEVENT_MEDIAOK:
        switch (conn->state)
        {
            case RV_CCCONNSTATE_ADDRESS_ANALYZE:
                rvCCConnectionSetState(conn, RV_CCCONNSTATE_INPROCESS);
//add by zhuhaibo 20110301 for caller display
                PSip_getPUriParam((RvSipAppCallLegHandle)conn);
//add end
                rvCCConnectionInProcessCB(conn, RV_CCCAUSE_NEW_CALL);
                return RV_CCTERMEVENT_NONE; /* wait for RV_CCTERMEVENT_RINGBACK event*/
            case RV_CCCONNSTATE_CONNECTED:
                /* media is created after call was connected, or in case of transfered call */
                rvCCConnectionMediaCreatedCB(conn);
                break;
            default:
                break;
        /*lint -e{788}  all relevant cases are accounted for */
        }
        break;

    case RV_CCTERMEVENT_DISCONNECTING:
        if (reason != RV_CCCAUSE_NORMAL)
        {
            rvCCCallDisconnectedRemote(conn, reason);
            /*Change state after CB to disconnect SIP connection too*/
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_DISCONNECTED);
        }
        else
        {
            rvCCConnectionSetState(conn, RV_CCCONNSTATE_DISCONNECTED);
            rvCCCallDisconnectedRemote(conn, RV_CCCAUSE_NEW_CALL);
        }
        break;

    case RV_CCTERMEVENT_TERMINATED:

		/* If we got to the Terminated final stage and the connection is not in Disconnected state
		   something was missing on the way. Complete the process by sending onhook if autoDiconnect was
		   configured by the user. Otherwise the process will be completed when the user goes onhook */
		if (conn->state != RV_CCCONNSTATE_DISCONNECTED)
		{
			if (isAutoDisconnectEnabled(conn) == RV_TRUE)
			{
				rvCCCallSendOnhookToMdmStateMachine(conn);
			}
		}
		/*Inform the call this connection was released*/
        *stillAlive = rvCCCallPartyReleased(conn);
        releaseConnection(conn);
        break;

    case RV_CCTERMEVENT_MODIFYMEDIA:/* incoming re-invite or update*/
	{
        RvCCConnState   connState    = rvCCConnectionGetState(conn);

		/*When B sends Hold after receiving REFER, we should accept it*/
        if (((connState == RV_CCCONNSTATE_CONNECTED)||(connState==RV_CCCONNSTATE_TRANSFER_INIT) ||
			((conn->updateState == RV_CCUPDATESTATE_RECEIVED))) &&
             (rvCCConnectionGetMediaState(conn) != RV_CCMEDIASTATE_MODIFYING))
        {
            RvMdmMediaStreamInfo newMedia;
            rvMdmMediaStreamInfoConstructCopy(&newMedia, rvCCConnectionGetNewMedia(conn), prvDefaultAlloc);

            rvCCConnectionSetMediaState(conn, RV_CCMEDIASTATE_MODIFYING);
            /* Since in SIP conn the local media is stored in remote descriptor,
               and vice versa, we need to switch between them before we send it to MDM conn*/
            rvCCConnSipSwitchLocalAndRemote(&newMedia);

            if (rvCCCallModifyMediaCB(conn, &newMedia) == rvTrue)
            {
				RvCCConnection*         party;
                /* Switch back*/
                rvCCConnSipSwitchLocalAndRemote(&newMedia);
                /* Modify media succeeded, we can replace old media with new one*/
                replaceLocalMedia(conn, &newMedia);
                /* Send OK Reply to remote party*/
				rvCCConnSipAccept(conn, rvCCConnSipGetMediaCaps(conn));

				/* update the local media in the MDM connection */
				party = rvCCConnectionGetConnectParty(conn);
				rvCCConnectionSetLocalMedia(party, rvCCConnSipGetMediaCaps(conn));
				/* update the remote media in the MDM connection */
				rvCCConnectionSetRemoteMedia(party, rvCCConnSipGetMedia(conn));
            }
            else
            {
                /* Send Reject reply to remote party*/
                rvCCConnSipReject(conn, RV_CCCAUSE_MEDIA_NOT_SUPPORTED);
            }

            RvMdmMediaStreamInfoDestruct(&newMedia);

			/* in the sip RvCCConnection object there is no use of the media state
			   RV_CCMEDIASTATE_MODIFYING_BEFORE_CONNECTED, therefore when media modifying is done or failed
			   the state changed to CONNECTED even if the modification is triggered by an UPDATE request
			   at an early media setting stage, where the actual mediastate is CREATED. */
			rvCCConnectionSetMediaState(conn, RV_CCMEDIASTATE_CONNECTED);
        }
        else
        {
            RvLogWarning(ippLogSource,(ippLogSource,"connStateMachine::RV_CCTERMEVENT_MODIFYMEDIA, conn:%p, connState:%s, connTermState:%s",conn,rvCCTextConnState(conn->state),rvCCTextTermConnState(conn->termState) ));
        }
	}
        break;

    case RV_CCTERMEVENT_MODIFYMEDIA_DONE:/*end of outgoing re-invite*/
    {
        RvMdmMediaStreamInfo newMedia;
        RvCCConnection* party;

        rvCCConnectionSetMediaState(conn, RV_CCMEDIASTATE_CONNECTED);

        /* get the media after negotiation which is stored in the MDM connection    */
        party = rvCCConnectionGetConnectParty( conn);
        rvMdmMediaStreamInfoConstructCopy(&newMedia, rvCCConnectionGetNewMedia(party), prvDefaultAlloc);

        if (reason == RV_CCCAUSE_OPERATION_FAILED)
            rvCCCallModifyMediaDoneCB(conn, rvFalse, &newMedia, RV_MDMTERMREASON_REMOTE_REJECTED);
        else
        {
            /* This is the end of modify media process, we can replace old media with new one*/
            /* in the SIP connection we store the re-invite outgoing sdp msg in the remote media
            and the sdp of the OK msg in the local media                                */
            replaceLocalMedia(conn, rvCCConnectionGetNewMedia(conn));

            rvCCCallModifyMediaDoneCB(conn, rvTrue, &newMedia, RV_MDMTERMREASON_SUCCESS);
        }

        RvMdmMediaStreamInfoDestruct(&newMedia);
        break;
    }

    default:
        return RV_CCTERMEVENT_UNKNOWN;
    /*lint -e{788}  all relevant cases are accounted for */
    }

    return RV_CCTERMEVENT_NONE;

}

void rvCCConnSipProcessEvent(
                RvCCConnection*     conn,
                RvCCTerminalEvent   event,
                RvBool*             callStillAlive,
                RvCCEventCause      reason)
{
    RvCCTerminalEvent   nextEvent = event;
    RvCCEventCause      origReason = reason;

    do
    {
        nextEvent = connStateMachine(conn, event, reason, callStillAlive);
        if ((callStillAlive != NULL) && (*callStillAlive == 1))
		{
			rvCCTextPrintEvent(conn, &event, nextEvent, &origReason, reason);
		}

        event = nextEvent;
    } while (nextEvent != RV_CCTERMEVENT_NONE);

}

/***************************************************************************
 * rvCCConnSipReferTimerExpires
 * ------------------------------------------------------------------------
 * General: This function is called when the Sip refer timer is expired.
 *
 * Return Value: RvBool (rvTrue in case of success, rvFalse in case of failure
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   data            - user data which is the connection itself.
  ***************************************************************************/
RvBool rvCCConnSipReferTimerExpires( void* data)
{

    RvCCConnection*         c                   = (RvCCConnection*)data;
    RvCCConnSip*            conn                = rvCCConnSipGetIns(c);
    RvSipAppCallLegHandle   hAppCallLegHandle;

    /* NOTIFY has not been received after a REFER message was sent.
    Since NOTIFY message is not mandatory we will assume that the transfer succeeded  */
    RvLogInfo(ippLogSource,(ippLogSource,"<-- rvCCConnSipReferTimerExpires for connection %p",c));
    RvSipCallLegGetAppHandle(conn->callLegHndl,&hAppCallLegHandle);
    rvCCProviderSipTransferNotified(hAppCallLegHandle, RV_FALSE);

    RvLogInfo(ippLogSource,(ippLogSource,"--> rvCCConnSipReferTimerExpires 1"));
    return rvTrue;
}

/******************************************************************************
*  rvCCConnSipResendUpdate
*  -----------------------
*  General :        This function is called when resend UPDATE timer expires.
*					It sends UPDATE request again.
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          data                pointer to connection object
*
*  Output:         RvBool
******************************************************************************/
RvBool rvCCConnSipResendUpdate( void* data)
{
    RvCCConnection*     c      = (RvCCConnection*)data;
	/* get the SDP that was sent in the previous UPDATE message */
	RvSdpMsg*           sdpMsg = rvCCConnSipGetUpdateSdp(c);

	/* Verify that all pre conditions for sending UPDATE are fulfilled */
	if (rvCCConnSipIsUpdatePermitted(c))
	{
		rvSipControlSendUpdate(c, sdpMsg);
	}
	else
		if (sdpMsg != NULL)
		{
			rvSdpMsgDestruct(sdpMsg);
		}

	return RV_TRUE;

}

/*******************************************************************************
 * rvTimerSendRinging
 * purpose: send RINGING (180) and restart timer to Resend it
 *          or stop timer if the call is answered.
 *          If the call was canceled timer is destructed and
 *          this function is not called
 * parameters:
 *   data  - RvCCConnection
 *******************************************************************************/
RvBool rvTimerSendRinging(void* data)
{
    RvCCConnection* xConn = (RvCCConnection*) data;
    RvCCConnSip* conn;

    if (xConn == NULL)
      return rvFalse;
    else
    {
        conn = rvCCConnSipGetIns(xConn);
        if (xConn->state == RV_CCCONNSTATE_INPROCESS)
        {
            rvSipControlSendRinging (conn->callLegHndl);
            IppTimerStart(&conn->ringingTimer, IPP_TIMER_RESTART_IF_STARTED, 0);
        }
        else
            IppTimerStop(&conn->ringingTimer);

    }
    return rvTrue;
}


/***************************************************************************
 * rvCCConnSipNotifyError
 * ------------------------------------------------------------------------
 * General: This function notifies the Ipp on errors. (for example, from tls or stun features)
 *
 * Return Value: -
 * ------------------------------------------------------------------------
 *  Arguments:
 *  Input:         RvCCConnection *connection: pointer to sip connection
 *  Output:        None
***************************************************************************/
void rvCCConnSipNotifyError(RvCCConnection *connection)
{

    if (connection->call !=NULL)
    {
        RvBool          callStillAlive;
        RvCCConnState   state;
        RvCCConnection* cMdm = rvCCConnectionGetConnectParty(connection);

        if ((cMdm !=NULL) && (cMdm->call != NULL))
        {
            state = rvCCConnectionGetState(cMdm);

            if((state != RV_CCCONNSTATE_IDLE) &&
                (state != RV_CCCONNSTATE_DISCONNECTED) &&
                (state != RV_CCCONNSTATE_UNKNOWN))
            {
                rvCCConnSipProcessEvent( connection, RV_CCTERMEVENT_FAILGENERAL, &callStillAlive, RV_CCCAUSE_NORMAL);
            }
        }

    }
}
void rvCCConnSipConstruct(RvCCConnection* x, RvCCProvider* p, RvCCTerminal* t, RvAlloc* a)
{

    RvCCProviderSip* provider = rvCCProviderSipGetImpl(p);
    RvCCConnSip* conn = NULL;
	rvMtfAllocatorAlloc(sizeof(RvCCConnSip), (void**)&conn);

    memset(conn, 0, sizeof(*conn));
    conn->provider = p;
    conn->terminal = t;
    conn->streamId = RV_CONNSIP_STREAMID_NONE;
    conn->rejectCall = rvFalse;
    conn->callLegHndl = NULL;
    conn->alloc = a;
	conn->offerAnswerState = RV_MTF_OFFERANSWER_OFFER_NONE;
	conn->updateAllowedByRemoteParty =  RV_TRUE;      	/* always true until we receive a message with ALLOW header that
													       does not contain UPDATE in it */
	conn->sdpOfLastSentUpdate = NULL;

    rvCCConnectionConstruct(x, NULL, conn, RV_CCCONNTYPE_NETWORK, &provider->connFuncs, &provider->connClbks);

    IppTimerConstruct( &conn->referTimer, (RvUint32)provider->referTimeout, rvCCConnSipReferTimerExpires, x);
    IppTimerConstruct(&conn->ringingTimer, (RvUint32)SIP_MINUTE_RESEND, rvTimerSendRinging, x);
	IppTimerConstruct(&conn->updateResendTimer, 0, rvCCConnSipResendUpdate, x);
    RvLogInfo(ippLogSource,(ippLogSource, "SIP Connection Constructed (%p)", conn));
}

void rvCCConnSipDestruct(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvCCProvider*   p = rvCCConnSipGetProvider(x);
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(p);

    rvCCProviderSipClearMediaStream(provider, conn->streamId);

    IppTimerDestruct(&conn->referTimer);

    IppTimerStop(&conn->ringingTimer);
    IppTimerDestruct(&conn->ringingTimer);
	IppTimerDestruct(&conn->updateResendTimer);


    RvLogInfo(ippLogSource,(ippLogSource,"SIP Connection Destruct (%p)",conn));

	rvMtfAllocatorDealloc(conn, sizeof(RvCCConnSip));

    rvCCConnectionDestruct(x);

}
/***************************************************************************
 * rvCCConnSipAccept
 * ------------------------------------------------------------------------
 * General: This function handles acceptance of an incoming request, i.e.
 *          triggers sending an OK (200) response.
 *          It distinguishes between UPDATE requests and other requests
 *          that should be handled differently.
 *
 * Return Value: -
 * ------------------------------------------------------------------------
 *  Arguments:
 *  Input:         RvCCConnection *connection: pointer to sip connection
 *                 inMedia         Sdp that will be inserted to the OK message
 *  Output:        None
***************************************************************************/
void rvCCConnSipAccept(RvCCConnection* x, RvSdpMsg* inMedia)
{
    RvCCConnSip*		conn = rvCCConnSipGetIns(x);
	RvMtfUpdateState	updateState = x->updateState;

	if (updateState ==  RV_CCUPDATESTATE_RECEIVED)
	{
		/* Accept an incoming UPDATE request */
		rvSipControlUpdateAccept(conn->callLegHndl, inMedia);
		rvCCConnSetUpdateState(x, RV_CCUPDATESTATE_NONE);
	}
	else
	{
		rvSipControlCallAccept(conn->callLegHndl, inMedia);
	}

}
/***************************************************************************
 * rvCCConnSipReject
 * ------------------------------------------------------------------------
 * General: This function handles rejecting of an incoming request.
 *          It converts the rejection reason to a SIP reject code.
 *          It distinguishes between UPDATE requests and other requests
 *          that should be handled differently.
 *
 * Return Value: -
 * ------------------------------------------------------------------------
 *  Arguments:
 *  Input:         RvCCConnection *connection: pointer to sip connection
 *                 reason         reason for the call reject.
 *  Output:        None
***************************************************************************/
void rvCCConnSipReject(RvCCConnection* x, RvCCEventCause reason)
{
    RvCCConnSip*		conn = rvCCConnSipGetIns(x);
    int					responseCode = RV_SIPCTRL_STATUS_BUSYHERE;	/* give a bogus response code, so at least we return
													a valid response */
	RvMtfUpdateState	updateState = x->updateState;

    switch(reason)
    {
    case RV_CCCAUSE_NOT_FOUND:
        responseCode = RV_SIPCTRL_STATUS_NOTFOUND;
        break;
    case RV_CCCAUSE_BUSY:
        responseCode = RV_SIPCTRL_STATUS_BUSYHERE;
        break;
    case RV_CCCAUSE_MEDIA_NOT_SUPPORTED:
        responseCode = RV_SIPCTRL_STATUS_NOTACCEPT_HERE;
        break;
    case RV_CCCAUSE_CALL_CANCELLED:
        responseCode = RV_SIPCTRL_STATUS_FORBIDDEN;
        break;
	case RV_CCCAUSE_BAD_REQUEST:
		responseCode = RV_SIPCTRL_STATUS_BADREQUEST;

    default:
        break;
    /*lint -e{788}  all relevant cases are accounted for */
    }

	if (updateState ==  RV_CCUPDATESTATE_RECEIVED)
	{
		/* need to reject an UPDATE request */
		rvSipControlRejectUpdate(conn->callLegHndl, NULL, responseCode);
		rvCCConnSetUpdateState(x, RV_CCUPDATESTATE_NONE);
	}
	else
	{
		rvSipControlReject(conn->callLegHndl, responseCode);
	}

}
/*
static RvBool setLocalMedia(RvCCConnection* x, RvSdpMsg* sdp)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(conn->provider);
    RvMdmMediaStreamInfo* media;
    const RvSdpMsg* localSdpCaps;
    RvMdmStreamDescriptor* mediaCaps = rvCCProviderSipGetMediaCaps(provider);

    localSdpCaps = rvMdmStreamDescriptorGetLocalDescriptor(mediaCaps, 0);

    /Set media stream and connection taken from local media (ip address & port)/
    rvSdpConnectionCopy(rvSdpMsgGetConnection(localSdpCaps), rvSdpMsgGetConnection(sdp));
    rvSdpMediaDescrConstructCopy(rvSdpMsgGetMediaDescr(localSdpCaps, 0), rvSdpMsgGetMediaDescr(sdp, 0));
    rvSdpMediaDescrCopy(rvSdpMsgGetMediaDescr(localSdpCaps, 0), rvSdpMsgGetMediaDescr(sdp, 0));

    / no media yet, add an empty media stream/
    if (conn->streamId == RV_CONNSIP_STREAMID_NONE)  {
        conn->streamId = rvCCProviderSipAddEmptyMediaStream(provider);
    }

    media =  rvCCProviderSipGetMediaStream(provider, conn->streamId);
    rvMdmMediaStreamInfoAddLocalDescriptor(media, (RvSdpMsg*)localSdpCaps);

    return rvTrue;
}
*/

void rvCCConnSipMakeCall(RvCCConnection* x, RvSdpMsg* inMedia)
{

   /*setLocalMedia(x, inMedia);*/
    rvCCConnSipSetRemoteMedia(x, inMedia, RV_TRUE);
    rvCCConnSipProcessEvent(x, RV_CCTERMEVENT_MAKECALL, NULL, RV_CCCAUSE_NEW_CALL);

}


/*if remote party hanged up, release resources only. if local party hanged up,
send bye message (can't release resources yet since we need to wait for ack).
If the connection is in IDLE state, no call-leg was created.*/
void rvCCConnSipDisconnecting(RvCCConnection* x,RvCCEventCause reason)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);

    if (reason == RV_CCCAUSE_TRANSFER)
	{
		/* set curParty to NULL in case of call transfer, this will prevent media disconnect of party C
		   on its connection with party B */
		if (x->curParty != NULL)
		{
			RvLogDebug(ippLogSource,(ippLogSource,"rvCCConnSipDisconnecting %p->curParty=NULL",x->curParty));
			x->curParty = NULL;
		}
	}

    if ((reason==RV_CCCAUSE_BUSY) ||
        (reason==RV_CCCAUSE_MEDIA_NOT_SUPPORTED) ||
        (reason == RV_CCCAUSE_CALL_CANCELLED))
    {
        rvCCConnSipReject(x,reason);
        return;
    }

    /*If remote party disconnected, no need to send bye message only ack*/
    if ((x->state != RV_CCCONNSTATE_DISCONNECTED) &&
        (x->state != RV_CCCONNSTATE_IDLE) &&
        (x->state != RV_CCCONNSTATE_FAILED)) {
        rvCCConnectionSetState(x, RV_CCCONNSTATE_DISCONNECTED);
        RvSipCallLegDisconnect(conn->callLegHndl);
    }

}

/*Start a ringback in the connection
Connection must be in ESTABLISHED state
Ringback will stop in modify media or moving out of ESTABLISHED ?*/
void rvCCConnSipRingback(RvCCConnection* x, /*RvSdpMsg* inMedia, */RvCCEventCause reason)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(conn->provider);
/*  we will not send Media in Ringing
    rvCCConnSipSetRemoteMedia(x, inMedia, RV_TRUE);
 */

    switch (reason)
    {
        case RV_CCCAUSE_CALL_WAITING:
            if (provider->callWaitingReply == RV_REPLY_QUEUED)
                rvSipControlSendQueued ( conn->callLegHndl);
            else /*provider->callWaitingReply == RV_REPLY_RINGING */
                rvSipControlSendRinging ( conn->callLegHndl);
            break;
        case RV_CCCAUSE_TRANSFER: /*If call was transfered, no need to play ringback*/
            break;
        default:
            /*send ringing response*/
            rvSipControlSendRinging ( conn->callLegHndl);
            /* start a timer to resend ringing every minute is there is no answer */
            IppTimerStart(&conn->ringingTimer, IPP_TIMER_RESTART_IF_STARTED, 0);

    /*lint -e{788}  all relevant cases are accounted for */
    }
}


RvStatus rvCCConnSipForwardCall(RvCCConnection* x, RvChar *sendToAddress)
{
    RvStatus            rc;
    RvSipCallLegHandle  hCallLeg;

    hCallLeg            = rvCCConnSipGetCallLegHandle(x);


    if ((rc = rvSipControlForwardCall(hCallLeg, x, sendToAddress)) == RV_OK)
    {
        if ((rc = RvSipCallLegReject (hCallLeg, RV_SIPCTRL_STATUS_MOVEDTEMP)) != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvCCConnSipForwardCall: RvSipCallLegReject fail, rc = %d", rc));
        }
        else
        {
            RvLogInfo(ippLogSource,(ippLogSource,"rvCCConnSipForwardCall: Forward call successfully"));
        }
    }
    else
    {
        RvLogError(ippLogSource,(ippLogSource,"rvCCConnSipForwardCall: rvSipControlForwardCall fail, rc = %d", rc));
    }
    return rc;
}

RvBool rvCCConnSipHold(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvSdpMsg* sdpMsg;

    rvCCConnectionSetTermState(x, RV_CCTERMCONSTATE_HELD);

    sdpMsg = buildHoldUnholdSdpMsg(x);

    return rvSipControlSendModify(conn->callLegHndl, x, sdpMsg);
}

RvBool rvCCConnSipUnhold(RvCCConnection* x, RvMdmMediaStreamInfo*   streamDescr)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvCCTermConnState state;
    RvSdpMsg* sdpMsg;
	RV_UNUSED_ARG(streamDescr);

    if (rvCCConnectionGetTermState(x) == RV_CCTERMCONSTATE_REMOTE_HELD_LOCAL_HELD)
        state = RV_CCTERMCONSTATE_REMOTE_HELD;
    else
        state = RV_CCTERMCONSTATE_TALKING;
    rvCCConnectionSetTermState(x, state);

    sdpMsg = buildHoldUnholdSdpMsg(x);

    return rvSipControlSendModify(conn->callLegHndl,x, sdpMsg);
}

RvBool rvCCConnSipRemoteHold(RvCCConnection* x)
{
    return rvCCConnSipHold(x);
}

RvBool rvCCConnSipRemoteUnhold(RvCCConnection* x)
{
    return rvCCConnSipUnhold(x, NULL);
}


const char* rvCCConnSipGetCallerName(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);

    if (conn->callerName[0])
        return conn->callerName;

    return NULL;
}

const char* rvCCConnSipGetCallerAddress(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);

    if (conn->callerAddress[0])
        return conn->callerAddress;

    return NULL;
}

const char* rvCCConnSipGetCallerNumber(RvCCConnection* x, int index)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);

    RV_UNUSED_ARG(index); /* this parameter is used in h323 for multiple numbers*/

    if (conn->callerNumber[0])
        return conn->callerNumber;

    return NULL;
}

void rvCCConnSipSetCallerName(RvCCConnection* x, char* name)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    strncpy(conn->callerName, name, sizeof(conn->callerName)-1);
    conn->callerName[sizeof(conn->callerName)-1] = '\0';
}

void rvCCConnSipSetCallerAddress(RvCCConnection* x, char* address)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    strncpy(conn->callerAddress, address, sizeof(conn->callerAddress)-1);
    conn->callerAddress[sizeof(conn->callerAddress)-1] = '\0';
}

void rvCCConnSipSetCallerNumber(RvCCConnection* x, char* name)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    strncpy(conn->callerNumber, name, sizeof(conn->callerNumber)-1);
    conn->callerNumber[sizeof(conn->callerNumber)-1] = '\0';
}

const char* rvCCConnSipGetCallerId(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    return conn->callerId;
}

void rvCCConnSipSetCallerId(RvCCConnection* x, char* callerId)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    strncpy(conn->callerId, callerId, sizeof(conn->callerId)-1);
    conn->callerId[sizeof(conn->callerId)-1] = '\0';
}

void rvCCConnSipTransferInit(RvCCConnection* x)
{
    rvCCConnectionSetMediaState(x,RV_CCMEDIASTATE_DISCONNECTED);
    rvCCConnSipProcessEvent(x,RV_CCTERMEVENT_TRANSFER_INIT, NULL, RV_CCCAUSE_TRANSFER);
}

/*Called after rvCCConnSipTransferInit - disconnect the party on Hold*/
void rvCCConnSipTransferInProgress(RvCCConnection* x)
{
    rvCCConnectionDisconnect(x,RV_CCCAUSE_NORMAL);
}

/* Placeholder to send DTMF to the other side */
void rvCCConnSipPlayDtmf(IN RvCCConnection* x, IN RvDtmfParameters* dtmfParam)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);

    rvSipControlSendDTMF(conn->callLegHndl, dtmfParam);
}



static const RvSdpMsg* getLocalMedia(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(conn->provider);
    RvMdmMediaStreamInfo* media = rvCCProviderSipGetMediaStream(provider, conn->streamId);
    RvBool res;
    if (media == NULL)
        return NULL;
    res = rvMdmStreamDescriptorIsLocalDescriptorSet(&media->streamDescr);
    if (res == rvTrue)
        return rvMdmStreamDescriptorGetLocalDescriptor(&media->streamDescr, 0);
    return NULL;

}

static const RvSdpMsg* getRemoteMedia(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(conn->provider);
    RvMdmMediaStreamInfo* media = rvCCProviderSipGetMediaStream(provider, conn->streamId);

    RvBool res = rvMdmStreamDescriptorIsRemoteDescriptorSet(&media->streamDescr);
    if (res == rvTrue)
        return rvMdmStreamDescriptorGetRemoteDescriptor(&media->streamDescr, 0);
    return NULL;

}

/*returns the local media*/
RvSdpMsg* rvCCConnSipGetMedia(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    if (conn->streamId == RV_CONNSIP_STREAMID_NONE)
        return NULL;

    return (RvSdpMsg*)getLocalMedia(x);
}

/*returns the remote media (capabilities of other party)*/
RvSdpMsg* rvCCConnSipGetMediaRemote(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    if (conn->streamId == RV_CONNSIP_STREAMID_NONE)
        return NULL;

    return (RvSdpMsg*)getRemoteMedia(x);
}

/*returns the remote media (capabilities of other party)*/
RvSdpMsg* rvCCConnSipGetMediaCaps(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    if (conn->streamId == RV_CONNSIP_STREAMID_NONE)
        return NULL;

    /*TODO: should return LOCAL media caps*/
    return (RvSdpMsg*)getRemoteMedia(x);
}

RvSdpMsg* rvCCConnSipGetAllMediaCaps(RvCCConnection* x)
{
    RvCCProvider* p;
    RvCCProviderSip* provider;
    RvMdmStreamDescriptor* mediaCaps;


    if ((p = rvCCConnSipGetProvider(x)) == NULL)
        return NULL;

    if ((provider = rvCCProviderSipGetImpl(p)) == NULL)
        return NULL;

    if ((mediaCaps = rvCCProviderSipGetMediaCaps(provider)) == NULL)
        return NULL;

    return (RvSdpMsg*)(rvMdmStreamDescriptorGetLocalDescriptor(mediaCaps, 0));

}

RvCCMediaState rvCCConnSipCreateMedia(RvCCConnection* x, RvSdpMsg* inMedia)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(conn->provider);
    RvMdmMediaStreamInfo* media;
    RvCCMediaState mediaState = RV_CCMEDIASTATE_NONE;

    if (inMedia == NULL)
        return mediaState;

    RvLogInfo(ippLogSource, (ippLogSource,
        "RvCCConnSip::Creating Local Media, conn %p", x));

    /* no media yet, add an empty media stream*/
    if (conn->streamId == RV_MDM_STREAMID_NONE)  {
        conn->streamId = rvCCProviderSipAddEmptyMediaStream(provider);
    }
    media = rvCCProviderSipGetMediaStream(provider, conn->streamId);

    /* clear any existing local media*/
    if (rvMdmMediaStreamInfoIsLocalDescriptorSet(media) == rvTrue)
        rvMdmMediaStreamInfoClearLocal(media);

    rvMdmMediaStreamInfoAddLocalDescriptor(media, inMedia);

    if ((rvCCConnectionMediaUpdatedCB(x, inMedia)) == rvFalse)
        mediaState = RV_CCMEDIASTATE_FAILED;
    else
	{
        /* We may get to this proc in the process of modifying media (re-invite)
           or in other scenarios. We don't want to change the original media state
           unless it was not set before */

      	mediaState = rvCCConnectionGetMediaState(x);

        if (mediaState == RV_CCMEDIASTATE_NONE)
            mediaState = RV_CCMEDIASTATE_CREATING;
	}

    rvCCConnectionSetMediaState(x, mediaState);
    return mediaState;

}
/* Change the existing media.
Note: Do I need additional media states  ? Probably.
Needs a callback to return modified media...*/
RvBool rvCCConnSipSetRemoteMedia(RvCCConnection* x, RvSdpMsg* inMedia, RvBool modify)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    RvCCProviderSip* provider = rvCCProviderSipGetImpl(conn->provider);
    RvMdmMediaStreamInfo* media;
	RV_UNUSED_ARG(modify);

    if (inMedia == NULL)
        return rvTrue;

    RvLogInfo(ippLogSource,(ippLogSource,"RvCCConnSip::Setting Remote Media, conn %p", x));

    /* no remote media yet, add an empty media stream*/
    if (conn->streamId == RV_CONNSIP_STREAMID_NONE)  {
        conn->streamId = rvCCProviderSipAddEmptyMediaStream(provider);

    }

    media = rvCCProviderSipGetMediaStream(provider, conn->streamId);

    rvMdmMediaStreamInfoClearRemote(media);
    rvMdmMediaStreamInfoAddRemoteDescriptor(media, inMedia);

    return rvTrue;
}
/*
void rvCCConnSipConnectMedia(RvCCConnection* x)
{
}

void rvCCConnSipDisconnectMedia(RvCCConnection* x)
{
}
*/
void rvCCConnSipSetOtherParty(RvCCConnection* x, RvCCConnection* otherParty)
{

    x->curParty = otherParty;

}

void rvCCConnSipCallAnswered(RvCCConnection* x,RvSdpMsg* inMedia)
{
    RvSdpMsg* media = rvCCConnectionGetMedia(rvCCConnectionGetConnectParty(x));
    RvCCConnSip* conn = rvCCConnSipGetIns(x);

    RV_UNUSED_ARG(inMedia);
    rvCCConnSipSetRemoteMedia(x, media, RV_TRUE);

    if (x->state != RV_CCCONNSTATE_CONNECTED) {
        rvCCConnectionSetState(x, RV_CCCONNSTATE_CONNECTED);
        rvSipControlCallAccept(conn->callLegHndl, rvCCConnSipGetMediaCaps(x)); /*Send OK*/
    }

}
/*Outgoing re-invite*/
RvBool rvCCConnSipModifyMedia(RvCCConnection* x, RvMdmMediaStreamInfo* streamDescr)
{
    RvCCConnSip*    conn    = rvCCConnSipGetIns(x);
    const RvSdpMsg* sdpMsg  = NULL;
    RvBool ret              = rvFalse;

    RvLogEnter(ippLogSource, (ippLogSource,
        "rvCCConnSipModifyMedia(x=%p, streamDescr=%p)", x, streamDescr));

	/* in the sip RvCCConnection object there is no use of the media state
	   RV_CCMEDIASTATE_MODIFYING_BEFORE_CONNECTED, therefore the current state before
	   changing to MODIFYING is not checked.*/
	rvCCConnectionSetMediaState(x, RV_CCMEDIASTATE_MODIFYING);

    sdpMsg = rvMdmMediaStreamInfoGetLocalDescriptor(streamDescr, 0);

    /* Send Re-invite with the new media*/
    ret = rvSipControlSendModify(conn->callLegHndl, x, (RvSdpMsg*)sdpMsg);


    /* Store new local media in connection
      (in SIP conn the local media is stored in remote descriptor, and vice versa)*/
    /* We need to remove the previously stored media first,                  */
    /* otherwise the new media will be linked after it and won't be handled. */
    rvMdmMediaStreamInfoClearRemote(&x->newMediaStream);
    rvCCConnectionAddNewMediaRemoteDescr(x, (RvSdpMsg*)sdpMsg);

    RvLogLeave(ippLogSource, (ippLogSource, "rvCCConnSipModifyMedia()=%d", ret));
    return ret;
}

/******************************************************************************
*  rvCCConnSipModifyMediaDone
*  ----------------------------
*  General : Incoming re-invite has been received. The reply is stored in the
*            Sip connection media capabilities  (remote media)
*  Return Value:
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:
*
*  Output:         none.
******************************************************************************/

void rvCCConnSipModifyMediaDone(RvCCConnection*             x,
                                RvBool                      status,
                                RvMdmMediaStreamInfo*       newMedia,
                                RvMdmTermReasonModifyMedia  reason)
{
    RV_UNUSED_ARG(reason);

    if (status == rvTrue)
    {
        RvMdmMediaStreamInfo*   newMediaStream = rvCCConnectionGetNewMedia(x);
        const RvSdpMsg *sdpMsg = rvMdmMediaStreamInfoGetLocalDescriptor(newMediaStream, 0);
        rvCCConnSipSetRemoteMedia(x, (RvSdpMsg*)sdpMsg, RV_TRUE);
        rvCCConnSipAccept(x, rvCCConnSipGetMediaCaps(x));
    }
    else
    {
        rvCCConnSipReject(x, RV_CCCAUSE_MEDIA_NOT_SUPPORTED);
        rvCCConnectionClearNewMedia(x);
    }

    RV_UNUSED_ARG(newMedia);

}

/******************************************************************************
*  rvCCConnSipChangeOfferAnswerState
*  ---------------------------------
*  General :        Changes the offer-answer state according to the message
*                   that is currently handled.
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                pointer to connection object
*                  outgoingMsg      a boolean denoting if the message is utgoing or incoming
*                  isMsgAck         a boolean denoting if the message is ACK
*
*  Output:         RvBool
******************************************************************************/
void rvCCConnSipChangeOfferAnswerState(RvCCConnection* x, RvBool outgoingMsg, RvBool isMsgAck)
{

	/* State transition table:                                                                                          */
	/* =======================                                                                                          */
	RvMtfOfferAnswerState offerAnswerStateTransition[RV_MTF_OFFERANSWER_NUM_OF_STATES][2] =
	{
  /*         Old State                 |             state after                |            state after                */
  /*	                               |               inc msg                  |             outg msg                  */
  /* ----------------------------------+----------------------------------------+-------------------------------------- */
  /*                                   |                                        |                                       */
  /* RV_MTF_OFFERANSWER_OFFER_NONE     */ { RV_MTF_OFFERANSWER_OFFER_RECEIVED,        RV_MTF_OFFERANSWER_OFFER_SENT },
  /*                                   |                                        |                                       */
  /* RV_MTF_OFFERANSWER_OFFER_BUILDING */ { RV_MTF_OFFERANSWER_OFFER_RECEIVED,        RV_MTF_OFFERANSWER_OFFER_SENT},
  /*                                   |                                        |                                       */
  /* RV_MTF_OFFERANSWER_OFFER_SENT     */ { RV_MTF_OFFERANSWER_OFFER_ANSWERED,        RV_MTF_OFFERANSWER_OFFER_SENT },
  /*                                   |                                        |                                       */
  /* RV_MTF_OFFERANSWER_OFFER_RECEIVED */ { RV_MTF_OFFERANSWER_OFFER_RECEIVED,        RV_MTF_OFFERANSWER_OFFER_ANSWERED},
  /*                                   |                                        |                                       */
  /* RV_MTF_OFFERANSWER_OFFER_ANSWERED */ { RV_MTF_OFFERANSWER_OFFER_RECEIVED,        RV_MTF_OFFERANSWER_OFFER_SENT}
  /* ----------------------------------+----------------------------------------+-------------------------------------- */
	};

	RvMtfOfferAnswerState newState, oldState;
	oldState = rvCCConnSipGetOfferAnswerState(x);

   /* if the message is ACK the offer-answer state moves to ANSWERED regardless of the current state */
	if (isMsgAck)
	{
		newState = RV_MTF_OFFERANSWER_OFFER_ANSWERED;
	}
	else
	/* Move to state according to the state transition table above  */
	{
		newState = offerAnswerStateTransition[oldState][outgoingMsg];
	}

	rvCCConnSipSetOfferAnswerState(x, newState);

	RvLogDebug(ippLogSource, (ippLogSource, "rvCCConnSipChangeOfferAnswerState : Moving from state %s to %s, conn %p, isMsgAck = %d ",
		                     rvMtfTextOfferAnswerState(oldState), rvMtfTextOfferAnswerState(newState), x, isMsgAck));

}


/******************************************************************************
*  rvCCConnSipIsUpdatePermitted
*  ----------------------------
*  General :        Verify if UPDATE message can be sent or accepted
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                pointer to CC connection object
*
*  Output:         RvBool
******************************************************************************/
RvBool rvCCConnSipIsUpdatePermitted(RvCCConnection* x)
{
	RvCCConnection* party;

	/* verify that the MTF is configured to support UPDATE method */
	if (!g_sipControl->addUpdateSupport)
	{
		RvLogInfo(ippLogSource, (ippLogSource, "rvCCConnSipIsUpdatePermitted: UPDATE is not supported"));
		return RV_FALSE;
	}
	/* verify that at least one offer/answer process has been completed and there is no other
	   process going on */
	if (rvCCConnSipGetOfferAnswerState(x) != RV_MTF_OFFERANSWER_OFFER_ANSWERED)
	{
		RvLogInfo(ippLogSource, (ippLogSource,
			"rvCCConnSipIsUpdatePermitted: can't handle UPDATE when not in ANSWERED state, conn %p", x));
		return RV_FALSE;
	}
	/* verify that we are not in the middle of other UPDATE processing */
	if (rvCCConnGetUpdateState(x) != RV_CCUPDATESTATE_NONE)
	{
		RvLogInfo(ippLogSource, (ippLogSource,
			"rvCCConnSipIsUpdatePermitted: a previous UPDATE in process, conn %p", x));
		return RV_FALSE;
	}
	/* Check if the other end allows UPDATE reception */
	if (!rvCCConnSipIsUpdateAllowedByRemoteParty(x))
	{
		RvLogError(ippLogSource, (ippLogSource,
			"rvCCConnSipIsUpdatePermitted: an UPDATE is not supported by remote party, conn %p", x));
		return RV_FALSE;
	}

	/* make sure there is no re-invite in process by checking the media state */
	/* Note - the media state is held in the MDM RvCCConnection object        */
	party = rvCCConnectionGetConnectParty(x);
	if (rvCCConnectionGetMediaState(party) == RV_CCMEDIASTATE_MODIFYING)
	{
		RvLogInfo(ippLogSource, (ippLogSource,
			"rvCCConnSipIsUpdatePermitted: modify media is in process, conn %p", x));
		return RV_FALSE;
	}

	return RV_TRUE;
}

void rvCCConnSipTerminate(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);

    rvSipControlTerminate(conn->callLegHndl);
}

void rvCCConnSipRelease(RvCCConnection* x)
{
	RvSipCallLegHandle callLegHndl;

	callLegHndl = rvCCConnSipGetCallLegHandle(x);
	/*Stop processing SIP events after connection is released */
	RvSipCallLegSetAppHandle(callLegHndl, NULL);
	rvCCConnSipDestruct(x);
	rvMtfAllocatorDealloc(x, sizeof(RvCCConnection));
}

RvBool rvCCConnSipIsDisconnected(RvCCConnection* x)
{
    return (x->state == RV_CCCONNSTATE_DISCONNECTED);
}

void rvCCConnSipSetCallLegHandle(RvCCConnection* x, RvSipCallLegHandle hCallLeg)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    conn->callLegHndl = hCallLeg;
}

RvSipCallLegHandle rvCCConnSipGetCallLegHandle(RvCCConnection* x)
{
    RvCCConnSip* conn = rvCCConnSipGetIns(x);
    return (conn->callLegHndl);

}

/******************************************************************************
*  rvCCConnSipSetNonce
*  ----------------------------
*  General :        copy nonce into RvCCConnSip object.
*
*  Return Value:
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                pointer to CC connection object
*                  nonce            nonce string
*  Output:         none.
******************************************************************************/
void rvCCConnSipSetNonce(IN RvCCConnection* x,IN char* nonce)
{
    if (x!=NULL)
    {
        RvCCConnSip* conn = rvCCConnSipGetIns(x);

        if (nonce!=NULL)
        {
            if (conn != NULL)
            {
                strncpy(conn->nonce,nonce,sizeof(conn->nonce)-1);
                conn->nonce[sizeof(conn->nonce)- 1] = '\0';
            }
            else
            {
                RvLogError(ippLogSource,(ippLogSource,"rvCCConnSipSetNonce fail conn = NULL"));
            }
        }
        else
        {
            RvLogError(ippLogSource,(ippLogSource,"rvCCConnSipSetNonce fail nonce = NULL"));
        }
    }
    else
    {
        RvLogError(ippLogSource,(ippLogSource,"rvCCConnSipSetNonce fail x = NULL"));
    }
}
/******************************************************************************
*  rvCCConnSipGetNonce
*  ----------------------------
*  General :        get nonce string from RvCCConnSip object.
*
*  Return Value:   nonce string
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                pointer to CC connection object
*
*  Output:         none
******************************************************************************/
const char* rvCCConnSipGetNonce(RvCCConnection* x)
{
    if (x==NULL)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvCCConnSipGetNonce fail connection = NULL"));

    }
    else
    {

        RvCCConnSip* conn = rvCCConnSipGetIns(x);
        if (conn != NULL)
            return conn->nonce;
        else
		{
            RvLogError(ippLogSource,(ippLogSource,"rvCCConnSipGetNonce fail conn = NULL"));
		}
    }
    return (char*)NULL;
}

/******************************************************************************
*  rvCCConnSipSetCallAuthRetriesCount
*  ----------------------------------
*  General :        Sets the value of the authorization retries to the given value.
*
*  Return Value:
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                pointer to CC connection object
*                  count            counter value
*  Output:         none.
******************************************************************************/
void rvCCConnSipSetCallAuthRetriesCount(IN RvCCConnection* x,IN RvUint16 count)
{
	   if (x!=NULL)
	   {
		   RvCCConnSip* conn = rvCCConnSipGetIns(x);

		   conn->callAuthRetriesCount = count;
	   }
}

/******************************************************************************
*  rvCCConnSipGetCallAuthRetriesCount
*  ----------------------------------
*  General :        Gets the value of the authorization retries from the
*                   RvCCConnSip object.
*
*  Return Value:   nonce string
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                pointer to CC connection object
*
*  Output:         none
******************************************************************************/
RvUint16 rvCCConnSipGetCallAuthRetriesCount(RvCCConnection* x)
{
    if (x==NULL)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvCCConnSipGetCallAuthRetriesCount fail connection = NULL"));
    }
    else
    {

        RvCCConnSip* conn = rvCCConnSipGetIns(x);
        if (conn != NULL)
            return conn->callAuthRetriesCount;
        else
		{
            RvLogError(ippLogSource,(ippLogSource,"rvCCConnSipGetCallAuthRetriesCount fail conn = NULL"));
		}
    }
    return 0;
}

/******************************************************************************
*  rvCCConnSipSetOfferAnswerState
*  ------------------------------
*  General :        Sets the state of Offer-Answer processing.
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                     pointer to CC connection object
*                  offerAnswerState      Offer-Answer state during call establishment
*
*  Output:         none
******************************************************************************/
void rvCCConnSipSetOfferAnswerState(IN RvCCConnection* x,IN RvMtfOfferAnswerState offerAnswerState)
{
	RvCCConnSip*    conn    = rvCCConnSipGetIns(x);

	conn->offerAnswerState = offerAnswerState;

	RvLogDebug(ippLogSource, (ippLogSource, "rvCCConnSipSetOfferAnswerState : Setting state %s , conn %p, ",
		                     rvMtfTextOfferAnswerState(offerAnswerState), x));

}

/******************************************************************************
*  rvCCConnSipGetOfferAnswerState
*  ----------------------------
*  General :       Gets the state of Offer-Answer processing.
*
*  Return Value:   Offer-Answer state
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                   pointer to CC connection object
*
*  Output:         offerAnswerState    Offer-Answer state during call establishment
******************************************************************************/
RvMtfOfferAnswerState rvCCConnSipGetOfferAnswerState(IN RvCCConnection* x)
{
	RvCCConnSip*    conn    = rvCCConnSipGetIns(x);

	return conn->offerAnswerState;
}

/******************************************************************************
*  rvCCConnSipSetUpdateAllowedByRemoteParty
*  ----------------------------------------
*  General :        Sets the value of updateAllowedByRemoteParty in the rvccconnsip object.
*                   This value is set to RV_TRUE if a message has arrived from the
*                   other endpoint which contained UPDATE in its allowed header.
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                            pointer to CC connection object
*                  updateAllowedByRemoteParty   RvBool
*
*  Output:         none
******************************************************************************/
void rvCCConnSipSetUpdateAllowedByRemoteParty(IN RvCCConnection* x,IN RvBool isAllowed)
{
	RvCCConnSip*    conn    = rvCCConnSipGetIns(x);

	conn->updateAllowedByRemoteParty = isAllowed;

}

/******************************************************************************
*  rvCCConnSipIsUpdateAllowedByRemoteParty
*  ----------------------------------------
*  General :       Gets the value of updateAllowedByRemoteParty in the rvccconnsip object.
*
*  Return Value:   RvBool
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                   pointer to CC connection object
*
*  Output:
******************************************************************************/
RvBool rvCCConnSipIsUpdateAllowedByRemoteParty(IN RvCCConnection* x)
{

	RvCCConnSip*    conn    = rvCCConnSipGetIns(x);

	return conn->updateAllowedByRemoteParty;

}

/******************************************************************************
*  rvCCConnSipGetUpdateResendTimer
*  -------------------------------
*  General :       Gets a pointer to the updateResendTimer in the rvccconnsip object.
*
*  Return Value:   IppTimer*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                   pointer to CC connection object
*
*  Output:
******************************************************************************/

IppTimer* rvCCConnSipGetUpdateResendTimer(IN RvCCConnection* x)
{

	RvCCConnSip*    conn    = rvCCConnSipGetIns(x);

	return &conn->updateResendTimer;

}

/******************************************************************************
*  rvCCConnSipGetUpdateSdp
*  -----------------------
*  General :       Sets a pointer to the last sent SDP in UPDATE message.
*
*  Return Value:   None
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                   pointer to CC connection object
*                  sdpMsg*             pointer to SDP Msg
*
*  Output:
******************************************************************************/
void rvCCConnSipSetUpdateSdp(IN RvCCConnection* x, RvSdpMsg* sdpMsg)
{

	RvCCConnSip*    conn    = rvCCConnSipGetIns(x);

	conn->sdpOfLastSentUpdate = sdpMsg;

}

/******************************************************************************
*  rvCCConnSipGetUpdateSdp
*  -----------------------
*  General :       Gets a pointer to the last sent SDP in UPDATE message.
*
*  Return Value:   RvSdpMsg*
*  ----------------------------------------------------------------------------
*  Arguments:
*  Input:          x                   pointer to CC connection object
*
*  Output:
******************************************************************************/
RvSdpMsg* rvCCConnSipGetUpdateSdp(IN RvCCConnection* x)
{

	RvCCConnSip*    conn    = rvCCConnSipGetIns(x);

	return conn->sdpOfLastSentUpdate;

}
int rvCCConnSipGetProtocolId()
{
	return RV_MTF_PROTOCOL_SIP;
}
/******************************************************************************
*  rvCCConnSipSetRemoteUri
*  -----------------------
*  General :   Sets the remote Uri. Remote uri is built from display name
*			   and ip .
*
*  Arguments:
*  Input:          x		- Handle to the connection.
*				   address  - ip address of the remote party
*
*  Return Value:   pointer to String containing the remote uri
******************************************************************************/
void rvCCConnSipSetRemoteUri(RvCCConnection* x, char* address)
{

	RvCCConnSip* conn = rvCCConnSipGetIns(x);
	char tmpUri[RV_SHORT_STR_SZ]= "";

	if(conn->callerName[0])
	{
		RvSprintf(tmpUri,"sip:%s@%s",conn->callerName,address);
		strncpy(conn->remotePartyUri, tmpUri, sizeof(conn->remotePartyUri)-1);
	}
	else
	{
		strncpy(conn->remotePartyUri, address, sizeof(conn->remotePartyUri)-1);
	}
	conn->remotePartyUri[sizeof(conn->remotePartyUri)-1] = '\0';
}
/******************************************************************************
*  rvCCConnSipSetUserData
*  -----------------------
*  General :   Sets the remote user data : username,remoteUri. All data is taken from
*				the TO header
*
*  Arguments:
*  Input:          x		- Handle to the connection.
*				   to -      to header string
*
*  Return Value:   none
******************************************************************************/
void rvSipSetRemoteData(RvCCConnection* x, char* to)
{
	RvCCConnSip*    conn    = rvCCConnSipGetIns(x);

	char toUser[RV_SHORT_STR_SZ];
	memset (toUser, 0, sizeof(toUser));

	rvSipMgrGetUserNameFromUrl(to, toUser);
	strncpy(conn->remoteUserName, toUser, sizeof(conn->remoteUserName)-1);
	conn->remoteUserName[sizeof(conn->remoteUserName)-1] = '\0';

	strncpy(conn->remotePartyUri, to, sizeof(conn->remotePartyUri)-1);
	conn->remotePartyUri[sizeof(conn->remotePartyUri)-1] = '\0';

    rvSipMgrGetHostFromUrl(to, conn->remotePartyAddress, sizeof(conn->remotePartyAddress));

	return;
}

/******************************************************************************
*  rvCCConnSipGetRemoteDisplayName
*  -----------------------
*  General :   Gets the remote display name .
*              display name as received from incoming Invite message or
*			   user name from remote URI or the address from remote URI.
*
*  Arguments:
*  Input:          x - Handle to the connection.
*
*  Return Value:   pointer to String containing the display name.
******************************************************************************/
const char* rvCCConnSipGetRemoteDisplayName(RvCCConnection* x)
{
	RvCCConnSip* conn = rvCCConnSipGetIns(x);

	RvSipCallLegDirection   eDirection;

	RvSipCallLegGetDirection(conn->callLegHndl, &eDirection);
	if (eDirection == RVSIP_CALL_LEG_DIRECTION_INCOMING)
	{
		if (conn->callerId[0]!= '\0')
		{
			return conn->callerId;
		}
		else
			if(conn->callerName[0]!= '\0')
			{
				return conn->callerName;
			}
			else
				if(conn->callerAddress[0]!= '\0')
				{
					return conn->callerAddress;
				}
	}
	else
	{
		if (eDirection == RVSIP_CALL_LEG_DIRECTION_OUTGOING)
		{
			if (conn->remoteUserName[0]!= '\0')
			{
					return conn->remoteUserName;
			}
			else
			{
				if(conn->remotePartyAddress[0]!= '\0')
				{
					return conn->remotePartyAddress;
				}
			}
		}
	}

	return NULL;
}
/******************************************************************************
*  rvCCConnSipGetRemotePhoneNumber
*  -----------------------
*  General :   Gets the Phone Number.
*
*  Arguments:
*  Input:          x - Handle to the connection.
*
*
*  Return Value:   pointer to string contains the remote phone number
******************************************************************************/
const char* rvCCConnSipGetRemotePhoneNumber(RvCCConnection* x)
{
	RV_UNUSED_ARG(x);

	return NULL;

}
/******************************************************************************
*  rvCCConnSipGetRemoteUri
*  -----------------------
*  General :   Gets the remote Uri which is the
*              display name as received from incoming Invite message or
*			   the user name from remote URI or the address from remote URI.
*
*  Arguments:
*  Input:          x - Handle to the connection.
*
*  Return Value:   pointer to String containing the remote uri
******************************************************************************/
const char* rvCCConnSipGetRemoteUri(RvCCConnection* x)
{
	RvCCConnSip* conn = rvCCConnSipGetIns(x);

	RvSipCallLegDirection   eDirection ;

	RvSipCallLegGetDirection(conn->callLegHndl, &eDirection);
	if (eDirection == RVSIP_CALL_LEG_DIRECTION_INCOMING)
	{
		if (conn->remotePartyUri[0]!= '\0')
		{
			return conn->remotePartyUri;
		}
	}
	return NULL;
}
