/******************************************************************************
Filename:    sipStun.c
Description: Stun support in IPP TK
*******************************************************************************
                Copyright (c) 2005 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
#define LOGSRC  LOGSRC_SIPCONTROL
#include "ipp_inc_std.h"
#include "RvSipMsg.h"
#include "rvSipControlApi.h"
#include "RvSipBody.h"
#include "RvSipHeader.h"
#include "RvSipContactHeader.h"
#include "RvSipContentTypeHeader.h"
#include "RvSipViaHeader.h"
#include "rvsdpenc.h"
#include "AdsRpool.h"
#include "RvSipAddress.h"
#include "RvSipAddress.h"
#include "RvSipTransmitter.h"
#include "RvSipTransmitterTypes.h"
#include "RvSipSubscription.h"
#include "rvccprovidersip.h"
#include "rvccconnsip.h"
#include "rvSipControlApi.h"
#include "sipControlInt.h"
#include "sipphone.h"
#include "sipMgr.h"
#include "sipStun.h"

extern HRPOOL           g_appPool;
RvStunMgr* g_stunMgr = NULL; /* singleton. not thread safe */


/*-----------------------------------------------------------------------*/
/*                        FORWARD DECLARATION                            */
/*-----------------------------------------------------------------------*/
static RvStatus  holdSendMessage(
    IN RvStun*                  frame,
    IN RvSipTransmitterHandle   hTrx,
    IN RvSipMsgHandle           hMsgToSend);

static void RVCALLCONV AppTransportBufferReceivedEvHandler(
                                                            IN  RvSipTransportMgrHandle             hTransportMgr,
                                                            IN  RvSipAppTransportMgrHandle          hAppTransportMgr,
                                                            IN  RvSipTransportLocalAddrHandle       hLocalAddr,
                                                            IN  RvSipTransportAddr                  *pSenderAddrDetails,
                                                            IN  RvSipTransportConnectionHandle      hConn,
                                                            IN  RvSipTransportConnectionAppHandle   hAppConn,
                                                            IN  RvChar                              *buffer,
                                                            IN  RvUint32                            buffLen,
                                                            OUT RvBool                              *pbDiscardBuffer);

static void RVCALLCONV AppTransmitterStateChangedEvHandler(
                                                           IN  RvSipTransmitterHandle            hTrx,
                                                           IN  RvSipAppTransmitterHandle         hAppTrx,
                                                           IN  RvSipTransmitterState             eState,
                                                           IN  RvSipTransmitterReason            eReason,
                                                           IN  RvSipMsgHandle                    hMsg,
                                                           IN  void*                             pExtraInfo);

static void RVCALLCONV  AppTransStateChangedEvHandler(
                                               IN RvSipTranscHandle                 hTransc,
                                               IN RvSipTranscOwnerHandle            hTranscOwner,
                                               IN RvSipTransactionState             eState,
                                               IN RvSipTransactionStateChangeReason eReason);

static void RVCALLCONV AppCallLegStateChangedEvHandler(
                                   IN  RvSipCallLegHandle            hCallLeg,
                                   IN  RvSipAppCallLegHandle         hAppCallLeg,
                                   IN  RvSipCallLegState             eState,
                                   IN  RvSipCallLegStateChangeReason eReason);

static RvStatus RVCALLCONV AppCallLegFinalDestResolvedEvHandler(
                                                  IN  RvSipCallLegHandle     hCallLeg,
                                                  IN  RvSipAppCallLegHandle  hAppCallLeg,
                                                  IN  RvSipTranscHandle      hTransc,
                                                  IN  RvSipAppTranscHandle   hAppTransc,
                                                  IN  RvSipMsgHandle         hMsgToSend);

static RvStatus RVCALLCONV AppRegClientFinalDestResolvedEvHandler(
                                                           IN  RvSipRegClientHandle    hRegClient,
                                                           IN  RvSipAppRegClientHandle hAppRegClient,
                                                           IN  RvSipTranscHandle       hTransc,
                                                           IN  RvSipMsgHandle          hMsgToSend);

static RvStatus RVCALLCONV AppSubsFinalDestResolvedEvHandler(
                                                             IN  RvSipSubsHandle           hSubs,
                                                             IN  RvSipAppSubsHandle        hAppSubs,
                                                             IN  RvSipNotifyHandle         hNotify,
                                                             IN  RvSipAppNotifyHandle      hAppNotify,
                                                             IN  RvSipTranscHandle         hTransc,
                                                             IN  RvSipMsgHandle            hMsgToSend);

static RvStatus RVCALLCONV parseFinalDestResolved( RvStun* frame);

static RvStatus RvStunMgrDbProceedResolvedRequests(INOUT RvStunMgrDb* db);

static void RvStunMgrDbConstruct(
    IN RvStunMgrDb*             db,
    IN RvStunResolvedHandlerCB  resolvedHandler,
    IN RvStunErrorHandlerCB     errorHandler);

static RvStatus RvStunMgrSendRawMsg(
    IN void*            mgr,
    IN const RvChar*    addrString,
    IN RvUint16         addrPort,
    IN RvUint8*         buf,
    IN RvSize_t         size);


static RvBool RvIppStunAddrDataEqual(RvIppStunAddrData  * a1, RvIppStunAddrData  * a2)
{
    return RvAddressCompare( &a1->inAddr, &a2->inAddr, RV_ADDRESS_FULLADDRESS);
}

#define RvIppStunAddrDataConstructCopy rvDefaultConstructCopy
#define RvIppStunAddrDataDestruct(_n) 

rvDefineList(RvIppStunAddrData)

static RvBool RvStunIsAddrListEmpty(IN RvStun* data)
{
    return rvListEmpty(&data->stunAddrList);
}



/***************************************************************************
 * sendReqToStunClient
 * ------------------------------------------------------------------------
 * General: read the list elements and send element by element to the STUN client
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   stunAddrList - STUN msg list
 *          plocalAddr   - address from where stack sends a message containing addresses needed to resolve
 *          plocalAddr   - address to where stack sends a message containing addresses needed to resolve
 ***************************************************************************/
static RvStatus sendReqToStunClient(IN RvStunAddrList* stunAddrList)
{
    RvIppStunAddrData*              tempStunAddressData;
    RvListIter(RvIppStunAddrData)   iter;
    RvStatus    status;
    RvChar      buf[64];
    RvUint16    port;

    for (iter=rvListBegin(stunAddrList); iter!=rvListEnd(stunAddrList); iter=rvListIterNext(iter))
    {
        tempStunAddressData = (RvIppStunAddrData *)rvListIterData(iter);

        /* Extract ip and port for log need only */
        RvAddressGetString(&tempStunAddressData->inAddr, sizeof(buf)-1, buf);
        port = RvAddressGetIpPort(&tempStunAddressData->inAddr);

        RvLogEnter(ippLogSource,(ippLogSource, "addressResolveStartCB(%s:%d)", buf, port));

        status = g_stunMgr->addressResolveStartCB(tempStunAddressData);

        RvLogLeave(ippLogSource,(ippLogSource, "addressResolvestartCB()=%d", status));

        if (status != RV_OK)
            return status;
    }

    return RV_OK;
}

/*-----------------------------------------------------------------------*/
/*                            PRIVATE  FUNCTIONS                         */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * addToStunList
 * ------------------------------------------------------------------------
 * General: build a RvIppStunAddrData   struct and adds it to the STUN msg list
 *          to be used by the STUN client
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   inAddr     - address parameters (port and IP address)
 *          type       - the type of the msg field (e.g c=/o=/m=...)
 *          mediaIndex - media index or 0 in the elemnt is not media
 *          stunAddrList - STUN msg list
 ***************************************************************************/
static RvStatus addToStunList(RvAddress inAddr,RvIppSipAddressFieldType type,
                       RvUint16 mediaIndex,RvStunAddrList *stunAddrList)
{
    RvIppStunAddrData      stunMsgElemnt;

    memset(&stunMsgElemnt,0,sizeof(stunMsgElemnt));

    stunMsgElemnt.inAddr = inAddr;
    stunMsgElemnt.index = mediaIndex;
    stunMsgElemnt.type = type;

    if (rvListPushBack(RvIppStunAddrData)(stunAddrList,&stunMsgElemnt) == rvListEnd(stunAddrList))
        return RV_ERROR_UNKNOWN;
    else
        return RV_OK;
}


/***************************************************************************************
 * AppBodyConvertSipBodyToSdp
 * -------------------------------------------------------------------------------------
 * General:  this function converts standard sip body to sdp message format
 * Return Value: RV_SUCCESS on success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:    hBody - the sdp message converted to a sip body
 * Output:   pMessage - the sdp message to convert
 **************************************************************************************/
static RV_Status AppBodyConvertSipBodyToSdp(IN RvSipBodyHandle hBody,
                                     OUT RvSdpMsg *pMessage)
{
    RV_Status           retStatus                  = RV_Success;
    RV_INT              sdpLen              = STUN_APP_BODY_STRING_SIZE;
    RvSdpParseStatus    eParseStatus   = RV_SDPPARSER_STOP_ZERO;
    RV_UINT32           length;
    RvChar              szBody[STUN_APP_BODY_STRING_SIZE] = {'\0'};


    length = RvSipBodyGetBodyStrLength(hBody);
    if (0 == length)
    {
        return RV_ERROR_UNKNOWN;
    }


    retStatus = RvSipBodyGetBodyStr(hBody, szBody, length, &length);

    if (RV_Success != retStatus)
    {
        return retStatus;
    }

    sdpLen = (RV_INT)length;

    rvSdpMsgConstructParseA(pMessage,szBody, &sdpLen,&eParseStatus, prvDefaultAlloc); /*DO need the default or pool alloctor ? yossi*/

    if (RV_SDPSTATUS_OK != eParseStatus)
    {
        return RV_ERROR_UNKNOWN;
    }

    return retStatus;
}


/***************************************************************************************
 * AppBodyConvertSdpToSipBody
 * -------------------------------------------------------------------------------------
 * General:  this function converts standard sdp message format to sip body
 * Return Value: RV_SUCCESS on success
 * -------------------------------------------------------------------------------------
 * Arguments:
 * Input:    pSdp - the sdp message to convert
 * Output:   hBody - the sdp message converted to a sip body
 **************************************************************************************/
static RvStatus AppBodyConvertSdpToSipBody(IN RvSdpMsg *pSdp, OUT RvSipBodyHandle hBody)
{
    RvStatus           rv             = RV_OK;
    RvChar             szBody[STUN_APP_BODY_STRING_SIZE] = {'\0'};
    RvSipContentTypeHeaderHandle    hContentType     = NULL;
    RvSdpStatus         stat          = RV_SDPSTATUS_OK;

    rvSdpMsgEncodeToBuf(pSdp,szBody,STUN_APP_BODY_STRING_SIZE,&stat);
	if (stat != RV_SDPSTATUS_OK)
	{
		/* SDP message failed to be encoded to buffer */
		RvLogError(ippLogSource, (ippLogSource, "AppBodyConvertSdpToSipBody() - SDP message failed to be encoded to buffer, sdp=0x%p, status=%d",
			pSdp, stat));
		return RV_ERROR_UNKNOWN;
	}

    rv = RvSipBodySetBodyStr(hBody,szBody,(RvUint32)strlen(szBody));
    if (RV_OK != rv)
    {
        return rv;
    }

    hContentType = RvSipBodyGetContentType(hBody);
    rv = RvSipContentTypeHeaderSetMediaType(hContentType,RVSIP_MEDIATYPE_APPLICATION,NULL);
    if (RV_OK != rv)
    {
        return rv;
    }

    rv = RvSipContentTypeHeaderSetMediaSubType(hContentType,RVSIP_MEDIASUBTYPE_SDP,NULL);
    if (RV_OK != rv)
    {
        return rv;
    }

    return rv;
}


/***************************************************************************
 * AppBodyIsMediaBody
 * ------------------------------------------------------------------------
 * General:  see if a body is application/sdp
 * Return Value: RV_TRUE - is media. RV_FALSE o/w
 * ------------------------------------------------------------------------
 * Arguments:
 * input   : hBody body to examine
 ***************************************************************************/
static RvBool AppBodyIsMediaBody(IN RvSipBodyHandle hBody)
{
    RvSipContentTypeHeaderHandle    hContentType = NULL;

    hContentType = RvSipBodyGetContentType(hBody);
    if (NULL == hContentType)
    {
        return RV_FALSE;
    }
    if ( (RVSIP_MEDIATYPE_APPLICATION != RvSipContentTypeHeaderGetMediaType(hContentType)) ||
         (RVSIP_MEDIASUBTYPE_SDP != RvSipContentTypeHeaderGetMediaSubType(hContentType)) )
    {
        return RV_FALSE;
    }
    return RV_TRUE;
}


/***************************************************************************
 * AppSetStunConnection
 * ------------------------------------------------------------------------
 * General: extracts the connection and media fields from the SIP message
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pSdpMsg    - the SDP message
 *          stunAddrList - STUN msg list
 ***************************************************************************/
static RvStatus AppSetStunConnection(IN RvSdpMsg* pSdpMsg,RvStunAddrList *stunAddrList){

    RvSdpConnection  *pSdpConnection;
    RvChar           strIp[STUN_IP_STR_LEN];
    RV_INT32         numOfMedia = 0;
    RvUint16         tempPort;
    RvSdpMediaDescr  *pMediaDescriptor;
    RvSdpConnection  *pMediaDescriptorConnection;
    RvAddress        tempAddr;
    RvIppSipAddressFieldType    stunReqType;
    RvUint16                  i;

    pSdpConnection = rvSdpMsgGetConnection(pSdpMsg);
    if (NULL!= pSdpConnection  &&  NULL!=rvSdpConnectionGetAddress(pSdpConnection))
    {   /* TODO: replace with strncpy as strIp is limited in size */
        if(!strcmp("0.0.0.0", rvSdpConnectionGetAddress(pSdpConnection)))
            return RV_OK;
        strncpy(strIp, rvSdpConnectionGetAddress(pSdpConnection), sizeof(strIp));
        strIp[sizeof(strIp)-1] = '\0';
    }
    else
    {
        /*return RV_ERROR_UNKNOWN;*/
        // TODO: Get back that line above...
        return RV_OK;
    }
    RvAddressConstruct(RV_ADDRESS_TYPE_IPV4,&tempAddr);
    /* TODO: check return values */
    RvAddressSetString(strIp,&tempAddr);

    numOfMedia = rvSdpMsgGetNumOfMediaDescr(pSdpMsg);
    for (i=0; i<numOfMedia; i++)
    {
        pMediaDescriptor = rvSdpMsgGetMediaDescr(pSdpMsg, i);
        if (NULL == pMediaDescriptor)
        {
            return RV_ERROR_UNKNOWN;
        }

        /* Load Port */
        tempPort= (RvUint16)rvSdpMediaDescrGetPort(pMediaDescriptor);
        if (tempPort == 0 )
        {
            RvAddressSetIpPort(&tempAddr,STUN_DEFAULT_PORT);
            stunReqType = RVIPP_SDP_MEDIA_CLOSE_FIELD;
        }
        else
        {
            RvAddressSetIpPort(&tempAddr,tempPort);
            stunReqType = RVIPP_SDP_MEDIA_FIELD;
        }

		if (i==0)
		{
			if (addToStunList(tempAddr,stunReqType,i,stunAddrList) != RV_OK)
            {
                return RV_ERROR_UNKNOWN;
            }
		}
        /* Load IP for media from 'Connection' field */
        pMediaDescriptorConnection = rvSdpMediaDescrGetConnection(pMediaDescriptor);
        if (NULL !=pMediaDescriptorConnection  &&
            NULL !=rvSdpConnectionGetAddress(pMediaDescriptorConnection))
        {
            strncpy(strIp, rvSdpConnectionGetAddress(pMediaDescriptorConnection), sizeof(strIp)-1);
            strIp[sizeof(strIp)-1] = '\0';
            strcpy(strIp,rvSdpConnectionGetAddress(pMediaDescriptorConnection));
            RvAddressSetString(strIp,&tempAddr);
            if (stunReqType == RVIPP_SDP_MEDIA_CLOSE_FIELD )
            {
                stunReqType = RVIPP_SDP_MEDIA_CONN_CLOSE_FIELD;
            }
            else
            {
                stunReqType = RVIPP_SDP_MEDIA_CONN_FIELD;
            }
            if (addToStunList(tempAddr,stunReqType,i,stunAddrList) != RV_OK)
            {
                return RV_ERROR_UNKNOWN;
            }
        }

        /*checking if the media is RTP/RTCP and if so setting a RTCP port for RTCP attribute*/
        if (rvSdpMediaDescrGetProtocol(pMediaDescriptor) == RV_SDPPROTOCOL_RTP)
        {
            tempPort++;
            RvAddressSetIpPort(&tempAddr,tempPort);
            if (addToStunList(tempAddr,RVIPP_SDP_ATTRIBUTE_FIELD,i,stunAddrList) !=RV_OK)
            {
                return RV_ERROR_UNKNOWN;
            }
        }
    }

    return RV_OK;
}



/***************************************************************************
 * AppSetStunOrigin
 * ------------------------------------------------------------------------
 * General: extracts the origin fields from the SIP message
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pSdpMsg    - the SDP message
 *          stunAddrList - STUN msg list
 ***************************************************************************/
static RvStatus AppSetStunOrigin(IN RvSdpMsg* pSdpMsg, IN RvStunAddrList* stunAddrList)
{

    RvSdpOrigin*    pOrigin;
    const RvChar*   originAddrStr;
    RvChar          strIp[STUN_IP_STR_LEN];
    RvAddress       tempAddr;
    RvStatus        status = RV_ERROR_UNKNOWN;

    pOrigin = rvSdpMsgGetOrigin(pSdpMsg);
    if (pOrigin != NULL)
    {
        originAddrStr = rvSdpOriginGetAddress(pOrigin);
        if (originAddrStr != NULL)
        {
            strncpy(strIp, originAddrStr, sizeof(strIp)-1);
            strIp[sizeof(strIp)-1] = '\0';
            RvAddressConstruct(RV_ADDRESS_TYPE_IPV4, &tempAddr);
            RvAddressSetString(strIp, &tempAddr);
            RvAddressSetIpPort(&tempAddr, STUN_DEFAULT_PORT);
            status = addToStunList(tempAddr, RVIPP_SDP_ORIGIN_FIELD, 0, stunAddrList);
        }
    }

    return status;
}


/***************************************************************************
 * AppSetStunVia
 * ------------------------------------------------------------------------
 * General: extracts the via fields from the SIP message
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pSdpMsg    - the SDP message
 *          stunAddrList - STUN msg list
 ***************************************************************************/
static RvStatus AppSetStunVia(IN RvSipMsgHandle  hMsgToSend,RvStunAddrList *stunAddrList,RvBool* isUdp)
{
    RvStatus                    rv;
    RvInt32                     offset;
    RvUint                      length, actSize;
    RvSipHeaderListElemHandle   hPos;
    RvChar                      *pViaStrHostName = NULL;
    RvSipViaHeaderHandle        hViaHeader = NULL;
    RvAddress                   tempAddr;
    HPAGE                       hHelpPage =NULL;
    RvInt16                     tempPort;
    RvSipTransport              tempTransportType;

    hViaHeader = RvSipMsgGetHeaderByType(hMsgToSend, RVSIP_HEADERTYPE_VIA,
                                                RVSIP_FIRST_HEADER, &hPos);
    if (NULL == hViaHeader)
    {
        return RV_ERROR_UNKNOWN;
    }

    /*lets check that the protocol is UDP */
    tempTransportType = RvSipViaHeaderGetTransport(hViaHeader);
    *isUdp = (tempTransportType == RVSIP_TRANSPORT_UDP);
    if (*isUdp != RV_TRUE)
        return RV_OK;

    length = RvSipViaHeaderGetStringLength(hViaHeader, RVSIP_VIA_HOST);
    if (length == 0)
        return RV_ERROR_NOT_FOUND;

    rv = RPOOL_GetPage(g_appPool, 0, &hHelpPage);
    if (rv != RV_OK)
        return rv;

    rv = RPOOL_Append(g_appPool, hHelpPage, length+1, RV_TRUE, &offset);
    if (rv == RV_OK)
    {
        pViaStrHostName = RPOOL_GetPtr( g_appPool, hHelpPage, offset);

        rv = RvSipViaHeaderGetHost(hViaHeader, pViaStrHostName, length+1, &actSize);
    }

    if (rv == RV_OK)
    {
        tempPort = (RvUint16)RvSipViaHeaderGetPortNum(hViaHeader);
        if (tempPort == UNDEFINED)
        {
            tempPort = STUN_DEFAULT_PORT;
        }

        /*changing the VIA from IP_STRING to IP_ADDR */
        RvAddressConstruct(RV_ADDRESS_TYPE_IPV4, &tempAddr);
        RvAddressSetString(pViaStrHostName, &tempAddr);
        RvAddressSetIpPort(&tempAddr, tempPort);
        rv = addToStunList(tempAddr, RVIPP_SIP_VIA_FIELD, 0, stunAddrList);
    }

    if (hHelpPage != NULL_PAGE)
        RPOOL_FreePage(g_appPool, hHelpPage);
    return rv;
}



/***************************************************************************
 * AppSetStunContact
 * ------------------------------------------------------------------------
 * General: extracts the contact fields from the SIP message
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pSdpMsg    - the SDP message
 *          stunAddrList - STUN msg list
 ***************************************************************************/
static RvStatus AppSetStunContact(IN RvSipMsgHandle  hMsgToSend,RvStunAddrList *stunAddrList,RvBool* isUdp)
{
    RvStatus                    rv;
    RvInt32                     offset;
    RvSipContactHeaderHandle    hContact;
    RvSipAddressHandle          hContactAddress;
    RV_UINT                     length,actSize;
    RvSipHeaderListElemHandle   hPos;
    RvChar                      *pContactStrHostName = NULL;
    RvAddress                   tempAddr;
    HPAGE                       hHelpPage = NULL;
    RvInt16                     tempPort;
    RvSipTransport              tempTransportType;

    hContact = RvSipMsgGetHeaderByType(hMsgToSend, RVSIP_HEADERTYPE_CONTACT,
        RVSIP_FIRST_HEADER, &hPos);
    if (NULL == hContact)
        return RV_ERROR_UNKNOWN;

    hContactAddress = RvSipContactHeaderGetAddrSpec(hContact);
    if (hContactAddress == NULL)
        return RV_ERROR_UNKNOWN;

    /*lets check that the protocol is UDP */
    tempTransportType = RvSipAddrUrlGetTransport(hContactAddress);
    if (tempTransportType == RVSIP_TRANSPORT_UNDEFINED)
        tempTransportType = RVSIP_TRANSPORT_UDP;

    *isUdp = (tempTransportType == RVSIP_TRANSPORT_UDP);
    if (*isUdp == RV_FALSE)
        return RV_OK;


    length = RvSipAddrGetStringLength(hContactAddress, RVSIP_ADDRESS_HOST);
    if (0 == length)
        return RV_ERROR_NOT_FOUND;

    rv = RPOOL_GetPage(g_appPool, 0, &hHelpPage);
    if (rv != RV_OK)
        return rv;

    rv = RPOOL_Append(g_appPool, hHelpPage, length+1, RV_TRUE, &offset);
    if (rv == RV_OK)
    {
        pContactStrHostName = RPOOL_GetPtr(g_appPool, hHelpPage, offset);

        rv = RvSipAddrUrlGetHost(hContactAddress, pContactStrHostName, length, &actSize);
    }

    if (rv == RV_OK)
    {
        tempPort = (RvUint16)RvSipAddrUrlGetPortNum(hContactAddress);
        if (tempPort == UNDEFINED)
            tempPort = STUN_DEFAULT_PORT;

        /*changing the Contact from IP_STRING to IP_ADDR*/
        RvAddressConstruct(RV_ADDRESS_TYPE_IPV4, &tempAddr);
        RvAddressSetString(pContactStrHostName, &tempAddr);
        RvAddressSetIpPort(&tempAddr, tempPort);
        rv = addToStunList(tempAddr, RVIPP_SIP_CONTACT_FIELD, 0, stunAddrList);
    }

    if (hHelpPage != NULL_PAGE)
        RPOOL_FreePage(g_appPool, hHelpPage);
    return rv;
}



/***************************************************************************
 * AppUpdateVia
 * ------------------------------------------------------------------------
 * General: update the via fields after STUN reply
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsgToSend - the SIP message
 *          addr       - the STUN updated address
 ***************************************************************************/
static RvStatus AppUpdateVia(IN RvSipMsgHandle  hMsgToSend,RvAddress *addr)
{
    RvStatus                    rv;
    RvSipViaHeaderHandle        hViaHeader = NULL;
    RvSipHeaderListElemHandle   hPos;
    RvChar                      strIp[STUN_IP_STR_LEN];
    RvInt32                     port = 0;

    hViaHeader = RvSipMsgGetHeaderByType(hMsgToSend, RVSIP_HEADERTYPE_VIA,
                                                RVSIP_FIRST_HEADER, &hPos);
    if (NULL == hViaHeader)
        return RV_ERROR_UNKNOWN;

    RvAddressGetString(addr,STUN_IP_STR_LEN,strIp);

    rv = RvSipViaHeaderSetHost(hViaHeader,strIp);
    if (rv != RV_OK)
        return rv;

    port = RvAddressGetIpPort(addr);

    rv = RvSipViaHeaderSetPortNum(hViaHeader,port);

    return rv;
}



/***************************************************************************
 * AppUpdateContact
 * ------------------------------------------------------------------------
 * General: update the contact fields after STUN reply
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsgToSend - the SIP message
 *          addr       - the STUN updated address
 ***************************************************************************/
static RvStatus AppUpdateContact(IN RvSipMsgHandle  hMsgToSend,RvAddress *addr)
{
    RvStatus                    rv;
    RvSipContactHeaderHandle    hContact;
    RvSipAddressHandle          hContactAddress;
    RvSipHeaderListElemHandle   hPos;
    RvChar                      strIp[STUN_IP_STR_LEN];
    RvUint16                    port;

    hContact = RvSipMsgGetHeaderByType(hMsgToSend, RVSIP_HEADERTYPE_CONTACT,
                                                RVSIP_FIRST_HEADER, &hPos);
    if (NULL == hContact)
        return RV_ERROR_UNKNOWN;

    hContactAddress = RvSipContactHeaderGetAddrSpec(hContact);
    if (hContactAddress == NULL)
        return RV_ERROR_UNKNOWN;

    RvAddressGetString(addr,STUN_IP_STR_LEN,strIp);
    rv = RvSipAddrUrlSetHost(hContactAddress,strIp);
    if (rv != RV_OK)
        return rv;

    port = RvAddressGetIpPort(addr);

    rv = RvSipAddrUrlSetPortNum(hContactAddress,port);

    return rv;
}




/***************************************************************************
 * AppUpdateOrigin
 * ------------------------------------------------------------------------
 * General: update the origin fields after STUN reply
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pSdpMsg    - the SDP message
 *          addr       - the STUN updated address
 ***************************************************************************/
static RvStatus AppUpdateOrigin(IN RvSdpMsg* pSdpMsg,RvAddress *addr)
{
    RvSdpOrigin*  pOrigin = NULL;
    RvChar        strIp[STUN_IP_STR_LEN];

    pOrigin = rvSdpMsgGetOrigin(pSdpMsg);
    if (pOrigin == NULL)
        return RV_ERROR_UNKNOWN;

    RvAddressGetString(addr,STUN_IP_STR_LEN,strIp);
    rvSdpOriginSetAddress(pOrigin,strIp);

    return RV_OK;
}


/***************************************************************************
 * AppUpdateSdpConnection
 * ------------------------------------------------------------------------
 * General: update the SDP connection fields after STUN reply
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pSdpMsg    - the SDP message
 *          addr       - the STUN updated address
 ***************************************************************************/
static RvStatus AppUpdateSdpConnection(IN RvSdpMsg* pSdpMsg,RvAddress *addr)
{
    RvSdpConnection  *pSdpConnection;
    RvChar           strIp[STUN_IP_STR_LEN];
    RvSdpAddrType    addr_type;
    RvSdpNetType     net_type;

    pSdpConnection = rvSdpMsgGetConnection(pSdpMsg);
    if (NULL == pSdpConnection)
        return RV_ERROR_UNKNOWN;

    addr_type = rvSdpConnectionGetAddrType(pSdpConnection);
    net_type = rvSdpConnectionGetNetType(pSdpConnection);

    RvAddressGetString(addr,STUN_IP_STR_LEN,strIp);
	/* clear the internal connection before adding the resolved one */
	rvSdpMsgClearConnection(pSdpMsg);
    rvSdpMsgSetConnection(pSdpMsg,net_type,addr_type,strIp);

    return RV_OK;
}



/***************************************************************************
 * AppUpdateSdpMediaConnection
 * ------------------------------------------------------------------------
 * General: update the SDP media connection fields after STUN reply
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pSdpMsg    - the SDP message
 *          addr       - the STUN updated address
 *          mediaIndex - the media index number
 ***************************************************************************/
static RvStatus AppUpdateSdpMediaConnection(IN RvSdpMsg* pSdpMsg,RvAddress *addr,RvInt16 mediaIndex){


    RvChar           strIp[STUN_IP_STR_LEN];
    RvSdpAddrType    addr_type;
    RvSdpNetType     net_type;
    RvSdpMediaDescr  *pMediaDescriptor;
    RvSdpConnection  *pMediaDescriptorConnection;

    pMediaDescriptor = rvSdpMsgGetMediaDescr(pSdpMsg, mediaIndex);
    if (NULL == pMediaDescriptor)
    {
        return RV_ERROR_UNKNOWN;
    }

    pMediaDescriptorConnection = rvSdpMediaDescrGetConnection(pMediaDescriptor);
    if (NULL == pMediaDescriptorConnection )
        return RV_ERROR_UNKNOWN;

    addr_type = rvSdpConnectionGetAddrType(pMediaDescriptorConnection);
    net_type = rvSdpConnectionGetNetType(pMediaDescriptorConnection);

    RvAddressGetString(addr,STUN_IP_STR_LEN,strIp);
	/* Remove Connection field with the internal IP address */
	rvSdpMediaDescrClearConnection(pMediaDescriptor);
	/* Add connection with the resolved IP address */
    rvSdpMediaDescrSetConnection(pMediaDescriptor,net_type,addr_type,strIp);

    return RV_OK;

}



/***************************************************************************
 * AppUpdateSdpMedia
 * ------------------------------------------------------------------------
 * General: update the SDP media fields after STUN reply
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pSdpMsg    - the SDP message
 *          addr       - the STUN updated address
 *          mediaIndex - the media index number
 ***************************************************************************/
static RvStatus AppUpdateSdpMedia(IN RvSdpMsg* pSdpMsg,RvAddress *addr,RvInt16 mediaIndex){


    RvUint16         port;
    RvSdpMediaDescr  *pMediaDescriptor;


    pMediaDescriptor = rvSdpMsgGetMediaDescr(pSdpMsg, mediaIndex);
    if (NULL == pMediaDescriptor)
    {
        return RV_ERROR_UNKNOWN;
    }

    port = RvAddressGetIpPort(addr);

    rvSdpMediaDescrSetPort(pMediaDescriptor,port);

    return RV_OK;

}


/***************************************************************************
 * AppUpdateSdpMediaAttribute
 * ------------------------------------------------------------------------
 * General: update the SDP media rtcp attribute field after STUN reply
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   pSdpMsg    - the SDP message
 *          addr       - the STUN updated address
 *          mediaIndex - the media index number
 ***************************************************************************/
static RvStatus AppUpdateSdpMediaAttribute(IN RvSdpMsg* pSdpMsg,RvAddress *addr,RvInt16 mediaIndex){


    RvUint16         port;
    RvSdpMediaDescr  *pMediaDescriptor;
    RvChar           strHelper[16];


    pMediaDescriptor = rvSdpMsgGetMediaDescr(pSdpMsg, mediaIndex);
    if (NULL == pMediaDescriptor)
    {
        return RV_ERROR_UNKNOWN;
    }

    port = RvAddressGetIpPort(addr);

    /* itoa(port, strHelper) */
    RvSprintf(strHelper, "%d", port);

    rvSdpMediaDescrAddAttr(pMediaDescriptor, "rtcp",strHelper);

    return RV_OK;

}



/***************************************************************************
 * updateAllMsgFields
 * ------------------------------------------------------------------------
 * General: updates the SIP/SDP message according to the STUN client reply
 *
 * Return Value:
 *          RV_OK               - on successful operation
 *          RV_ERROR_UNKNOWN    - on error
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hMsgToSend - handle to the SIP message
 *          pSdpMsg    - the SDP message
 *          stunAddrList - STUN msg list
 ***************************************************************************/
static RvStatus updateAllMsgFields(INOUT RvStun*   frame)
{
    RvSipMsgHandle  hMsgToSend  = frame->hMsgToSend;
    RvSdpMsg*       pSdpMsg     = &frame->sdpMsg;
    RvStunAddrList  *pstunAddrList= &frame->stunAddrList;
    char            szIP[64];

    RvIppStunAddrData               *tempStunAddressData;
    RvListIter(RvIppStunAddrData)    iter;

    for(iter=rvListBegin( pstunAddrList); iter!=rvListEnd(  pstunAddrList); iter=rvListIterNext(iter))
    {
        tempStunAddressData = (RvIppStunAddrData  *)rvListIterData(iter);

        /* what do we do if some of the fields don't exist?
         for now we use the original ip address
        */
        if (RvAddressIsNull(&tempStunAddressData->outAddr))
        {
            RvLogError(ippLogSource,(ippLogSource, "updateAllMsgFields(): no map exist for ip =%s, port =%d",
                                                    RvAddressGetString (&tempStunAddressData->outAddr, sizeof(szIP), szIP),
                                                    RvAddressGetIpPort (&tempStunAddressData->outAddr)));
            RvAddressCopy(&tempStunAddressData->inAddr, &tempStunAddressData->outAddr);
        }

		RvLogInfo(ippLogSource,(ippLogSource, "STUN: updateAllMsgFields(): updating ip =%s, port =%d in field %d",
			RvAddressGetString (&tempStunAddressData->outAddr, sizeof(szIP), szIP),
                                                    RvAddressGetIpPort (&tempStunAddressData->outAddr),
													tempStunAddressData->type));
        switch (tempStunAddressData->type)
        {
        case RVIPP_SIP_VIA_FIELD:
			{
				RvBool  isResponse = (RvSipMsgGetMsgType(hMsgToSend) == RVSIP_MSG_RESPONSE);

				/* A Via header must not be changed in a response. Changing the Via header will 
				   cause a creation of a new SIP transaction. Other responses that will be received
				   for the original transaction (like re-transmission of a request) will not be
				   associated with the new one. As a result a wrong response will be sent 
				   (e.g. 481 Call Leg/Transaction Does Not Exist).*/

				if (!isResponse)
				{			
					AppUpdateVia(hMsgToSend,&(tempStunAddressData->outAddr));
				}
			}
            break;

        case RVIPP_SIP_CONTACT_FIELD:
            AppUpdateContact(hMsgToSend,&(tempStunAddressData->outAddr));
            break;

        case RVIPP_SDP_MEDIA_FIELD:
            /* if this is the first media descriptor will use the IP address for the SDP connection */
            if (tempStunAddressData->index == 0)
            {
                AppUpdateSdpConnection(pSdpMsg,&(tempStunAddressData->outAddr));
            }
            AppUpdateSdpMedia(pSdpMsg,&(tempStunAddressData->outAddr),(tempStunAddressData->index));
            break;

        case RVIPP_SDP_MEDIA_CONN_FIELD:
            AppUpdateSdpMediaConnection(pSdpMsg,&(tempStunAddressData->outAddr),tempStunAddressData->index);
            AppUpdateSdpMedia(pSdpMsg,&(tempStunAddressData->outAddr),(tempStunAddressData->index));
            break;

        case RVIPP_SDP_ORIGIN_FIELD:
            AppUpdateOrigin(pSdpMsg,&(tempStunAddressData->outAddr));
            break;

        case RVIPP_SDP_ATTRIBUTE_FIELD:
            AppUpdateSdpMediaAttribute(pSdpMsg,&(tempStunAddressData->outAddr),tempStunAddressData->index);
            break;

        case RVIPP_SDP_MEDIA_CLOSE_FIELD:
            /* if this is the first media descriptor will use the IP address for the SDP connection */
            if (tempStunAddressData->index == 0 )
            {
                AppUpdateSdpConnection(pSdpMsg,&(tempStunAddressData->outAddr));
            }
            RvAddressSetIpPort(&(tempStunAddressData->outAddr),0);
            AppUpdateSdpMedia(pSdpMsg,&(tempStunAddressData->outAddr),(tempStunAddressData->index));
            break;

        case RVIPP_SDP_MEDIA_CONN_CLOSE_FIELD:
            AppUpdateSdpMediaConnection(pSdpMsg,&(tempStunAddressData->outAddr),tempStunAddressData->index);
            RvAddressSetIpPort(&(tempStunAddressData->outAddr),0);
            AppUpdateSdpMedia(pSdpMsg,&(tempStunAddressData->outAddr),(tempStunAddressData->index));
            break;
        default:
            RvLogError(ippLogSource,(ippLogSource, "updateAllMsgFields(): unknown AddressData type. hMsgToSend = %p", hMsgToSend));
            return RV_ERROR_UNKNOWN;
        }
    }


    /* no SDP to change back */
    if (frame->isViaOnly == RV_FALSE)
    {
        if (AppBodyIsMediaBody(frame->hBody) == RV_TRUE)
        {
            if (AppBodyConvertSdpToSipBody(&frame->sdpMsg, frame->hBody) != RV_OK)
            {
                return RV_ERROR_UNKNOWN;
            }
        }
    }
    return RV_OK;
}


/***************************************************************************
 * stunCompleteResolution
 * ------------------------------------------------------------------------
 * General: Complete address resolution and replace all fields in the
 *          pending message, sending it to the correct destination in the
 *          end of the process.
 *
 * Return Value: None.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   frame   - STUN frame to handle.
 ***************************************************************************/
static void stunCompleteResolution(IN RvStun* frame)
{
    RvSipTransmitterHandle  hTrx;
    RvSipTransmitterState   eState;
    RvStatus                status;

    status = updateAllMsgFields(frame);
    if (status == RV_OK)
    {
        status = RvSipTransactionGetTransmitter(frame->hTransc, &hTrx);
        if (status == RV_OK)
        {
            status = RvSipTransmitterGetCurrentState (hTrx, &eState);
            if ((status == RV_OK) && (eState == RVSIP_TRANSMITTER_STATE_ON_HOLD))
                status = RvSipTransmitterResumeSending(hTrx);
        }
    }

    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Had some problems while trying to resume sending the message"));
    }
}









/***************************************************************************
 * RvSipTransactionStateChangedEv
 * ------------------------------------------------------------------------
 * General: Notifies the application of a transaction state change and the
 *          associated state change reason.
 *          This function is probably the most useful of the events that the
 *          SIP transaction reports. When you receive notifications of SIP
 *          transaction state changes, your application can act upon the state.
 *          For example, upon receipt of a Server-General-Request-Received state
 *          notification, your application can respond with a desired response code.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hTransc      - The transaction handle.
 *            hTranscOwner - The application handle for this transaction.
 *            eState       - The new transaction state.
 *            eReason      - The reason for the state change.
 **************************************************************************/
static void RVCALLCONV  AppTransStateChangedEvHandler(
                                    IN RvSipTranscHandle                 hTransc,
                                    IN RvSipTranscOwnerHandle            hTranscOwner,
                                    IN RvSipTransactionState             eState,
                                    IN RvSipTransactionStateChangeReason eReason)
{
    /*
     *  do my work first
     */
    if (eState == RVSIP_TRANSC_STATE_TERMINATED)
        RvStunMgrDbDeleteFrameByKey( &g_stunMgr->database, (void*)hTransc);

    if (g_stunMgr->old_pfnTransEvStateChanged != NULL)
    {
        g_stunMgr->old_pfnTransEvStateChanged(
                                            hTransc,
                                            hTranscOwner,
                                            eState,
                                            eReason);
    }
}
/***************************************************************************
 * RvSipCallLegStateChangedEv
 * ------------------------------------------------------------------------
 * General: Notifies the application of a call-leg state change.
 *          If the new state is Offering - accept the call with
 *          RvSipCallLegAccept().
 *          If and incoming call-leg reached the Connected state, disconnect
 *          the call with RvSipCallLegDisconnect().
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hCallLeg -    The sip stack call-leg handle
 *          hAppCallLeg - The application handle for this call-leg.
 *          eState -      The new call-leg state
 *          eReason -     The reason for the state change.
 ***************************************************************************/
static void RVCALLCONV AppCallLegStateChangedEvHandler(
                                   IN  RvSipCallLegHandle            hCallLeg,
                                   IN  RvSipAppCallLegHandle         hAppCallLeg,
                                   IN  RvSipCallLegState             eState,
                                   IN  RvSipCallLegStateChangeReason eReason)
{
    /*
     *  do my work first
     */
    switch(eState)
    {
    case RVSIP_CALL_LEG_STATE_DISCONNECTED:
    case RVSIP_CALL_LEG_STATE_TERMINATED:
        RvStunMgrDbDeleteFrameByKey( &g_stunMgr->database, (void*)hCallLeg);
        break;
    default:
        break;
    }



    if( g_stunMgr->old_pfnCallLegStateChangedEvHandler)
    {
        g_stunMgr->old_pfnCallLegStateChangedEvHandler(
                                                    hCallLeg,
                                                    hAppCallLeg,
                                                    eState,
                                                    eReason);
    }

    return;
}

/***************************************************************************
 * parseFinalDestResolved
 * ------------------------------------------------------------------------
 * General:
 *
 * Return Value: RvStatus. .
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     RvStun     - object containing context of  FinalDestResolvedEvHandler.
 ***************************************************************************/
static RvStatus RVCALLCONV parseFinalDestResolved( RvStun* frame)
{
    RvSipMsgHandle      hMsgToSend = frame->hMsgToSend;
    RvSipMethodType     eMethod = RvSipMsgGetRequestMethod(hMsgToSend); /*need to check register message */
    RvBool              isUdp;

    frame->hBody        = NULL;
    frame->isViaOnly    = RV_FALSE;

	frame->isViaOnly =
		(eMethod == RVSIP_METHOD_BYE) || (eMethod == RVSIP_METHOD_CANCEL);

	if (AppSetStunVia(hMsgToSend, &frame->stunAddrList, &isUdp) != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource, "RvStunConstruct(): failed in AppSetStunVia(). hMsgToSend = %p", hMsgToSend));
		goto err_exit;
	}

	/* if protocol is not UDP then clear the list and exit */
	if (isUdp != RV_TRUE)
	{
		RvLogInfo(ippLogSource,(ippLogSource, "RvStunConstruct(): not UDP message. hMsgToSend = %p", hMsgToSend));
		goto ok_exit;
	}

    /* if its a bye req then leave after VIA change
    *  else continue
    */
    if (frame->isViaOnly == RV_FALSE)
    {
        if (AppSetStunContact(hMsgToSend, &frame->stunAddrList,&isUdp) != RV_OK)
        {
			RvLogError(ippLogSource,(ippLogSource, "RvStunConstruct(): failed in AppSetStunContact(). hMsgToSend = %p", hMsgToSend));
			goto err_exit;
        }

        frame->hBody = RvSipMsgGetBodyObject(hMsgToSend);
        if ( AppBodyIsMediaBody( frame->hBody) == RV_TRUE)
        {

            if (AppBodyConvertSipBodyToSdp( frame->hBody,&frame->sdpMsg) != RV_OK)
            {
                RvLogError(ippLogSource,(ippLogSource, "RvStunConstruct(): failed in AppBodyConvertSipBodyToSdp(). hMsgToSend = %p", hMsgToSend));
                goto err_exit;
            }


			if (AppSetStunOrigin( &frame->sdpMsg,&frame->stunAddrList) !=RV_OK)
			{
				RvLogError(ippLogSource,(ippLogSource, "RvStunConstruct(): failed in AppSetStunOrigin(). hMsgToSend = %p", hMsgToSend));
				goto err_exit;
			}

            if (AppSetStunConnection(&frame->sdpMsg,&frame->stunAddrList) != RV_OK)
            {
                RvLogError(ippLogSource,(ippLogSource, "RvStunConstruct(): failed in AppSetStunConnection(). hMsgToSend = %p", hMsgToSend));
                goto err_exit;
            }
        }
    }

ok_exit:
    /* Now that we have the list of addresses found in the SIP message,
     * what we do is go through them one-by-one, and check if they need
     * resolution or not - if they don't, then it means that they are internal
     * and not public addresses, which means just the opposite - that we need
     * to execute a STUN request on them.
     */
    {
        RvIppStunAddrData*              data;
        RvListIter(RvIppStunAddrData)  i, e;
        RvStunAddrList *list = &frame->stunAddrList;

        i = rvListBegin(list);
        e = rvListEnd(list);
        while (i != e)
        {
            RvBool resolutionNeeded;
            data = (RvIppStunAddrData*)RvListIterData(i);

            RvLogEnter(ippLogSource,(ippLogSource, "isAddressResolveNeededCB()"));
            resolutionNeeded = g_stunMgr->isAddressResolveNeededCB(&data->inAddr);
            RvLogLeave(ippLogSource,(ippLogSource, "isAddressResolveNeededCB()=%d", resolutionNeeded));

            // TODO: TSAHI remove!!!
            //resolutionNeeded = RV_FALSE;

            if (resolutionNeeded)
                i = rvListErase(RvIppStunAddrData)(list, i);
            else
                i = rvListIterNext(i);
        }
    }

    return RV_OK;

err_exit:
    return  RV_ERROR_UNKNOWN;
}


/***************************************************************************
 * proceedFinalDestResolved
 * ------------------------------------------------------------------------
 * General:
 *
 * Return Value: RvStatus. .
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     RvStun     - object containing context of  FinalDestResolvedEvHandler.
 ***************************************************************************/
static void proceedFinalDestResolved(IN RvStun* frame)
{

	/*
	 * some of found addresses maybe already requested due to previous Stun requests
	 * extract those addresses which are not requested yet
	 */

	if(RV_OK != RvStunMgrDbMergeRequest( &g_stunMgr->database, frame))
	{
		RvLogError(ippLogSource,(ippLogSource, "proceedFinalDestResolved(): failed in RvStunMgrDbMergeRequest(). "));
		RvStunNotifyError(frame);
		RvStunMgrDbRemoveFrame(&g_stunMgr->database, frame);
		RvStunDestruct(frame);
		rvMtfAllocatorDealloc(frame, sizeof(RvStun));
	}

	return;

}


/***************************************************************************
 * registerStackCallbacks
 * ------------------------------------------------------------------------
 * General: Create object that will be used to send raw buffer over Sip signaling socket
 *          Set  callback functions for this transmitter objects.
 ***************************************************************************/
static void registerStackCallbacks(IN RvStunMgr* stunMgr)
{
    RvStatus                    status;
    RvSipCallLegMgrHandle       hCallLegMgr;
    RvSipRegClientMgrHandle     hRegClientMgr;
    RvSipTranscMgrHandle        hTranscMgr;
    RvSipTransportMgrHandle     hTransportMgr;
    RvSipSubsMgrHandle          hSubsMgr;
    RvIppSipStackCallbacks*     stackCallbacks;
    RvSipControl*               sipMgr = rvCCSipPhoneGetSipMgr();
    RvSipStackHandle            hStack  = rvSipControlGetStackHandle(sipMgr);

    /* Get the relevant manager handles of the SIP stack */
    RvSipStackGetCallLegMgrHandle(hStack,  &hCallLegMgr);
    RvSipStackGetRegClientMgrHandle(hStack, &hRegClientMgr);
    RvSipStackGetTransactionMgrHandle(hStack, &hTranscMgr);
    RvSipStackGetTransportMgrHandle(hStack, &hTransportMgr);
    RvSipStackGetSubsMgrHandle(hStack, &hSubsMgr);

    /* Get current callbacks. We're going to replace some of them, but we still
       want to call the original ones when we're not dealing with our STUN messages. */
    stackCallbacks = rvIppSipControlGetStackCallbacks((RvIppSipControlHandle)sipMgr);

    /*
     *  store the old callbacks in order to call them inside overriding callback
     */
    stunMgr->old_pfnFinalDestResolvedEvHandler = stackCallbacks->sipCallLegEvHandlers.pfnFinalDestResolvedEvHandler;
    stunMgr->old_pfnRegClientFinalDestResolvedEvHandler = stackCallbacks->sipRegClientEvHandlers.pfnFinalDestResolvedEvHandler;
    stunMgr->old_pfnCallLegStateChangedEvHandler = stackCallbacks->sipCallLegEvHandlers.pfnStateChangedEvHandler;
    stunMgr->old_pfnTransEvStateChanged = stackCallbacks->sipTransEvHandlers.pfnEvStateChanged;
    stunMgr->old_pfnTtransportEvBufferReceived = stackCallbacks->sipTransportEvHandlers.pfnEvBufferReceived;
    stunMgr->old_pfnSubsFinalDestResolvedEvHandler = stackCallbacks->sipSubsEvHandlers.pfnFinalDestResolvedEvHandler;

    /* Set our new callbacks in the structure */
    stackCallbacks->sipCallLegEvHandlers.pfnFinalDestResolvedEvHandler = AppCallLegFinalDestResolvedEvHandler;
    stackCallbacks->sipCallLegEvHandlers.pfnStateChangedEvHandler = AppCallLegStateChangedEvHandler;
    stackCallbacks->sipRegClientEvHandlers.pfnFinalDestResolvedEvHandler= AppRegClientFinalDestResolvedEvHandler;
    stackCallbacks->sipTransEvHandlers.pfnEvStateChanged = AppTransStateChangedEvHandler;
    stackCallbacks->sipTransportEvHandlers.pfnEvBufferReceived = AppTransportBufferReceivedEvHandler;
    stackCallbacks->sipSubsEvHandlers.pfnFinalDestResolvedEvHandler= AppSubsFinalDestResolvedEvHandler;

    /* Start setting the new callbacks that we have */

    status = RvSipCallLegMgrSetEvHandlers(hCallLegMgr,
        &stackCallbacks->sipCallLegEvHandlers,
        sizeof(stackCallbacks->sipCallLegEvHandlers));
    if (status == RV_OK)
    {
        status = RvSipRegClientMgrSetEvHandlers(hRegClientMgr,
            &stackCallbacks->sipRegClientEvHandlers,
            sizeof(stackCallbacks->sipRegClientEvHandlers));
    }

    if (status == RV_OK)
    {
        status = RvSipTransactionMgrSetEvHandlers(hTranscMgr,
            stunMgr,
            &stackCallbacks->sipTransEvHandlers,
            sizeof(stackCallbacks->sipTransEvHandlers));
    }

    if (status == RV_OK)
    {
        status = RvSipTransportMgrSetEvHandlers(hTransportMgr,
            (RvSipAppTransportMgrHandle)stunMgr,
            &stackCallbacks->sipTransportEvHandlers,
            sizeof(stackCallbacks->sipTransportEvHandlers));
    }

    if (status == RV_OK)
    {
        status = RvSipSubsMgrSetEvHandlers(hSubsMgr,
            &stackCallbacks->sipSubsEvHandlers,
            sizeof(RvSipSubsEvHandlers));
    }

    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Failed to set register STUN related callbacks"));
	}
}

/***************************************************************************
 * unregisterStackCallbacks
 * ------------------------------------------------------------------------
 * General: Create object that will be used to send raw buffer over Sip signaling socket
 *          Set  callback functions for this transmitter objects.
 ***************************************************************************/
static void unregisterStackCallbacks(IN RvStunMgr* stunMgr)
{
    RvStatus                    status;
    RvSipCallLegMgrHandle       hCallLegMgr;
    RvSipRegClientMgrHandle     hRegClientMgr;
    RvSipSubsMgrHandle          hSubsMgr;
    RvSipTranscMgrHandle        hTranscMgr;
    RvSipTransportMgrHandle     hTransportMgr;
    RvIppSipStackCallbacks*     stackCallbacks;
    RvSipControl*               sipMgr = rvCCSipPhoneGetSipMgr();
    RvSipStackHandle            hStack  = rvSipControlGetStackHandle( sipMgr);

    RvSipStackGetCallLegMgrHandle(hStack,  &hCallLegMgr);
    RvSipStackGetRegClientMgrHandle(hStack, &hRegClientMgr);
    RvSipStackGetTransactionMgrHandle(hStack, &hTranscMgr);
    RvSipStackGetTransportMgrHandle(hStack, &hTransportMgr);
    RvSipStackGetSubsMgrHandle(hStack, &hSubsMgr);


    /*
     *  store the old callbacks in order to call them inside overriding callback
     */
    stackCallbacks = rvIppSipControlGetStackCallbacks((RvIppSipControlHandle)sipMgr);

    stackCallbacks->sipCallLegEvHandlers.pfnFinalDestResolvedEvHandler = stunMgr->old_pfnFinalDestResolvedEvHandler;
    stackCallbacks->sipCallLegEvHandlers.pfnStateChangedEvHandler = stunMgr->old_pfnCallLegStateChangedEvHandler;
    stackCallbacks->sipRegClientEvHandlers.pfnFinalDestResolvedEvHandler= stunMgr->old_pfnRegClientFinalDestResolvedEvHandler;
    stackCallbacks->sipTransEvHandlers.pfnEvStateChanged = stunMgr->old_pfnTransEvStateChanged       ;
    stackCallbacks->sipTransportEvHandlers.pfnEvBufferReceived = stunMgr->old_pfnTtransportEvBufferReceived;
    stackCallbacks->sipSubsEvHandlers.pfnFinalDestResolvedEvHandler= stunMgr->old_pfnSubsFinalDestResolvedEvHandler;

    /* Set'em all */

    status = RvSipCallLegMgrSetEvHandlers(hCallLegMgr,
        &stackCallbacks->sipCallLegEvHandlers,
        sizeof(RvSipCallLegEvHandlers));

    if (status == RV_OK)
    {
        status = RvSipRegClientMgrSetEvHandlers(hRegClientMgr,
            &stackCallbacks->sipRegClientEvHandlers,
            sizeof(RvSipRegClientEvHandlers));
    }

    if (status == RV_OK)
    {
        status = RvSipSubsMgrSetEvHandlers(hSubsMgr,
            &stackCallbacks->sipSubsEvHandlers,
            sizeof(RvSipSubsEvHandlers));
    }

    /* TODO: In the next two calls, we set application context handle to NULL, which might
       be different than those originally set here */
    if (status == RV_OK)
    {
        status = RvSipTransactionMgrSetEvHandlers(hTranscMgr,
            NULL,
            &stackCallbacks->sipTransEvHandlers,
            sizeof(RvSipTransactionEvHandlers));
    }

    if (status == RV_OK)
    {
        status = RvSipTransportMgrSetEvHandlers(hTransportMgr,
            NULL,
            &stackCallbacks->sipTransportEvHandlers,
            sizeof(RvSipTransportMgrEvHandlers));
    }

    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Failed to set back original callbacks"));
	}
}

/***************************************************************************
 * createTransmitter
 * ------------------------------------------------------------------------
 * General: Create object that will be used to send raw buffer over Sip signaling socket
 *          Set  callback functions for this transmitter objects.
 ***************************************************************************/
static void createTransmitter(  IN RvSipStackHandle stackHndl, OUT RvSipTransmitterHandle* phTrx)
{
    RvStatus        rv;
    RvSipTransmitterMgrHandle   hTrxMgr;
    RvSipTransmitterEvHandlers  evHandlers;

    RvSipStackGetTransmitterMgrHandle(stackHndl,    &hTrxMgr);
    memset(&evHandlers,0, sizeof(evHandlers));

    evHandlers.pfnStateChangedEvHandler = AppTransmitterStateChangedEvHandler;

    /*Create Transmitter object */
    rv = RvSipTransmitterMgrCreateTransmitter(
                                            hTrxMgr,
                                            (RvSipAppTransmitterHandle)NULL,
                                            &evHandlers,
                                            sizeof(evHandlers),
                                            phTrx);

    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "createTransmitter(): Failed"));
        return;
    }

    RvSipTransmitterSetIgnoreOutboundProxyFlag( *phTrx, RV_TRUE);
}
/***************************************************************************
 * destroyTransmitter
 * ------------------------------------------------------------------------
 * General: Create object that will be used to send raw buffer over Sip signaling socket
 *          Set  callback functions for this transmitter objects.
 ***************************************************************************/
static void destroyTransmitter(  IN  RvSipTransmitterHandle phTrx)
{
    if(RV_OK != RvSipTransmitterTerminate( phTrx))
    {
        RvLogError(ippLogSource,(ippLogSource, "destroyTransmitter(): Failed"));
	}

}
/*-----------------------------------------------------------------------*/
/*                            RvStunMgr  IMPLEMENTATION               */
/*-----------------------------------------------------------------------*/

/*===========================================*/
static void RvStunMgrConstruct(
    INOUT RvStunMgr*            stunMgr,
    IN    RvIppStunMgrParam*    param)
{
    RvCCProvider*           p = rvCCBasePhoneGetNetProvider();
    RvCCProviderSip*        provider = rvCCProviderSipGetImpl(p);
    RvSipControl*           sipMgr = rvCCSipPhoneGetSipMgr();
    RvSize_t                len;
    SendMethod*             method;

    /* TODO: lose the global pointer, use access functions instead */
    g_stunMgr = stunMgr;

    /*
     *  if default allocator isn't defined use CommonCore default
     */
    if (prvDefaultAlloc == NULL)
        prvDefaultAlloc = rvAllocGetDefaultAllocator();

    /*
     *  store primary parameters
     */
    stunMgr->isAddressResolveNeededCB = param->isAddressResolveNeededCB;
    stunMgr->addressResolveStartCB = param->addressResolveStartCB;
    stunMgr->addressResolveReplyCB = param->addressResolveReplyCB;

    /*
     *  override stack callbacks
     */
    registerStackCallbacks(stunMgr);

    /*
     *  initialize database
     */
    RvStunMgrDbConstruct(&stunMgr->database,
        stunCompleteResolution,
        RvStunNotifyError);

    /*
     *  construct container keeping temporary objects while sending stun message over SIP stack socket
     */
    rvPtrListConstruct(&stunMgr->stunMsgDataList, prvDefaultAlloc);
    RvMutexConstruct(IppLogMgr(), &stunMgr->stunMsgDataMutex);

    /*
     * Create the send method for backward compatibility. This allows applications
     * to send messages over the SIP socket. It is not needed from SIP TK v4.5.
     */
    method = &stunMgr->sendMethod;
    len = sizeof(method->srcAddr)-1;
    strncpy(method->srcAddr, provider->localAddress, len);
    method->srcAddr[len] = '\0';
    method->srcPort = sipMgr->stackPort;
    method->usrData = (void*)stunMgr;
    method->sendMsgCB = RvStunMgrSendRawMsg;
}



static void RvStunMgrDestruct(IN RvStunMgr* stunMgr)
{
    g_stunMgr = NULL;
    RvAddressDestruct(&stunMgr->addrStunServer);

    /*
     *  restorer stack callbacks
     */
    unregisterStackCallbacks(stunMgr);

    /*
    *   destroy database
    */
    RvStunMgrDbDestruct(&stunMgr->database);

    /*
     *  destruct container keeping temporary objects while sending stun message over SIP stack socket
     */
    rvPtrListDestruct(&stunMgr->stunMsgDataList);
    RvMutexDestruct(&stunMgr->stunMsgDataMutex, IppLogMgr());
}
/*-----------------------------------------------------------------------*/



/*-----------------------------------------------------------------------*/
/*                            RvStun  IMPLEMENTATION                     */
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*
 *  common part of all RvStunConstruct functions
 */
static RvStatus sendMtfStunRequest(
    INOUT RvStun*           frame,
    IN    RvSipTranscHandle hTransc,
    IN    RvSipMsgHandle    hMsgToSend,
    OUT   RvBool*           needToResolve)
{
    RvStatus                status;
    RvSipTransmitterHandle  hTrx;

    frame->hTransc = hTransc;
    frame->hMsgToSend = hMsgToSend;

    rvListConstruct(RvIppStunAddrData)(&frame->stunAddrList, prvDefaultAlloc);

    /*
     *  start timer dictating max time_to_live of frame
     */
    /*status = IppTimerConstruct(&frame->timeToLiveTimer, IPP_STUN_REQ_TIME_TO_LIVE_ms, (RvTimerFunc)RvStunTimeToLiveFunc, frame);
    if (status == RV_OK)
        status = IppTimerStart(&frame->timeToLiveTimer, IPP_TIMER_DONT_CHECK_IF_STARTED, 0);
    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "commonRvStunConstruct(): failed to start a timer"));
        return status;
    }*/

    status = parseFinalDestResolved(frame);

    /* If no addresses exist to resolve - do nothing */
    if (status == RV_OK)
    {
        if (RvStunIsAddrListEmpty(frame))
        {
            *needToResolve = RV_FALSE;
            return RV_OK;
        }
        *needToResolve = RV_TRUE;
    }

    status = RvSipTransactionGetTransmitter(hTransc, &hTrx);
    if (status == RV_OK)
        status = holdSendMessage(frame, hTrx, hMsgToSend);

    return status;
}


void RvStunDestruct(IN RvStun* frame)
{
    if (frame == NULL)
        return;

    frame->hBody = NULL;

    rvSdpMsgDestruct(&frame->sdpMsg);
    rvListDestruct(RvIppStunAddrData)(&frame->stunAddrList);

    IppTimerStop(&frame->timeToLiveTimer);
    IppTimerDestruct(&frame->timeToLiveTimer);
}



/*-----------------------------------------------------------------------*/
void RvStunNotifyError(RvStun  * frame)
{
    switch (frame->type)
    {
    case MtfStunFrameCallLeg:
    {
        RvBool          callStillAlive;
        RvCCConnState   state;
        RvCCConnection* cSip = (RvCCConnection*)frame->sipAppHandle;
        RvCCConnection* cMdm = NULL;

        if (cSip != NULL)
            cMdm = cSip->curParty;

        if ((cMdm != NULL) && (cMdm->call != NULL))
        {
            state = rvCCConnectionGetState(cMdm);

            if (state != RV_CCCONNSTATE_IDLE &&
                state != RV_CCCONNSTATE_DISCONNECTED &&
                state != RV_CCCONNSTATE_UNKNOWN)
            {
                rvCCConnSipProcessEvent(cSip, RV_CCTERMEVENT_FAILGENERAL, &callStillAlive, RV_CCCAUSE_NORMAL);
            }
        }
        break;
    }

    case MtfStunFrameRegClient:
    {
        RvSipTransmitterHandle  hTrx;
        RvSipTransmitterState   eState;

        if(RV_OK != RvSipTransactionGetTransmitter( frame->hTransc, &hTrx))
        {
            RvLogError(ippLogSource,(ippLogSource, "RvStunNotifyError(): failed in RvSipTransactionGetTransmitter(). hMsgToSend = %p", frame->hMsgToSend));
            return;
        }

        if(RV_OK != RvSipTransmitterGetCurrentState (hTrx, &eState))
        {
            RvLogError(ippLogSource,(ippLogSource, "RvStunNotifyError(): failed in RvSipTransmitterGetCurrentState(). hMsgToSend = %p", frame->hMsgToSend));
            return;
        }

        if(eState == RVSIP_TRANSMITTER_STATE_ON_HOLD)
        {
            if( RV_OK != RvSipTransmitterResumeSending( hTrx))
            {
                RvLogError(ippLogSource,(ippLogSource, "RvStunNotifyError(): failed in RvSipTransmitterResumeSending(). hMsgToSend = %p", frame->hMsgToSend));
                return;
            }
        }
        break;
    }

    case MtfStunFrameSubs:
        // TODO...
        break;
    }
}



/*-----------------------------------------------------------------------*/
/*                            CALLBACKS IMPLEMENTATION                   */
/*-----------------------------------------------------------------------*/

/***************************************************************************
 * RvSipTransportBufferReceivedEv
 * ------------------------------------------------------------------------
 * General: Exposes the raw data buffer to an application that contains exactly
 *          one SIP message that was received on the TCP/UDP layer.
 *          The application can dump the data by means of this callback.
 *          Also, the application can order the SIP Stack to discard the buffer
 *          and not to parse it, by means of the pbDiscardBuffer parameter.
 *
 * Return Value: none.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hTransportMgr    - A handle to the transport manager object.
 *          hAppTransportMgr - The application handle. You supply this handle
 *                             when setting the event handles
 *          hLocalAddr       - Handle to Local Address object, corresponding to
 *                             address on which the buffer was received.
 *          pSenderAddrDetails - A pointer to Transport Address structure,
 *                             which contains details of the address from which
 *                             the message was sent.
 *          hConn            - handle of the connection, on which the buffer
 *                             was received. NULL for UDP.
 *          hAppConn         - handle, set by Application for the connection.
 *          buffer           - pointer to the buffer,which contains the message
 *          buffLen          - length of the message in the buffer (in bytes)
 * Output:  bDiscardBuffer   - if set to RV_TRUE, the buffer will be not
 *                             processed, the resources will be freed.
 ***************************************************************************/
static void RVCALLCONV AppTransportBufferReceivedEvHandler(
                                                    IN  RvSipTransportMgrHandle             hTransportMgr,
                                                    IN  RvSipAppTransportMgrHandle          hAppTransportMgr,
                                                    IN  RvSipTransportLocalAddrHandle       hLocalAddr,
                                                    IN  RvSipTransportAddr                  *pSenderAddrDetails,
                                                    IN  RvSipTransportConnectionHandle      hConn,
                                                    IN  RvSipTransportConnectionAppHandle   hAppConn,
                                                    IN  RvChar                              *buffer,
                                                    IN  RvUint32                            buffLen,
                                                    OUT RvBool                              *pbDiscardBuffer)
{
    *pbDiscardBuffer = RV_FALSE;

    if (g_stunMgr->addressResolveReplyCB != NULL)
    {
        RvStatus    status;
        RvAddress   addr;
        RvSipTransportConvertTransportAddr2RvAddress(pSenderAddrDetails, &addr);

        RvLogEnter(ippLogSource,(ippLogSource, "RvIppAddressResolveReplyCB(buf=%p,len=%d)",
            buffer, buffLen));

        status = g_stunMgr->addressResolveReplyCB(&addr, buffer, buffLen, pbDiscardBuffer);
        if (status != RV_OK)
            *pbDiscardBuffer = RV_FALSE;

        RvLogLeave(ippLogSource,(ippLogSource, "RvIppAddressResolveReplyCB(discardBuffer=%d)=%d",
            *pbDiscardBuffer, status));
    }

    if (*pbDiscardBuffer == RV_FALSE)
    {
        /* We need to handle this buffer, so we pass it to the old callback we stored */
        if (g_stunMgr->old_pfnTtransportEvBufferReceived != NULL)
        {
            g_stunMgr->old_pfnTtransportEvBufferReceived(
                hTransportMgr, hAppTransportMgr, hLocalAddr,
                pSenderAddrDetails, hConn, hAppConn,
                buffer, buffLen, pbDiscardBuffer);
        }
    }
}
/*-----------------------------------------------------------------------*/
static void RVCALLCONV AppTransmitterStateChangedEvHandler(
                                                           IN  RvSipTransmitterHandle            hTrx,
                                                           IN  RvSipAppTransmitterHandle         hAppTrx,
                                                           IN  RvSipTransmitterState             eState,
                                                           IN  RvSipTransmitterReason            eReason,
                                                           IN  RvSipMsgHandle                    hMsg,
                                                           IN  void*                             pExtraInfo)
{
    RV_UNUSED_ARG(hAppTrx);
    RV_UNUSED_ARG(eReason);
    RV_UNUSED_ARG(hMsg);
    RV_UNUSED_ARG(pExtraInfo);

    switch(eState)
    {
    case RVSIP_TRANSMITTER_STATE_READY_FOR_SENDING:
        {
            RvStunMsgData* data;
            RvMutexLock ( &g_stunMgr->stunMsgDataMutex, IppLogMgr());
            data = RvStunMsgDataListFind( &g_stunMgr->stunMsgDataList, hTrx);
            RvMutexUnlock ( &g_stunMgr->stunMsgDataMutex, IppLogMgr());

                if( NULL != data)
                {
                    /*RvSipTransmitterReadyForSendingInfo*  info = (RvSipTransmitterReadyForSendingInfo*)pExtraInfo;
                    info->buffLen = data->size;
                    info->strBuff = (char*)data->buf;*/
                }
        }
        break;

        /*
         *  the next cases are not delimited by break !!!
         */
    case RVSIP_TRANSMITTER_STATE_MSG_SENT:
    case RVSIP_TRANSMITTER_STATE_MSG_SEND_FAILURE:
    case RVSIP_TRANSMITTER_STATE_TERMINATED:
        {
            RvStunMsgData* data;
            RvMutexLock ( &g_stunMgr->stunMsgDataMutex, IppLogMgr());
            data = RvStunMsgDataListFind( &g_stunMgr->stunMsgDataList, hTrx);

            if( NULL != data)
            {
                rvPtrListRemove( &g_stunMgr->stunMsgDataList, data);
                RvStunMsgDataDestruct( data);
                rvMtfAllocatorDealloc(data, sizeof(RvStunMsgData));
            }
            RvMutexUnlock ( &g_stunMgr->stunMsgDataMutex, IppLogMgr());
        }
        break;

    default:
        break;
    }
    /*
     *  understand if it's fake message - target for replacement by STUN
     */

}

/*---------------------------------------------------------------*/
static RvStatus  holdSendMessage(
    IN RvStun*                  frame,
    IN RvSipTransmitterHandle   hTrx,
    IN RvSipMsgHandle           hMsgToSend)
{
    RvStatus    status;

	status = RvSipTransmitterHoldSending(hTrx);
	if (status != RV_OK)
	{
		RvLogError(ippLogSource,(ippLogSource, "holdSendMessage(): failed in RvSipTransmitterHoldSending(). hMsgToSend = %p", hMsgToSend));
		return status;
	}

    proceedFinalDestResolved(frame);

    status = sendReqToStunClient(&frame->stunAddrList);

    return status;
}



/******************************************************************************
 * createMtfStunFrame
 * ----------------------------------------------------------------------------
 * General:
 *  Check for a SIP transaction if there is a need to ask for a STUN public
 *  address. Essentially, it checks the remote address against the application's
 *  resolution requirements and then creates a STUN frame to process it
 *  asynchronously if needed.
 *
 * Arguments:
 * Input:  hTransc      - SIP transaction.
 * Output: stunFrame    - The created STUN frame if resolution is needed.
 *                        NULL otherwise.
 * Return Value: RvStatus
 *****************************************************************************/
static RvStatus createMtfStunFrame(
    IN  RvSipTranscHandle       hTransc,
    OUT RvStun**                stunFrame)
{
    RvStatus                    status;
    RvAddress                   remoteAddress;
    RvSipTransport              eTransportType;
    RvSipTransportAddressType   eAddressType;
    RvChar                      szAddress[RVSIP_TRANSPORT_LEN_STRING_IP];
    RvUint16                    port;

    *stunFrame = NULL;

    /* Now see what's the destination address the message is being sent to */
    status = RvSipTransactionGetCurrentDestAddress(
        hTransc, &eTransportType, &eAddressType, szAddress, &port);
    if (status == RV_OK)
    {
        RvInt addrtype = RV_ADDRESS_TYPE_NONE;
        switch(eAddressType)
        {
        case RVSIP_TRANSPORT_ADDRESS_TYPE_IP:   addrtype = RV_ADDRESS_TYPE_IPV4; break;
        case RVSIP_TRANSPORT_ADDRESS_TYPE_IP6:  addrtype = RV_ADDRESS_TYPE_IPV6; break;
        default: status = RV_ERROR_BADPARAM;
        }
        if (status == RV_OK)
        {
            RvAddressConstruct(addrtype, &remoteAddress);
            RvAddressSetString(szAddress, &remoteAddress);
            RvAddressSetIpPort(&remoteAddress, port);
        }
    }

    /* Check if we should enable mapping mechanism by STUN.
       To check it we call user CB function passing the destination address of the message. */
    if ((status == RV_OK) && (g_stunMgr->isAddressResolveNeededCB != NULL))
    {
        RvBool resolutionNeeded;

        RvLogEnter(ippLogSource,(ippLogSource, "isAddressResolveNeededCB(addr=%s:%d)", szAddress, port));
        resolutionNeeded = g_stunMgr->isAddressResolveNeededCB(&remoteAddress);
        RvLogLeave(ippLogSource,(ippLogSource, "isAddressResolveNeededCB()=%d", resolutionNeeded));

        if (!resolutionNeeded)
            return RV_OK;
    }

    /* Create the STUN frame in order to process it asynchronously */
    if (status == RV_OK)
    {
        rvMtfAllocatorAlloc(sizeof(RvStun), (void**)stunFrame);
        if (*stunFrame != NULL)
            memset(*stunFrame, 0, sizeof(**stunFrame));
        else
            status = RV_ERROR_UNKNOWN;
    }

    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "createMtfStunFrame - failed to build frame for some reason..."));
    }

    return status;
}
/*---------------------------------------------------------------*/


/***************************************************************************
 * RvSipRegClientFinalDestResolvedEv
 * ------------------------------------------------------------------------
 * General: Notifies the application that the register-client is about to send a
 *          message after the destination address was resolved.
 *          This callback supplies the final message object and the transaction
 *          that is responsible for sending this message. Changes in the message
 *          at this stage will not effect the destination address.
 *          When this callback is called, the application can query the transaction
 *          about the destination address using the
 *          RvSipTransactionGetCurrentDestAddress() function. If the application
 *          wishes, it can update the sent-by part of the top-most Via header.
 *          The application must not update the branch parameter.
 *
 * Return Value: RvStatus. If the application returns a value other then
 *               RV_OK the message will not be sent. The transaction will
 *               terminate with error and the register-client will move to the
 *               Failed state.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hRegClient     - Handle to the register client.
 *            hAppRegClient  - The application handle for this register client.
 *            hTransc        - The transaction handle
 *            hMsgToSend     - The handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppSubsFinalDestResolvedEvHandler(
                                            IN  RvSipSubsHandle           hSubs,
                                            IN  RvSipAppSubsHandle        hAppSubs,
                                            IN  RvSipNotifyHandle         hNotify,
                                            IN  RvSipAppNotifyHandle      hAppNotify,
                                            IN  RvSipTranscHandle         hTransc,
                                            IN  RvSipMsgHandle            hMsgToSend)
{
    RvBool      needToResolve = RV_TRUE;
    RvStatus    status = RV_OK;
    RvStun*     frame = NULL;

    /* Invoke the old implementation now, before we start STUNning this message */
    if (g_stunMgr->old_pfnFinalDestResolvedEvHandler != NULL)
    {
        status = g_stunMgr->old_pfnSubsFinalDestResolvedEvHandler(
            hSubs, hAppSubs, hNotify, hAppNotify, hTransc, hMsgToSend);
    }

    /* Check if we need to work with STUN or not */
    if (status == RV_OK)
    {
        status = createMtfStunFrame(hTransc, &frame);
    }

    if ((status == RV_OK) && (frame != NULL))
    {
        frame->type = MtfStunFrameSubs;
        frame->sipHandle = (void*)hSubs;
        frame->sipAppHandle = (void*)hAppSubs;

        status = sendMtfStunRequest(frame, hTransc, hMsgToSend, &needToResolve);
    }

    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Error starting a STUN trasnaction"));
    }
    if (((status != RV_OK) || !needToResolve) && (frame != NULL))
    {
        RvStunDestruct(frame);
        rvMtfAllocatorDealloc(frame, sizeof(RvStun));
    }

    return status;
}


/***************************************************************************
 * AppCallLegFinalDestResolvedEvHandler
 * ------------------------------------------------------------------------
 * General: Notifies the application that the call-leg is about to send a
 *          message after the destination address was resolved.
 *          This callback supplies the final message object and the transaction
 *          that is responsible for sending this message. Changes in the message
 *          at this stage will not effect the destination address.
 *          When this callback is called, the application can query the transaction
 *          about the destination address using the
 *          RvSipTransactionGetCurrentDestAddress() function. If the application
 *          wishes, it can update the sent-by part of the top-most Via header.
 *          The application must not update the branch parameter.
 *
 * Return Value: RvStatus. If the application returns a value other then
 *               RV_OK the message will not be sent. The transaction will
 *               terminate with error.The call-leg will also terminate unless
 *               the transaction was initiated by the application (for example
 *               INFO).
 *
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hCallLeg       - The sip stack call-leg handle
 *            hAppCallLeg    - The application handle for this call-leg.
 *            hTransc        - The transaction handle
 *            hAppTransc     - The application handle for this transaction.
 *                             For INVITE/BYE the hAppTransc is NULL.
 *            hMsgToSend     - The handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppCallLegFinalDestResolvedEvHandler(
                      IN  RvSipCallLegHandle     hCallLeg,
                      IN  RvSipAppCallLegHandle  hAppCallLeg,
                      IN  RvSipTranscHandle      hTransc,
                      IN  RvSipAppTranscHandle   hAppTransc,
                      IN  RvSipMsgHandle         hMsgToSend)
{
    RvBool      needToResolve = RV_TRUE;
    RvStatus    status = RV_OK;
    RvStun*     frame = NULL;

    /* Invoke the old implementation now, before we start STUNning this message */
    if (g_stunMgr->old_pfnFinalDestResolvedEvHandler != NULL)
    {
        status = g_stunMgr->old_pfnFinalDestResolvedEvHandler(
            hCallLeg, hAppCallLeg, hTransc, hAppTransc, hMsgToSend);
    }

    /* Check if we need to work with STUN or not */
    if (status == RV_OK)
    {
        status = createMtfStunFrame(hTransc, &frame);
    }

    if ((status == RV_OK) && (frame != NULL))
    {
        frame->type = MtfStunFrameCallLeg;
        frame->sipHandle = (void*)hCallLeg;
        frame->sipAppHandle = (void*)hAppCallLeg;

        status = sendMtfStunRequest(frame, hTransc, hMsgToSend, &needToResolve);
    }

    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Error starting a STUN trasnaction"));
    }
    if (((status != RV_OK) || !needToResolve) && (frame != NULL))
    {
        RvStunDestruct(frame);
        rvMtfAllocatorDealloc(frame, sizeof(RvStun));
    }

    return status;
}

/***************************************************************************
 * RvSipRegClientFinalDestResolvedEv
 * ------------------------------------------------------------------------
 * General: Notifies the application that the register-client is about to send a
 *          message after the destination address was resolved.
 *          This callback supplies the final message object and the transaction
 *          that is responsible for sending this message. Changes in the message
 *          at this stage will not effect the destination address.
 *          When this callback is called, the application can query the transaction
 *          about the destination address using the
 *          RvSipTransactionGetCurrentDestAddress() function. If the application
 *          wishes, it can update the sent-by part of the top-most Via header.
 *          The application must not update the branch parameter.
 *
 * Return Value: RvStatus. If the application returns a value other then
 *               RV_OK the message will not be sent. The transaction will
 *               terminate with error and the register-client will move to the
 *               Failed state.
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:     hRegClient     - Handle to the register client.
 *            hAppRegClient  - The application handle for this register client.
 *            hTransc        - The transaction handle
 *            hMsgToSend     - The handle to the outgoing message.
 ***************************************************************************/
static RvStatus RVCALLCONV AppRegClientFinalDestResolvedEvHandler(
                      IN  RvSipRegClientHandle    hRegClient,
                      IN  RvSipAppRegClientHandle hAppRegClient,
                      IN  RvSipTranscHandle       hTransc,
                      IN  RvSipMsgHandle          hMsgToSend)
{
    RvBool      needToResolve = RV_TRUE;
    RvStatus    status = RV_OK;
    RvStun*     frame = NULL;

    /* Invoke the old implementation now, before we start STUNning this message */
    if (g_stunMgr->old_pfnRegClientFinalDestResolvedEvHandler != NULL)
    {
        status = g_stunMgr->old_pfnRegClientFinalDestResolvedEvHandler(
            hRegClient, hAppRegClient, hTransc, hMsgToSend);
    }

    /* In case of SIP response to REGISTER there is no need in STUN address resolution  */
    if (RvSipMsgGetMsgType(hMsgToSend) == RVSIP_MSG_RESPONSE)
        return status;

    /* Check if we need to work with STUN or not */
    if (status == RV_OK)
    {
        status = createMtfStunFrame(hTransc, &frame);
    }

    if ((status == RV_OK) && (frame != NULL))
    {
        frame->type = MtfStunFrameRegClient;
        frame->sipHandle = (void*)hRegClient;
        frame->sipAppHandle = (void*)hAppRegClient;

        status = sendMtfStunRequest(frame, hTransc, hMsgToSend, &needToResolve);
    }

    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "Error starting a STUN trasnaction"));
    }
    if (((status != RV_OK) || !needToResolve) && (frame != NULL))
    {
        RvStunDestruct(frame);
        rvMtfAllocatorDealloc(frame, sizeof(RvStun));
    }

    return status;
}


RVAPI RvIppStunMgrHandle RVCALLCONV RvIppStunMgrCreate(IN RvIppStunMgrParam* param)
{
    RvStunMgr*  p = NULL;

    RvLogEnter(ippLogSource,(ippLogSource, "RvIppStunMgrCreate(param=%p)", param));

	rvMtfAllocatorAlloc(sizeof(RvStunMgr), (void**)&p);
    if (p != NULL)
        RvStunMgrConstruct(p, param);

    RvLogLeave(ippLogSource,(ippLogSource, "RvIppStunMgrCreate()=%p", p));

    return (RvIppStunMgrHandle)p;
}


RVAPI void RVCALLCONV RvIppStunMgrDelete(IN RvIppStunMgrHandle stunMgrHndl)
{
    RvLogEnter(ippLogSource,(ippLogSource, "RvIppStunMgrDelete(stunMgr=%p)", stunMgrHndl));

    if (NULL != stunMgrHndl)
        RvStunMgrDestruct((RvStunMgr*)stunMgrHndl);
	rvMtfAllocatorDealloc((RvStunMgr*)stunMgrHndl, sizeof(RvStunMgr));

    RvLogLeave(ippLogSource,(ippLogSource, "RvIppStunMgrDelete()"));
}


RVAPI RvStatus RVCALLCONV RvIppStunAddressResolveComplete(
    IN RvIppStunAddrData*   addrData,
    IN RvBool               bStatusOK)
{
    RvStatus status;
    RvLogEnter(ippLogSource,(ippLogSource, "RvIppStunAddressResolveComplete(addr=%p,ok=%d)",
        addrData, bStatusOK));

    if (bStatusOK)
        addrData->status = RvIppStunAddrDataStatus_Response;
    else
        addrData->status = RvIppStunAddrDataStatus_Error;

    /*
     *  update database
     */
    status = RvStunMgrDbUpdateByResponse(&g_stunMgr->database, addrData);
    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "RvIppStunAddressResolveComplete(): can't update database"));
        return status;
    }

    /*
     *  check if all addresses are resolved for any frame
     */
    status = RvStunMgrDbProceedResolvedRequests(&g_stunMgr->database);
    if (status != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource, "RvIppStunAddressResolveComplete(): failed to proceed"));
    }

    RvLogLeave(ippLogSource,(ippLogSource, "RvIppStunAddressResolveComplete()=%d", status));

    return status;
}


/*-----------------------------------------------------------------------*/
/*                        RvStunMgrDb implementation                     */
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
static void RvStunMgrDbConstruct(
    IN RvStunMgrDb*             db,
    IN RvStunResolvedHandlerCB  resolvedHandler,
    IN RvStunErrorHandlerCB     errorHandler)
{
    db->resolvedHandler = resolvedHandler;
    db->errorHandler = errorHandler;

    rvListConstruct(RvIppStunAddrData)(&db->stunAddrDataList, prvDefaultAlloc);
    rvPtrListConstruct(&db->stunList, prvDefaultAlloc);
    RvMutexConstruct(IppLogMgr(), &db->mutex);
}


/*-----------------------------------------------------------------------*/
void    RvStunMgrDbDestruct( RvStunMgrDb* db)
{
    rvListDestruct(RvIppStunAddrData)( &db->stunAddrDataList);
    rvPtrListDestruct( &db->stunList);
    RvMutexDestruct ( &db->mutex,  IppLogMgr());
}
/*-----------------------------------------------------------------------*/
/*
 *  some of found addresses maybe already requested due to previous Stun requests
 * extract those addresses which are not requested yet
 */
void    mergeRvIppAddrDataList( INOUT RvStunAddrList* mergeTo,
                                 IN RvStunAddrList *mergeFrom)
{
    RvListIter(RvIppStunAddrData)   toIter, fromIter;
    RvIppStunAddrData               *toData, *fromData;

    for(fromIter =rvListBegin( mergeFrom); fromIter !=rvListEnd( mergeFrom); fromIter =rvListIterNext( fromIter))
    {
        fromData = (RvIppStunAddrData*)rvListIterData( fromIter);
        for(toIter =rvListBegin( mergeTo); toIter !=rvListEnd( mergeTo); toIter =rvListIterNext( toIter))
        {
            toData = (RvIppStunAddrData*)rvListIterData( toIter);
            if( RvIppStunAddrDataEqual(toData, fromData))
                break;
        }
        if(toIter ==rvListEnd( mergeTo))
        {
			/*we didn't find fromData. Add to mergeTo */
            rvListPushBack(RvIppStunAddrData) ( mergeTo, fromData);
        }
    }
}
/*-----------------------------------------------------------------------*/
RvStatus    RvStunMgrDbMergeRequest( INOUT RvStunMgrDb* db,
                                  IN RvStun*            frame)
{

    if(RV_OK != RvMutexLock ( &db->mutex, IppLogMgr()))
    {
        RvLogError(ippLogSource,(ippLogSource, "RvMutexLock(): failed.  mutex =%p ", &db->mutex));
        return RV_ERROR_UNKNOWN;
    }

    mergeRvIppAddrDataList(&db->stunAddrDataList, &frame->stunAddrList);

    rvPtrListPushBack(&db->stunList, frame);

    if(RV_OK != RvMutexUnlock ( &db->mutex, IppLogMgr()))
    {
        RvLogError(ippLogSource,(ippLogSource, "RvMutexUnlock(): failed.  mutex =%p ", &db->mutex));
        return RV_ERROR_UNKNOWN;
    }

    return RV_OK;
}
/*-----------------------------------------------------------------------*/
static void responseUpdate( INOUT RvStunAddrList* toList, IN RvIppStunAddrData* stunAddr)
{
    RvListIter(RvIppStunAddrData)   toIter;
    RvIppStunAddrData               *toData;

    for(toIter =rvListBegin( toList); toIter !=rvListEnd( toList); toIter =rvListIterNext( toIter))
    {
        toData = (RvIppStunAddrData*)rvListIterData( toIter);
        if( RvIppStunAddrDataEqual(toData, stunAddr))
        {
            if( stunAddr->status == RvIppStunAddrDataStatus_Error)
            {
                toData->status = RvIppStunAddrDataStatus_Error;
                RvLogInfo(ippLogSource,(ippLogSource, "responseUpdate(): addr map error. in port =%d",
                                                stunAddr->inAddr.data.ipv4.port));
            }else
            {
                RvAddressCopy(&stunAddr->outAddr, &toData->outAddr);
                switch (toData->status)
                {
                case RvIppStunAddrDataStatus_Request:
                    RvLogInfo(ippLogSource,(ippLogSource, "responseUpdate(): addr map. in port =%d, out port =%d",
                                            stunAddr->inAddr.data.ipv4.port, stunAddr->outAddr.data.ipv4.port));
                    toData->status = RvIppStunAddrDataStatus_Response;
                    break;
                case RvIppStunAddrDataStatus_Response:
                    RvLogInfo(ippLogSource,(ippLogSource, "responseUpdate(): addr map overrided. in port =%d, out port =%d",
                                            stunAddr->inAddr.data.ipv4.port, stunAddr->outAddr.data.ipv4.port));
                    break;
                case RvIppStunAddrDataStatus_Error:
                    RvLogInfo(ippLogSource,(ippLogSource, "responseUpdate(): addr(previous err) map. in port =%d, out port =%d",
                                            stunAddr->inAddr.data.ipv4.port, stunAddr->outAddr.data.ipv4.port));
                    toData->status = RvIppStunAddrDataStatus_Response;
                    break;
                }
            }
        }
    }
}
/*-----------------------------------------------------------------------*/
RvStatus    RvStunMgrDbUpdateByResponse( INOUT RvStunMgrDb* db,
                                     IN RvIppStunAddrData* stunAddr)
{
    RvStun*         frame;
    RvPtrListIter   toStunIter;
    RvPtrList       *toStunList = &db->stunList;

    if(RV_OK != RvMutexLock ( &db->mutex, IppLogMgr()))
    {
        RvLogError(ippLogSource,(ippLogSource, "RvMutexLock(): failed.  mutex =%p ", &db->mutex));
        return RV_ERROR_UNKNOWN;
    }

    /*
     *  update db->stunAddrDataList. remove resolved element
     */
    rvListRemove(RvIppStunAddrData)( &db->stunAddrDataList, stunAddr);

    /*
     *  update db->stunList
     */
    for(toStunIter =rvListBegin( toStunList); toStunIter !=rvListEnd( toStunList); toStunIter =rvListIterNext( toStunIter))
    {
        frame = (RvStun*)RvPtrListIterData( toStunIter);
        responseUpdate( &frame->stunAddrList, stunAddr);
    }

    if(RV_OK != RvMutexUnlock ( &db->mutex, IppLogMgr()))
    {
        RvLogError(ippLogSource,(ippLogSource, "RvMutexUnlock(): failed.  mutex =%p ", &db->mutex));
        return RV_ERROR_UNKNOWN;
    }

    return RV_OK;
}

/*-----------------------------------------------------------------------/
* not thread safe. tmp
*-----------------------------------------------------------------------*/
RvBool      RvStunMgrDbIsExistFrame( RvStunMgrDb* db, RvStun* frame)
{
    RvPtrListIter  i, e;
    RvPtrList       *list = &db->stunList;


    /*
     *  find appropriate frame from db->stunList
     */
    i =rvListBegin( list);
    e =rvListEnd( list);
    while( i != e)
    {
        if(frame == (RvStun*)RvPtrListIterData( i))
            return RV_TRUE;
        else
            i =rvListIterNext( i);
    }

    return RV_FALSE;
}
/*-----------------------------------------------------------------------*/
RvStatus    RvStunMgrDbRemoveFrame( INOUT RvStunMgrDb* db, RvStun* frame)
{
    RvPtrList       *list = &db->stunList;

    if(RV_OK != RvMutexLock ( &db->mutex, IppLogMgr()))
    {
        RvLogError(ippLogSource,(ippLogSource, "RvMutexLock(): failed.  mutex =%p ", &db->mutex));
        return RV_ERROR_UNKNOWN;
    }

    /*
     *  erase appropriate frame from db->stunList
     */
    rvPtrListRemove( list, frame);

    if(RV_OK != RvMutexUnlock ( &db->mutex, IppLogMgr()))
    {
        RvLogError(ippLogSource,(ippLogSource, "RvMutexUnlock(): failed.  mutex =%p ", &db->mutex));
        return RV_ERROR_UNKNOWN;
    }

    return RV_OK;
}
/*-----------------------------------------------------------------------*/
/*
 *  hObject - key to search in DB. Maybe frame->hTransc, frame->hTransc, frame->hRegClient, frame->hTransc, &frame->timeToLiveTimer
 */
RvStatus    RvStunMgrDbDeleteFrameByKey( INOUT RvStunMgrDb* db, void* hObject)
{
    RvStun*         frame;
    RvPtrListIter   i, e;
    RvPtrList       *list = &db->stunList;

    if(RV_OK != RvMutexLock ( &db->mutex, IppLogMgr()))
    {
        RvLogError(ippLogSource,(ippLogSource, "RvMutexLock(): failed.  mutex =%p ", &db->mutex));
        return RV_ERROR_UNKNOWN;
    }

    /*
     *  erase appropriate frame from db->stunList
     */
    i =rvListBegin( list);
    e =rvListEnd( list);
    while( i != e)
    {
        RvBool  bFound;
        frame = (RvStun*)RvPtrListIterData( i);
        bFound =(hObject == &frame->timeToLiveTimer)||
                (hObject == (void*)frame->hTransc)||
                ((hObject == frame->sipAppHandle) && (frame->type == MtfStunFrameCallLeg)) ||
                ((hObject == frame->sipHandle) && (frame->type == MtfStunFrameRegClient));

        if(bFound)
        {
            i =rvPtrListErase( list, i);
            RvStunDestruct (frame);
            rvMtfAllocatorDealloc(frame, sizeof(RvStun));
        }
        else
            i =rvListIterNext( i);
    }

    if(RV_OK != RvMutexUnlock ( &db->mutex, IppLogMgr()))
    {
        RvLogError(ippLogSource,(ippLogSource, "RvMutexUnlock(): failed.  mutex =%p ", &db->mutex));
        return RV_ERROR_UNKNOWN;
    }

    return RV_OK;
}
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
static void proceedResolvedRequests(
    IN RvPtrList*               fromList,
    IN RvStunResolvedHandlerCB  resolvedHandler,
    IN RvStunErrorHandlerCB     errorHandler)
{
    RvStun*             frame;
    RvPtrListIter       i, e;
    RvListIter(RvIppStunAddrData)   j;
    RvIppStunAddrData               *data;
    RvList(RvIppStunAddrData)       *dataList;
    RvIppStunAddrDataStatus         status = RvIppStunAddrDataStatus_Request;/*initialization is done to avoid compiler waning and never used*/

    i = rvListBegin(fromList);
    e = rvListEnd(fromList);
    while (i != e)
    {
        frame = (RvStun*)RvPtrListIterData(i);
        dataList = &frame->stunAddrList;
        if (rvListEmpty(dataList))
        {
            RvLogError(ippLogSource,(ippLogSource, "extractResolvedRequest(): empty list."));
            continue;
        }

        for (j = rvListBegin(dataList); j != rvListEnd(dataList); j = rvListIterNext(j))
        {
            data = (RvIppStunAddrData*)rvListIterData(j);
            if (j == rvListBegin(dataList))
            {
                /*first time*/
                status = data->status;
            }

            if (data->status != RvIppStunAddrDataStatus_Response)
            {
                /* not yet resolved or error frame */
                status = data->status;
                break;
            }
            else
                continue;
        }

        switch (status)
        {
        case RvIppStunAddrDataStatus_Response:
            resolvedHandler(frame);
            break;
        case RvIppStunAddrDataStatus_Error:
            errorHandler(frame);
            break;
        default:
            i = rvListIterNext(i);
            continue; /* We shouldn't be killing this frame */
        }

        /*remove processed frame*/
        i = rvPtrListErase(fromList, i);
        RvStunDestruct(frame);
        rvMtfAllocatorDealloc(frame, sizeof(RvStun));
    }
}
/*-----------------------------------------------------------------------*/
static RvStatus RvStunMgrDbProceedResolvedRequests(INOUT RvStunMgrDb* db)
{
    if (RV_OK != RvMutexLock ( &db->mutex, IppLogMgr()))
    {
        RvLogError(ippLogSource,(ippLogSource, "RvMutexLock(): failed.  mutex =%p ", &db->mutex));
        return RV_ERROR_UNKNOWN;
    }

    proceedResolvedRequests(&db->stunList, db->resolvedHandler, db->errorHandler);

    if (RV_OK != RvMutexUnlock ( &db->mutex, IppLogMgr()))
    {
        RvLogError(ippLogSource,(ippLogSource, "RvMutexUnlock(): failed.  mutex =%p ", &db->mutex));
        return RV_ERROR_UNKNOWN;
    }

    return RV_OK;
}


/*===================================================================================*/
static RvSipMsgHandle createMessage(
                             RvSipMsgMgrHandle  hMgr,
                             const char*        addrString,
                             RvUint16           addrPort
                             )
{
    RvSipMsgHandle      hMsg =NULL;
    RvStatus            rv;
    char                *ptr;
    char                szUri[ sizeof "sip:stun@" +STUN_IP_STR_LEN + 2];
    char                szTempl[512]=
/*don't remove a big blank place after INVITE $  */
"\
INVITE $                                                       SIP/2.0\n\
Via: SIP/2.0/UDP pc33.atlanta.com;branch=z9hG4bK776asdhds\n\
Max-Forwards: 70\n\
To: Bob <sip:bob@biloxi.com>\n\
From: Alice <sip:alice@atlanta.com>;tag=1928301774\n\
Call-ID: a84b4c76e66710@pc33.atlanta.com\n\
CSeq: 314159 INVITE\n\
Contact: <sip:alice@pc33.atlanta.com>\n\
Content-Length: 0\n\n";


    /*Constructs a new message object.*/
    rv = RvSipMsgConstruct(hMgr, g_appPool, &hMsg);
    if(rv!= RV_OK)
        return NULL;
    /*
     *  build szUri from addrStunServer
     */
    sprintf( szUri, "sip:stun@%s:%d",  addrString, addrPort);

    ptr= strchr( szTempl, '$');
    memcpy( ptr, szUri, strlen(szUri));

    RvSipMsgParse( hMsg,szTempl, (RvUint32)strlen(szTempl));

    return hMsg;
}



/* Send message over SIP stack socket. Here for backwards compatibility. */
static RvStatus RvStunMgrSendRawMsg(
    IN void*            mgr,
    IN const RvChar*    addrString,
    IN RvUint16         addrPort,
    IN RvUint8*         buf,
    IN RvSize_t         size)
{
    RvStunMgr*              stunMgr = (RvStunMgr *)mgr;
    RvStunMsgData*          data = NULL;
    RvSipMsgHandle          hMsgToSend = NULL;
    RvSipMsgMgrHandle       hMsgMgr;
    RvSipControl*           sipMgr = rvCCSipPhoneGetSipMgr();
    RvSipStackHandle        hStack = rvSipControlGetStackHandle(sipMgr);

    RvLogInfo(ippLogSource,(ippLogSource, "RvStunMgrSendRawMsg() enter: port= %d ", addrPort));

    /*
     *  build message
     */
    RvSipStackGetMsgMgrHandle(hStack, &hMsgMgr);
    hMsgToSend = createMessage(hMsgMgr, addrString, addrPort);
    if (hMsgToSend == NULL)
        goto err_exit;

    /*
     *  create object that would send raw messages over SIP signaling socket
     */
    rvMtfAllocatorAlloc(sizeof(RvStunMsgData), (void**)&data);
    if (data == NULL)
        goto err_exit;
    RvStunMsgDataConstruct(data, hStack, buf, size);

    /*
     *  insert data to temporary list
     */
    RvMutexLock(&g_stunMgr->stunMsgDataMutex, IppLogMgr());
    rvPtrListPushBack(&stunMgr->stunMsgDataList, data);
    RvMutexUnlock(&g_stunMgr->stunMsgDataMutex, IppLogMgr());

    /*
     *  send stun msg
     */
    if (RV_OK != RvStunMsgDataSend(data, hMsgToSend))
        goto err_exit;

    RvSipMsgDestruct(hMsgToSend);
    RvLogInfo(ippLogSource,(ippLogSource, "RvStunMgrSendRawMsg() success: port= %d ", addrPort));
    return RV_OK;

err_exit:
    if (hMsgToSend != NULL)
        RvSipMsgDestruct(hMsgToSend);
    RvLogError(ippLogSource,(ippLogSource, "RvStunMgrSendRawMsg() failed: port= %d ", addrPort));
    return RV_ERROR_UNKNOWN;
}


/* Returns the sending method. Used for backwards compatibility */
RVAPI void RVCALLCONV RvIppStunMgrGetSendMethod(
    IN  RvIppStunMgrHandle  stunMgrHndl,
    OUT SendMethod**        method)
{
    RvStunMgr* stunMgr = (RvStunMgr*)stunMgrHndl;

    RvLogEnter(ippLogSource,(ippLogSource, "RvIppStunMgrGetSendMethod(mgr=%p,method=%p)",
        stunMgrHndl, method));

    *method = &stunMgr->sendMethod;

    RvLogLeave(ippLogSource,(ippLogSource, "RvIppStunMgrGetSendMethod()"));
}



/*-----------------------------------------------------------------------*/
/*                        RvStunMsgData* implementation              */
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
void    RvStunMsgDataConstruct( RvStunMsgData* data,
                               RvSipStackHandle hStack,
                               IN RvUint8* buf,
                               IN RvSize_t size)
{
    createTransmitter( hStack, &data->hTrx);
    memcpy(data->buf, buf, size);
    data->size= size;
}
/*-----------------------------------------------------------------------*/
void    RvStunMsgDataDestruct( RvStunMsgData* data)
{
    destroyTransmitter ( data->hTrx);
}
/*-----------------------------------------------------------------------*/
RvStatus    RvStunMsgDataSend(  RvStunMsgData* data, RvSipMsgHandle hMsgToSend)
{
    RvStatus rv = RvSipTransmitterSendMessage(
                                data->hTrx,
                                hMsgToSend,
                                RV_FALSE/*bHandleTopVia*/);
    return rv;
}
/*-----------------------------------------------------------------------*/


/*-----------------------------------------------------------------------*/
/*                        RvStunMsgData List implementation              */
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
RvStunMsgData*  RvStunMsgDataListFind( RvPtrList* l, RvSipTransmitterHandle hTrx)

{
    RvPtrListIter   i,e;
    RvStunMsgData*  data;

    i = rvListBegin( l);
    e = rvListEnd( l);
    while( i != e)
    {
        data = (RvStunMsgData*)RvPtrListIterData(i);
        if( hTrx == data->hTrx)
            return data;
        else
            i = RvPtrListIterNext( i);
    }

    return NULL;
}
/*-----------------------------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
