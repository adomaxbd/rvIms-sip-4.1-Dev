/******************************************************************************
Filename   : rvAkaAuth.c
Description: Implements Aka authentication
******************************************************************************
                Copyright (c) 2001 RADVISION
************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION.

RADVISION reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************
$Revision:$
$Date:   23.9.07$
$Author: Tamar Aharony$
******************************************************************************/
#include "rvtypes.h"

#ifdef RV_SIP_IMS_ON

#define LOGSRC	LOGSRC_IMS

#include "ipp_inc_std.h"
#include "rvAkaAuth.h"
#include "AKA_Auc.h"
#include "RvSipMsgTypes.h"
#include "RvSipAuthorizationHeader.h"
#include "RvSipAuthenticationHeader.h"
#include "RvSipMid.h"

#include "rvccprovidersip.h"
#include "rvccconnsip.h"
#include "mtfImsSecAgree.h"
#include "mtfImsReg.h"

extern RvSipControl* g_sipControl;

static RvStatus AppClientGetAkaRESorAUTS(IN  RvSipAuthObjHandle hAuthObj,
                                         OUT RvUint8           *pRES,
                                         OUT RvUint8          **ppAUTS,
										 IN  RvCCTerminalSip   *sipTerm);

/***************************************************************************************
* buildEmptyAuthorization
* -------------------------------------------------------------------------------------
* General:  This function fills an authorization header with the user name and realm
*           parameters.
* Return Value: -
* -------------------------------------------------------------------------------------
* Arguments:
* Input:  pAppObj - application object that sends the initial request.
*         hAuthorization- Handle to the header to fill.
*		  hUri - Handle to sip address object.
* Output:   none
**************************************************************************************/
static RvStatus buildEmptyAuthorization( INOUT	RvSipAuthorizationHeaderHandle hAuthorization,
										 IN		RvCCTerminalSip*  sipTerm,
										 IN		RvSipAddressHandle  hUri)
{
    RvStatus rv = RV_OK;
	RvChar userName[RV_NAME_STR_SZ];
	RvChar realm[RV_NAME_STR_SZ];

	sprintf(userName,"\"%s\"",rvCCTerminalSipGetUsername(sipTerm));
	sprintf(realm,"\"%s\"", g_sipControl->userDomain);

    /* set an empty authorization header */
    rv = RvSipAuthorizationHeaderSetAuthScheme(hAuthorization, RVSIP_AUTH_SCHEME_DIGEST, NULL);
    if(rv == RV_OK)
        rv = RvSipAuthorizationHeaderSetHeaderType(hAuthorization, RVSIP_AUTH_AUTHORIZATION_HEADER);
    if(rv == RV_OK)
        rv = RvSipAuthorizationHeaderSetAuthAlgorithm(hAuthorization, RVSIP_AUTH_ALGORITHM_UNDEFINED, NULL);
    if(rv == RV_OK)
        rv = RvSipAuthorizationHeaderSetUserName(hAuthorization, userName);
    if(rv == RV_OK)
		rv = RvSipAuthorizationHeaderSetRealm(hAuthorization, realm);
    if(rv == RV_OK)
		rv = RvSipAuthorizationHeaderSetDigestUri(hAuthorization, hUri);

    return rv;
}
/***************************************************************************************
* rvAkaAuthIsAkaAlgorithmInAuthHeader
* -------------------------------------------------------------------------------------
* General:  Checks if the  algorithm in the authentication header is AKA
*
* Return Value: -
* -------------------------------------------------------------------------------------
* Arguments:
* Input:    authHeader - handle to the SIP Authorization header
* Output:   none
**************************************************************************************/
RvBool rvAkaAuthIsAkaAlgorithmInAuthHeader(RvSipAuthenticationHeaderHandle hAuthHeader)
{
	RvSipAuthAlgorithm  authAlgorithm = RVSIP_AUTH_ALGORITHM_MD5;

	authAlgorithm  = RvSipAuthenticationHeaderGetAuthAlgorithm(hAuthHeader);
	if (authAlgorithm == RVSIP_AUTH_ALGORITHM_MD5)
	{
		if(RvSipAuthenticationHeaderGetAKAVersion(hAuthHeader) != UNDEFINED)
		{
			return rvTrue;;
		}
	}
	return rvFalse;
}

/***************************************************************************************
* rvAkaAuthRegClientBuildInitialId
* -------------------------------------------------------------------------------------
* General:  Build a RegClient authorization header with initial identification to start the
*           process of AKA authorization.
* Return Value: -
* -------------------------------------------------------------------------------------
* Arguments:
* Input:    hRegClient - handle to the SIP Reg Client object
* Output:   none
**************************************************************************************/
RvStatus rvAkaAuthRegClientBuildInitialId(RvSipRegClientHandle* hRegClient, RvCCTerminalSip* sipTerm)
{
	RvSipAuthorizationHeaderHandle hAuthorization;
	RvStatus   rv;
	RvSipAddressHandle hUri;

	rv = RvSipRegClientGetNewMsgElementHandle(*hRegClient, RVSIP_HEADERTYPE_AUTHORIZATION,
		RVSIP_ADDRTYPE_UNDEFINED, (void**)&hAuthorization);

    if (RV_OK != rv)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvAkaAuthRegClientBuildInitialId(): failed to get msg handle"));
        return rv;
    }
	rv = RvSipRegClientGetRegistrar(*hRegClient, &hUri);
    if (RV_OK != rv)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvAkaAuthRegClientBuildInitialId(): failed to set uri value for hRegClient 0x%p, rv=%d", hRegClient, rv));
    }
    rv = buildEmptyAuthorization(hAuthorization, sipTerm, hUri);
    if (RV_OK != rv)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvAkaAuthRegClientBuildInitialId(): buildEmptyAuthorization failed"));
        return rv;
    }
    rv = RvSipRegClientSetInitialAuthorization(*hRegClient, hAuthorization);
    if (RV_OK != rv)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvAkaAuthRegClientBuildInitialId(): failed to set initial authorization"));
        return rv;
    }

	RvLogInfo(ippLogSource,(ippLogSource,"rvAkaAuthRegClientBuildInitialId(): sending initial authorization request "));

	return RV_OK;
}

/***************************************************************************************
* rvAkaAuthCallLegBuildInitialId
* -------------------------------------------------------------------------------------
* General:  Build a CallLeg authorization header with initial identification to start the
*           process of AKA authorization.
* Return Value: -
* -------------------------------------------------------------------------------------
* Arguments:
* Input:    hCallLeg - handle to the SIP callLeg object
* Output:   none
**************************************************************************************/
RvStatus rvAkaAuthCallLegBuildInitialId(RvSipCallLegHandle    hCallLeg, RvSipMsgHandle hMsg, RvCCTerminalSip*  sipTerm)
{
	RvSipAuthorizationHeaderHandle hAuthorization;
	RvStatus   rv;
	RvSipAddressHandle hUri;

	RvSipAuthorizationHeaderConstructInMsg(hMsg, RV_FALSE, &hAuthorization);

	rv = RvSipCallLegGetRemoteContactAddress(hCallLeg, &hUri);
    if (RV_OK != rv)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvAkaAuthCallLegBuildInitialId(): failed to set uri value for CallLeg 0x%p, rv=%d", hCallLeg, rv));
    }
	rv = buildEmptyAuthorization(hAuthorization, sipTerm, hUri);
    if (RV_OK != rv)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvAkaAuthCallLegBuildInitialId(): buildEmptyAuthorization failed for CallLeg 0x%p, rv=%d", hCallLeg, rv));
        return rv;
    }

	RvLogInfo(ippLogSource,(ippLogSource,"rvAkaAuthCallLegBuildInitialId(): sending initial authorization request for CallLeg 0x%p", hCallLeg));

	return RV_OK;
}

/***************************************************************************
 * rvAkaAuthHandleCallLegUnauthState
 * ------------------------------------------------------------------------
 * General: Handles the UNAUTHENTICATED state.
 *          1) Before resending the request, we remove the old authorization header,
 *          if exists. (Otherwise the request will have 2 Authorization headers,
 *          one with AUTS parameter, and one without).
 *          2) Resend the INVITE request with RvSipCallLegAuthenticate().
 ***************************************************************************/
RvStatus rvAkaAuthHandleCallLegUnauthState(RvSipCallLegHandle hCallLeg, RvCCTerminalSip* sipTerm)
{
    RvStatus rv = RV_OK;
    RvSipAuthObjHandle hAuthobj;


    /* Get the auth-obj from the call-leg */
    rv = RvSipCallLegAuthObjGet(hCallLeg, RVSIP_FIRST_ELEMENT, NULL, &hAuthobj) ;
    if(rv != RV_OK || hAuthobj == NULL)
    {
        /* ERROR: we reached state unauthenticated, but there is no authentication header
           in the call-leg */
        RvLogError(ippLogSource,(ippLogSource,"rvAkaAuthHandleCallLegUnauthState(): no auth-obj in call-leg\n"));
		return rv;
    }

    while (rv == RV_OK && hAuthobj != NULL)
    {
        /* Set the AUTS parameter or the shared secret in the authentication object */
    rv = AppSetSharedSecretInAuthObj(hAuthobj, sipTerm);
        if(rv != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"rvAkaAuthHandleCallLegUnauthState(): failed to set shared secret before sending request.\n"));
			return rv;
        }
        /* Get the next auth-obj from the call-leg */
        RvSipCallLegAuthObjGet(hCallLeg, RVSIP_NEXT_ELEMENT, hAuthobj, &hAuthobj) ;
    }

	return rv;
}

/***************************************************************************
 * rvAkaAuthHandleRegClientUnauthState
 * ------------------------------------------------------------------------
 * General: Handles the UNAUTHENTICATED state.
 *          1) Before resending the request, we remove the old authorization header,
 *          if exists. (Otherwise the request will have 2 Authorization headers,
 *          one with AUTS parameter, and one without).
 *          2) Choose the security mechanism for the terminal.
 *          3) Resend the REGISTER request with RvSipRegClientAuthenticate().
 ***************************************************************************/
RvStatus rvAkaAuthHandleRegClientUnauthState(RvSipRegClientHandle hRegClient, RvCCTerminalSip* sipTerm)
{
    RvStatus rv = RV_OK;
    RvSipAuthObjHandle hAuthobj;


    /* Get the auth-obj from the call-leg */
    rv = RvSipRegClientAuthObjGet(hRegClient, RVSIP_FIRST_ELEMENT, NULL, &hAuthobj) ;
    if(rv != RV_OK || hAuthobj == NULL)
    {
        /* ERROR: we reached state unauthenticated, but there is no authentication header
           in the call-leg */
    RvLogError(ippLogSource,(ippLogSource,"rvAkaAuthHandleRegClientUnauthState(): no auth-obj in Reg Client 0x%p", hRegClient));
		return rv;
    }

    while (rv == RV_OK && hAuthobj != NULL)
    {
        /* Set the AUTS parameter or the shared secret in the authentication object */
		rv = AppSetSharedSecretInAuthObj(hAuthobj, sipTerm);
        if(rv != RV_OK)
        {
        RvLogError(ippLogSource,(ippLogSource,"rvAkaAuthHandleRegClientUnauthState(): failed to set shared secret before sending request."));
			return rv;
        }
        /* Get the next auth-obj from the call-leg */
        RvSipRegClientAuthObjGet(hRegClient, RVSIP_NEXT_ELEMENT, hAuthobj, &hAuthobj) ;
    }

	if (sipTerm->imsTerminalSip.SecAgreeInitiated == RV_TRUE)
	{
		/* now that we have AKA values, security mechanism can be chosen */
		if (rvSecAgreeChooseSecurity(sipTerm) == RV_TRUE)
		{
			RvSipSecurityMechanismType chosenSecurity = sipTerm->imsTerminalSip.chosenSecurity;

			rvCallSecAgreeUserCallback(sipTerm, RV_TRUE, RV_MTF_SEC_AGREE_SUCCESS, chosenSecurity);
			/* security mechanism chosen, now determine which one */
#ifdef RV_CFLAG_TLS
			if (chosenSecurity == RVSIP_SECURITY_MECHANISM_TYPE_TLS)
			{
				/* initiate TLS security from second REGISTER onwards */
				mtfImsRegSetRegClientOutboundPort(hRegClient, sipTerm->outboundProxyAddress, 
					sipTerm->registrarTlsPort);
			}
			else
#endif
			if ((chosenSecurity == RVSIP_SECURITY_MECHANISM_TYPE_IPSEC_IKE) ||
				(chosenSecurity == RVSIP_SECURITY_MECHANISM_TYPE_IPSEC_MAN) ||
				(chosenSecurity == RVSIP_SECURITY_MECHANISM_TYPE_IPSEC_3GPP))
			{
				/* set PORT-S value of reg client */
				mtfImsRegSetRegClientPortS(hRegClient,sipTerm->imsTerminalSip.ipsecPortS);
			}
		}
		else
		{
			rvCallSecAgreeUserCallback(sipTerm, rvFalse, RV_MTF_SEC_AGREE_CHOOSE_FAILED, RVSIP_SECURITY_MECHANISM_TYPE_UNDEFINED);
		}
	}

    /* Resend the request */
    rv = RvSipRegClientAuthenticate(hRegClient);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"rvAkaAuthHandleRegClientUnauthState():authenticating failed for call-leg"));
    }

	RvLogInfo(ippLogSource,(ippLogSource,"rvAkaAuthHandleRegClientUnauthState:: New registration was sent for Reg Client 0x%p.",hRegClient));
	return rv;
}

/***************************************************************************
 * AppClientHandleGetSharedSecretEv
 * ------------------------------------------------------------------------
 * General:  Client authentication - when the stack builds the Authorization
 *           header, using the received WWW-Authenticate header,
 *           the client should supply the user-name and password.
 * Return Value: (-)
 * ------------------------------------------------------------------------
 * Arguments:
 * Input:   hAuthObj          - Handle to the currently processed auth-obj.
 *          hAuthenticator    - Handle to the authenticator object.
 *          hAppAuthenticator - Handle to the application authenticator handle.
 *          hObject           - handle to the Object, that is served
 *                              by the Authenticator (e.g. CallLeg, RegClient)
 *          peObjectType      - pointer to the variable, that stores type of
 *                              the Object. Use following code to get the type:
 *                              RvSipCommonStackObjectType eObjType = *peObjectType;
 *          pRpoolRealm       - the realm string in RPool_ptr format
 * Output:  pRpoolUserName    - the user-name string in RPool_ptr format
 *          pRpoolPassword    - the password string in RPool_ptr format
 ***************************************************************************/
void RVCALLCONV AppClientHandleGetSharedSecretEv(
                                   IN  RvSipAuthObjHandle             hAuthObj,
                                   IN  RvSipAuthenticatorHandle       hAuthenticator,
                                   IN  RvSipAppAuthenticatorHandle    hAppAuthenticator,
                                   IN  void*                          hObject,
                                   IN  void*                          peObjectType,
                                   IN  RPOOL_Ptr                     *pRpoolRealm,
                                   OUT RPOOL_Ptr                     *pRpoolUserName,
                                   OUT RPOOL_Ptr                     *pRpoolPassword)
{
    RvStatus rv;
    RvUint8  RES[AKA_RES_LEN+1]; /* one more place for NULL termination */
    RvUint8  *pAUTS = NULL;
	RvChar   userName[RV_NAME_STR_SZ];
	RvSipCommonStackObjectType *eObjType =  peObjectType; 
	RvCCTerminal*     xTerm    = NULL;
	RvCCTerminalSip*  sipTerm  = NULL;
		
	/* We should get here with either reg client or callLeg. In any other case an error log is generated */
	if (*eObjType == RVSIP_COMMON_STACK_OBJECT_TYPE_REG_CLIENT)
	{
		RvSipAppRegClientHandle         hAppRegClient;
		
		/* Get the terminal from the hAppRegClient */
		RvSipRegClientGetAppHandle ((RvSipRegClientHandle)hObject, &hAppRegClient);
		xTerm   = (RvCCTerminal*)hAppRegClient;		
	}
	else
	if (*eObjType == RVSIP_COMMON_STACK_OBJECT_TYPE_CALL_LEG)
	{
		RvSipAppCallLegHandle         hAppCallLeg;
		/* Get the terminal from the sip connection which is stored in the hAppCallLeg */
		RvSipCallLegGetAppHandle ((RvSipCallLegHandle)hObject, &hAppCallLeg);
		xTerm   = rvCCConnSipGetTerminal((RvCCConnection*)hAppCallLeg);		
	}
	else
	{
		RvLogError(ippLogSource,(ippLogSource,"AppClientHandleGetSharedSecretEv: unexpected auth object type %d for object 0x%p",eObjType,hObject  ))
		return;
	}
		
	sipTerm = rvCCTerminalSipGetImpl(xTerm);

    memset(RES, 0, sizeof(RES));

    rv = AppClientGetAkaRESorAUTS(hAuthObj, RES, &pAUTS, sipTerm);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"\nClient - failed to create RES or AUTS in shared-secret callback\n"));
		return;
    }

	sprintf(userName,"\"%s\"",rvCCTerminalSipGetUsername(sipTerm));

    /*copy the username + '\0' to the given page*/
    RPOOL_AppendFromExternalToPage(pRpoolUserName->hPool,
                                   pRpoolUserName->hPage,
                                   (void*)userName,
                                   strlen(userName) + 1,
                                   &(pRpoolUserName->offset));

    /*copy the RES + '\0' to the given page (may be "") */
    RPOOL_AppendFromExternalToPage(pRpoolPassword->hPool,
                                   pRpoolPassword->hPage,
                                   (void*)RES,
                                   strlen((RvChar*)RES) + 1,
                                   &(pRpoolPassword->offset));

    if(pAUTS != NULL)
    {
        /* Set AUTS parameter in the Authentication object */
        rv = RvSipAuthObjSetAutsParam(hAuthObj, (RvChar*)pAUTS);
        if(rv != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"AppClientHandleGetSharedSecretEv():: failed to set AUTS in shared-secret callback"));
        }
    }

    RV_UNUSED_ARG(hAppAuthenticator);
    RV_UNUSED_ARG(hAuthenticator);
    RV_UNUSED_ARG(hObject);
    RV_UNUSED_ARG(peObjectType);
    RV_UNUSED_ARG(pRpoolRealm);
}


/***************************************************************************************
* AppSetSharedSecretInAuthObj
* -------------------------------------------------------------------------------------
* General:  This function sets the shared secret in the authentication object,
*           1. Generates the Aka RES value.
*           2. Sets the user-name and the RES value in the auth-obj.
* Return Value: RvStatus.
* -------------------------------------------------------------------------------------
* Arguments:
* Input:    hAuthObj - Handle to the authentication object.
* Output:   none
**************************************************************************************/
RvStatus AppSetSharedSecretInAuthObj( IN RvSipAuthObjHandle hAuthObj, RvCCTerminalSip* sipTerm)
{
    RvStatus rv;
    RvUint8  RES[AKA_RES_LEN];
    RvUint8  *pAUTS = NULL;
	RvChar   userName[RV_NAME_STR_SZ];

    /* Make authentication decisions - set an AUTS parameter, and empty password "",
       or treat the SQN as synchronized, and supply the correct RES as password. */
    rv = AppClientGetAkaRESorAUTS(hAuthObj, RES, &pAUTS, sipTerm);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"AppSetSharedSecretInAuthObj:: Failed to get RES or AUTS value\n"));
        return RV_ERROR_NOT_FOUND;
    }

	sprintf(userName,"%s",rvCCTerminalSipGetUsername(sipTerm));

    /* Set the shared secret in the auth-obj */
    rv = RvSipAuthObjSetUserInfo(hAuthObj, userName, (RvChar*)RES);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"AppSetSharedSecretInAuthObj:: Failed to set shared-secret in authObj"));
        return RV_ERROR_NOT_FOUND;
    }

    if(pAUTS != NULL)
    {
        /* Set the AUTS parameter in the auth-obj */
        rv = RvSipAuthObjSetAutsParam(hAuthObj, (RvChar*)pAUTS);
        if(rv != RV_OK)
        {
            RvLogError(ippLogSource,(ippLogSource,"AppSetSharedSecretInAuthObj:: Failed to set AUTS in authObj"));
            return rv;
        }
    }

	RvLogInfo(ippLogSource,(ippLogSource,"AppSetSharedSecretInAuthObj:: Shared secret was set succesfully for user %s in authObj 0x%p",
		                     userName, hAuthObj));
    return RV_OK;
}


/***************************************************************************
* GetRandAndAutnFromHeader
* ------------------------------------------------------------------------
* General:  Gets the nonce value from authentication header.
*           Decode it base 64, and break it into AUTN and RAND strings.
* Return Value: RV_OK - if successful. error code o/w
* ------------------------------------------------------------------------
* Arguments:
* input   : hAuthHeader - The Authentication header.
* output  : pRAND - pointer to the RAND buffer.
*           pAUTN - pointer to the AUTN buffer.
***************************************************************************/
static RvStatus GetRandAndAutnFromHeader(IN  RvSipAuthenticationHeaderHandle hAuthHeader,
                                                  OUT RvUint8 *pRAND,
                                                  OUT RvUint8 *pAUTN)
{
    RvUint8 nonce[150];
    RvInt   len;
    RvStatus rv;
    RvUint8 nonceDecodeB64[AKA_RAND_LEN+AKA_AUTN_LEN];

    rv = RvSipAuthenticationHeaderGetNonce(hAuthHeader, (RvChar*)nonce, 150, (RvUint*)&len);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource," client - no nonce in AppClientGetRandAndAutnFromHeader"));
        return RV_ERROR_NOT_FOUND;
    }

    /* Give the decode function, the nonce string without the quotation marks:
	giving nonce+1 -> skip the first mark.
	giving len-2   -> don't reach the second mark. */
    len = RvSipMidDecodeB64(nonce+1, len-2, nonceDecodeB64, AKA_RAND_LEN+AKA_AUTN_LEN);

    /* Break the nonce string to RAND and AUTN */
    memcpy(pRAND, nonceDecodeB64, AKA_RAND_LEN);
    memcpy(pAUTN, nonceDecodeB64 + AKA_RAND_LEN, AKA_AUTN_LEN);
    return RV_OK;
}


/***************************************************************************************
* AppClientGetAkaRESorAUTS
* -------------------------------------------------------------------------------------
* General:  This function generates the AKA - RES value or the AUTS value:
*           In this sample code, we always set the AUTS parameter on the first time,
*           in order to indicate the server that the SQN is out of synchronization.
*           On the second time, we treat the SQN value as synchronized, and we
*           get the RES value.
*           For both RES and AUTS building, first actions are:
*           1. Get the nonce value from the authentication header.
*           2. Extract the RAND and AUTN values from the nonce value.
*
*           ->RES building  - Generate an authentication vector, and a RES value, using
*                             RAND and KEY.
*           NOTE:
*           MTF as a client doesn't create AUTS. AUTS reference is left here for convinience
*           only.
* Return Value: RvStatus.
* -------------------------------------------------------------------------------------
* Arguments:
* Input:  hAuthObj - Handle to the authentication object.
* Output: pRES     - The filled buffer of RES. "" is AUTS is supplied.
*         ppAUTS   - The AUTS value to set in the authentication-object
**************************************************************************************/
static RvStatus AppClientGetAkaRESorAUTS(IN  RvSipAuthObjHandle hAuthObj,
                                         OUT RvUint8           *pRES,
                                         OUT RvUint8          **ppAUTS,
										 IN  RvCCTerminalSip   *sipTerm)
{
    RvStatus rv;
    RvSipAuthenticationHeaderHandle hAuthHeader;
    RvBool  bValid;
    RvUint8 givenRAND[AKA_RAND_LEN+1]; /* +1 for null termination */
    RvUint8 givenAUTN[AKA_AUTN_LEN+1]; /* +1 for null termination */
    RvBool  bCorrectMacInAutn;
    RvUint8 Key[USER_KEY_LEN];
	RvChar  password[RV_NAME_STR_SZ];
	RvUint8 givenNonce[RV_NAME_STR_SZ];
	unsigned int len;

	RV_UNUSED_ARG(ppAUTS);

    /* Get the authentication header from the auth-object
       -------------------------------------------------- */
    rv = RvSipAuthObjGetAuthenticationHeader(hAuthObj, &hAuthHeader, &bValid);
    if(rv != RV_OK || RV_FALSE == bValid)
    {
        RvLogError(ippLogSource,(ippLogSource,"AppClientGetAkaRESorAUTS:: Failed to get authentication header from authObj 0x%p bValid=%d", hAuthObj, bValid));
        return RV_ERROR_NOT_FOUND;
    }

    /* Verify that server asked for AKA-MD5 authentication algorithm
       ------------------------------------------------------------- */
    if(RvSipAuthenticationHeaderGetAKAVersion(hAuthHeader) == UNDEFINED)
    {
        RvLogError(ippLogSource,(ippLogSource,"AppClientGetAkaRESorAUTS:: Server did not ask for AKA authentication - not supported."));
        return RV_ERROR_ILLEGAL_ACTION;
    }

	/* Get the nonce value from authentication header. */
    rv = RvSipAuthenticationHeaderGetNonce(hAuthHeader, (RvChar*)givenNonce,
		sizeof(givenNonce), (RvUint*)&len);
    if(rv != RV_OK)
    {
        RvLogError(ippLogSource,(ippLogSource,"AppClientGetAkaRESorAUTS(): no nonce in auth header"));
        return RV_ERROR_NOT_FOUND;
    }


		/* Extract the RAND and AUTN values from the header nonce value.
		   ------------------------------------------------------------- */
		memset(givenAUTN, 0, sizeof(givenAUTN));
		memset(givenRAND, 0, sizeof(givenRAND));

	rv = GetRandAndAutnFromHeader(hAuthHeader, givenRAND, givenAUTN);

		/* Convert the saved password to Key (16 bytes buffer)
		   --------------------------------------------------- */
		memset (Key, 0, USER_KEY_LEN);
		sprintf(password,"%s",rvCCTerminalSipGetPassword(sipTerm));
		memcpy((void*)Key, (void*)password, RvMin(strlen(password), USER_KEY_LEN));

		/* Generate the AUTS or RES values
		   ------------------------------- */

			AkaCreateClientRES(givenRAND, Key, givenAUTN, &sipTerm->imsTerminalSip.ClientAkaAV, &bCorrectMacInAutn);
			if(bCorrectMacInAutn == RV_FALSE)
			{
				RvLogError(ippLogSource,(ippLogSource,"AppClientGetAkaRESorAUTS:: mac is incorrect in authObj 0x%p", hAuthObj));
			}

	memcpy(pRES, sipTerm->imsTerminalSip.ClientAkaAV.XRES, AKA_RES_LEN);

	RvLogInfo(ippLogSource,(ippLogSource,"AppClientGetAkaRESorAUTS:: RES calculation completed for authObj 0x%p, nonce: %s",
		hAuthObj, givenNonce));

    return RV_OK;
}

#endif

