/******************************************************************************
Filename:    sipTls.c
Description: sip TLS support in IPP TK
*******************************************************************************
                Copyright (c) 2005 RADVISION Inc.
*******************************************************************************
NOTICE:
This document contains information that is proprietary to RADVISION LTD.
No part of this publication may be reproduced in any form whatsoever
without written prior approval by RADVISION LTD.

RADVISION LTD. reserves the right to revise this publication and make
changes without obligation to notify any person of such revisions or
changes.
******************************************************************************/
/******************************************************************************************
This file is used to support TLS in the IP Phone toolkit.
TLS is a security mechanism that operates on the Transport layer, on top of TCP transport.
By using TLS as a connection transport, a SIP entity can send and receive data in a secure
authenticated manner.
TLS, together with the commonly used Public Key Infrastructure certification distribution
mechanism achieves the following goals:
Guarantees the identity of a remote computer
Transmits messages to that remote computer in a secure encrypted manner.
TLS uses pairs of asymmetrical encryptions keys to guarantee the identity of a remote
computer. The public key of each remote computer is published in a certificate.

RFC 3261 defines the use of TLS as a transport mechanism by using the "sips:" scheme.
When using the "sips:" scheme in a URI-or any other header that indicates the next hop
of a message, such as Route, Via, and so on-RFC 3261 mandates the transport to be TLS.
(For this reason TLS will not guarantee a secure delivery end-to-end, but only to the
next hop).

******************************************************************************************/

/* TLS is used as an add on feature by using a compilation flag RV_CFLAG_TLS */
#include "rvtypes.h"

#ifdef RV_CFLAG_TLS
#define LOGSRC	LOGSRC_SIPCONTROL

#include <stdio.h>
#include <stdarg.h>
/* Please note: here we use openSSL functions to load certificates and keys to TLS engines.
This is the reason than we include openSSL h file. The location of openSSL include directory
and lib files should be predefined. Please also note that this application links with
openSSL lib files libeay32.lib and ssleay32.lib */
#if (RV_TLS_TYPE == RV_TLS_OPENSSL)
/* this code contains calls to openSSl */
#include <openssl/ssl.h>
#endif
#include "RvSipStackTypes.h"
#include "RvSipTransportTypes.h"
#include "RvSipTransport.h"
#include "RvSipMid.h"

#include "ipp_inc_std.h"
#include "sipphone.h"
#include "rvccconnsip.h"
#include "rvSipTlsApi.h"
#include "sipTls.h"


/*===============================================================================*/
/*=============== S I P		S T A C K		E X T E N S I O N S =================*/
/*===============================================================================*/
RvIppSipTlsExtClbks        sipTlsExtClbks;


/*-----------------------------------------------------------------------*/
/*                           DEFINITIONS                                 */
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
/*                        GLOBAL VARIABLES                               */
/*-----------------------------------------------------------------------*/
/*Handle to the client TLS engine. that engine will be loaded with a certificate
authority certificate and will be responsible to verify any incoming certificate */
static RvSipTransportTlsEngineHandle		g_hTlsEngine;
static RvUint16 ippStackTlsPort;

/*-----------------------------------------------------------------------*/
/*                        STATIC FUNCTIONS PROTOTYPES                    */
/*-----------------------------------------------------------------------*/
static void setStackTlsPort(RvUint16 stackTlsPort);



/*---- TLS E V E N T    H A N D L E R S   I M P L M E N T A T I O N ---------*/


/***************************************************************************
* AppTransportConnectionTlsStateChanged
* ------------------------------------------------------------------------
* General:  This callback is used by SIP stack to notify the IPPTK on TLS
*           connection state changes. This callback is called only for
*           TLS state changes and not for connection state changes.
* Return Value: RvStatus
* ------------------------------------------------------------------------
* Arguments:
* Input:   hLine  - The handle of the connection that changed TLS state
*          eState       - The connection state
*          eReason      - The reason for the state change
***************************************************************************/
RvStatus RVCALLCONV AppTransportConnectionTlsStateChanged(
								IN    RvSipTransportConnectionHandle             hLine,
								IN    RvSipTransportConnectionAppHandle       hAppConnection,
								IN    RvSipTransportConnectionTlsState              eState,
								IN    RvSipTransportConnectionStateChangedReason eReason)
{
    RvStatus rv   = RV_OK;
    RvBool bIsTcpClient = RV_TRUE;

   switch (eState)
    {
    case RVSIP_TRANSPORT_CONN_TLS_STATE_HANDSHAKE_READY:
        {
            RvLogInfo(ippLogSource,(ippLogSource, "connection %x - TLS State changed to handshake ready\n", (int)hLine));
            /* deciding what engine to use.
			1. for clients we use the client engine.
			2. for servers we use the server engine.
            */
            rv = RvSipTransportConnectionIsTcpClient(hLine,&bIsTcpClient);
            if(rv != RV_OK)
            {
                RvLogError(ippLogSource,(ippLogSource, "Failed to Discover side of connection"));
				rvCCConnSipNotifyError((RvCCConnection *)hAppConnection);
				return (rv);
            }
            if (RVSIP_TRANSPORT_CONN_REASON_CLIENT_CONNECTED == eReason)
            {
			/* Starting the handshake. Since this is the client we associate the client
				engine to the connection and specify the default verification call back*/
                rv = RvSipTransportConnectionTlsHandshake(hLine,
					g_hTlsEngine,
					RVSIP_TRANSPORT_TLS_HANDSHAKE_SIDE_DEFAULT,
					NULL);
            }
            else
            {
			/* Starting the handshake. Since this is the server we associate the server
			engine to the connection and do not specify a certificate verification call
			back. another option is to specify a call back and than client certificate
				will be required*/
                rv = RvSipTransportConnectionTlsHandshake(hLine,
					g_hTlsEngine,
					RVSIP_TRANSPORT_TLS_HANDSHAKE_SIDE_DEFAULT,
					NULL);
            }
       }
        break;
    case RVSIP_TRANSPORT_CONN_TLS_STATE_CONNECTED:
		RvLogInfo(ippLogSource,(ippLogSource, "connection %x - TLS State changed to TLS Connected\n", (int)hLine));
        break;
    case RVSIP_TRANSPORT_CONN_TLS_STATE_HANDSHAKE_FAILED:
		RvLogInfo(ippLogSource,(ippLogSource, "connection %x - TLS State changed to handshake failed\n", (int)hLine));
        break;
    case RVSIP_TRANSPORT_CONN_TLS_STATE_TERMINATED:
		RvLogInfo(ippLogSource,(ippLogSource, "connection %x - TLS State changed to terminated\n", (int)hLine));
        break;
    default:
        break;
    }

    return rv;
}


/***************************************************************************
* AppTransportConnectionTlsPostConnectionAssertionEv
* ------------------------------------------------------------------------
* General:  This callback is used to override the stack's default post connection
*           assertion. once a connection has completed the hand shake, it is
*           necessary to make sure that the certificate presented was indeed issued
*           for the address to which the connection was made. that assertion is
*           automaticly done by the stack, if for some reason, the application would
*           like to over ride this assertion it can implement this callback.
*           In this example we always override the stack's decision.
* Return Value: -
* ------------------------------------------------------------------------
* Arguments:
* Input:   hLine   - The handle of the connection that changed TLS state
*          hAppConnection - The application handle for the connection
*          strHostName   - A NULL terminated string, indicating the host name
*                          (IP/FQDN) that the connection was meant to connect to.
*          hMsg          - a message if the connection was asserted against a message.
* Output: pbAsserted     - Fill that boolean with the result of your assertion.
*                          RV_TRUE - indicated you asserted the connection, successfully.
*                          RV_FALSE - indicates the assertion failed. the connection
*                                     will be terminated automatically.
***************************************************************************/
void RVCALLCONV AppTransportConnectionTlsPostConnectionAssertionEv(IN    RvSipTransportConnectionHandle             hLine,
																   IN    RvSipTransportConnectionAppHandle          hAppConnection,
																   IN    RvChar*                                   strHostName,
																   IN    RvSipMsgHandle                             hMsg,
																   OUT   RvBool*                                   pbAsserted)
{
	/* call to RvIppSipTlsPostConnectionAssertionCB - located in rvSipControlApi.h/c (add to RvIppSipExtClbks) */
	if(sipTlsExtClbks.tlsPostConnectionAssertF != NULL)
	{
		sipTlsExtClbks.tlsPostConnectionAssertF(hLine,hAppConnection,strHostName,hMsg,pbAsserted);
	}
	else /* default behavior */
	{
		*pbAsserted = RV_TRUE;
	}
}


/***************************************************************************
 * rvIppTlsStackConfigValidate
 * ------------------------------------------------------------------------
 * General: This function gets pointer to the stack configuration and makes
 *			validations on the tls parameters configured.
 *			If it is successfully validate, returns RV_OK.
 *			The sip stack parameter numOfTlsEngines is blocked to the user,
 *			meaning, that for now, the IPPTK will handle one engine and ignore
 *			any other number configured by the user.
 *			In addition, the parameter tcpEnabled is also blocked since it
 *			must be set to RV_TRUE.
 *			No need to make parameters validation, because of the fact that the
 *			sip stack already makes validation, and in case error, the return
 *			code will be not equal to RV_OK.
 *
 * Return Value:
 *			RV_OK				- on successful operation
 *			RV_ERROR_UNKNOWN	- on error
 * ------------------------------------------------------------------------
 *  Arguments:
 *  Input:         pStackCfgOld - IPP TK default configuration
 *				   pStackCfgNew - User configuration
 *
 *  Output:        pStackCfgOld - will include user values for allowed parameters
 *				                  and default values for blocked parameters.
***************************************************************************/
RvStatus rvIppTlsStackConfigValidate(RvSipStackCfg *pStackCfgOld, RvSipStackCfg *pStackCfgNew)
{
	if(pStackCfgOld->numOfTlsAddresses != pStackCfgNew->numOfTlsAddresses)
	{
		RvUint16 index = 0;
		RvLogInfo(ippLogSource,(ippLogSource,"rvIppTlsStackConfigValidate - numOfTlsAddresses = %d",pStackCfgNew->numOfTlsAddresses));

		for(index = 0; index < pStackCfgNew->numOfTlsAddresses; index++ )
		{
			RvLogInfo(ippLogSource,(ippLogSource,"rvIppTlsStackConfigValidate - TLS Address[%d] = %s",index,pStackCfgNew->localTlsAddresses[index]));
			RvLogInfo(ippLogSource,(ippLogSource,"rvIppTlsStackConfigValidate - TLS Port[%d] = %d",index,pStackCfgNew->localTlsPorts[index]));
		}
		pStackCfgOld->numOfTlsAddresses		= pStackCfgNew->numOfTlsAddresses;
		pStackCfgOld->localTlsAddresses		= pStackCfgNew->localTlsAddresses;
		pStackCfgOld->localTlsPorts			= pStackCfgNew->localTlsPorts;
	}

	if (pStackCfgOld->numOfTlsEngines != pStackCfgNew->numOfTlsEngines)
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvIppTlsStackConfigValidate - numOfTlsEngines = %d",pStackCfgNew->numOfTlsEngines));
		/* Meanwhile, this feature support only one engine as client */
		if (pStackCfgNew->numOfTlsEngines != 1)
		{
			RvLogInfo(ippLogSource,(ippLogSource,"rvIppTlsStackConfigValidate - Set numOfTlsEngines to be 1"));
		}
		pStackCfgOld->numOfTlsEngines = 1;
	}

	if (pStackCfgOld->maxTlsSessions != pStackCfgNew->maxTlsSessions)
	{
		RvLogInfo(ippLogSource,(ippLogSource,"rvIppTlsStackConfigValidate - maxTlsSessions = %d",pStackCfgNew->maxTlsSessions));
		pStackCfgOld->maxTlsSessions = pStackCfgNew->maxTlsSessions;
	}
	return (RV_OK);
}


/***************************************************************************
 * sipStackTlsConfigInit
 * ------------------------------------------------------------------------
 * General: Initialize SIP Stack configuration TLS parameters.
 *          These parameters are set by application.
 *          Application may reset these parameters by specifying
 *          SIPStackParameters:
 *					numOfTlsAddresses
 *					localTlsAddresses
 *					localTlsPorts
 *
 * Return Value:
 *			RV_OK
 * ------------------------------------------------------------------------
 *  Arguments:
 *  Input:         sipStackCfg - Pointer to Sip Stack configuration structure
 *				   stackHndl - Pointer to application's transport TLS Configuration
 *
 *  Output:        none
***************************************************************************/
RvStatus sipStackTlsConfigInit(RvSipStackCfg *sipStackCfg, RvIppTransportTlsCfg *transportTlsCfg)
{
    sipStackCfg->localTlsPorts = &transportTlsCfg->stackTlsPort;
    sipStackCfg->localTlsAddresses = &transportTlsCfg->stackTlsAddress;
	sipStackCfg->numOfTlsEngines = 1; /* Set to 1. Sip stack doesn't support more than 1 client */
	sipStackCfg->maxTlsSessions = 10; /* Default value */

	return RV_OK;
}

/***************************************************************************
 * rvIppTlsInit
 * ------------------------------------------------------------------------
 * General: This function initializes the Tls security. In this function we
 *			use openSSL to load the certificates and key, therefore, the files
 *			are built in a format openSSL recognizes.
 *			Keys and certificates can be read with different function and than
 *			be passed to the engine configuration struct. Construct one TLS
 *			client engine.
 *			The client engine holds a certificate of a trusted entity
 *			(certificate authority).
 *
 * Return Value:
 *			RV_OK				- on successful operation
 *			RV_ERROR_UNKNOWN	- on error
 * ------------------------------------------------------------------------
 *  Arguments:
 *  Input:         pStackCfg - IPP TK configuration
 *				   stackHndl - Pointer to sip stack handle
 *
 *  Output:        None
***************************************************************************/
RvStatus rvIppTlsInit(RvIppTransportTlsCfg *ippTlsCfg, RvSipStackHandle	stackHndl)
{
    RvSipTransportTlsEngineCfg		TlsEngineCfg;
    RvChar							privKey[TLS_STRING_SIZE];
    RvUint32						privKeyLen      = 0;
    RvChar							cert[TLS_STRING_SIZE];
    RvUint32						certLen         = 0;
	RvSipTransportMgrHandle			hTransportMgr;
	RvInt32							cntCA=0;         /* CA counter*/
	RvStatus						rv = RV_OK;
	RvBool                          response = RV_TRUE;

	/* When privateKeyType = RVSIP_TRANSPORT_PRIVATE_KEY_TYPE_UNDEFINED (defined in the configuration file)
	   it means that the user doesn't want to use a private key.
       A private key is required when working in a mutual authentication mode where both client
	   and server require a private key.
	   When the MTF needs to communicate with a server in a non-mutual authentication manner,
	   the private key will not be loaded to the TLS engine thus not used. 
	   Note that not using a private key is possible when communicating with a server that
	   supports a non-mutual authentication mode. The MTF itself cannot work as server in non-mutual 
	   mode. This means that when running MTF application with MTF application (and TLS is enabled) 
	   a private key sould be used in both sides otherwise calls functionality cannot run properly.
	   If only one of the MTFs uses a private key, the one that doesn't can only be a client 
	   i.e. be the initiator of SIP requests. TLS connection attempts by the other side will fail. */     
	
	RvBool                          usePrivateKey = (ippTlsCfg->privateKeyType != RVSIP_TRANSPORT_PRIVATE_KEY_TYPE_UNDEFINED);
	
	if (sipTlsExtClbks.tlsGetBufferF == NULL)
	{
		RvLogError(ippLogSource,(ippLogSource,  "rvIppTlsInit: sipTlsExtClbks.tlsGetBufferF is not registered."));
		return(RV_ERROR_UNKNOWN);
	}
	
	/* First - set a TLS port */
	setStackTlsPort(ippTlsCfg->stackTlsPort);
	
	/* ask the user to get a private key */
	if (usePrivateKey == RV_TRUE)
	{
		response = sipTlsExtClbks.tlsGetBufferF(IPP_TLS_SERVER_KEY_BUFFER, (char *)privKey, &privKeyLen);
		
		if (response == RV_TRUE)
		{			
		   /* Here, like in the previous call to tlsGetBufferF (the one above), the file which is actually
		      read is the private key file */
			response = sipTlsExtClbks.tlsGetBufferF(IPP_TLS_SERVER_CA_BUFFER, (char *)cert, &certLen);
		}
	}
	
	if (response == RV_FALSE)
	{
		/* if fail we don't want to use tls address */
		ippTlsCfg->stackNumOfTlsAddresses = 0;
		return(RV_ERROR_UNKNOWN);
	}

    TlsEngineCfg.eTlsMethod         = ippTlsCfg->tlsMethod;
    TlsEngineCfg.strCert            = cert;
    TlsEngineCfg.certLen            = certLen;
    TlsEngineCfg.strPrivateKey      = (usePrivateKey ? privKey: NULL);
    TlsEngineCfg.privateKeyLen      = privKeyLen;
    TlsEngineCfg.ePrivateKeyType    = ippTlsCfg->privateKeyType;
    TlsEngineCfg.certDepth          = ippTlsCfg->certDepth;

	RvSipStackGetTransportMgrHandle(stackHndl, &hTransportMgr);

	rv = RvSipTransportTlsEngineConstruct(hTransportMgr,
			&TlsEngineCfg,
			sizeof(TlsEngineCfg),
			&g_hTlsEngine);

	if (RV_OK != rv)
    {
        RvLogError(ippLogSource,(ippLogSource,  "failed to construct TLS client engine"));
		return(RV_ERROR_UNKNOWN);
    }

	/* checking that key and cert match */
	if (usePrivateKey == RV_TRUE)
	{
		rv = RvSipTransportTlsEngineCheckPrivateKey(hTransportMgr,g_hTlsEngine);
		if (RV_OK != rv)
		{
			RvLogError(ippLogSource,(ippLogSource,  "RvSipTransportTlsEngineCheckPrivateKey() in rvIppTlsInit():\n***key and cert don't match***\n***don't expect TLS tests to work :)***\n  (rv=%d)\n",rv));
			return(RV_ERROR_UNKNOWN);
		}
	}

	/* Get certifications list in loop until cert is not NULL */
	while (sipTlsExtClbks.tlsGetBufferF(IPP_TLS_CA_BUFFER, (char *)cert, &certLen) == RV_TRUE)
	{
		/* Adding a trusted certificate to the engine.
		This should be the CA that signed the certificate for the server engine */
		rv = RvSipTransportTlsEngineAddTrustedCA(hTransportMgr,
				g_hTlsEngine,
				cert,
				certLen);

		if (RV_OK == rv)
		{
			++cntCA;
		}
	}

	if (cntCA == 0)
	{
		RvLogError(ippLogSource,(ippLogSource,  "Can not add CA certificate to the client engine"));
		return(RV_ERROR_UNKNOWN);
	}
	else
		return (RV_OK);
}

/***************************************************************************
 * rvIppTLSSetCallBackFunctions
 * ------------------------------------------------------------------------
 * General: This function sets IPP TLS call back functions in the transport manager.
 *
 * Return Value:
 *			RV_OK				- on successful operation
 *			RV_ERROR_UNKNOWN	- on error
 * ------------------------------------------------------------------------
 *  Arguments:
 *  Input:         hTransportMgr          - handle to the Transport Manager.
 *                 sipTransportEvHandlers - hanlde to the Callbacks
 *  Output:        None
**************************************************************************/
RvStatus rvIppTLSSetCallBackFunctions(RvSipTransportMgrHandle	hTransportMgr,
                                  RvSipTransportMgrEvHandlers*	sipTransportEvHandlers)

{
	RvStatus rv;

	sipTransportEvHandlers->pfnEvTlsStateChanged = AppTransportConnectionTlsStateChanged;
	sipTransportEvHandlers->pfnEvTlsPostConnectionAssertion =
						AppTransportConnectionTlsPostConnectionAssertionEv;

	rv = RvSipTransportMgrSetEvHandlers( hTransportMgr,
		                                (RvSipAppTransportMgrHandle)hTransportMgr,
		                                 sipTransportEvHandlers,
		                                 sizeof(RvSipTransportMgrEvHandlers));		                 
	return rv;

}

/***************************************************************************
 * rvIppTlsGetPort
 * ------------------------------------------------------------------------
 * General: get a port to be used by IPP-TK on TLS transaction
 * Parameters: none
 * Return: the port to be used by IPP-TK on TLS transaction
 ***************************************************************************/
RvUint16 rvIppTlsGetPort(void)
{
	return ippStackTlsPort;
}


/***************************************************************************
 * setStackTlsPort
 * ------------------------------------------------------------------------
 * General: Set a port to be used by IPP-TK on TLS transaction
 * Parameters:
 *		IN  - stackTlsPort - port to be used by IPP-TK on TLS transaction
 *		Out - none
 ***************************************************************************/
static void setStackTlsPort(RvUint16 stackTlsPort)
{
	ippStackTlsPort = stackTlsPort;
}


#endif /* RV_CFLAG_TLS */
